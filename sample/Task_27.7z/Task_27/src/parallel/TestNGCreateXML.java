package parallel;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.filefilter.RegexFileFilter;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.w3c.dom.Document;

import org.w3c.dom.Element;

import utils.Constants;
import utils.ReadExcel;

/**
 * 
 * <h1>TestNGCreateXML</h1>
 * 
 * <p>
 * <b>Note: Used to Create all TestNG XML files</b> 
 * 
 * @author Lakshman A
 * @since OCT 1, 2016
 *
 */

public class TestNGCreateXML {

	private static Logger log = Logger.getLogger(TestNGCreateXML.class.getName());
	private static Properties sysProperty;
	static ArrayList<String> alltestNGFiles= new ArrayList<>();
	static int configuredSplitCount=0;

	public static void main(String[] args) throws IOException {
		String testBatchFileName=null;
		
		try {
			//Instantiate the Property file
			sysProperty =new Properties();
			sysProperty.load(new FileInputStream(new File("./src/properties/SystemConfig.properties")));
			
			//Instantiate the Log file
			String log4jConfPath = sysProperty.getProperty("log4jConfPath");
			PropertyConfigurator.configure(log4jConfPath);

			//Get the TestCase split count per testng file from the Property file
			configuredSplitCount=Integer.parseInt(sysProperty.getProperty("testCaseSplitCount"));

			//Create an object for this class for calling all the methods
			TestNGCreateXML run = new TestNGCreateXML();
			
			//At first, create the testNG config file to set Pre conditions using TestBatch_Config xls
			run.createXMLForConfigScripts();

			String testBatchFilePath=sysProperty.getProperty("testBatchFilePath");
			String testBatchExtension=".xls";

			//Retrieve the folder path of the Test Batch Spreadsheets
			File testBatchFolder = new File(testBatchFilePath);

			//Retrieve all the TestBatch Spreadsheets from the TestBatch folder
			String regexpattern = "^Test_Batch_(\\d+)\\.xls";
			FileFilter filter = new RegexFileFilter(regexpattern);
			File[] testBatchFiles = testBatchFolder.listFiles(filter);

			//Function ArraySort to Sort the TestBatch file names in Numerical Order.
			Arrays.sort(testBatchFiles, new Comparator<File>() {
				@Override
				public int compare(File o1, File o2) {
					int n1 = extractNumber(o1.getName());
					int n2 = extractNumber(o2.getName());
					return n1 - n2;
				}
				private int extractNumber(String name) {
					int i = 0;
					try {
						int s = name.indexOf('_')+7;
						int e = name.lastIndexOf('.');
						String number = name.substring(s, e);
						i = Integer.parseInt(number);
					} catch(Exception e) {
						i = 0; 
					}
					return i;
				}
			}	);

			//Looping through all the Batch sheets in the TestBatch folder
			for (int testBatchPointer = 0; testBatchPointer < testBatchFiles.length; testBatchPointer++) {   

				String fileName = testBatchFiles[testBatchPointer].getName();

				int index = fileName.lastIndexOf('.');
				if (index == -1) {
					//log.info("Do nothing");
				} else {
					testBatchFileName= fileName.substring(0, index);
				}
				
				//Create the TestNG files based on Parallel and Serial Batch
				run.createXMLForParallelScripts(testBatchFilePath,testBatchFileName,testBatchExtension);
				run.createXMLForSerialScripts(testBatchFilePath,testBatchFileName,testBatchExtension);
			}

			
			
			
			
			
			
			
			//Finally create the TestNG file where the execution starts
			run.createTestNGXML();
		
		} catch (Exception e) {
			log.info("Exception occured in TestNGCreateXML. Exception is "+e);
			e.printStackTrace();
		}

	}

	public void createXMLForConfigScripts() throws IOException {

		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.newDocument();
			Element rootElement = doc.createElement("suite");
			rootElement.setAttribute("name", sysProperty.getProperty("XML_Suite_Name_For_Config"));
			rootElement.setAttribute("parallel", "tests");
			rootElement.setAttribute("thread-count", sysProperty.getProperty("No_of_Instances"));
			
			Element parameterIsName = doc.createElement("parameter");
			parameterIsName.setAttribute("name", "suiteType");
			parameterIsName.setAttribute("value", sysProperty.getProperty("ParallelSuiteType"));
			rootElement.appendChild(parameterIsName);
			doc.appendChild(rootElement);

			ReadExcel suiteXL = new ReadExcel(sysProperty.getProperty("testBatchFilePath")+sysProperty.getProperty("testBatchConfigFileName")+".xls");
			boolean isAtleastOneCaseIsYes=false;
			
			int totalTestCaseCount = suiteXL.getRowCount(Constants.TestBatch_Sheet);
			for(int testCaseCounter=1; testCaseCounter <totalTestCaseCount+1; testCaseCounter++){

				String testCaseName = suiteXL.getCellData(Constants.TestBatch_Sheet, Constants.TestCase_ColName, testCaseCounter);
				String testCaseDesc = suiteXL.getCellData(Constants.TestBatch_Sheet, Constants.TestDescription_ColName, testCaseCounter);
				String testCategory=suiteXL.getCellData(Constants.TestBatch_Sheet, Constants.TestCategory_ColName, testCaseCounter);
				String testAuthor=suiteXL.getCellData(Constants.TestBatch_Sheet, Constants.TestAuthor_ColName, testCaseCounter);

				
				
				if(suiteXL.getCellData(Constants.TestBatch_Sheet, Constants.TestRun_ColName, testCaseCounter).equalsIgnoreCase(Constants.RUNMODE_YES)){
					String testDataExcelPath = sysProperty.getProperty("testDataFilePath")+testCaseName+".xls";
					
					boolean testCaseSheetExist=suiteXL.CheckTestCaseNamedSheetExist(testDataExcelPath,testCaseName);
					if(testCaseSheetExist){
						isAtleastOneCaseIsYes=true;
						try{
							Element test = doc.createElement("test");
							test.setAttribute("name", testCaseName);
							rootElement.appendChild(test);

							Element parameter = doc.createElement("parameter");
							parameter.setAttribute("name", "testcaseName");
							parameter.setAttribute("value", testCaseName);
							test.appendChild(parameter);

							Element parameter2 = doc.createElement("parameter");
							parameter2.setAttribute("name", "testcaseDesc");
							parameter2.setAttribute("value", testCaseDesc);
							test.appendChild(parameter2);

							Element parameter3 = doc.createElement("parameter");
							parameter3.setAttribute("name", "testCategory");
							parameter3.setAttribute("value", testCategory);
							test.appendChild(parameter3);

							Element parameter4 = doc.createElement("parameter");
							parameter4.setAttribute("name", "testAuthor");
							parameter4.setAttribute("value", testAuthor);
							test.appendChild(parameter4);

							Element parameter5 = doc.createElement("parameter");
							parameter5.setAttribute("name", "testdatasheet");
							parameter5.setAttribute("value", sysProperty.getProperty("testDataFilePath")+testCaseName+".xls");
							test.appendChild(parameter5);

							Element classes = doc.createElement("classes");
							test.appendChild(classes);
							Element singleClass = doc.createElement("class");
							singleClass.setAttribute("name", "wrappers.Components");
							classes.appendChild(singleClass);
							Element method = doc.createElement("methods");
							singleClass.appendChild(method);

							Element include = doc.createElement("include");
							include.setAttribute("name", "runComponents");
							method.appendChild(include);

						}catch(Exception e){
							log.error("TestCase Failed. Skip the TestCase.");
							e.printStackTrace();
						}

					}else{
						//Do Nothing
					}
				}else{
					//log.info("TestCase [ "+testCaseName+" ] Execution status in TestBatch is - NO. Skip the TestCase\n");
				}
			}
			
			if (isAtleastOneCaseIsYes) {
				TransformerFactory transformFactory = TransformerFactory.newInstance();
				Transformer transformer = transformFactory.newTransformer();
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				transformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "http://testng.org/testng-1.0.dtd");
				DOMSource source = new DOMSource(doc);
				String fileFullPath = sysProperty.getProperty("TestNG_XML_FilePath")
						+ sysProperty.getProperty("Config_TestNG_XML_FileName") + ".xml";
				StreamResult result = new StreamResult(new File(fileFullPath));
				alltestNGFiles.add(fileFullPath);
				transformer.transform(source, result);
				StreamResult consleresult = new StreamResult(System.out);
				transformer.transform(source, consleresult);
			}

		} catch (Exception e) {
			log.info("Problem with the TestBatch Sheet. Exception is : "+e);
			e.printStackTrace();
		}
	}
	
	public void createXMLForParallelScripts(String testBatchFilePath,String testBatchFileName, String testBatchExtension) throws IOException {

		try {
			ReadExcel suiteXL = new ReadExcel(testBatchFilePath+testBatchFileName+testBatchExtension);
			int totalTestCaseCount = suiteXL.getRowCount(Constants.TestBatch_Sheet);
			int totalBatchAfterSplit=totalTestCaseCount/configuredSplitCount;
			int testCaseCounter=1;

			for(int batchIterator=1;batchIterator<=totalBatchAfterSplit+1;batchIterator++){

				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.newDocument();
				Element rootElement = doc.createElement("suite");
				rootElement.setAttribute("name", sysProperty.getProperty("XML_Suite_Name_For_Parallel"));
				rootElement.setAttribute("parallel", "tests");
				rootElement.setAttribute("thread-count", sysProperty.getProperty("No_of_Instances"));

				Element parameterIsName = doc.createElement("parameter");
				parameterIsName.setAttribute("name", "suiteType");
				parameterIsName.setAttribute("value", sysProperty.getProperty("ParallelSuiteType"));
				rootElement.appendChild(parameterIsName);
				doc.appendChild(rootElement);

				int caseCountInXML=1;
				boolean isAtleastOneCaseIsYes=false;

				for(; (testCaseCounter <totalTestCaseCount+1) &&(caseCountInXML<=configuredSplitCount); testCaseCounter++){

					String testCaseName = suiteXL.getCellData(Constants.TestBatch_Sheet, Constants.TestCase_ColName, testCaseCounter);
					String testCaseDesc = suiteXL.getCellData(Constants.TestBatch_Sheet, Constants.TestDescription_ColName, testCaseCounter);
					String testCategory=suiteXL.getCellData(Constants.TestBatch_Sheet, Constants.TestCategory_ColName, testCaseCounter);
					String testAuthor=suiteXL.getCellData(Constants.TestBatch_Sheet, Constants.TestAuthor_ColName, testCaseCounter);

					if(suiteXL.getCellData(Constants.TestBatch_Sheet, Constants.TestRun_ColName, testCaseCounter).equalsIgnoreCase(Constants.RUNMODE_YES)){
						String testDataExcelPath = sysProperty.getProperty("testDataFilePath")+testCaseName+".xls";
						isAtleastOneCaseIsYes=true;

						boolean testCaseSheetExist=suiteXL.CheckTestCaseNamedSheetExist(testDataExcelPath,testCaseName);
						if(testCaseSheetExist){
							try{
								Element test = doc.createElement("test");
								test.setAttribute("name", testCaseName);
								rootElement.appendChild(test);

								Element parameter = doc.createElement("parameter");
								parameter.setAttribute("name", "testcaseName");
								parameter.setAttribute("value", testCaseName);
								test.appendChild(parameter);

								Element parameter2 = doc.createElement("parameter");
								parameter2.setAttribute("name", "testcaseDesc");
								parameter2.setAttribute("value", testCaseDesc);
								test.appendChild(parameter2);

								Element parameter3 = doc.createElement("parameter");
								parameter3.setAttribute("name", "testCategory");
								parameter3.setAttribute("value", testCategory);
								test.appendChild(parameter3);

								Element parameter4 = doc.createElement("parameter");
								parameter4.setAttribute("name", "testAuthor");
								parameter4.setAttribute("value", testAuthor);
								test.appendChild(parameter4);

								Element parameter5 = doc.createElement("parameter");
								parameter5.setAttribute("name", "testdatasheet");
								parameter5.setAttribute("value", sysProperty.getProperty("testDataFilePath")+testCaseName+".xls");
								test.appendChild(parameter5);

								Element classes = doc.createElement("classes");
								test.appendChild(classes);
								Element singleClass = doc.createElement("class");
								singleClass.setAttribute("name", "wrappers.Components");
								classes.appendChild(singleClass);
								Element method = doc.createElement("methods");
								singleClass.appendChild(method);

								Element include = doc.createElement("include");
								include.setAttribute("name", "runComponents");
								method.appendChild(include);

							}catch(Exception e){
								log.error("TestCase Failed. Skip the TestCase.");
								e.printStackTrace();
							}

						}else{
							//Do Nothing
						}
					}else{
						//log.info("TestCase [ "+testCaseName+" ] Execution status in TestBatch is - NO. Skip the TestCase\n");

					}
					caseCountInXML++;
				}

				if (isAtleastOneCaseIsYes) {
					TransformerFactory transformFactory = TransformerFactory.newInstance();
					Transformer transformer = transformFactory.newTransformer();
					transformer.setOutputProperty(OutputKeys.INDENT, "yes");
					transformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "http://testng.org/testng-1.0.dtd");
					DOMSource source = new DOMSource(doc);

					String fileFullPath=sysProperty.getProperty("TestNG_XML_FilePath")+ testBatchFileName+  "_" +sysProperty.getProperty("Parallel_TestNG_XML_FileName")+ "_" +batchIterator+".xml";
					StreamResult result = new StreamResult(new File(fileFullPath));
					alltestNGFiles.add(fileFullPath);

					transformer.transform(source, result);
					StreamResult consleresult = new StreamResult(System.out);
					transformer.transform(source, consleresult);
				}
			}

		} catch (Exception e) {
			log.info("Problem with the TestBatch Sheet. Exception is : "+e);
			e.printStackTrace();
		}
	}

	public void createXMLForSerialScripts(String testBatchFilePath,String testBatchFileName, String testBatchExtension) throws IOException {

		try {
			ReadExcel suiteSerialXL = new ReadExcel(testBatchFilePath+testBatchFileName+testBatchExtension);
			int totalTestCaseCount = suiteSerialXL.getRowCount(Constants.TestBatch_Sheet_Serial);
			int totalBatchAfterSplit=totalTestCaseCount/configuredSplitCount;
			int testCaseCounter=1;

			for(int batchIterator=1;batchIterator<=totalBatchAfterSplit+1;batchIterator++){

				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.newDocument();
				Element rootElement = doc.createElement("suite");
				rootElement.setAttribute("name", sysProperty.getProperty("XML_Suite_Name_For_Serial"));
				rootElement.setAttribute("parallel", "tests");
				rootElement.setAttribute("thread-count", sysProperty.getProperty("No_of_Instances_Serial"));

				Element parameterIsName = doc.createElement("parameter");
				parameterIsName.setAttribute("name", "suiteType");
				parameterIsName.setAttribute("value", sysProperty.getProperty("SerialSuiteType"));
				rootElement.appendChild(parameterIsName);
				doc.appendChild(rootElement);

				int caseCountInXML=1;
				boolean isAtleastOneCaseIsYes=false;

				for(; (testCaseCounter <totalTestCaseCount+1) &&(caseCountInXML<=configuredSplitCount); testCaseCounter++){

					String testCaseName = suiteSerialXL.getCellData(Constants.TestBatch_Sheet_Serial, Constants.TestCase_ColName, testCaseCounter);
					String testCaseDesc = suiteSerialXL.getCellData(Constants.TestBatch_Sheet_Serial, Constants.TestDescription_ColName, testCaseCounter);
					String testCategory=suiteSerialXL.getCellData(Constants.TestBatch_Sheet_Serial, Constants.TestCategory_ColName, testCaseCounter);
					String testAuthor=suiteSerialXL.getCellData(Constants.TestBatch_Sheet_Serial, Constants.TestAuthor_ColName, testCaseCounter);

					if(suiteSerialXL.getCellData(Constants.TestBatch_Sheet_Serial, Constants.TestRun_ColName, testCaseCounter).equalsIgnoreCase(Constants.RUNMODE_YES)){
						String testDataExcelPath = sysProperty.getProperty("testDataFilePath")+testCaseName+".xls";

						isAtleastOneCaseIsYes=true;
						boolean testCaseSheetExist=suiteSerialXL.CheckTestCaseNamedSheetExist(testDataExcelPath,testCaseName);

						if(testCaseSheetExist){
							try{
								Element test = doc.createElement("test");
								test.setAttribute("name", testCaseName);
								rootElement.appendChild(test);

								Element parameter = doc.createElement("parameter");
								parameter.setAttribute("name", "testcaseName");
								parameter.setAttribute("value", testCaseName);
								test.appendChild(parameter);

								Element parameter2 = doc.createElement("parameter");
								parameter2.setAttribute("name", "testcaseDesc");
								parameter2.setAttribute("value", testCaseDesc);
								test.appendChild(parameter2);

								Element parameter3 = doc.createElement("parameter");
								parameter3.setAttribute("name", "testCategory");
								parameter3.setAttribute("value", testCategory);
								test.appendChild(parameter3);

								Element parameter4 = doc.createElement("parameter");
								parameter4.setAttribute("name", "testAuthor");
								parameter4.setAttribute("value", testAuthor);
								test.appendChild(parameter4);

								Element parameter5 = doc.createElement("parameter");
								parameter5.setAttribute("name", "testdatasheet");
								parameter5.setAttribute("value", sysProperty.getProperty("testDataFilePath")+testCaseName+".xls");
								test.appendChild(parameter5);

								Element classes = doc.createElement("classes");
								test.appendChild(classes);
								Element singleClass = doc.createElement("class");
								singleClass.setAttribute("name", "wrappers.Components");
								classes.appendChild(singleClass);
								Element method = doc.createElement("methods");
								singleClass.appendChild(method);

								Element include = doc.createElement("include");
								include.setAttribute("name", "runComponents");
								method.appendChild(include);

							}catch(Exception e){
								log.error("TestCase Failed. Skip the TestCase.");
								e.printStackTrace();
							}

						}else{
							//Do Nothing
						}
					}else{
						//log.info("TestCase [ "+testCaseName+" ] Execution status in TestBatch is - NO. Skip the TestCase\n");

					}
					caseCountInXML++;
				}

				if (isAtleastOneCaseIsYes) {
					TransformerFactory transformFactory = TransformerFactory.newInstance();
					Transformer transformer = transformFactory.newTransformer();
					transformer.setOutputProperty(OutputKeys.INDENT, "yes");
					transformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "http://testng.org/testng-1.0.dtd");
					DOMSource source = new DOMSource(doc);
					String fileFullPath=sysProperty.getProperty("TestNG_XML_FilePath")+   testBatchFileName+ "_"+ sysProperty.getProperty("Serial_TestNG_XML_FileName") + "_" +batchIterator+".xml";
					StreamResult result = new StreamResult(new File(fileFullPath));
					alltestNGFiles.add(fileFullPath);
					transformer.transform(source, result);
					StreamResult consleresult = new StreamResult(System.out);
					transformer.transform(source, consleresult);
				}
			}

		} catch (Exception e) {
			log.info("Problem with the TestBatch Sheet. Exception is : "+e);
			e.printStackTrace();
		}
	}

	
	public void createTestNGXML() throws IOException {

		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.newDocument();
			Element rootElement = doc.createElement("suite");
			rootElement.setAttribute("name", sysProperty.getProperty("XML_Suite_Name_For_Project"));
			doc.appendChild(rootElement);
			log.info("TestNG file Creation Starts...\n");

			try{
				Element suite = doc.createElement("suite-files");
				rootElement.appendChild(suite);
		
				for (String testNGFile : alltestNGFiles) {
					Element parallelSuite = doc.createElement("suite-file");
					parallelSuite.setAttribute("path", testNGFile);
					suite.appendChild(parallelSuite);
				}

			}catch(Exception e){
				log.error("TestCase Failed. Skip the TestCase.");
				e.printStackTrace();
			}

			TransformerFactory transformFactory =  TransformerFactory.newInstance();
			Transformer transformer = transformFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "http://testng.org/testng-1.0.dtd");
			DOMSource source = new DOMSource(doc);
			String fileFullPath=sysProperty.getProperty("Main_TestNG_XML_FilePath")+ sysProperty.getProperty("Common_TestNG_XML_FileName")+".xml";
			StreamResult result = new StreamResult(new File(fileFullPath));
			transformer.transform(source, result);
			StreamResult consleresult = new StreamResult(System.out);
			transformer.transform(source, consleresult);
			log.info("TestNG file Generated Successfully");

		} catch (Exception e) {
			log.info("Exception occured while creating the XML file : "+e);
			e.printStackTrace();
		}
	}

}
