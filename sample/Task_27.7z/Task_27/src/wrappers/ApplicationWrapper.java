package wrappers;


import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;


import report.ExtentTestManager;
import utils.ScriptDetails;

/**
 * 
 * <h1>ApplicationWrapper</h1>
 * 
 * <p>
 * <b>Class holds all the TestNG Annotation for Creating Report</b> 
 * 
 * @author Lakshman A
 * @since OCT 1, 2016
 *
 */

public class ApplicationWrapper extends FunctionLibrary {

	public static int fileCount;
	public static String  reportFileName;
	static Set<Integer> set;
	static CountDownLatch latch;
	static CountDownLatch afterLatch;
	private static boolean calledMyMethod;

	public void killBrowserInTaskManager(){
		try {
			if (sysProperty.getProperty("killBrowser").equalsIgnoreCase("true")) {
				if (property.getProperty("testBrowser").equalsIgnoreCase("firefox")) {
					Runtime.getRuntime().exec("taskkill /F /IM firefox.exe");
				} else if (property.getProperty("testBrowser").equalsIgnoreCase("chrome")) {
					Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");
				} else if (property.getProperty("testBrowser").equalsIgnoreCase("ie")) {
					Runtime.getRuntime().exec("taskkill /F /IM iexplore.exe");
				}
				Thread.sleep(2000);
				log.info("Browser " + property.getProperty("testBrowser") + " killed successfully");
			}
		} catch (Exception e) {
			log.info("Exception while killBrowserInTaskManager. "+e);
			e.printStackTrace();
		}
	}

	public void killBrowserDriverInTaskManager(){
		try {
			if (property.getProperty("testBrowser").equalsIgnoreCase("firefox")) {
				Runtime.getRuntime().exec("taskkill /F /IM geckodriver.exe");
			} else if (property.getProperty("testBrowser").equalsIgnoreCase("chrome")) {
				Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
			} else if (property.getProperty("testBrowser").equalsIgnoreCase("ie")) {
				Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
			}
			Thread.sleep(2000);
			log.info("Browser Driver" + property.getProperty("testBrowser") + " killed successfully");

		} catch (Exception e) {
			log.info("Exception while killBrowserInTaskManager. "+e);
			e.printStackTrace();
		}
	}

	public void createReport(String suiteType) throws Exception{

		if(suiteType.trim().equalsIgnoreCase(sysProperty.getProperty("ParallelSuiteType"))){
			latch = new CountDownLatch(Integer.parseInt(sysProperty.getProperty("No_of_Instances")));
			afterLatch = new CountDownLatch(Integer.parseInt(sysProperty.getProperty("No_of_Instances")));
		}

		fileCount++;
		String datetime=new SimpleDateFormat ("_dd_MM_yyyy_hhmmss_a").format(new Date());
		reportFileName=sysProperty.getProperty("extentReportFileName")+datetime+"_"+fileCount+".html";
		ExtentTestManager.startReportWithFileName(fileCount,reportFileName);
		ExtentTestManager.addReportInfo("Selenium Version", "2.53.0");
	}

	@BeforeSuite(alwaysRun=true)
	@Parameters({"suiteType"})
	public void beforeSuite(String suiteType) throws Exception{
		initializeFiles();
		log.info("***** PARALLEL TESTBATCH EXECUTION STARTS... *****");		
		createReport(suiteType);
		killBrowserInTaskManager();
		killBrowserDriverInTaskManager();
	}

	@BeforeTest(alwaysRun=true)
	@Parameters({"testcaseName","testcaseDesc","testCategory","testAuthor","suiteType"})
	public void beforeTest(String testcaseName, String testcaseDesc, String testCategory, String testAuthor,String suiteType){
		try {
			if(suiteType.equalsIgnoreCase(sysProperty.getProperty("SerialSuiteType"))){
				killBrowserInTaskManager();
				killBrowserDriverInTaskManager();
			}
		} catch (Exception e) {
			log.info("Exception occured in beforeTest. "+e);
			e.printStackTrace();
		}
		ExtentTestManager.startTestCase(testcaseName, "<b>"+testcaseDesc+"</b>", testCategory, testAuthor);
	}

	@AfterTest(alwaysRun=true)
	@Parameters({"suiteType"})
	public void afterTest(String suiteType) throws Exception{

		ExtentTestManager.endTestCase();

		File file =new File("./"+sysProperty.getProperty("extentReportFilePath")+"/"+reportFileName);
		double reportFileSizeInBytes = file.length();
		double reportFileSizeInKB = (reportFileSizeInBytes / 1024);
		int fileSize=(int) reportFileSizeInKB;
		log.info("FileSize in KB : "+fileSize);

		if(fileSize > Integer.parseInt(sysProperty.getProperty("MaxReportFileSize"))){
			
			int ID=(int) Thread.currentThread().getId();
			log.info("Thread -> '"+ID+"' reached New report condition");

			if(suiteType.trim().equalsIgnoreCase(sysProperty.getProperty("ParallelSuiteType"))){
				Thread t = new Thread() {
					public void run() {
						//System.out.println("Thread '"+ID+"' Going to count down...");
						latch.countDown();
					}
				};
				t.start();
				log.info("Thread -> '"+ID+"' started waiting for other threads.");
				//latch.await();
				try {
					afterLatch.await(5,TimeUnit.MINUTES);
					log.info("Either All Threads reached here or Latch waited Long enough to Timeout!");
				} catch (InterruptedException e) {
					e.printStackTrace();
					log.info("InterruptedException in  Waited Long enough!");
				}
				//log.info("Thread '"+ID+"' Done waiting!");
			}

			createReportSynchronized(suiteType);

			if(suiteType.trim().equalsIgnoreCase(sysProperty.getProperty("ParallelSuiteType"))){
				Thread th = new Thread() {
					public void run() {
						//System.out.println("After Thread '"+ID+"' Going to count down...");
						afterLatch.countDown();
					}
				};
				th.start();
				log.info("After Process. Thread -> '"+ID+"' started waiting for other threads.");
				//afterLatch.await();
				try {
					afterLatch.await(20,TimeUnit.SECONDS);
					log.info("After Process. Either All Threads reached here or Latch waited Long enough to Timeout!");
				} catch (InterruptedException  e) {
					e.printStackTrace();
					log.info("InterruptedException in After Waited Long enough!");
				}
				//log.info("After Thread '"+ID+"' Done waiting!");
			}

			log.info("New Report name : "+reportFileName);
			log.info("*************************All Threads Released*******************");
			calledMyMethod=false;

		}else{
			log.info("New report condition not yet needed");
		}

	}

	@AfterSuite(alwaysRun=true)
	public void afterSuite(){
		killBrowserInTaskManager();
		killBrowserDriverInTaskManager();
		log.info("***** PARALLEL EXECUTION COMPLETED. *****");
		log.info("\n\n\n***** Generating the Overview Html Report *****");
		log.info("Note: Kindly check the Script details Tracker is placed in the Path, else it wont get Updated.");
		try{
			Thread.sleep(2000);
			ScriptDetails.generateExcelReports();
			log.info("***** Overview Html Report Generated & Script Details Tracker Updated *****");
		}catch(Exception e){
			log.info("Exception in afterSuite generateExcelReports. "+e);
			e.printStackTrace();
		}
	}

	public synchronized void createReportSynchronized(String suiteType) throws Exception{

		if(calledMyMethod) {
			return;
		} else {
			calledMyMethod = true;
			log.info("Synchronized Report Create Method. Thread Creating by Thread -> "+(int)Thread.currentThread().getId()+"");
			createReport(suiteType);
			killBrowserInTaskManager();
			killBrowserDriverInTaskManager();
			log.info("*** Report Created Successfully! ***");
		}     

	}

}
