package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class BrowserUpdate {

	@Test
	@Parameters({"browserName"})
	public void updateTestBrowserName(String browserName) {
		try {
			
			Properties property =new Properties();
			property.load(new FileInputStream(new File("./src/properties/Env.properties")));
		
			property.setProperty("testBrowser", browserName);
			
			FileOutputStream fileOut = new FileOutputStream(new File("./src/properties/Env.properties"));
			//property.store(fileOut, "Browser Update");
			property.save(fileOut, null);
			fileOut.close();
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	}

}
