package com.paypal.test.rule.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLConnection;
import java.nio.charset.Charset;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/download")
public class FileDownloadController {
	final static Logger log = Logger.getLogger(FileDownloadController.class);
	private static final String EXTERNAL_FILE_PATH = "C:\\Project\\LEARNING\\Rule-Process-Tool\\rule-process-tool\\rest-api\\spring-boot\\hybrid-automation\\test-output\\ExtentReports\\";

	@RequestMapping("/view/testReportFile/{reportName:.+}")
	public void showHtmlResource(HttpServletRequest request, HttpServletResponse response, @PathVariable("reportName") String fileName)
			throws IOException {

		File file = new File(EXTERNAL_FILE_PATH + fileName);
		if (file.exists()) {

			// get the mimetype
			String mimeType = URLConnection.guessContentTypeFromName(file.getName());
			if (mimeType == null) {
				// unknown mimetype so set the mimetype to application/octet-stream
				mimeType = "application/octet-stream";
			}

			response.setContentType(mimeType);

			/**
			 * In a regular HTTP response, the Content-Disposition response header is a header indicating if the content is expected to be displayed
			 * inline in the browser, that is, as a Web page or as part of a Web page, or as an attachment, that is downloaded and saved locally.
			 * 
			 */

			/**
			 * Here we have mentioned it to show inline
			 */
			response.setHeader("Content-Disposition", String.format("inline; reportName=\"" + file.getName() + "\""));

			// Here we have mentioned it to show as attachment
			// response.setHeader("Content-Disposition", String.format("attachment; filename=\"" + file.getName() + "\""));

			response.setContentLength((int) file.length());

			InputStream inputStream = new BufferedInputStream(new FileInputStream(file));

			FileCopyUtils.copy(inputStream, response.getOutputStream());

		} else {
			String errorMessage = "Oops! The HTML Report file you are looking for does not exist or has been archived.";
			log.info(errorMessage);
			OutputStream outputStream = response.getOutputStream();
			outputStream.write(errorMessage.getBytes(Charset.forName("UTF-8")));
			outputStream.close();
			return;
		}
	}

	@RequestMapping("/save/testReportFile/{reportName:.+}")
	public void downloadHtmlResource(HttpServletRequest request, HttpServletResponse response, @PathVariable("reportName") String fileName)
			throws IOException {

		File file = new File(EXTERNAL_FILE_PATH + fileName);
		if (file.exists()) {

			// get the mimetype
			String mimeType = URLConnection.guessContentTypeFromName(file.getName());
			if (mimeType == null) {
				// unknown mimetype so set the mimetype to application/octet-stream
				mimeType = "application/octet-stream";
			}

			response.setContentType("multipart/form-data");

			/**
			 * In a regular HTTP response, the Content-Disposition response header is a header indicating if the content is expected to be displayed
			 * inline in the browser, that is, as a Web page or as part of a Web page, or as an attachment, that is downloaded and saved locally.
			 * 
			 */

			/**
			 * Here we have mentioned it to show inline
			 */
			response.setHeader("Content-Disposition", String.format("inline; reportName=\"" + file.getName() + "\""));

			// Here we have mentioned it to show as attachment
			// response.setHeader("Content-Disposition", String.format("attachment; filename=\"" + file.getName() + "\""));

			response.setContentLength((int) file.length());

			InputStream inputStream = new BufferedInputStream(new FileInputStream(file));

			FileCopyUtils.copy(inputStream, response.getOutputStream());

		} else {
			String errorMessage = "Oops! The HTML Report file you are looking for does not exist or has been archived.";
			log.info(errorMessage);
			OutputStream outputStream = response.getOutputStream();
			outputStream.write(errorMessage.getBytes(Charset.forName("UTF-8")));
			outputStream.close();
			return;
		}
	}
}