package com.paypal.test.rule.helper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;

import org.apache.log4j.Logger;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;

public class LinuxCommandExecutor {
	final static Logger log = Logger.getLogger(LinuxCommandExecutor.class);

	public synchronized boolean checkConnectionJschSFTP(String stage, String user, String password) throws Exception {
		log.info("Method: checkConnectionJschSFTP. Params -stage,host,user,password");
		log.info("user: " + user);
		log.info("stage: " + stage);
		String host = stage.toLowerCase() + ".qa.paypal.com";
	
		boolean result = false;
		stage = stage.toUpperCase();
		Session session = null;
		try {
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			session = jsch.getSession(user, host, 22);
			session.setPassword(password);
			session.setConfig(config);
			try {
				session.connect();
				log.info("Connection Success to the mentioned STAGE! ");
				result = true;
			} catch (JSchException e) {
				log.error("Connection failed to the mentioned STAGE! " + e);
				e.printStackTrace();
				result = false;
			}

			session.disconnect();
		} catch (Exception e) {
			log.error("Exception occured while moving file to Linux STAGE. Exception is");
			e.printStackTrace();
			throw e;
		} finally {
			if (session != null) {
				session.disconnect();
			}

		}
		return result;
	}

	public synchronized void moveFolderFromLocalToStageByJschSFTP(String stage, String user, String password,
			String outJarName, String windowsPath, String linuxPath) throws Exception {
		log.info("Moving the post processed jar to the Linux Server with User credential");
		log.info("Method: moveFolderFromLocalToStageByJschSFTP. Params -stage,host,user,password,uploadedJar");
		log.info("stage: " + stage);
		String host = stage.toLowerCase() + ".qa.paypal.com";
		log.info("user: " + user);
		log.info("outJarName: " + outJarName);

		stage = stage.toUpperCase();
		String workingDirectoryInLinux = linuxPath;
		workingDirectoryInLinux = workingDirectoryInLinux.replace("$USER_STAGE$", stage.toUpperCase());
		String localWindowsPath = windowsPath;

		log.info("Linux Working directory: " + workingDirectoryInLinux);
		log.info("Local Win post processed Jar path with files: " + localWindowsPath);
		Session session = null;
		try {
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			session = jsch.getSession(user, host, 22);
			session.setPassword(password);
			session.setConfig(config);
			try {
				session.connect();
				log.info("Connection Success to the mentioned STAGE! ");
			} catch (JSchException e) {
				log.error("Connection failed to the mentioned STAGE! " + e);
				e.printStackTrace();
				throw e;
			}

			log.info("Deleting the RRDS file inside resdata... ");
			session = executeCommand(session, "cd ../../web/" + stage
					+ "/riskresolutiondecisionserv/config/res_data/; rm -rf riskresolutiondecisionserv");
			log.info("Deleted riskresolutiondecisionserv successfully. ");

			Channel channel = session.openChannel("sftp");
			channel.connect();
			ChannelSftp channelSftp = (ChannelSftp) channel;

			channelSftp.cd(workingDirectoryInLinux);
			try {
				channelSftp.mkdir("riskresolutiondecisionserv");
			} catch (Exception e) {
				log.info("Riskresolutiondecisionserv folder already Exist ");
				// e.printStackTrace();
			}
			channelSftp.cd("riskresolutiondecisionserv");
			recursiveFolderUpload(channelSftp, localWindowsPath, workingDirectoryInLinux);

			log.info("Giving full permission for the RRDS file... ");
			executeCommand(session, "cd ../../web/" + stage
					+ "/riskresolutiondecisionserv/config/res_data/; chmod -R 777 riskresolutiondecisionserv");
			log.info("Permission granted successfully!");

			channelSftp.disconnect();
			channel.disconnect();
			session.disconnect();
			log.info("File from Local Path : '" + localWindowsPath + "' is copied successfully to Linux Path : "
					+ workingDirectoryInLinux);
		} catch (Exception e) {
			log.error("Exception occured while moving file to Linux STAGE. Exception is");
			e.printStackTrace();
			throw e;
		} finally {
			if (session != null) {
				session.disconnect();
			}

		}
	}

	private void recursiveFolderUpload(ChannelSftp channelSftp, String sourcePath, String destinationPath)
			throws SftpException, FileNotFoundException {

		File sourceFile = new File(sourcePath);
		log.info("Copying file in Linux : " + sourceFile.getName());

		if (sourceFile.isFile()) {

			// copy if it is a file
			channelSftp.cd(destinationPath);
			if (!sourceFile.getName().startsWith("."))
				channelSftp.put(new FileInputStream(sourceFile), sourceFile.getName(), ChannelSftp.OVERWRITE);

		} else {

			// log.info("Inside else " + sourceFile.getName());
			File[] files = sourceFile.listFiles();

			if (files != null && !sourceFile.getName().startsWith(".")) {
				// log.info("Processing file : " + sourceFile.getName());

				channelSftp.cd(destinationPath);
				SftpATTRS attrs = null;

				// check if the directory is already existing
				try {
					attrs = channelSftp.stat(destinationPath + "/" + sourceFile.getName());
				} catch (Exception e) {
					// log.info(destinationPath + "/" + sourceFile.getName() + " not found");
				}

				// else create a directory
				if (attrs != null) {
					// log.info("Directory exists IsDir=" + attrs.isDir());
				} else {
					// log.info("Creating dir " + sourceFile.getName());
					channelSftp.mkdir(sourceFile.getName());
				}

				for (File f : files) {
					recursiveFolderUpload(channelSftp, f.getAbsolutePath(),
							destinationPath + "/" + sourceFile.getName());
				}

			}
		}

	}

	public void executeUnixCommand(String stage, String user, String password, List<String> cmd) throws Exception {
		log.info("Method: executeUnixCommand. Params -stage,host,user,password,cmd");
		log.info("stage: " + stage);
		String host = stage.toLowerCase() + ".qa.paypal.com";
		log.info("user: " + user);
		log.info("cmd " + cmd);

		Session session = null;
		try {
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			session = jsch.getSession(user, host, 22);
			session.setPassword(password);
			session.setConfig(config);
			try {
				session.connect();
				log.info("Connection Success to the mentioned STAGE! ");
			} catch (JSchException e) {
				log.error("Connection failed to the mentioned STAGE! " + e);
				e.printStackTrace();
				throw e;
			}

			log.info("Executing UNIX Command... ");

			for (String eachCmd : cmd) {
				Channel channel = session.openChannel("exec");
				((ChannelExec) channel).setCommand(eachCmd);
				channel.setInputStream(null);
				((ChannelExec) channel).setErrStream(System.err);

				InputStream in = channel.getInputStream();
				channel.connect();
				byte[] tmp = new byte[1024];
				String consolePrint = "";
				int status = -5;
				while (true) {
					while (in.available() > 0) {
						int i = in.read(tmp, 0, 1024);
						if (i < 0)
							break;
						consolePrint = consolePrint + new String(tmp, 0, i);
					}

					if (channel.isClosed()) {
						consolePrint = consolePrint + "exit-status: " + channel.getExitStatus();
						status = channel.getExitStatus();
						break;
					}
				}
				log.info("Console: " + consolePrint);
				channel.disconnect();
				if (status > 1) {
					log.error("Severe Error occured while executing the Command");
					throw new Exception("Severe Error occured while executing the Command");
				}
			}
			log.info("UNIX Command Executed successfully... ");
			session.disconnect();
		} catch (Exception e) {
			log.error("Exception occured while moving file to Linux STAGE. Exception is");
			e.printStackTrace();
			throw e;
		} finally {
			if (session != null) {
				session.disconnect();
			}

		}
		
	}
	
	public void linuxStartStopComponent(String stage, String user, String password, String action) throws Exception {
		log.info("Method: linuxStartStopComponent. Params -stage,host,user,password,uploadedJar");
		log.info("stage: " + stage);
		stage=stage.toUpperCase();
		String host = stage.toLowerCase() + ".qa.paypal.com";
		log.info("user: " + user);
		Session session=null;
		try {
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			session = jsch.getSession(user, host, 22);
			session.setPassword(password);
			session.setConfig(config);
			try {
				session.connect();
				log.info("Connection Success to the mentioned STAGE! ");
			} catch (JSchException e) {
				log.error("Connection failed to the mentioned STAGE! " + e);
				e.printStackTrace();
				throw e;
			}
			
			if(action.equalsIgnoreCase("start")) {
				log.info("Starting RRDS... ");
				session = executeCommand(session, "echo aardvark | /x/web/"+stage+"/riskresolutiondecisionserv/./start.sh");
				log.info("RRDS Start successful!");
			}else if (action.equalsIgnoreCase("stop") || action.equalsIgnoreCase("shutdown")) {
				log.info("Shutdown RRDS initiated... ");
				session = executeCommand(session, "cd ../../web/"+stage+"/riskresolutiondecisionserv; ./shutdown.sh");
				log.info("RRDS Shutdown successful! ");
			}
			
			session.disconnect();
		} catch (Exception e) {
			log.error("Exception occured while start or shutdown of component. Exception is");
			e.printStackTrace();
			throw e;
		}finally {
			if(session!=null) {
				session.disconnect();
			}
			
		}
	}

	private Session executeCommand(Session session, String command1) throws Exception {

		try {
			Channel channel = session.openChannel("exec");
			((ChannelExec) channel).setCommand(command1);
			channel.setInputStream(null);
			((ChannelExec) channel).setErrStream(System.err);

			InputStream in = channel.getInputStream();
			channel.connect();
			byte[] tmp = new byte[1024];
			String consolePrint = "";
			int status = -5;
			while (true) {
				while (in.available() > 0) {
					int i = in.read(tmp, 0, 1024);
					if (i < 0)
						break;
					consolePrint = consolePrint + new String(tmp, 0, i);
				}

				if (channel.isClosed()) {
					consolePrint = consolePrint + "exit-status: " + channel.getExitStatus();
					status = channel.getExitStatus();
					break;
				}
			}
			log.info("Console: " + consolePrint);
			channel.disconnect();
			if (status > 1 && status!=13) {
				log.error("Severe Error occured while executing the Command");
				throw new Exception("Severe Error occured while executing the Command");
			}
		} catch (Exception e) {
			log.error("Exception while executing the Linux command: " + e);
			e.printStackTrace();
			throw e;
		}

		return session;
	}

}
