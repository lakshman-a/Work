package com.paypal.test.rule.controller;

import java.util.List;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.paypal.test.rule.model.CommonProcessResponse;
import com.paypal.test.rule.model.PlutoDCVersionList;
import com.paypal.test.rule.model.PostProcessRequest;
import com.paypal.test.rule.model.PostProcessedJarList;
import com.paypal.test.rule.service.PlutoDCService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class PlutoDCController {
	final static Logger log = Logger.getLogger(PlutoDCController.class);
	PlutoDCService service = new PlutoDCService();

	// ------------- GET ALL ------------------//
	@RequestMapping(value = "/plutoDCList", method = RequestMethod.GET, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<PlutoDCVersionList>> getPlutoList() {
		log.info("Request to Service : PlutoDCController - plutoDcList");

		// Get Data from Service Layer
		List<PlutoDCVersionList> list;
		try {
			list = this.service.getPlutoDcListWithRboList();
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Check if any Exception, then throw 500
		if (Objects.isNull(list))
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		log.info("Response to Service : [ " + list + " ]");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	// ------------- GET List of Post Processed JAR ------------------//
	@RequestMapping(value = "/postProcessedJarList", method = RequestMethod.GET, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<PostProcessedJarList>> getPostProcessedJarList() {
		log.info("Request to Service : getPostProcessedJarList - plutoDcList");

		// Get Data from Service Layer
		List<PostProcessedJarList> list;
		try {
			list = this.service.getPostProcessedList();
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Check if any Exception, then throw 500
		if (Objects.isNull(list))
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		log.info("Response to Service : [ " + list + " ]");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	// ------------- POST ------------------//
	@RequestMapping(value = "/doPostProcess", method = RequestMethod.POST, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonProcessResponse> addData(@RequestBody final PostProcessRequest body) {
		log.info("Request to POST Service : PlutoDCController - doPostProcess - '" + body + "'");

		// Get Data from Service Layer
		CommonProcessResponse response = null;
		try {
			response = this.service.doPostProcessing(body);
		} catch (Exception e) {
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
