package com.paypal.test.rule.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class TestSuite {

	private String id;
	private String test_suite_name;
	private String test_suite_desc;
	private String active;
	private String created_tmstmp;
	private String created_by;
	private String updated_tmstmp;
	private String updated_by;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTest_suite_name() {
		return test_suite_name;
	}

	public void setTest_suite_name(String test_suite_name) {
		this.test_suite_name = test_suite_name;
	}

	public String getTest_suite_desc() {
		return test_suite_desc;
	}

	public void setTest_suite_desc(String test_suite_desc) {
		this.test_suite_desc = test_suite_desc;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getCreated_tmstmp() {
		return created_tmstmp;
	}

	public void setCreated_tmstmp(String created_tmstmp) {
		this.created_tmstmp = created_tmstmp;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getUpdated_tmstmp() {
		return updated_tmstmp;
	}

	public void setUpdated_tmstmp(String updated_tmstmp) {
		this.updated_tmstmp = updated_tmstmp;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
