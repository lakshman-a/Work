package com.paypal.test.rule.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class ActionTrnDetail {

	private String id;
	private String run_id;
	private String test_case_num;
	private String test_case_name;
	private Object comp_num;
	private Object comp_name;
	private String test_data_num;
	private String step_num;
	private String action_name;
	private String step_result;
	private Object step_desc;
	private Object screenshot_path;
	private String step_start_time;
	private String step_end_time;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRun_id() {
		return run_id;
	}

	public void setRun_id(String run_id) {
		this.run_id = run_id;
	}

	public String getTest_case_num() {
		return test_case_num;
	}

	public void setTest_case_num(String test_case_num) {
		this.test_case_num = test_case_num;
	}

	public String getTest_case_name() {
		return test_case_name;
	}

	public void setTest_case_name(String test_case_name) {
		this.test_case_name = test_case_name;
	}

	public Object getComp_num() {
		return comp_num;
	}

	public void setComp_num(Object comp_num) {
		this.comp_num = comp_num;
	}

	public Object getComp_name() {
		return comp_name;
	}

	public void setComp_name(Object comp_name) {
		this.comp_name = comp_name;
	}

	public String getStep_num() {
		return step_num;
	}

	public void setStep_num(String step_num) {
		this.step_num = step_num;
	}

	public String getAction_name() {
		return action_name;
	}

	public void setAction_name(String action_name) {
		this.action_name = action_name;
	}

	public String getStep_result() {
		return step_result;
	}

	public void setStep_result(String step_result) {
		this.step_result = step_result;
	}

	public Object getStep_desc() {
		return step_desc;
	}

	public void setStep_desc(Object step_desc) {
		this.step_desc = step_desc;
	}

	public Object getScreenshot_path() {
		return screenshot_path;
	}

	public void setScreenshot_path(Object screenshot_path) {
		this.screenshot_path = screenshot_path;
	}

	public String getStep_start_time() {
		return step_start_time;
	}

	public void setStep_start_time(String step_start_time) {
		this.step_start_time = step_start_time;
	}

	public String getStep_end_time() {
		return step_end_time;
	}

	public void setStep_end_time(String step_end_time) {
		this.step_end_time = step_end_time;
	}

	public String getTest_data_num() {
		return test_data_num;
	}

	public void setTest_data_num(String test_data_num) {
		this.test_data_num = test_data_num;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
