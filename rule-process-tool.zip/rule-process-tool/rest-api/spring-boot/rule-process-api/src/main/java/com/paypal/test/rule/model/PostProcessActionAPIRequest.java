package com.paypal.test.rule.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class PostProcessActionAPIRequest {

	private String trigger_id;
	private String pluto_dc_version;
	private String rbo_version;
	private String rbo_jar_name;
	private String rbo_jar_desc;
	private String rbo_jar_file_name;
	private String rbo_jar_location;
	private String component;
	private String created_by;
	private String created_tmstmp;
	private String status;
	private String log_trace;

	public String getTrigger_id() {
		return trigger_id;
	}

	public void setTrigger_id(String trigger_id) {
		this.trigger_id = trigger_id;
	}

	public String getPluto_dc_version() {
		return pluto_dc_version;
	}

	public void setPluto_dc_version(String pluto_dc_version) {
		this.pluto_dc_version = pluto_dc_version;
	}

	public String getRbo_version() {
		return rbo_version;
	}

	public void setRbo_version(String rbo_version) {
		this.rbo_version = rbo_version;
	}

	public String getRbo_jar_name() {
		return rbo_jar_name;
	}

	public void setRbo_jar_name(String rbo_jar_name) {
		this.rbo_jar_name = rbo_jar_name;
	}

	public String getRbo_jar_desc() {
		return rbo_jar_desc;
	}

	public void setRbo_jar_desc(String rbo_jar_desc) {
		this.rbo_jar_desc = rbo_jar_desc;
	}

	public String getRbo_jar_file_name() {
		return rbo_jar_file_name;
	}

	public void setRbo_jar_file_name(String rbo_jar_file_name) {
		this.rbo_jar_file_name = rbo_jar_file_name;
	}

	public String getRbo_jar_location() {
		return rbo_jar_location;
	}

	public void setRbo_jar_location(String rbo_jar_location) {
		this.rbo_jar_location = rbo_jar_location;
	}

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getCreated_tmstmp() {
		return created_tmstmp;
	}

	public void setCreated_tmstmp(String created_tmstmp) {
		this.created_tmstmp = created_tmstmp;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getLog_trace() {
		return log_trace;
	}

	public void setLog_trace(String log_trace) {
		this.log_trace = log_trace;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
