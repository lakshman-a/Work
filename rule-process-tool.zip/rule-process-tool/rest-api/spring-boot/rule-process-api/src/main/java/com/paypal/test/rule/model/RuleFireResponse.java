package com.paypal.test.rule.model;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

public class RuleFireResponse {

	private String status_code;
	private String status_phrase;
	private Object response_body;
	private String response_time;
	private String response_headers;
	private String isLogPatternSuccess;
	private String logPatternErrorMsg;
	private List<LogPattern> logPattern;
	private String error_msg;

	public String getStatus_code() {
		return status_code;
	}

	public void setStatus_code(String status_code) {
		this.status_code = status_code;
	}

	public String getStatus_phrase() {
		return status_phrase;
	}

	public void setStatus_phrase(String status_phrase) {
		this.status_phrase = status_phrase;
	}

	public Object getResponse_body() {
		return response_body;
	}

	public void setResponse_body(Object response_body) {
		this.response_body = response_body;
	}

	public String getResponse_time() {
		return response_time;
	}

	public void setResponse_time(String response_time) {
		this.response_time = response_time;
	}

	public String getResponse_headers() {
		return response_headers;
	}

	public void setResponse_headers(String response_headers) {
		this.response_headers = response_headers;
	}

	public String getError_msg() {
		return error_msg;
	}

	public void setError_msg(String error_msg) {
		this.error_msg = error_msg;
	}

	public List<LogPattern> getLogPattern() {
		return logPattern;
	}

	public void setLogPattern(List<LogPattern> logPattern) {
		this.logPattern = logPattern;
	}

	public String getLogPatternErrorMsg() {
		return logPatternErrorMsg;
	}

	public void setLogPatternErrorMsg(String logPatternErrorMsg) {
		this.logPatternErrorMsg = logPatternErrorMsg;
	}

	public String getIsLogPatternSuccess() {
		return isLogPatternSuccess;
	}

	public void setIsLogPatternSuccess(String isLogPatternSuccess) {
		this.isLogPatternSuccess = isLogPatternSuccess;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
