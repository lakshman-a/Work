package com.paypal.test.rule.model;

import java.util.Set;

import org.apache.commons.lang.builder.ToStringBuilder;

public class TestCasesAndActionsList {

	private Set<String> testCases;
	private Set<String> testActions;

	public Set<String> getTestCases() {
		return testCases;
	}

	public void setTestCases(Set<String> testCases) {
		this.testCases = testCases;
	}

	public Set<String> getTestActions() {
		return testActions;
	}

	public void setTestActions(Set<String> testActions) {
		this.testActions = testActions;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
