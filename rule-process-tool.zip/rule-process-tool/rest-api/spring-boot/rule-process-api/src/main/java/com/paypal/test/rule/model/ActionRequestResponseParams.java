package com.paypal.test.rule.model;

public class ActionRequestResponseParams {

	private boolean paramFlag;
	private String paramName;
	private String paramValue;

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

	public boolean isParamFlag() {
		return paramFlag;
	}

	public void setParamFlag(boolean paramFlag) {
		this.paramFlag = paramFlag;
	}

	@Override
	public String toString() {
		return "{paramFlag : "+paramFlag+", paramName : " + paramName + ",paramValue : " + paramValue + "}";
	}

	
}
