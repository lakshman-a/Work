package com.paypal.test.rule.helper;

import java.net.URL;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.paypal.test.jaws.http.rest.PayPalRestClientFactory;
import com.paypal.test.jaws.http.rest.impl.EntityRestClient;
import com.paypal.test.rule.model.HeaderPojo;
import com.paypal.test.rule.model.RuleFireResponse;

public class HttpRestClient {
	final static Logger log = Logger.getLogger(HttpRestClient.class);

	public RuleFireResponse doPost(String url, List<HeaderPojo> headers, String payload) throws Exception {
		RuleFireResponse response = new RuleFireResponse();
		Object rawHttpResponse = null;

		log.info("********* HTTP CALL - Method : POST ************");
		log.info("Request Details: ");
		log.info("URL: " + url);
		log.info("Headers: " + headers.toString());
		log.info("Payload: " + payload);

		try {
			EntityRestClient<String> testClient = (EntityRestClient<String>) PayPalRestClientFactory.createEntityClient(String.class, new URL(url),
					MediaType.APPLICATION_JSON);

			for (HeaderPojo eachheader : headers) {
				testClient.addHeader(eachheader.getKey(), eachheader.getValue());
			}

			try {
				rawHttpResponse = testClient.simplePost(payload);
				response.setResponse_body(rawHttpResponse);

			} catch (javax.ws.rs.WebApplicationException e) {
				log.info("Response Code for the Request is not 200. So Capturing the response from Exception. Exception is - " + e);
				rawHttpResponse = e.getLocalizedMessage();
				e.printStackTrace();
			}

			response.setStatus_code(String.valueOf(testClient.getStatus().getStatusCode()));
			response.setStatus_phrase(testClient.getStatus().getReasonPhrase());
			response.setResponse_time(String.valueOf(testClient.getElapsedMillis()) + " ms");
			response.setResponse_headers(testClient.getResponseHeaders().toString());

			log.info("Response Details: ");
			log.info("Status Code: " + testClient.getStatus().getStatusCode());
			log.info("Status Phrase: " + testClient.getStatus().getReasonPhrase());
			log.info("Response Time: " + String.valueOf(testClient.getElapsedMillis()) + " ms");
			log.info("Response Headers: " + String.valueOf(testClient.getResponseHeaders().toString()));
			log.info("Response Body: " + rawHttpResponse);

			// String Response to JSON Node
			// ObjectMapper mapper = new ObjectMapper();
			// responseAsJsonNode = mapper.readTree(response.toString());
			// responseAsJsonObject = mapper.convertValue(responseAsJsonNode, JSONObject.class);

		} catch (Exception e) {
			log.error("Exception occured while involing the POST Request. Exception is : " + e);
			e.printStackTrace();
			throw e;
		}
		return response;
	}

	public Object doGet(String url, List<HeaderPojo> headers) throws Exception {
		RuleFireResponse response = new RuleFireResponse();
		Object rawHttpResponse = null;

		log.info("********* HTTP CALL - Method : POST ************");
		log.info("Request Details: ");
		log.info("URL: " + url);
		log.info("Headers: " + headers.toString());

		try {
			EntityRestClient<String> testClient = (EntityRestClient<String>) PayPalRestClientFactory.createEntityClient(String.class, new URL(url),
					MediaType.APPLICATION_JSON);

			for (HeaderPojo eachheader : headers) {
				testClient.addHeader(eachheader.getKey(), eachheader.getValue());
			}

			try {
				rawHttpResponse = testClient.simpleGet();
				response.setResponse_body(rawHttpResponse);

			} catch (javax.ws.rs.WebApplicationException e) {
				log.info("Response Code for the Request is not 200. So Capturing the response from Exception. Exception is - " + e);
				rawHttpResponse = e.getLocalizedMessage();
				e.printStackTrace();
			}

			response.setStatus_code(String.valueOf(testClient.getStatus().getStatusCode()));
			response.setStatus_phrase(testClient.getStatus().getReasonPhrase());
			response.setResponse_time(String.valueOf(testClient.getElapsedMillis()) + " ms");
			response.setResponse_headers(testClient.getResponseHeaders().toString());

			log.info("Response Details: ");
			log.info("Status Code: " + testClient.getStatus().getStatusCode());
			log.info("Status Phrase: " + testClient.getStatus().getReasonPhrase());
			log.info("Response Time: " + String.valueOf(testClient.getElapsedMillis()) + " ms");
			log.info("Response Headers: " + String.valueOf(testClient.getResponseHeaders().toString()));
			log.info("Response Body: " + rawHttpResponse);

		} catch (Exception e) {
			log.error("Exception occured while involing the POST Request. Exception is : " + e);
			e.printStackTrace();
			throw e;
		}
		return response;
	}

//	public Object doGet(String url, Map<String, String> headersMap) throws Exception {
//		JsonNode responseAsJsonNode = null;
//		JSONObject responseAsJsonObject = null;
//
//		try {
//			EntityRestClient<String> testClient = (EntityRestClient<String>) PayPalRestClientFactory
//					.createEntityClient(String.class, new URL(url), MediaType.APPLICATION_JSON);
//			testClient.addHeaders(headersMap);
//
//			String response;
//			try {
//				response = testClient.simpleGet();
//			} catch (javax.ws.rs.WebApplicationException e) {
//				log.info(
//						"Response Code for the Request is not 200. So Capturing the response from Exception. Exception is - "
//								+ e);
//				throw e;
//			}
//
//			// String Response to JSON Node
//			ObjectMapper mapper = new ObjectMapper();
//			responseAsJsonNode = mapper.readTree(response);
//			responseAsJsonObject = mapper.convertValue(responseAsJsonNode, JSONObject.class);
//
//		} catch (Exception e) {
//			log.error("Exception occured while involing the GET Request. Exception is : " + e);
//			e.printStackTrace();
//			throw e;
//		}
//		return responseAsJsonObject;
//	}

	public static void main(String[] args) {
	}
}
