package com.paypal.test.rule.model;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

public class PlutoDCVersionList {

	private String name;
	private String description;
	private List<String> rboVersionList;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<String> getRboVersionList() {
		return rboVersionList;
	}

	public void setRboVersionList(List<String> rboVersionList) {
		this.rboVersionList = rboVersionList;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
}