package com.paypal.test.rule.service;


import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.apache.log4j.Logger;

import com.paypal.test.rule.helper.Constants;
import com.paypal.test.rule.helper.LinuxCommandExecutor;
import com.paypal.test.rule.model.CommonProcessResponse;
import com.paypal.test.rule.model.StageProcessRequest;

public class LinuxProcessService {
	final static Logger log = Logger.getLogger(LinuxProcessService.class);

	public CommonProcessResponse doLinuxConnect(StageProcessRequest request) {
		CommonProcessResponse response = new CommonProcessResponse();
		log.info("Method: doLinuxConnect. Params -rLinuxConnectRequest request");
		
		String stage = request.getStage();
		stage=stage.toUpperCase();
		String username = request.getUsername();
		String password = request.getPassword();
		byte[] valueDecoded = Base64.getDecoder().decode(password); 
		String decodedPassword = new String(valueDecoded, Charset.forName("UTF-8"));
		String uploadedRuleJar = request.getPostProcessedJarName();
		
		log.info("stage: " + stage);
		log.info("username: " + username);
		log.info("uploadedRuleJar: " + uploadedRuleJar);

		try {
			LinuxCommandExecutor linux = new LinuxCommandExecutor();
			boolean result = linux.checkConnectionJschSFTP(stage, username, decodedPassword);
			if(result) {
				response.setStatus("success");
				response.setMessage("Connection Successful.");
			}else {
				response.setStatus("fail");
				response.setMessage("Connection failed. Check Stage name or Credentials.");
			}
			return response;			
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus("fail");
			response.setMessage("Exection occured during check connection");
			response.setLogTrace(e.getMessage());
			log.error("Exception occured in check connection : " + e);
			return response;
		}

	}
	
	public CommonProcessResponse doLinuxConnectAndCopy(StageProcessRequest request) {
		CommonProcessResponse response = new CommonProcessResponse();
		log.info("Method: doLinuxConnectAndCopy. Params -rLinuxConnectRequest request");
		
		String stage = request.getStage();
		stage=stage.toUpperCase();
		String username = request.getUsername();
		String password = request.getPassword();
		byte[] valueDecoded = Base64.getDecoder().decode(password); 
		String decodedPassword = new String(valueDecoded, Charset.forName("UTF-8"));
		//Commenting below line to get the out jar name in request
		//String uploadedRuleJar = request.getUploadedRuleJar();
		String outJarName = request.getPostProcessedJarName();
		
		log.info("stage: " + stage);
		log.info("username: " + username);
		log.info("outJarName: " + outJarName);

		try {
			LinuxCommandExecutor linux = new LinuxCommandExecutor();
			String outputRuleJarName = outJarName.split("\\.")[0];
			String windowsPath= Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName+"\\riskresolutiondecisionserv";
			String linuxPath = Constants.LINUX_RRDS_RESDATA_PATH;
			linux.moveFolderFromLocalToStageByJschSFTP(stage, username, decodedPassword, outJarName, windowsPath, linuxPath);
			
			log.info("RRDS folder moved to "+stage+" res_data and Granted Full permission.");
			response.setStatus("success");
			response.setMessage("RRDS folder moved to "+stage+" res_data and Granted Full permission.");
			return response;
			
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus("fail");
			response.setMessage("RRDS folder move to STAGE Failed due to Exception : "+e.getMessage());
			response.setLogTrace(e.getMessage());
			log.error("Exception occured in PlutoDCService Layer : " + e);
			return response;
		}

	}
	
	public CommonProcessResponse doPropertyChangeInRRDS(StageProcessRequest request) {
		CommonProcessResponse response = new CommonProcessResponse();
		log.info("Method: doPropertyChangeInRRDS. Params -rLinuxConnectRequest request");
		
		String stage = request.getStage();
		stage=stage.toUpperCase();
		String username = request.getUsername();
		String password = request.getPassword();
		byte[] valueDecoded = Base64.getDecoder().decode(password); 
		String decodedPassword = new String(valueDecoded, Charset.forName("UTF-8"));
		String loggerLevel = request.getLoggerLevel().toUpperCase();
		String fileBased = request.getFileBased().toLowerCase();
		
		log.info("stage: " + stage);
		log.info("username: " + username);
		log.info("loggerLevel: " + loggerLevel);
		log.info("fileBased: " + fileBased);

		try {
			LinuxCommandExecutor linux = new LinuxCommandExecutor();

			List<String> cmdArray=new ArrayList<>();
			cmdArray.add("sed -i '68 s/false/"+fileBased+"/' ./../..//web/"+stage+"/riskresolutiondecisionserv/config/PlutoDecisionEngine.xml");
			cmdArray.add("sed -i '48 s/SEVERE/"+loggerLevel+"/' ./../../web/"+stage+"/riskresolutiondecisionserv/config/config/ukernelcore/logging.properties");
			cmdArray.add("sed -i '48 s/INFO/"+loggerLevel+"/' ./../../web/"+stage+"/riskresolutiondecisionserv/config/config/ukernelcore/logging.properties");
					
			linux.executeUnixCommand(stage, username, decodedPassword, cmdArray);
			
			log.info("RRDS Property file updated done.");
			response.setStatus("success");
			response.setMessage("RRDS Property file update done successfully.");
			return response;
			
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus("fail");
			response.setMessage("RRDS Property file update failed due to Exception : "+e.getMessage());
			response.setLogTrace(e.getMessage());
			log.error("RRDS Property file update failed due to Exception : "+e.getMessage());
			return response;
		}

	}
	
	public CommonProcessResponse doStartStopService(StageProcessRequest request) {
		CommonProcessResponse response = new CommonProcessResponse();
		log.info("Method: doStartStopService. Params -rLinuxConnectRequest request");
		
		String stage = request.getStage();
		String username = request.getUsername();
		String password = request.getPassword();
		byte[] valueDecoded = Base64.getDecoder().decode(password); 
		String decodedPassword = new String(valueDecoded, Charset.forName("UTF-8"));
		String action = request.getAction();
		
		log.info("stage: " + stage);
		log.info("username: " + username);
		log.info("action: " + action);

		try {
			LinuxCommandExecutor linux = new LinuxCommandExecutor();					
			linux.linuxStartStopComponent(stage, username, decodedPassword, action);
			
			log.info("RRDS Component - "+action+" done successfully.");
			response.setStatus("success");
			response.setMessage("RRDS Component - "+action+" done successfully.");
			return response;
			
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus("fail");
			response.setMessage("RRDS Component - "+action+" failed due to Exception : "+e.getMessage());
			response.setLogTrace(e.getMessage());
			log.error("RRDS Component - "+action+" failed due to Exception : "+e.getMessage());
			return response;
		}

	}
	

}
