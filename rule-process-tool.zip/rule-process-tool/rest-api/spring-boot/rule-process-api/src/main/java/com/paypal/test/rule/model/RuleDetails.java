package com.paypal.test.rule.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class RuleDetails {

	private Object id;
	private Object rule_id;
	private Object rule_name;
	private Object rule_desc;
	private Object component;
	private Object checkpoint;
	private Object rule;
	private Object rule_path;
	private Object active;
	private Object created_tmstmp;
	private Object created_by;
	private Object updated_tmstmp;
	private Object updated_by;

	public Object getRule_id() {
		return rule_id;
	}

	public void setRule_id(Object rule_id) {
		this.rule_id = rule_id;
	}

	public Object getRule_name() {
		return rule_name;
	}

	public void setRule_name(Object rule_name) {
		this.rule_name = rule_name;
	}

	public Object getRule_desc() {
		return rule_desc;
	}

	public void setRule_desc(Object rule_desc) {
		this.rule_desc = rule_desc;
	}

	public Object getComponent() {
		return component;
	}

	public void setComponent(Object component) {
		this.component = component;
	}

	public Object getCheckpoint() {
		return checkpoint;
	}

	public void setCheckpoint(Object checkpoint) {
		this.checkpoint = checkpoint;
	}

	public Object getRule() {
		return rule;
	}

	public void setRule(Object rule) {
		this.rule = rule;
	}

	public Object getCreated_tmstmp() {
		return created_tmstmp;
	}

	public void setCreated_tmstmp(Object created_tmstmp) {
		this.created_tmstmp = created_tmstmp;
	}

	public Object getCreated_by() {
		return created_by;
	}

	public void setCreated_by(Object created_by) {
		this.created_by = created_by;
	}

	public Object getUpdated_tmstmp() {
		return updated_tmstmp;
	}

	public void setUpdated_tmstmp(Object updated_tmstmp) {
		this.updated_tmstmp = updated_tmstmp;
	}

	public Object getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(Object updated_by) {
		this.updated_by = updated_by;
	}

	public Object getActive() {
		return active;
	}

	public void setActive(Object active) {
		this.active = active;
	}

	public Object getId() {
		return id;
	}

	public void setId(Object id) {
		this.id = id;
	}

	public Object getRule_path() {
		return rule_path;
	}

	public void setRule_path(Object rule_path) {
		this.rule_path = rule_path;
	}

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
}
