package com.paypal.test.rule.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.paypal.test.rule.helper.MysqlDbHelper;
import com.paypal.test.rule.model.CommonServiceResponse;
import com.paypal.test.rule.model.TestSuiteTrn;

public class TestSuiteTrnService {
	MysqlDbHelper sql = new MysqlDbHelper();
	final static Logger log = Logger.getLogger(TestSuiteTrnService.class);

	public List<TestSuiteTrn> getAllData(String caseName) throws Exception {
		List<TestSuiteTrn> responseList = new ArrayList<>();
		try {
			String query = "select * from rule_process.test_suite_trn where test_suite_name='"+caseName+"' order by test_case_num";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				for (HashMap<String, Object> hashMap : resultHash) {
					TestSuiteTrn eachItem = new TestSuiteTrn();
					eachItem.setId(hashMap.get("id").toString());
					eachItem.setTest_suite_name(hashMap.get("test_suite_name").toString());
					eachItem.setTest_case_num(hashMap.get("test_case_num").toString());
					eachItem.setTest_case_name(hashMap.get("test_case_name").toString());
					eachItem.setActive(hashMap.get("active").toString());
					eachItem.setCreated_tmstmp(hashMap.get("created_tmstmp").toString());
					eachItem.setCreated_by(hashMap.get("created_by").toString());
					eachItem.setUpdated_tmstmp(hashMap.get("updated_tmstmp").toString());
					eachItem.setUpdated_by(hashMap.get("updated_by").toString());
					responseList.add(eachItem);
				}
			}
//			else if (resultHash.size() == 0) {
//				return null;
//			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return responseList;
	}

	public CommonServiceResponse modifyData(String action, final TestSuiteTrn data) throws Exception {
		CommonServiceResponse response = new CommonServiceResponse();
		String query = null;
		Connection conn = null;
		Statement stmt = null;
		PreparedStatement preparedStmt = null;

		try {
			String jdbcClass = "com.mysql.jdbc.Driver";
			String connectionHostPort = "localhost";
			String schema = "atom";
			String sqlUser = "root";
			String sqlPwd = "root";

			// Load Classname and connection URL
			Class.forName(jdbcClass);
			String connectionUrl = "jdbc:mysql://" + connectionHostPort + "/" + schema + "";

			// Set SQL Properties
			Properties properties = new Properties();
			properties.setProperty("user", sqlUser);
			properties.setProperty("password", sqlPwd);
			properties.setProperty("useSSL", "true");
			properties.setProperty("autoReconnect", "true");
			properties.setProperty("verifyServerCertificate", "false");

			// Create Connection
			conn = DriverManager.getConnection(connectionUrl, properties);
			conn.setAutoCommit(false);
			conn.rollback();

//			id
//			test_case_name
//			step_no
//			action_name
//			active
//			created_by
//			created_tmstmp
//			updated_by
//			updated_tmstmp

			switch (action.toLowerCase()) {
			case "insert":

				query = "INSERT INTO rule_process.test_suite_trn (`test_suite_name`, `test_case_num`, `test_case_name`,`active`, `created_by`, `updated_by`) " + "VALUES "
						+ "(?, ?, ?, ?, ?, ?)";

				preparedStmt = conn.prepareStatement(query);
				preparedStmt.setString(1, data.getTest_suite_name());
				preparedStmt.setString(2, data.getTest_case_num());
				preparedStmt.setString(3, data.getTest_case_name());
				preparedStmt.setString(4, data.getActive().toString());
				preparedStmt.setString(5, data.getCreated_by().toString());
				preparedStmt.setString(6, data.getUpdated_by().toString());

				break;

			case "update":
				query = "UPDATE rule_process.test_suite_trn set test_case_name=?,active=?,updated_by=? where test_suite_name=? and test_case_num=?";
				
				preparedStmt = conn.prepareStatement(query);
				preparedStmt.setString(1, data.getTest_case_name());
				preparedStmt.setString(2, data.getActive().toString());
				preparedStmt.setString(3, data.getUpdated_by().toString());
				preparedStmt.setString(4, data.getTest_suite_name());
				preparedStmt.setString(5, data.getTest_case_num());

				
				break;

			case "delete":
				query = "DELETE FROM rule_process.test_suite_trn where test_suite_name=? and test_case_num=?";
				
				preparedStmt = conn.prepareStatement(query);
				preparedStmt.setString(1, data.getTest_suite_name());
				preparedStmt.setString(2, data.getTest_case_num());
				
				break;

			default:
				log.error("Invalid Action choosen!");
				throw new Exception(
						"Invalid Action choosen. Choose one of the following action : INSERT/UPDATE/DELETE");
			}

			log.info("Executing Update/Delete Query : [ " + query + " ]");
			log.info(preparedStmt.toString());
			int count = preparedStmt.executeUpdate();
			conn.commit();

			log.info("Count of Rows Updated/Deleted Successfully : [ " + count + " ]");
			if (count > 0) {
				response.setKey(data.getTest_suite_name().toString());
				response.setName(data.getTest_case_num().toString());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully");
				response.setCode("200");

			} else if (count == 0) {
				response.setKey(data.getTest_suite_name().toString());
				response.setName(data.getTest_case_num().toString());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully. No Rows Affected");
				response.setCode("201");

			}

		} catch (SQLIntegrityConstraintViolationException e) {
			e.printStackTrace();
			log.error("SQLIntegrityConstraintViolationException occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getTest_suite_name().toString());
			response.setName(data.getTest_case_num().toString());
			response.setAction(action);
			response.setStatus("failure");
			response.setReason(
					"Insert/Update/Delete failed due to SQL Contraint Error. May be duplicate key Insert or foriegn key constraint");
			response.setCode("500");

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("SQL Exception occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getTest_suite_name().toString());
			response.setName(data.getTest_case_num().toString());
			response.setAction(action);
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to SQL Exception.");
			response.setCode("500");

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Common Exception occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getTest_suite_name().toString());
			response.setName(data.getTest_case_num().toString());
			response.setAction(action);
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to Common Exception.");
			response.setCode("500");

		} finally {
			if (conn != null) {
				conn.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}

		return response;
	}

}
