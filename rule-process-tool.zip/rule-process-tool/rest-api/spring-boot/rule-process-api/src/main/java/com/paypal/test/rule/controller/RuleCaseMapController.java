package com.paypal.test.rule.controller;

import java.util.List;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.paypal.test.rule.helper.HeaderValidator;
import com.paypal.test.rule.model.CommonServiceResponse;
import com.paypal.test.rule.model.RuleCaseMapDetails;
import com.paypal.test.rule.model.TestCasesAndRulesList;
import com.paypal.test.rule.service.RuleCaseMapService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("api")
public class RuleCaseMapController {
	final static Logger log = Logger.getLogger(RuleCaseMapController.class);
	RuleCaseMapService service = new RuleCaseMapService();
	HeaderValidator validator = new HeaderValidator();

	// ------------- GET ALL ------------------//
	@RequestMapping(value = "/ruleToCaseMapList", method = RequestMethod.GET, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<RuleCaseMapDetails>> getAllData(
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to Service : MainModules - All Data");

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		List<RuleCaseMapDetails> list;
		try {
			list = this.service.getAllData();
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Check if any Exception, then throw 500
		if (Objects.isNull(list))
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		log.info("Response to Service : [ " + list + " ]");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	// ------------- GET CASE AND ACTIONS LIST ------------------//
		@RequestMapping(value = "/testcasesAndRules", method = RequestMethod.GET, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<TestCasesAndRulesList> getListData(
				@RequestHeader(value = "accept", required = true) String acceptHeader,
				@RequestHeader(value = "authorization", required = true) String authToken) {
			log.info("Request to Service : TestActions - All Data");

			// Header Validation
			HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
			if (headerValidityCode != HttpStatus.OK) {
				return new ResponseEntity<>(headerValidityCode);
			}

			// Get Data from Service Layer
			TestCasesAndRulesList list;
			try {
				list = this.service.getListData();
			} catch (Exception e) {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}

			// Check if any Exception, then throw 500
			if (Objects.isNull(list))
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);

			log.info("Response to Service : [ " + list + " ]");
			return new ResponseEntity<>(list, HttpStatus.OK);
		}
		
	// ------------- POST ------------------//
	@RequestMapping(value = "/ruleToCase", method = RequestMethod.POST, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonServiceResponse> addData(@RequestBody final RuleCaseMapDetails body,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to PUT Service : MainModules - Data - '" + body + "'");
		String action = "INSERT";

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		CommonServiceResponse response;
		try {
			response = this.service.modifyData(action, body);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	// ------------- PUT ------------------//
	@RequestMapping(value = "/ruleToCase", method = RequestMethod.PUT, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonServiceResponse> updateData(@RequestBody final RuleCaseMapDetails body,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to PUT Service : MainModules - Data - '" + body + "'");
		String action = "UPDATE";

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		CommonServiceResponse response;
		try {
			response = this.service.modifyData(action, body);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	// ------------- DELETE ------------------//
	@RequestMapping(value = "/ruleToCase", method = RequestMethod.DELETE, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonServiceResponse> deleteData(@RequestBody final RuleCaseMapDetails body,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to DELETE Service : MainModules - Data - '" + body + "'");
		String action = "DELETE";

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		CommonServiceResponse response;
		try {
			response = this.service.modifyData(action, body);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
