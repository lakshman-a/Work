package com.paypal.test.rule.main;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.paypal.test.rule.helper.LinuxCommandExecutor;

public class LinuxReadFileLocalServerBatchFileDelete {
	final static Logger log = Logger.getLogger(LinuxReadFileLocalServerBatchFileDelete.class);

	public static void main(String[] args) throws Exception {

		String stage = "stage2ma152946.qa.paypal.com";
		String username = "layyakannu";
		String password = "Paypal@123";
		Session session = null;

		File[] listOfFile = null;
		boolean result = false;
		String fileName = null;
		String fileNameStartsWithFromExcel = "server.log";
		String fileNameStartsWithFromExcel2 = "verbosegc.log";
		String actualText = null;
		String textValue = "(.*)(FINAL_RESPONSE)(.*)";

		Pattern pattern = null;
		String startValue = "server";

		try {

			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			session = jsch.getSession(username, stage, 22);
			session.setPassword(password);
			session.setConfig(config);
			try {
				session.connect();
				log.info("Connection Success to the mentioned STAGE! ");
				result = true;
			} catch (JSchException e) {
				log.error("Connection failed to the mentioned STAGE! " + e);
				e.printStackTrace();
				result = false;
				return;
			}
			Channel channel = null;
			ChannelSftp channelSftp = null;

			String SFTPWORKINGDIR = "/x/web/STAGE2MA152946/riskresolutiondecisionserv/logs/";

			channel = session.openChannel("sftp");
			channel.connect();
			channelSftp = (ChannelSftp) channel;
			channelSftp.cd(SFTPWORKINGDIR);

			List<String> fileList = new ArrayList<>();
			Set<String> fileListSet = new TreeSet();
			log.info("Files : " + fileList);
			log.info("Sorted : " + fileListSet);
			
			Vector filelist = channelSftp.ls(SFTPWORKINGDIR);
			for (int i = 0; i < filelist.size(); i++) {
				LsEntry entry = (LsEntry) filelist.get(i);
				if (!entry.getFilename().equalsIgnoreCase("server.log") && entry.getFilename().startsWith(fileNameStartsWithFromExcel)) {
					fileList.add(entry.getFilename());
					fileListSet.add(entry.getFilename());
				}
				// System.out.println(entry.getFilename());
			}

			log.info("Files : " + fileList);
			log.info("Sorted : " + fileListSet);

			for (String eachFileName : fileListSet) {
				log.info("Reading filename: " + eachFileName);
				channelSftp.rm(eachFileName);
				log.info("Dweleted");

//				obj_StringBuilder = new StringBuilder();
//
//				InputStream obj_InputStream = channelSftp.get(eachFileName);
//				char[] ch_Buffer = new char[0x10000];
//				Reader obj_Reader = new InputStreamReader(obj_InputStream, "UTF-8");
//				int int_Line = 0;
//				do {
//					int_Line = obj_Reader.read(ch_Buffer, 0, ch_Buffer.length);
//					if (int_Line > 0) {
//						obj_StringBuilder.append(ch_Buffer, 0, int_Line);
//					}
//				} while (int_Line >= 0);
//				obj_Reader.close();
//				obj_InputStream.close();
			}
//			String str_Content = "";
//			InputStream obj_InputStream = new ByteArrayInputStream(str_Content.getBytes());
//			channelSftp.put(obj_InputStream, SFTPWORKINGDIR + "server.log");
//			obj_InputStream.close();

			// log.info("Content : " + obj_StringBuilder.toString());
			channelSftp.exit();
			channelSftp.disconnect();
			channel.disconnect();

//		     InputStream obj_InputStream = obj_SFTPChannel.get(str_FileName);
//		      char[] ch_Buffer = new char[0x10000];
//		      Reader obj_Reader = new InputStreamReader(obj_InputStream, "UTF-8");
//		      int int_Line = 0;
//		      do
//		      {
//		        int_Line = obj_Reader.read(ch_Buffer, 0, ch_Buffer.length);
//		        if (int_Line > 0)
//		        { obj_StringBuilder.append(ch_Buffer, 0, int_Line);}
//		      }
//		      while (int_Line >= 0);
//		      obj_Reader.close();
//		      obj_InputStream.close();
//		      obj_SFTPChannel.exit();

//			File directory = new File("C:\\Users\\layyakannu\\Desktop\\LOGS\\");
//			boolean fileexist = false;
//			int fileAppeartime = 0;
//
//			listOfFile = directory.listFiles();
//			LinuxReadFileLocalServerBatchFile obj = new LinuxReadFileLocalServerBatchFile();
//			log.info("Sorted List");
//			listOfFile = obj.sortByNumber(listOfFile);
//			boolean isPatterFound = false;
//
//			for (int i = 0; i < listOfFile.length; i++) {
//
//				if (listOfFile[i].isFile()) {
//
//					fileName = listOfFile[i].getName();
//					log.info("Fetching File name : " + fileName);
//
//					if (fileName.startsWith(fileNameStartsWithFromExcel)) {
//						log.info("FileName starts with : server.log");
//						log.info("Starting to search the Pattern in the file : " + fileName);
//
//						log.info("Searching Content : " + textValue);
//						File ff = new File("C:\\Users\\layyakannu\\Desktop\\LOGS\\" + fileName);
//						String fileContent = IOUtils.toString(new FileInputStream(ff), "UTF-8");
//						actualText = "Text is not available in log file";
//						pattern = Pattern.compile(textValue);
//						Matcher matcher = pattern.matcher(fileContent);
//						while (matcher.find()) {
//							actualText = matcher.group(1) + matcher.group(2) + matcher.group(3);
//							log.info("Actual Text : " + actualText);
//							log.info("Matched! ");
//							log.info("Matched in the file : " + fileName);
//							isPatterFound = true;
//							return;
//						}
//
//						log.info(actualText);
//						log.info(actualText + " is not available in the filename '" + startValue + "'");
//
//						result = true;
//					}
//					if (isPatterFound) {
//						log.info("Expected Pattern found in file : " + fileName + "'. SO bReak out the Loop");
//						break;
//					} else {
//						log.info("Expected Pattern not found in file : " + fileName + "'. SO continue to next file");
//					}
//				}
//
//			}
//
//			log.info("Result : " + fileName);

			session.disconnect();
		} catch (Exception e) {
			log.error("Exception occured while moving file to Linux STAGE. Exception is");
			e.printStackTrace();
			throw e;
		} finally {
			if (session != null) {
				session.disconnect();
			}

		}

	}

	public File[] sortByNumber(File[] files) {
		Arrays.sort(files, new Comparator<File>() {
			@Override
			public int compare(File o1, File o2) {
				int n1 = extractNumber(o1.getName());
				int n2 = extractNumber(o2.getName());
				return n1 - n2;
			}

			private int extractNumber(String name) {
				int i = 0;
				try {
					int s = 11;
					int e = name.length();
					String number = name.substring(s, e);
					i = Integer.parseInt(number);
				} catch (Exception e) {
					i = 0; // if filename does not match the format
							// then default to 0
				}
				return i;
			}
		});

		for (File f : files) {
			System.out.println(f.getName());
		}
		return files;
	}
}
