package com.paypal.test.rule.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class TestActions {

	private String id;
	private Object actionDesc;
	private String actionName;
	private Object checkpointName;
	private Object componentName;
	private String headers;
	private String httpMethod;
	private String httpUrlFlag;
	private Object httpUrl;
	private Object httpStageProtocol;
	private Object httpStageName;
	private Object httpStagePort;
	private Object httpStageUri;
	private Object requestBody;
	private Object requestParams;
	private String requestParamsVariables;
	private String responseAction;
	private String responseCodeFlag;
	private Object responseCodeValue;
	private String responseStatusFlag;
	private Object responseStatusValue;
	private Object responseBody;
	private Object responseAssertParams;
	private Object responseExtractParams;
	private String responseParamsVariables;
	private String projectName;
	private String active;
	private String created_tmstmp;
	private String created_by;
	private String updated_tmstmp;
	private String updated_by;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Object getActionDesc() {
		return actionDesc;
	}

	public void setActionDesc(Object actionDesc) {
		this.actionDesc = actionDesc;
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public String getHttpMethod() {
		return httpMethod;
	}

	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

	public Object getRequestBody() {
		return requestBody;
	}

	public void setRequestBody(Object requestBody) {
		this.requestBody = requestBody;
	}

	public Object getRequestParams() {
		return requestParams;
	}

	public void setRequestParams(Object requestParams) {
		this.requestParams = requestParams;
	}

	public String getResponseAction() {
		return responseAction;
	}

	public void setResponseAction(String responseAction) {
		this.responseAction = responseAction;
	}

	public Object getResponseBody() {
		return responseBody;
	}

	public void setResponseBody(Object responseBody) {
		this.responseBody = responseBody;
	}

	public Object getResponseAssertParams() {
		return responseAssertParams;
	}

	public void setResponseAssertParams(Object responseAssertParams) {
		this.responseAssertParams = responseAssertParams;
	}

	public Object getResponseExtractParams() {
		return responseExtractParams;
	}

	public void setResponseExtractParams(Object responseExtractParams) {
		this.responseExtractParams = responseExtractParams;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getCreated_tmstmp() {
		return created_tmstmp;
	}

	public void setCreated_tmstmp(String created_tmstmp) {
		this.created_tmstmp = created_tmstmp;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getUpdated_tmstmp() {
		return updated_tmstmp;
	}

	public void setUpdated_tmstmp(String updated_tmstmp) {
		this.updated_tmstmp = updated_tmstmp;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}

	public String getHeaders() {
		return headers;
	}

	public void setHeaders(String headers) {
		this.headers = headers;
	}

	public String getResponseCodeFlag() {
		return responseCodeFlag;
	}

	public void setResponseCodeFlag(String responseCodeFlag) {
		this.responseCodeFlag = responseCodeFlag;
	}

	public Object getResponseCodeValue() {
		return responseCodeValue;
	}

	public void setResponseCodeValue(Object responseCodeValue) {
		this.responseCodeValue = responseCodeValue;
	}

	public String getResponseStatusFlag() {
		return responseStatusFlag;
	}

	public void setResponseStatusFlag(String responseStatusFlag) {
		this.responseStatusFlag = responseStatusFlag;
	}

	public Object getResponseStatusValue() {
		return responseStatusValue;
	}

	public void setResponseStatusValue(Object responseStatusValue) {
		this.responseStatusValue = responseStatusValue;
	}

	public String getHttpUrlFlag() {
		return httpUrlFlag;
	}

	public void setHttpUrlFlag(String httpUrlFlag) {
		this.httpUrlFlag = httpUrlFlag;
	}

	public Object getHttpStageProtocol() {
		return httpStageProtocol;
	}

	public void setHttpStageProtocol(Object httpStageProtocol) {
		this.httpStageProtocol = httpStageProtocol;
	}

	public Object getHttpStageName() {
		return httpStageName;
	}

	public void setHttpStageName(Object httpStageName) {
		this.httpStageName = httpStageName;
	}

	public Object getHttpStagePort() {
		return httpStagePort;
	}

	public void setHttpStagePort(Object httpStagePort) {
		this.httpStagePort = httpStagePort;
	}

	public Object getHttpStageUri() {
		return httpStageUri;
	}

	public void setHttpStageUri(Object httpStageUri) {
		this.httpStageUri = httpStageUri;
	}

	public Object getHttpUrl() {
		return httpUrl;
	}

	public void setHttpUrl(Object httpUrl) {
		this.httpUrl = httpUrl;
	}

	public String getRequestParamsVariables() {
		return requestParamsVariables;
	}

	public void setRequestParamsVariables(String requestParamsVariables) {
		this.requestParamsVariables = requestParamsVariables;
	}

	public String getResponseParamsVariables() {
		return responseParamsVariables;
	}

	public void setResponseParamsVariables(String responseParamsVariables) {
		this.responseParamsVariables = responseParamsVariables;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public Object getCheckpointName() {
		return checkpointName;
	}

	public void setCheckpointName(Object checkpointName) {
		this.checkpointName = checkpointName;
	}

	public Object getComponentName() {
		return componentName;
	}

	public void setComponentName(Object componentName) {
		this.componentName = componentName;
	}

}
