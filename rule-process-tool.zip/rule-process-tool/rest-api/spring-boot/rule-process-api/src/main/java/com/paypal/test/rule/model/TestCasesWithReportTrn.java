package com.paypal.test.rule.model;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

public class TestCasesWithReportTrn {

	private String testcaseName;
	private String testcaseNum;
	private String testcaseResult;
	private List<ActionTrnDetail> testcaseStepReport;

	public String getTestcaseName() {
		return testcaseName;
	}

	public void setTestcaseName(String testcaseName) {
		this.testcaseName = testcaseName;
	}

	public List<ActionTrnDetail> getTestcaseStepReport() {
		return testcaseStepReport;
	}

	public void setTestcaseStepReport(List<ActionTrnDetail> testcaseStepReport) {
		this.testcaseStepReport = testcaseStepReport;
	}

	public String getTestcaseNum() {
		return testcaseNum;
	}

	public void setTestcaseNum(String testcaseNum) {
		this.testcaseNum = testcaseNum;
	}

	public String getTestcaseResult() {
		return testcaseResult;
	}

	public void setTestcaseResult(String testcaseResult) {
		this.testcaseResult = testcaseResult;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}


}
