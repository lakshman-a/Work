package com.paypal.test.rule.main;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Hashtable;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class sample {

	public static void main(String[] args) throws Exception {
	   
		
		String stage = "stage2ma152946.qa.paypal.com";
		String username = "layyakannu";
		String password = "Paypal@123";
		System.out.println("Started");

	    JSch jsch = new JSch();
	    Session session = jsch.getSession(username, stage, 22);
	    String pwd = password;
	    session.setPassword(pwd);
	    Hashtable<String, String> config = new Hashtable<String, String>();
	    config.put("StrictHostKeyChecking", "no");
	    session.setConfig(config);
	    session.connect(45000);
	    session.setServerAliveInterval(45000);
	    

	    ChannelExec
	    m_channelExec = (ChannelExec) session.openChannel("exec");
	    String cmd = "tail -n0 -f '/x/web/STAGE2MA152946/riskresolutiondecisionserv/logs/server.log' | grep \"Total rules\"";
	    m_channelExec.setCommand(cmd);
	    InputStream m_in = m_channelExec.getInputStream();
	    m_channelExec.setPty(true);
	    m_channelExec.connect();
	    BufferedReader m_bufferedReader = new BufferedReader(new InputStreamReader(m_in));
	    int i = 0;
	    while (++i < 30) {

	        if (m_bufferedReader.ready()) {
	            String line = m_bufferedReader.readLine();
	            System.out.println(line);
	        }
	        Thread.sleep(1000);
	    }
	    m_bufferedReader.close();
	    m_channelExec.sendSignal("SIGINT");
	    m_channelExec.sendSignal("2");
//	    m_channelExec.sendSignal("2");
	    m_channelExec.disconnect();
	    session.disconnect();
	    System.out.println("exit");
	}
}
