package com.paypal.test.rule.helper;

public class Constants {
	public static String PLUTO_DC_PATH = "C:/Project/LEARNING/Rule-Process-Tool/rule-process-tool/rest-api/spring-boot/rule-process-api/src/main/resources/app/pluto-dc/versions/";
	public static String UPLOADED_RULE_JAR_PATH = "C:/Project/LEARNING/Rule-Process-Tool/rule-process-tool/rest-api/spring-boot/rule-process-api/src/main/resources/app/uploaded-rule-jar/";
	public static String POST_PROCESSED_RULE_JAR_PATH = "C:/Project/LEARNING/Rule-Process-Tool/rule-process-tool/rest-api/spring-boot/rule-process-api/src/main/resources/app/post-processed-rrds/versions/";
	public static String LINUX_RRDS_RESDATA_PATH = "/x/web/$USER_STAGE$/riskresolutiondecisionserv/config/res_data";
	public static String RBOJAR_PATH_FROM_PLUTO_DC = PLUTO_DC_PATH+"$PLUTO-DC_VERSION$/rbojars/";
}
