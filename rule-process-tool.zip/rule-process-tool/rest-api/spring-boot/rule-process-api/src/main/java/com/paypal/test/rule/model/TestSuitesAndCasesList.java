package com.paypal.test.rule.model;

import java.util.Set;

import org.apache.commons.lang.builder.ToStringBuilder;

public class TestSuitesAndCasesList {

	private Set<String> testSuites;
	private Set<String> testCases;

	public Set<String> getTestSuites() {
		return testSuites;
	}

	public void setTestSuites(Set<String> testSuites) {
		this.testSuites = testSuites;
	}

	public Set<String> getTestCases() {
		return testCases;
	}

	public void setTestCases(Set<String> testCases) {
		this.testCases = testCases;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
