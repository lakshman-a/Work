package com.paypal.test.rule.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class StageProcessAPIRequest {

	private String trigger_id;
	private String stage_name;
	private String stage_username;
	private String is_check_conn;
	private String is_move_folder;
	private String component;
	private String created_by;
	private String created_tmstmp;
	private String status;
	private String log_trace;

	public String getTrigger_id() {
		return trigger_id;
	}

	public void setTrigger_id(String trigger_id) {
		this.trigger_id = trigger_id;
	}

	public String getStage_name() {
		return stage_name;
	}

	public void setStage_name(String stage_name) {
		this.stage_name = stage_name;
	}

	public String getStage_username() {
		return stage_username;
	}

	public void setStage_username(String stage_username) {
		this.stage_username = stage_username;
	}

	public String getIs_check_conn() {
		return is_check_conn;
	}

	public void setIs_check_conn(String is_check_conn) {
		this.is_check_conn = is_check_conn;
	}

	public String getIs_move_folder() {
		return is_move_folder;
	}

	public void setIs_move_folder(String is_move_folder) {
		this.is_move_folder = is_move_folder;
	}

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getCreated_tmstmp() {
		return created_tmstmp;
	}

	public void setCreated_tmstmp(String created_tmstmp) {
		this.created_tmstmp = created_tmstmp;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getLog_trace() {
		return log_trace;
	}

	public void setLog_trace(String log_trace) {
		this.log_trace = log_trace;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
