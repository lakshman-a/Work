package com.paypal.test.rule.controller;

import java.util.List;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.paypal.test.rule.helper.HeaderValidator;
import com.paypal.test.rule.model.TestCasesWithReportTrn;
import com.paypal.test.rule.model.TestRunDetails;
import com.paypal.test.rule.model.TestRunWithReportTrnDetails;
import com.paypal.test.rule.model.TestSuiteRunDetails;
import com.paypal.test.rule.service.TestReportService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("api")
public class TestReportController {
	final static Logger log = Logger.getLogger(TestReportController.class);
	TestReportService service = new TestReportService();
	HeaderValidator validator = new HeaderValidator();

	// ------------- GET ALL ------------------//
	@RequestMapping(value = "/testReports", method = RequestMethod.GET, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<TestRunDetails>> getAllData(@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to Service : TestRunDetails - All Data");

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		List<TestRunDetails> list;
		try {
			list = this.service.getAllData();
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Check if any Exception, then throw 500
		if (Objects.isNull(list))
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		log.info("Response to Service : [ " + list + " ]");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@RequestMapping(value = "/lastRunReport", method = RequestMethod.GET, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<TestRunWithReportTrnDetails> getData(@RequestParam(value = "username", required = true) String input,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to Service : TestRunDetails - All Data");

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		TestRunWithReportTrnDetails list;
		try {
			list = this.service.getLastRunData(input);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Check if any Exception, then throw 500
		if (Objects.isNull(list))
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		log.info("Response to Service : [ " + list + " ]");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@RequestMapping(value = "/reportForRunId", method = RequestMethod.GET, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<TestRunWithReportTrnDetails> getFullReportDataForRunId(@RequestParam(value = "runId", required = true) String input,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to Service : TestRunDetails - All Data");

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		TestRunWithReportTrnDetails list;
		try {
			list = this.service.getCompleteReportOnRunData(input);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Check if any Exception, then throw 500
		if (Objects.isNull(list))
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		log.info("Response to Service : [ " + list + " ]");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@RequestMapping(value = "/testReportsForRunId", method = RequestMethod.GET, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<TestCasesWithReportTrn>> getReportDataForARun(@RequestParam(value = "runId", required = true) String input,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to Service : TestRunDetails - All Data");

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		List<TestCasesWithReportTrn> list;
		try {
			list = this.service.getReportDataForRunId(input);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Check if any Exception, then throw 500
		if (Objects.isNull(list))
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		log.info("Response to Service : [ " + list + " ]");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@RequestMapping(value = "/reports/testSuites", method = RequestMethod.GET, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<TestSuiteRunDetails>> getTestSuiteAllData(@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to Service : TestSuiteRunDetails - All Data");

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		List<TestSuiteRunDetails> list;
		try {
			list = this.service.getSuiteLastFewRunData();
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Check if any Exception, then throw 500
		if (Objects.isNull(list))
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		log.info("Response to Service : [ " + list + " ]");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@RequestMapping(value = "/reports/test", method = RequestMethod.GET, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<TestRunDetails>> getSuiteSpecificData(@RequestParam(value = "type", required = true) String type,@RequestParam(value = "name", required = true) String name,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to Service : TestRunDetails - All Data");

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		List<TestRunDetails> list;
		try {
			list = this.service.getSuiteAllReportData(type,name);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Check if any Exception, then throw 500
		if (Objects.isNull(list))
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		log.info("Response to Service : [ " + list + " ]");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

}
