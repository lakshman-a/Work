package com.paypal.test.rule.service;
import org.apache.log4j.Logger;

import com.paypal.test.rule.helper.MysqlDbHelper;
import com.paypal.test.rule.model.CommonServiceResponse;
import com.paypal.test.rule.model.PostProcessActionAPIRequest;
import com.paypal.test.rule.model.RuleJarUploadAPIRequest;
import com.paypal.test.rule.model.StageProcessAPIRequest;
import com.paypal.test.rule.model.StageSettingAPIRequest;

public class PostProcessDeployService {
	MysqlDbHelper sql = new MysqlDbHelper();
	final static Logger log = Logger.getLogger(PostProcessDeployService.class);

	/*
	 * public List<MainModule> getAllData() throws Exception { List<MainModule>
	 * responseList = new ArrayList<>(); try { String query =
	 * "SELECT * FROM ATOM.test_main_modules"; List<HashMap<String, Object>>
	 * resultHash = sql.executeSelect(query);
	 * 
	 * if (resultHash.size() > 0) { for (HashMap<String, Object> hashMap :
	 * resultHash) { MainModule eachItem = new MainModule();
	 * eachItem.setModuleName(hashMap.get("module_name").toString());
	 * eachItem.setModuleDesc(hashMap.get("module_desc").toString());
	 * eachItem.setCreatedBy(hashMap.get("created_by").toString());
	 * eachItem.setCreatedTmstmp(hashMap.get("created_tmstmp").toString());
	 * eachItem.setUpdatedBy(hashMap.get("updated_by").toString());
	 * eachItem.setUpdatedTmstmp(hashMap.get("updated_tmstmp").toString());
	 * eachItem.setActive(hashMap.get("active").toString());
	 * responseList.add(eachItem); } } else if (resultHash.size() == 0) { return
	 * null; }
	 * 
	 * } catch (Exception e) { e.printStackTrace();
	 * log.error("Exception occured in Service Layer : " + e); throw e; } return
	 * responseList; }
	 * 
	 * public MainModule getSingleData(final String dataToQuery) throws Exception {
	 * MainModule eachItem = new MainModule(); try { String query =
	 * "SELECT * FROM ATOM.test_main_modules where module_name='" + dataToQuery +
	 * "'"; List<HashMap<String, Object>> resultHash = sql.executeSelect(query);
	 * 
	 * if (resultHash.size() > 0) { for (HashMap<String, Object> hashMap :
	 * resultHash) { eachItem.setModuleName(hashMap.get("module_name").toString());
	 * eachItem.setModuleDesc(hashMap.get("module_desc").toString());
	 * eachItem.setCreatedBy(hashMap.get("created_by").toString());
	 * eachItem.setCreatedTmstmp(hashMap.get("created_tmstmp").toString());
	 * eachItem.setUpdatedBy(hashMap.get("updated_by").toString());
	 * eachItem.setUpdatedTmstmp(hashMap.get("updated_tmstmp").toString());
	 * eachItem.setActive(hashMap.get("active").toString()); } } else if
	 * (resultHash.size() == 0) { eachItem = null; }
	 * 
	 * } catch (Exception e) { e.printStackTrace();
	 * log.error("Exception occured in Service Layer : " + e); throw e; } return
	 * eachItem; }
	 */

	public CommonServiceResponse modifyData(String action, final RuleJarUploadAPIRequest data) throws Exception {
		CommonServiceResponse response = new CommonServiceResponse();
		String query = null;
		try {

			switch (action.toLowerCase()) {
			case "insert":
				query = "INSERT INTO rule_process.rule_jar_upload (trigger_id, rule_jar_name,rule_jar_desc,rule_jar_file_name, rule_jar_location, created_by,status,log_trace) values ('"
						+ data.getTrigger_id() + "','" + data.getRule_jar_name() + "','" + data.getRule_jar_desc()
						+ "','" + data.getRule_jar_file_name() + "','" + data.getRule_jar_location() + "','"
						+ data.getCreated_by() + "','" + data.getStatus() + "','" + data.getLog_trace() + "')";
				break;
			/*
			 * case "update": query = "UPDATE ATOM.test_main_modules set module_desc='" +
			 * data.getModuleDesc() + "',active='" + data.getActive() + "', updated_by='" +
			 * data.getUpdatedBy() + "' where module_name='" + data.getModuleName() + "'";
			 * break;
			 */
			/*
			 * case "delete": query =
			 * "DELETE FROM ATOM.test_main_modules where module_name='" +
			 * data.getModuleName() + "'"; break;
			 */
			default:
				log.error("Invalid Action choosen!");
				throw new Exception(
						"Invalid Action choosen. Choose one of the following action : INSERT/UPDATE/DELETE");
			}

			int count = sql.executeUpdate(query);

			if (count > 0) {
				response.setKey(data.getTrigger_id());
				response.setName(data.getRule_jar_file_name());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully");
				response.setCode("200");

			} else if (count == 0) {
				response.setKey(data.getTrigger_id());
				response.setName(data.getRule_jar_file_name());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully. No Rows Affected");
				response.setCode("201");

			} else if (count == -2) {
				response.setKey(data.getTrigger_id());
				response.setName(data.getRule_jar_file_name());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason(
						"Insert/Update/Delete failed due to SQL Contraint Error. May be duplicate key Insert or foriegn key constraint");
				response.setCode("500");
			} else if (count == -3) {
				response.setKey(data.getTrigger_id());
				response.setName(data.getRule_jar_file_name());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason("Insert/Update/Delete failed due to SQL Exception.");
				response.setCode("500");

			} else if (count == -4) {
				response.setKey(data.getTrigger_id());
				response.setName(data.getRule_jar_file_name());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason("Insert/Update/Delete failed due to Common Exception.");
				response.setCode("500");
			} else if (count == -1) {
				response.setKey(data.getTrigger_id());
				response.setName(data.getRule_jar_file_name());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason("Unkown Reason.");
				response.setCode("500");
			}

		} catch (Exception e) {
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return response;
	}

	public CommonServiceResponse modifyPlutoDCData(String action, final PostProcessActionAPIRequest data)
			throws Exception {
		CommonServiceResponse response = new CommonServiceResponse();
		String query = null;
		try {

			switch (action.toLowerCase()) {
			case "insert":
				query = "INSERT INTO rule_process.post_process_action (trigger_id, pluto_dc_version,rbo_version,rbo_jar_name, rbo_jar_desc, rbo_jar_file_name,rbo_jar_location,component,created_by,status,log_trace) values ('"
						+ data.getTrigger_id() + "','" + data.getPluto_dc_version() + "','" + data.getRbo_version()
						+ "','" + data.getRbo_jar_name() + "','" + data.getRbo_jar_desc() + "','"
						+ data.getRbo_jar_file_name() + "','" + data.getRbo_jar_location() + "','" + data.getComponent()
						+ "','" + data.getCreated_by() + "','" + data.getStatus() + "','" + data.getLog_trace() + "')";
				break;
			/*
			 * case "update": query = "UPDATE ATOM.test_main_modules set module_desc='" +
			 * data.getModuleDesc() + "',active='" + data.getActive() + "', updated_by='" +
			 * data.getUpdatedBy() + "' where module_name='" + data.getModuleName() + "'";
			 * break;
			 */
			/*
			 * case "delete": query =
			 * "DELETE FROM ATOM.test_main_modules where module_name='" +
			 * data.getModuleName() + "'"; break;
			 */
			default:
				log.error("Invalid Action choosen!");
				throw new Exception(
						"Invalid Action choosen. Choose one of the following action : INSERT/UPDATE/DELETE");
			}

			int count = sql.executeUpdate(query);

			if (count > 0) {
				response.setKey(data.getTrigger_id());
				response.setSecondKey(data.getPluto_dc_version());
				response.setName(data.getRbo_version());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully");
				response.setCode("200");

			} else if (count == 0) {
				response.setKey(data.getTrigger_id());
				response.setSecondKey(data.getPluto_dc_version());
				response.setName(data.getRbo_version());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully. No Rows Affected");
				response.setCode("201");

			} else if (count == -2) {
				response.setKey(data.getTrigger_id());
				response.setSecondKey(data.getPluto_dc_version());
				response.setName(data.getRbo_version());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason(
						"Insert/Update/Delete failed due to SQL Contraint Error. May be duplicate key Insert or foriegn key constraint");
				response.setCode("500");
			} else if (count == -3) {
				response.setKey(data.getTrigger_id());
				response.setSecondKey(data.getPluto_dc_version());
				response.setName(data.getRbo_version());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason("Insert/Update/Delete failed due to SQL Exception.");
				response.setCode("500");

			} else if (count == -4) {
				response.setKey(data.getTrigger_id());
				response.setSecondKey(data.getPluto_dc_version());
				response.setName(data.getRbo_version());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason("Insert/Update/Delete failed due to Common Exception.");
				response.setCode("500");
			} else if (count == -1) {
				response.setKey(data.getTrigger_id());
				response.setSecondKey(data.getPluto_dc_version());
				response.setName(data.getRbo_version());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason("Unkown Reason.");
				response.setCode("500");
			}

		} catch (Exception e) {
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return response;
	}

	public CommonServiceResponse modifyStageConnData(String action, final StageProcessAPIRequest data)
			throws Exception {
		CommonServiceResponse response = new CommonServiceResponse();
		String query = null;
		try {

			switch (action.toLowerCase()) {
			case "insert":
				query = "INSERT INTO rule_process.stage_copy_process (trigger_id, stage_name,stage_username,is_check_conn, is_move_folder,component,created_by,status,log_trace) values ('"
						+ data.getTrigger_id() + "','" + data.getStage_name() + "','" + data.getStage_username() + "','"
						+ data.getIs_check_conn() + "','" + data.getIs_move_folder() + "','" + data.getComponent() + "','" + data.getCreated_by() + "','" + data.getStatus() + "','"
						+ data.getLog_trace() + "')";
				break;
			/*
			 * case "update": query = "UPDATE ATOM.test_main_modules set module_desc='" +
			 * data.getModuleDesc() + "',active='" + data.getActive() + "', updated_by='" +
			 * data.getUpdatedBy() + "' where module_name='" + data.getModuleName() + "'";
			 * break;
			 */
			/*
			 * case "delete": query =
			 * "DELETE FROM ATOM.test_main_modules where module_name='" +
			 * data.getModuleName() + "'"; break;
			 */
			default:
				log.error("Invalid Action choosen!");
				throw new Exception(
						"Invalid Action choosen. Choose one of the following action : INSERT/UPDATE/DELETE");
			}

			int count = sql.executeUpdate(query);

			if (count > 0) {
				response.setKey(data.getTrigger_id());
				response.setSecondKey(data.getStage_name());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully");
				response.setCode("200");

			} else if (count == 0) {
				response.setKey(data.getTrigger_id());
				response.setSecondKey(data.getStage_name());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully. No Rows Affected");
				response.setCode("201");

			} else if (count == -2) {
				response.setKey(data.getTrigger_id());
				response.setSecondKey(data.getStage_name());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason(
						"Insert/Update/Delete failed due to SQL Contraint Error. May be duplicate key Insert or foriegn key constraint");
				response.setCode("500");
			} else if (count == -3) {
				response.setKey(data.getTrigger_id());
				response.setSecondKey(data.getStage_name());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason("Insert/Update/Delete failed due to SQL Exception.");
				response.setCode("500");

			} else if (count == -4) {
				response.setKey(data.getTrigger_id());
				response.setSecondKey(data.getStage_name());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason("Insert/Update/Delete failed due to Common Exception.");
				response.setCode("500");
			} else if (count == -1) {
				response.setKey(data.getTrigger_id());
				response.setSecondKey(data.getStage_name());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason("Unkown Reason.");
				response.setCode("500");
			}

		} catch (Exception e) {
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return response;
	}

	public CommonServiceResponse modifyStageSettingData(String action, final StageSettingAPIRequest data)
			throws Exception {
		CommonServiceResponse response = new CommonServiceResponse();
		String query = null;
		try {

			switch (action.toLowerCase()) {
			case "insert":
				query = "INSERT INTO rule_process.stage_comp_settings (trigger_id, logger_level,file_based_flag,component,created_by,status,log_trace) values ('"
						+ data.getTrigger_id() + "','" + data.getLogger_level() + "','" + data.getFile_based_flag()
						+ "','" + data.getComponent() + "','" + data.getCreated_by() + "','" + data.getStatus() + "','"
						+ data.getLog_trace() + "')";
				break;
			/*
			 * case "update": query = "UPDATE ATOM.test_main_modules set module_desc='" +
			 * data.getModuleDesc() + "',active='" + data.getActive() + "', updated_by='" +
			 * data.getUpdatedBy() + "' where module_name='" + data.getModuleName() + "'";
			 * break;
			 */
			/*
			 * case "delete": query =
			 * "DELETE FROM ATOM.test_main_modules where module_name='" +
			 * data.getModuleName() + "'"; break;
			 */
			default:
				log.error("Invalid Action choosen!");
				throw new Exception(
						"Invalid Action choosen. Choose one of the following action : INSERT/UPDATE/DELETE");
			}

			int count = sql.executeUpdate(query);

			if (count > 0) {
				response.setKey(data.getTrigger_id());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully");
				response.setCode("200");

			} else if (count == 0) {
				response.setKey(data.getTrigger_id());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully. No Rows Affected");
				response.setCode("201");

			} else if (count == -2) {
				response.setKey(data.getTrigger_id());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason(
						"Insert/Update/Delete failed due to SQL Contraint Error. May be duplicate key Insert or foriegn key constraint");
				response.setCode("500");
			} else if (count == -3) {
				response.setKey(data.getTrigger_id());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason("Insert/Update/Delete failed due to SQL Exception.");
				response.setCode("500");

			} else if (count == -4) {
				response.setKey(data.getTrigger_id());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason("Insert/Update/Delete failed due to Common Exception.");
				response.setCode("500");
			} else if (count == -1) {
				response.setKey(data.getTrigger_id());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason("Unkown Reason.");
				response.setCode("500");
			}

		} catch (Exception e) {
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return response;
	}

}
