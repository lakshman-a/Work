package com.paypal.test.rule.tailer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

/**
 * Provides remote tailing facilities via ssh.
 */
public class TailerSsh {

	final static Logger log = Logger.getLogger(TailerSsh.class);
	private static final String DEFAULT_TAIL_COMMAND = "tail -F";

	private final TailerCallback tailerListener;
	private final Executor executor;
	private final JSch jsch;
	private final CountDownLatch completed;

	private String tailCommand;
	private Session session;
	private String filePath;
	private volatile boolean stopping;
	private volatile Thread inputThread;
	private volatile Thread errorThread;

	BufferedWriter writer = null;
	FileWriter fileWriter = null;

	/**
	 * Constructor.
	 * 
	 * @param jsch
	 * @param uri
	 * @param listener
	 * @param executor
	 * @throws IOException
	 */
	public TailerSsh(JSch jsch, TailerCallback listener, Executor executor, String stage, String filePathVariable,
			String username, String password) throws IOException {
		this.jsch = jsch;
		this.tailerListener = listener;
		this.executor = executor;
		completed = new CountDownLatch(1);

		tailCommand = DEFAULT_TAIL_COMMAND;
		stopping = false;

		filePath = filePathVariable;
		log.info("filePath {} :" + filePath);

		try {
			
			session = jsch.getSession(username, stage, 22);
			session.setPassword(password);
			session.setConfig("StrictHostKeyChecking", "no");
		} catch (JSchException e) {
			throw new IOException(e);
		}
	}

	/**
	 * Accessor for JSch instance.
	 * 
	 * @return
	 */
	public JSch getJsch() {
		return jsch;
	}

	/**
	 * Accessor for Session instance.
	 * 
	 * @return
	 */
	public Session getSession() {
		return session;
	}

	/**
	 * Set remote tail command.
	 * 
	 * @param tailCommand
	 */
	public void setTailCommand(String tailCommand) {
		this.tailCommand = tailCommand;
	}

	/**
	 * Commence tailing.
	 */
	public void start() {

		try {
			fileWriter = new FileWriter("C:\\Users\\layyakannu\\Desktop\\log.txt");
			writer = new BufferedWriter(fileWriter);
		} catch (IOException e) {
			log.error("Error while writing to a file");
			e.printStackTrace();
		}

		log.debug("start");
		Runnable runnable = new Runnable() {

			@Override
			public void run() {
				inputThread = Thread.currentThread();
				remoteTailWrapped();
			}
		};
		executor.execute(runnable);
	}

	/**
	 * Cease tailing.
	 */
	public void stop() {

		try {
			if (writer != null)
				writer.close();
			if (fileWriter != null)
				fileWriter.close();
		} catch (IOException e) {
			log.error("File buffer close exception");
			e.printStackTrace();
		}

		log.debug("stop");
		stopping = true;
		if (errorThread != null) {
			errorThread.interrupt();
		}
		if (inputThread != null) {
			inputThread.interrupt();
		}
	}

	/**
	 * Wait for tail thread to terminate.
	 * 
	 * @throws InterruptedException
	 */
	public void await() throws InterruptedException {
		completed.await();
	}

	private void remoteTailWrapped() {
		log.debug("start remoteTailWrapped");
		try {
			remoteTail();
		} catch (Exception e) {
			log.debug("exception", e);
			if (!stopping) {
				tailerListener.handleException(e);
			}
		} finally {
			completed.countDown();
		}
		log.debug("end remoteTailWrapped");
	}

	private void remoteTail() throws Exception {
		session.connect();
		ChannelExec channel = (ChannelExec) session.openChannel("exec");
		String command = tailCommand;
		log.info("command: " + command);
		// channel.setPty(true);

		((ChannelExec) channel).setCommand("sudo -S -p '' " + command);

		channel.setInputStream(null);
		InputStream errStream = channel.getErrStream();
		InputStream inputStream = channel.getInputStream();
		OutputStream out = channel.getOutputStream();

		channel.connect();
		log.debug("channel connected");

		drainErrorStream(errStream);
		drainInputStream(inputStream, out);

		channel.disconnect();
		session.disconnect();
	}

	private void drainInputStream(final InputStream inputStream, final OutputStream out) throws IOException {

		String sudo_pass = "Paypal@123";
		out.write((sudo_pass + "\n").getBytes());
		out.flush();

		log.info("Password done!");

		BufferedReader inputReader = new BufferedReader(new InputStreamReader(inputStream));

		while (!stopping) {
			String line = inputReader.readLine();
			writer.write(line + "\n");
			if (line == null) {
				break;
			}
			tailerListener.handleLine(line);
		}

		log.debug("input stream drained");

	}

	private void drainErrorStream(final InputStream errStream) {

		Runnable drainer = new Runnable() {

			@Override
			public void run() {
				errorThread = Thread.currentThread();
				BufferedReader errReader = new BufferedReader(new InputStreamReader(errStream));

				while (true) {
					String line;
					try {
						line = errReader.readLine();
					} catch (IOException e) {
						log.debug("exception", e);
						return;
					}
					if (line == null) {
						break;
					}
					log.error("remote process error: " + line);
					tailerListener.handleLine(String.format("[%s]", line));
				}
				log.debug("error stream drained");
			}

		};

		executor.execute(drainer);
	}

	/**
	 * Simple command-line tester.
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		log.info("main");
		String stage = "stage2ma152946.qa.paypal.com";
		String filePath = "/x/web/STAGE2MA152946/riskresolutiondecisionserv/logs";
		String username = "layyakannu";
		String password = "Paypal@123";
		String cmd = "tail -n0 -f /x/web/STAGE2MA152946/riskresolutiondecisionserv/logs/server.log |unbuffer -p egrep -i 'Total rule|rules fired|DA response'";
		
		ExecutorService executor = Executors.newFixedThreadPool(10, new DaemonThreadFactory());
		TailerCallback listener = new TailerCallback() {

			@Override
			public void handleLine(String line) {
				log.info("log line: " + line);
			}

			@Override
			public void handleException(Exception ex) {
				log.error("Unexpected exception", ex);
			}
		};

		JSch jsch = new JSch();
		TailerSsh tailer = new TailerSsh(jsch, listener, executor, stage, filePath, username, password);
		tailer.setTailCommand(cmd);
		
		//Process starts
		tailer.start();

		int i = 0;
		while (i < 25) {
			System.out.println("Count --> " + i);
			i++;
			Thread.sleep(1000);
		}

		tailer.stop();
		//Process ENds
		
		tailer.await();
		log.debug("shutdown");
		executor.shutdown();
		log.debug("awaitTermination");
		executor.awaitTermination(1, TimeUnit.MINUTES);
		log.info("normal termination");

	}

}
