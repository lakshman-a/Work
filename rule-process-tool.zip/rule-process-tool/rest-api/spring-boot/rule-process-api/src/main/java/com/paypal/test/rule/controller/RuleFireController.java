package com.paypal.test.rule.controller;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.paypal.test.rule.helper.HeaderValidator;
import com.paypal.test.rule.model.RuleFireRequest;
import com.paypal.test.rule.model.RuleFireResponse;
import com.paypal.test.rule.service.RuleFireService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("api")
public class RuleFireController {
	final static Logger log = Logger.getLogger(RuleFireController.class);
	RuleFireService service = new RuleFireService();
	HeaderValidator validator = new HeaderValidator();

	// ------------- POST ------------------//
	@RequestMapping(value = "/fireRuleRequest", method = RequestMethod.POST, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<RuleFireResponse> fireRuleRequest(@RequestBody final RuleFireRequest body,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to POST Service : ruleJarUpload - Data - '" + body + "'");

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		RuleFireResponse response;
		try {
			response = this.service.httpRequest(body);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	//
}
