package com.paypal.test.rule.model;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

public class RuleFireRequest {

	private String method;
	private String url;
	private List<HeaderPojo> headers;
	private boolean logCheckFlag;
	private String stage;
	private String username;
	private String password;
	private List<LogPattern> logPattern;
	private Object payload;
	private String component;
	private String created_by;
	private String created_tmstmp;
	private String status;
	private String log_trace;

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getCreated_tmstmp() {
		return created_tmstmp;
	}

	public void setCreated_tmstmp(String created_tmstmp) {
		this.created_tmstmp = created_tmstmp;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getLog_trace() {
		return log_trace;
	}

	public void setLog_trace(String log_trace) {
		this.log_trace = log_trace;
	}

	public List<HeaderPojo> getHeaders() {
		return headers;
	}

	public void setHeaders(List<HeaderPojo> headers) {
		this.headers = headers;
	}

	public Object getPayload() {
		return payload;
	}

	public void setPayload(Object payload) {
		this.payload = payload;
	}

	public List<LogPattern> getLogPattern() {
		return logPattern;
	}

	public void setLogPattern(List<LogPattern> logPattern) {
		this.logPattern = logPattern;
	}

	public boolean isLogCheckFlag() {
		return logCheckFlag;
	}

	public void setLogCheckFlag(boolean logCheckFlag) {
		this.logCheckFlag = logCheckFlag;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
