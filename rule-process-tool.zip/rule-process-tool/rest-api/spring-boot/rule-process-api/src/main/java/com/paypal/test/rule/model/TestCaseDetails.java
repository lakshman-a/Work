package com.paypal.test.rule.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class TestCaseDetails {

	private String id;
	private String caseName;
	private String caseSummary;
	private Object caseSteps;
	private String componentName;
	private Object checkpointName;
	private String projectName;
	private Object moduleName;
	private Object subModuleName;
	private Object stage;
	private Object complexity;
	private String isAutomationCase;
	private String runMode;
	private String isRuleBased;
	private String isEndToEndCase;
	private String isTestDataAvailable;
	private Object testDataColumns;
	private Object testDataValues;
	private String active;
	private String created_tmstmp;
	private String created_by;
	private String updated_tmstmp;
	private String updated_by;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCaseName() {
		return caseName;
	}

	public void setCaseName(String caseName) {
		this.caseName = caseName;
	}

	public String getCaseSummary() {
		return caseSummary;
	}

	public void setCaseSummary(String caseSummary) {
		this.caseSummary = caseSummary;
	}

	public Object getCaseSteps() {
		return caseSteps;
	}

	public void setCaseSteps(Object caseSteps) {
		this.caseSteps = caseSteps;
	}

	public Object getModuleName() {
		return moduleName;
	}

	public void setModuleName(Object moduleName) {
		this.moduleName = moduleName;
	}

	public Object getSubModuleName() {
		return subModuleName;
	}

	public void setSubModuleName(Object subModuleName) {
		this.subModuleName = subModuleName;
	}

	public Object getStage() {
		return stage;
	}

	public void setStage(Object stage) {
		this.stage = stage;
	}

	public Object getComplexity() {
		return complexity;
	}

	public void setComplexity(Object complexity) {
		this.complexity = complexity;
	}

	public String getIsAutomationCase() {
		return isAutomationCase;
	}

	public void setIsAutomationCase(String isAutomationCase) {
		this.isAutomationCase = isAutomationCase;
	}

	public String getRunMode() {
		return runMode;
	}

	public void setRunMode(String runMode) {
		this.runMode = runMode;
	}

	public String getIsRuleBased() {
		return isRuleBased;
	}

	public void setIsRuleBased(String isRuleBased) {
		this.isRuleBased = isRuleBased;
	}

	public String getIsEndToEndCase() {
		return isEndToEndCase;
	}

	public void setIsEndToEndCase(String isEndToEndCase) {
		this.isEndToEndCase = isEndToEndCase;
	}

	public String getIsTestDataAvailable() {
		return isTestDataAvailable;
	}

	public void setIsTestDataAvailable(String isTestDataAvailable) {
		this.isTestDataAvailable = isTestDataAvailable;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getCreated_tmstmp() {
		return created_tmstmp;
	}

	public void setCreated_tmstmp(String created_tmstmp) {
		this.created_tmstmp = created_tmstmp;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getUpdated_tmstmp() {
		return updated_tmstmp;
	}

	public void setUpdated_tmstmp(String updated_tmstmp) {
		this.updated_tmstmp = updated_tmstmp;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}

	public Object getTestDataColumns() {
		return testDataColumns;
	}

	public void setTestDataColumns(Object testDataColumns) {
		this.testDataColumns = testDataColumns;
	}

	public Object getTestDataValues() {
		return testDataValues;
	}

	public void setTestDataValues(Object testDataValues) {
		this.testDataValues = testDataValues;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

	public String getComponentName() {
		return componentName;
	}

	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

	public Object getCheckpointName() {
		return checkpointName;
	}

	public void setCheckpointName(Object checkpointName) {
		this.checkpointName = checkpointName;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

}
