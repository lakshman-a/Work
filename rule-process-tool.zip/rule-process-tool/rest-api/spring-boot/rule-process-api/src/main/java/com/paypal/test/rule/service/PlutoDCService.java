package com.paypal.test.rule.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.paypal.test.rule.helper.Constants;
import com.paypal.test.rule.helper.FileHelper;
import com.paypal.test.rule.helper.WindowsCommandExecutor;
import com.paypal.test.rule.model.CommonProcessResponse;
import com.paypal.test.rule.model.PlutoDCVersionList;
import com.paypal.test.rule.model.PostProcessRequest;
import com.paypal.test.rule.model.PostProcessedJarList;

public class PlutoDCService {
	final static Logger log = Logger.getLogger(PlutoDCService.class);

	public List<PlutoDCVersionList> getPlutoDcListWithRboList() throws Exception {
		List<PlutoDCVersionList> responseList = new ArrayList<>();
		try {

			FileHelper fileUtil = new FileHelper();
			List<String> plutoList = fileUtil.getListOfFilesInFolder(Constants.PLUTO_DC_PATH, "");

			for (String eachPluto : plutoList) {
				PlutoDCVersionList plutoDetails = new PlutoDCVersionList();
				plutoDetails.setName(eachPluto);

				String rboInPlutoPath = Constants.PLUTO_DC_PATH + eachPluto + "/rbojars/";
				List<String> rboList = fileUtil.getListOfFilesInFolder(rboInPlutoPath, ".jar");
				plutoDetails.setRboVersionList(rboList);

				responseList.add(plutoDetails);
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in PlutoDCService Layer : " + e);
			throw e;
		}
		return responseList;
	}

	public List<PostProcessedJarList> getPostProcessedList() throws Exception {
		List<PostProcessedJarList> responseList = new ArrayList<>();
		try {

			FileHelper fileUtil = new FileHelper();
			List<String> jarList = fileUtil.getListOfFilesInFolder(Constants.POST_PROCESSED_RULE_JAR_PATH, ".jar");

			for (String eachJar : jarList) {
				PostProcessedJarList jarDetails = new PostProcessedJarList();
				jarDetails.setName(eachJar);
				
				responseList.add(jarDetails);
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in PlutoDCService Layer : " + e);
			throw e;
		}
		return responseList;
	}
//		CommonProcessResponse response = new CommonProcessResponse();
//		log.info("Method: doPostProcessing. Params -ruleJar, plutoDcVersion,rboVersion");
//
//		String ruleJar = request.getRuleJar();
//		String plutoDcVersion = request.getPlutoDCVersion();
//		String rboVersion = request.getRboVersion();
//		log.info("ruleJar: " + ruleJar);
//		log.info("plutoDcVersion: " + plutoDcVersion);
//		log.info("rboVersion: " + rboVersion);
//
//		try {
//			// 1. Write RBO Version in File
//			FileHelper fileUtil = new FileHelper();
//			String rboInPlutoPath = Constants.PLUTO_DC_PATH + plutoDcVersion + "/rbojars/";
//			try {
//				fileUtil.createAndWriteFile(rboInPlutoPath + "rboVersions.txt", rboVersion);
//				log.info("RBO Version file successfully updated.");
//			} catch (Exception e) {
//				e.printStackTrace();
//				response.setStatus("fail");
//				response.setMessage("Exection occured while updating RBO Version in Pluto DC.");
//				response.setLogTrace(e.getMessage());
//				log.error("Exection occured while updating RBO Version in Pluto DC : " + e);
//				return response;
//			}
//
//			// 2. Copy the Rule jar to PLuto Path
//			try {
//				String soruce = Constants.UPLOADED_RULE_JAR_PATH + ruleJar;
//				String dest = Constants.PLUTO_DC_PATH + plutoDcVersion + "/" + ruleJar;
//				fileUtil.copyFileFromSourceToDestination(soruce, dest);
//				log.info("Copy Jar from from Source to Pluto DC Path Success. ");
//			} catch (IOException e) {
//				response.setStatus("fail");
//				response.setMessage("Exection occured while moving the Rule jar to in Pluto DC Path.");
//				response.setLogTrace(e.getMessage());
//				log.error("Exection occured while moving the Rule jar to in Pluto DC Path : " + e);
//				return response;
//			}
//
//			// 3. Do Post Process by Jar Command
//			try {
//
//				String plutoDirectory = Constants.PLUTO_DC_PATH + plutoDcVersion + "/";
//				log.info("plutoDirectory : " + plutoDirectory);
//				String outputRuleJarName = ruleJar.split("\\.")[0];
//				String cmd = "java -jar " + plutoDcVersion + ".jar " + ruleJar + " " + outputRuleJarName + "_out.jar";
//
//				WindowsCommandExecutor winObj = new WindowsCommandExecutor();
//				log.info("Executing Java jar Command : " + cmd);
//
//				// For Testing Purpose uncomment below line and comment the call to
//				// 'executeWindowsCommand' in comming lines
//				// String cmdOutput = "RuleApp Archive Processing is finished for " +
//				// outputRuleJarName + "_out.jar";
//
//				String cmdOutput = winObj.executeWindowsCommand(plutoDirectory, cmd);
//				log.info("Executing Java jar Command Completed: " + cmd);
//
//				if (cmdOutput.equalsIgnoreCase("The system cannot find the path specified.")) {
//					log.error("The system cannot find the path specified. Post process failed.");
//					response.setStatus("fail");
//					response.setMessage("The system cannot find the path specified. Post process failed");
//					response.setLogTrace(cmdOutput);
//					return response;
//				} else if (cmdOutput
//						.contains("RuleApp Archive Processing is finished for " + outputRuleJarName + "_out.jar")) {
//					log.info("Post Processing Completed Successfully for " + outputRuleJarName + "_out.jar");
//
//					try {
//						log.info("Copying the post processed Rule Jar to the seperate Path before moving to server...");
//						String source = Constants.PLUTO_DC_PATH + plutoDcVersion + "/" + outputRuleJarName + "_out.jar";
//						String dest2 = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName + "_out.jar";
//						fileUtil.copyFileFromSourceToDestination(source, dest2);
//						log.info("Copy Postprocessed Jar from from Source to Pluto DC Path Success. ");
//					} catch (Exception e) {
//						e.printStackTrace();
//						log.info(
//								"Post Processing completed but process failed during transfering Post Proceesed jar. RuleApp Archive Processing is finished for "
//										+ outputRuleJarName + "_out.jar");
//						response.setStatus("fail");
//						response.setMessage(
//								"Post Processing completed but process failed during transfering Post Proceesed jar. RuleApp Archive Processing is finished for "
//										+ outputRuleJarName + "_out.jar");
//						response.setLogTrace(cmdOutput);
//						return response;
//					}
//
//					try {
//						log.info("Extracting the Postprocessed jar to create Text file in it...");
//						String srcJarPath = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName + "_out.jar";
//						String tgtExtractPath = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName + "_out\\";
//						fileUtil.extractJavaJar(srcJarPath, tgtExtractPath);
//						log.info("Jar Extraction completed! ");
//					} catch (Exception e) {
//						log.info(
//								"Post Processing completed but process failed during Post Proceesed jar Extraction. RuleApp Archive Processing is finished for "
//										+ outputRuleJarName + "_out.jar");
//						e.printStackTrace();
//						response.setStatus("fail");
//						response.setMessage(
//								"Post Processing completed but process failed during Post Proceesed jar Extraction. RuleApp Archive Processing is finished for "
//										+ outputRuleJarName + "_out.jar");
//						response.setLogTrace(cmdOutput);
//						return response;
//					}
//
//					log.info("Creating necessary text files in the extracted Postprocessed jar.");
//
//					try {
//						String rrds_creation_date = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
//								+ "_out\\riskresolutiondecisionserv\\1.0\\creation_date.txt";
//						String rrds_creation_date_Content = "1382337683694";
//						fileUtil.createAndWriteFile(rrds_creation_date, rrds_creation_date_Content);
//						log.info("File Name :  creation_date.txt | Component Name: riskresolutiondecisionserv");
//
//						String rrds_description = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
//								+ "_out\\riskresolutiondecisionserv\\1.0\\description.txt";
//						String rrds_description_Content = "DisputeInitiation";
//						fileUtil.createAndWriteFile(rrds_description, rrds_description_Content);
//						log.info("File Name :  description.txt | Component Name: riskresolutiondecisionserv");
//
//						String rrds_display_name = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
//								+ "_out\\riskresolutiondecisionserv\\1.0\\display_name.txt";
//						String rrds_display_name_Content = "riskresolutiondecisionserv";
//						fileUtil.createAndWriteFile(rrds_display_name, rrds_display_name_Content);
//						log.info("File Name :  display_name.txt | Component Name: riskresolutiondecisionserv");
//
//						String rrds_properties_name = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
//								+ "_out\\riskresolutiondecisionserv\\1.0\\properties.txt";
//						String rrds_properties_Content = "#Mon Aug 05 09:04:23 PDT 2013\nilog.rules.teamserver.baseline=20170419-13\nCOMPONENT_NAME=riskresolutiondecisionserv\nRULEAPP_XOM_VERSION=1.0\nilog.rules.teamserver.mode=deploy";
//						fileUtil.createAndWriteFile(rrds_properties_name, rrds_properties_Content);
//						log.info("File Name :  properties.txt | Component Name: riskresolutiondecisionserv");
//
//						String rrds_DLA_properties_name = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
//								+ "_out\\riskresolutiondecisionserv\\1.0\\DisputeLifecycleAdjudication\\1.0\\creation_date.txt";
//						String rrds_DLA_properties_Content = "1382337683694";
//						fileUtil.createAndWriteFile(rrds_DLA_properties_name, rrds_DLA_properties_Content);
//						log.info("File Name :  creation_date.txt | Component CP Name: DisputeLifecycleAdjudication");
//
//						String rrds_DLA_display_name = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
//								+ "_out\\riskresolutiondecisionserv\\1.0\\DisputeLifecycleAdjudication\\1.0\\display_name.txt";
//						String rrds_DLA_display_name_Content = "DisputeLifecycleAdjudication";
//						fileUtil.createAndWriteFile(rrds_DLA_display_name, rrds_DLA_display_name_Content);
//						log.info("File Name :  display_name.txt | Component CP Name: DisputeLifecycleAdjudication");
//
//						String rrds_DLA_properties = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
//								+ "_out\\riskresolutiondecisionserv\\1.0\\DisputeLifecycleAdjudication\\1.0\\properties.txt";
//						String rrds_DLA_propertiese_Content = "#Mon Aug 05 09:04:23 PDT 2013\nruleset.bom.enabled=true\nilog.rules.teamserver.permalink.project=http\\://phx-iloas-001\\:9080/teamserver/faces/home.jsp?project\\=RulePreTxn&baseline\\=20130802-16&locale\\=en_US&datasource\\=jdbc%2FilogDataSource\nilog.rules.teamserver.baseline=20130802-16\nilog.rules.teamserver.permalink.report=http\\://phx-iloas-001\\:9080/teamserver/faces/servlet/ReportingServlet?project\\=RulePreTxn&baseline\\=20130802-16&locale\\=en_US&datasource\\=jdbc%2FilogDataSource\nruleset.engine=cre\nruleset.debug.enabled=false\nruleset.status=enabled";
//						fileUtil.createAndWriteFile(rrds_DLA_properties, rrds_DLA_propertiese_Content);
//						log.info("File Name :  properties.txt | Component CP Name: DisputeLifecycleAdjudication");
//
//						String rrds_DLI_creation_date = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
//								+ "_out\\riskresolutiondecisionserv\\1.0\\DisputeLifecycleInitiation\\1.0\\creation_date.txt";
//						String rrds_DLI_creation_date_Content = "1382337683694";
//						fileUtil.createAndWriteFile(rrds_DLI_creation_date, rrds_DLI_creation_date_Content);
//						log.info("File Name :  creation_date.txt | Component CP Name: DisputeLifecycleInitiation");
//
//						String rrds_DLI_display_name = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
//								+ "_out\\riskresolutiondecisionserv\\1.0\\DisputeLifecycleInitiation\\1.0\\display_name.txt";
//						String rrds_DLI_display_name_Content = "DisputeLifecycleInitiation";
//						fileUtil.createAndWriteFile(rrds_DLI_display_name, rrds_DLI_display_name_Content);
//						log.info("File Name :  display_name.txt | Component CP Name: DisputeLifecycleInitiation");
//
//						String rrds_DLI_properties = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
//								+ "_out\\riskresolutiondecisionserv\\1.0\\DisputeLifecycleInitiation\\1.0\\properties.txt";
//						String rrds_DLI_properties_Content = "#Mon Aug 05 09:04:23 PDT 2013\nruleset.bom.enabled=true\nilog.rules.teamserver.permalink.project=http\\://phx-iloas-001\\:9080/teamserver/faces/home.jsp?project\\=RulePreTxn&baseline\\=20130802-16&locale\\=en_US&datasource\\=jdbc%2FilogDataSource\nilog.rules.teamserver.baseline=20130802-16\nilog.rules.teamserver.permalink.report=http\\://phx-iloas-001\\:9080/teamserver/faces/servlet/ReportingServlet?project\\=RulePreTxn&baseline\\=20130802-16&locale\\=en_US&datasource\\=jdbc%2FilogDataSource\nruleset.engine=cre\nruleset.debug.enabled=false\nruleset.status=enabled";
//						fileUtil.createAndWriteFile(rrds_DLI_properties, rrds_DLI_properties_Content);
//						log.info("File Name :  properties.txt | Component CP Name: DisputeLifecycleInitiation");
//						log.info("All Necessary file created successfully");
//						log.info("All Steps in Post Process completed successfully");
//
//						response.setStatus("success");
//						response.setMessage(
//								"Post Process, JAR Extarct, Property file creation completed successfully. RuleApp Archive Processing is finished for "
//										+ outputRuleJarName + "_out.jar");
//						response.setKey(outputRuleJarName + "_out.jar");
//						response.setLogTrace(cmdOutput);
//						return response;
//
//					} catch (Exception e) {
//						log.info(
//								"Post Processing completed but process failed during property file creation inside Extratced Rule Jar. RuleApp Archive Processing is finished for "
//										+ outputRuleJarName + "_out.jar");
//						e.printStackTrace();
//						response.setStatus("fail");
//						response.setMessage(
//								"Post Processing completed but process failed during property file creation inside Extratced Rule Jar. RuleApp Archive Processing is finished for "
//										+ outputRuleJarName + "_out.jar");
//						response.setLogTrace(cmdOutput);
//						return response;
//					}
//
//				} else {
//					log.info("Post Processing with given Rule Jar and RBO Version Completed with Errors.");
//					response.setStatus("fail");
//					response.setMessage("Post Processed Jar Completed with Errors : " + cmdOutput);
//					response.setLogTrace(cmdOutput);
//					return response;
//				}
//
//			} catch (Exception e) {
//				e.printStackTrace();
//				response.setStatus("fail");
//				response.setMessage("Exection occured while Executing Post processing - java jar command");
//				response.setLogTrace(e.getMessage());
//				log.error("Exection occured while Executing Post processing - java jar command : " + e);
//				return response;
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//			response.setStatus("fail");
//			response.setMessage("Exection occured during Post Processing");
//			response.setLogTrace(e.getMessage());
//			log.error("Exception occured in PlutoDCService Layer : " + e);
//		}
//
//		return response;
//	}

	public CommonProcessResponse doPostProcessing(PostProcessRequest request) {
		CommonProcessResponse response = new CommonProcessResponse();
		log.info("Method: doPostProcessing. Params -ruleJar, plutoDcVersion,rboVersion");
		log.info("DUmmy Response");


		String ruleJar = request.getRuleJar();
		String plutoDcVersion = request.getPlutoDCVersion();
		String rboVersion = request.getRboVersion();
		log.info("ruleJar: " + ruleJar);
		log.info("plutoDcVersion: " + plutoDcVersion);
		log.info("rboVersion: " + rboVersion);

		try {
			// 1. Write RBO Version in File
			FileHelper fileUtil = new FileHelper();
			String rboInPlutoPath = Constants.PLUTO_DC_PATH + plutoDcVersion + "/rbojars/";
			try {
				fileUtil.createAndWriteFile(rboInPlutoPath + "rboVersions.txt", rboVersion);
				log.info("RBO Version file successfully updated.");
			} catch (Exception e) {
				e.printStackTrace();
				response.setStatus("fail");
				response.setMessage("Exection occured while updating RBO Version in Pluto DC.");
				response.setLogTrace(e.getMessage());
				log.error("Exection occured while updating RBO Version in Pluto DC : " + e);
				return response;
			}

			// 2. Copy the Rule jar to PLuto Path
			try {
				String soruce = Constants.UPLOADED_RULE_JAR_PATH + ruleJar;
				String dest = Constants.PLUTO_DC_PATH + plutoDcVersion + "/" + ruleJar;
				fileUtil.copyFileFromSourceToDestination(soruce, dest);
				log.info("Copy Jar from from Source to Pluto DC Path Success. ");
			} catch (IOException e) {
				response.setStatus("fail");
				response.setMessage("Exection occured while moving the Rule jar to in Pluto DC Path.");
				response.setLogTrace(e.getMessage());
				log.error("Exection occured while moving the Rule jar to in Pluto DC Path : " + e);
				return response;
			}

			// 3. Do Post Process by Jar Command
			try {

				String plutoDirectory = Constants.PLUTO_DC_PATH + plutoDcVersion + "/";
				log.info("plutoDirectory : " + plutoDirectory);
				String outputRuleJarName = ruleJar.split("\\.")[0];
				String cmd = "java -jar " + plutoDcVersion + ".jar " + ruleJar + " " + outputRuleJarName + "_out.jar";

				WindowsCommandExecutor winObj = new WindowsCommandExecutor();
				log.info("Executing Java jar Command : " + cmd);

				// For Testing Purpose uncomment below line and comment the call to
				// 'executeWindowsCommand' in comming lines
				// String cmdOutput = "RuleApp Archive Processing is finished for " +
				// outputRuleJarName + "_out.jar";

				String cmdOutput = winObj.executeWindowsCommand(plutoDirectory, cmd);
				log.info("Executing Java jar Command Completed: " + cmd);

				if (cmdOutput.equalsIgnoreCase("The system cannot find the path specified.")) {
					log.error("The system cannot find the path specified. Post process failed.");
					response.setStatus("fail");
					response.setMessage("The system cannot find the path specified. Post process failed");
					response.setLogTrace(cmdOutput);
					return response;
				} else if (cmdOutput
						.contains("RuleApp Archive Processing is finished for " + outputRuleJarName + "_out.jar")) {
					log.info("Post Processing Completed Successfully for " + outputRuleJarName + "_out.jar");

					try {
						log.info("Copying the post processed Rule Jar to the seperate Path before moving to server...");
						String source = Constants.PLUTO_DC_PATH + plutoDcVersion + "/" + outputRuleJarName + "_out.jar";
						String dest2 = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName + "_out.jar";
						fileUtil.copyFileFromSourceToDestination(source, dest2);
						log.info("Copy Postprocessed Jar from from Source to Pluto DC Path Success. ");
					} catch (Exception e) {
						e.printStackTrace();
						log.info(
								"Post Processing completed but process failed during transfering Post Proceesed jar. RuleApp Archive Processing is finished for "
										+ outputRuleJarName + "_out.jar");
						response.setStatus("fail");
						response.setMessage(
								"Post Processing completed but process failed during transfering Post Proceesed jar. RuleApp Archive Processing is finished for "
										+ outputRuleJarName + "_out.jar");
						response.setLogTrace(cmdOutput);
						return response;
					}

					try {
						log.info("Extracting the Postprocessed jar to create Text file in it...");
						String srcJarPath = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName + "_out.jar";
						String tgtExtractPath = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName + "_out\\";
						fileUtil.extractJavaJar(srcJarPath, tgtExtractPath);
						log.info("Jar Extraction completed! ");
					} catch (Exception e) {
						log.info(
								"Post Processing completed but process failed during Post Proceesed jar Extraction. RuleApp Archive Processing is finished for "
										+ outputRuleJarName + "_out.jar");
						e.printStackTrace();
						response.setStatus("fail");
						response.setMessage(
								"Post Processing completed but process failed during Post Proceesed jar Extraction. RuleApp Archive Processing is finished for "
										+ outputRuleJarName + "_out.jar");
						response.setLogTrace(cmdOutput);
						return response;
					}

					log.info("Creating necessary text files in the extracted Postprocessed jar.");

					try {
						String rrds_creation_date = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
								+ "_out\\riskresolutiondecisionserv\\1.0\\creation_date.txt";
						String rrds_creation_date_Content = "1382337683694";
						fileUtil.createAndWriteFile(rrds_creation_date, rrds_creation_date_Content);
						log.info("File Name :  creation_date.txt | Component Name: riskresolutiondecisionserv");

						String rrds_description = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
								+ "_out\\riskresolutiondecisionserv\\1.0\\description.txt";
						String rrds_description_Content = "DisputeInitiation";
						fileUtil.createAndWriteFile(rrds_description, rrds_description_Content);
						log.info("File Name :  description.txt | Component Name: riskresolutiondecisionserv");

						String rrds_display_name = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
								+ "_out\\riskresolutiondecisionserv\\1.0\\display_name.txt";
						String rrds_display_name_Content = "riskresolutiondecisionserv";
						fileUtil.createAndWriteFile(rrds_display_name, rrds_display_name_Content);
						log.info("File Name :  display_name.txt | Component Name: riskresolutiondecisionserv");

						String rrds_properties_name = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
								+ "_out\\riskresolutiondecisionserv\\1.0\\properties.txt";
						String rrds_properties_Content = "#Mon Aug 05 09:04:23 PDT 2013\nilog.rules.teamserver.baseline=20170419-13\nCOMPONENT_NAME=riskresolutiondecisionserv\nRULEAPP_XOM_VERSION=1.0\nilog.rules.teamserver.mode=deploy";
						fileUtil.createAndWriteFile(rrds_properties_name, rrds_properties_Content);
						log.info("File Name :  properties.txt | Component Name: riskresolutiondecisionserv");

						String rrds_DLA_properties_name = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
								+ "_out\\riskresolutiondecisionserv\\1.0\\DisputeLifecycleAdjudication\\1.0\\creation_date.txt";
						String rrds_DLA_properties_Content = "1382337683694";
						fileUtil.createAndWriteFile(rrds_DLA_properties_name, rrds_DLA_properties_Content);
						log.info("File Name :  creation_date.txt | Component CP Name: DisputeLifecycleAdjudication");

						String rrds_DLA_display_name = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
								+ "_out\\riskresolutiondecisionserv\\1.0\\DisputeLifecycleAdjudication\\1.0\\display_name.txt";
						String rrds_DLA_display_name_Content = "DisputeLifecycleAdjudication";
						fileUtil.createAndWriteFile(rrds_DLA_display_name, rrds_DLA_display_name_Content);
						log.info("File Name :  display_name.txt | Component CP Name: DisputeLifecycleAdjudication");

						String rrds_DLA_properties = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
								+ "_out\\riskresolutiondecisionserv\\1.0\\DisputeLifecycleAdjudication\\1.0\\properties.txt";
						String rrds_DLA_propertiese_Content = "#Mon Aug 05 09:04:23 PDT 2013\nruleset.bom.enabled=true\nilog.rules.teamserver.permalink.project=http\\://phx-iloas-001\\:9080/teamserver/faces/home.jsp?project\\=RulePreTxn&baseline\\=20130802-16&locale\\=en_US&datasource\\=jdbc%2FilogDataSource\nilog.rules.teamserver.baseline=20130802-16\nilog.rules.teamserver.permalink.report=http\\://phx-iloas-001\\:9080/teamserver/faces/servlet/ReportingServlet?project\\=RulePreTxn&baseline\\=20130802-16&locale\\=en_US&datasource\\=jdbc%2FilogDataSource\nruleset.engine=cre\nruleset.debug.enabled=false\nruleset.status=enabled";
						fileUtil.createAndWriteFile(rrds_DLA_properties, rrds_DLA_propertiese_Content);
						log.info("File Name :  properties.txt | Component CP Name: DisputeLifecycleAdjudication");

						String rrds_DLI_creation_date = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
								+ "_out\\riskresolutiondecisionserv\\1.0\\DisputeLifecycleInitiation\\1.0\\creation_date.txt";
						String rrds_DLI_creation_date_Content = "1382337683694";
						fileUtil.createAndWriteFile(rrds_DLI_creation_date, rrds_DLI_creation_date_Content);
						log.info("File Name :  creation_date.txt | Component CP Name: DisputeLifecycleInitiation");

						String rrds_DLI_display_name = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
								+ "_out\\riskresolutiondecisionserv\\1.0\\DisputeLifecycleInitiation\\1.0\\display_name.txt";
						String rrds_DLI_display_name_Content = "DisputeLifecycleInitiation";
						fileUtil.createAndWriteFile(rrds_DLI_display_name, rrds_DLI_display_name_Content);
						log.info("File Name :  display_name.txt | Component CP Name: DisputeLifecycleInitiation");

						String rrds_DLI_properties = Constants.POST_PROCESSED_RULE_JAR_PATH + outputRuleJarName
								+ "_out\\riskresolutiondecisionserv\\1.0\\DisputeLifecycleInitiation\\1.0\\properties.txt";
						String rrds_DLI_properties_Content = "#Mon Aug 05 09:04:23 PDT 2013\nruleset.bom.enabled=true\nilog.rules.teamserver.permalink.project=http\\://phx-iloas-001\\:9080/teamserver/faces/home.jsp?project\\=RulePreTxn&baseline\\=20130802-16&locale\\=en_US&datasource\\=jdbc%2FilogDataSource\nilog.rules.teamserver.baseline=20130802-16\nilog.rules.teamserver.permalink.report=http\\://phx-iloas-001\\:9080/teamserver/faces/servlet/ReportingServlet?project\\=RulePreTxn&baseline\\=20130802-16&locale\\=en_US&datasource\\=jdbc%2FilogDataSource\nruleset.engine=cre\nruleset.debug.enabled=false\nruleset.status=enabled";
						fileUtil.createAndWriteFile(rrds_DLI_properties, rrds_DLI_properties_Content);
						log.info("File Name :  properties.txt | Component CP Name: DisputeLifecycleInitiation");
						log.info("All Necessary file created successfully");
						log.info("All Steps in Post Process completed successfully");

						response.setStatus("success");
						response.setMessage(
								"Post Process, JAR Extarct, Property file creation completed successfully. RuleApp Archive Processing is finished for "
										+ outputRuleJarName + "_out.jar");
						response.setKey(outputRuleJarName + "_out.jar");
						response.setLogTrace(cmdOutput);
						return response;

					} catch (Exception e) {
						log.info(
								"Post Processing completed but process failed during property file creation inside Extratced Rule Jar. RuleApp Archive Processing is finished for "
										+ outputRuleJarName + "_out.jar");
						e.printStackTrace();
						response.setStatus("fail");
						response.setMessage(
								"Post Processing completed but process failed during property file creation inside Extratced Rule Jar. RuleApp Archive Processing is finished for "
										+ outputRuleJarName + "_out.jar");
						response.setLogTrace(cmdOutput);
						return response;
					}

				} else {
					log.info("Post Processing with given Rule Jar and RBO Version Completed with Errors.");
					response.setStatus("fail");
					response.setMessage("Post Processed Jar Completed with Errors : " + cmdOutput);
					response.setLogTrace(cmdOutput);
					return response;
				}

			} catch (Exception e) {
				e.printStackTrace();
				response.setStatus("fail");
				response.setMessage("Exection occured while Executing Post processing - java jar command");
				response.setLogTrace(e.getMessage());
				log.error("Exection occured while Executing Post processing - java jar command : " + e);
				return response;
			}

		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus("fail");
			response.setMessage("Exection occured during Post Processing");
			response.setLogTrace(e.getMessage());
			log.error("Exception occured in PlutoDCService Layer : " + e);
		}

		return response;
	}

	
	public static void main(String[] args) throws Exception {
//		PlutoDCService obj = new PlutoDCService();
//		log.info(obj.getPlutoDcListWithRboList());
		//String filename = "dispute_20180828_170000_riskresolutiondecisionserv.jar";
		//String extensionRemoved = filename.split("\\.")[0];
		
		PlutoDCService obj = new PlutoDCService();
		//obj.getPlutoDcPostProcessedList();
		System.out.println(obj.getPostProcessedList().toString());
	}

}
