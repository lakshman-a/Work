package com.paypal.test.rule.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class StageSettingAPIRequest {

	private String trigger_id;
	private String logger_level;
	private String file_based_flag;
	private String component;
	private String created_by;
	private String created_tmstmp;
	private String status;
	private String log_trace;

	public String getTrigger_id() {
		return trigger_id;
	}

	public void setTrigger_id(String trigger_id) {
		this.trigger_id = trigger_id;
	}

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getCreated_tmstmp() {
		return created_tmstmp;
	}

	public void setCreated_tmstmp(String created_tmstmp) {
		this.created_tmstmp = created_tmstmp;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getLog_trace() {
		return log_trace;
	}

	public void setLog_trace(String log_trace) {
		this.log_trace = log_trace;
	}

	public String getLogger_level() {
		return logger_level;
	}

	public void setLogger_level(String logger_level) {
		this.logger_level = logger_level;
	}

	public String getFile_based_flag() {
		return file_based_flag;
	}

	public void setFile_based_flag(String file_based_flag) {
		this.file_based_flag = file_based_flag;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
