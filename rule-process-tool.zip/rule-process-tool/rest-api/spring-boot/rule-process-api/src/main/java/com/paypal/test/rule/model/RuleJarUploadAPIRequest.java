package com.paypal.test.rule.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class RuleJarUploadAPIRequest {

	private String trigger_id;

	public String getTrigger_id() {
		return trigger_id;
	}

	public void setTrigger_id(String trigger_id) {
		this.trigger_id = trigger_id;
	}

	public String getRule_jar_name() {
		return rule_jar_name;
	}

	public void setRule_jar_name(String rule_jar_name) {
		this.rule_jar_name = rule_jar_name;
	}

	public String getRule_jar_desc() {
		return rule_jar_desc;
	}

	public void setRule_jar_desc(String rule_jar_desc) {
		this.rule_jar_desc = rule_jar_desc;
	}

	public String getRule_jar_file_name() {
		return rule_jar_file_name;
	}

	public void setRule_jar_file_name(String rule_jar_file_name) {
		this.rule_jar_file_name = rule_jar_file_name;
	}

	public String getRule_jar_location() {
		return rule_jar_location;
	}

	public void setRule_jar_location(String rule_jar_location) {
		this.rule_jar_location = rule_jar_location;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getCreated_tmstmp() {
		return created_tmstmp;
	}

	public void setCreated_tmstmp(String created_tmstmp) {
		this.created_tmstmp = created_tmstmp;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getLog_trace() {
		return log_trace;
	}

	public void setLog_trace(String log_trace) {
		this.log_trace = log_trace;
	}

	private String rule_jar_name;
	private String rule_jar_desc;
	private String rule_jar_file_name;
	private String rule_jar_location;
	private String created_by;
	private String created_tmstmp;
	private String status;
	private String log_trace;

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	
}
