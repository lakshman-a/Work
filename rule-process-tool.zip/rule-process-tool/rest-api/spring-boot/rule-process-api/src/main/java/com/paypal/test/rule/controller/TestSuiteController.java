package com.paypal.test.rule.controller;

import java.util.List;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.paypal.test.rule.helper.HeaderValidator;
import com.paypal.test.rule.model.CommonServiceResponse;
import com.paypal.test.rule.model.TestSuite;
import com.paypal.test.rule.model.TestSuitesAndCasesList;
import com.paypal.test.rule.service.TestSuiteService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("api")
public class TestSuiteController {
	final static Logger log = Logger.getLogger(TestSuiteController.class);
	TestSuiteService service = new TestSuiteService();
	HeaderValidator validator = new HeaderValidator();

	// ------------- GET ALL ------------------//
	@RequestMapping(value = "/testSuiteList", method = RequestMethod.GET, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<TestSuite>> getAllData(
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to Service : testSuiteList - All Data");

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		List<TestSuite> list;
		try {
			list = this.service.getAllData();
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Check if any Exception, then throw 500
		if (Objects.isNull(list))
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		log.info("Response to Service : [ " + list + " ]");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	// ------------- GET SINGLE CASE ------------------//
	@RequestMapping(value = "/testsuite", method = RequestMethod.GET, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<TestSuite> getData(@RequestParam(value="suiteName",required=true) String input,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to Service : TestSuite - All Data");

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		TestSuite list;
		try {
			list = this.service.getData(input);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Check if any Exception, then throw 500
		if (Objects.isNull(list))
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		log.info("Response to Service : [ " + list + " ]");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	// ------------- GET CASE AND ACTIONS LIST ------------------//
	@RequestMapping(value = "/testSuiteAndCases", method = RequestMethod.GET, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<TestSuitesAndCasesList> getListData(
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to Service : TestActions - All Data");

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		TestSuitesAndCasesList list;
		try {
			list = this.service.getListData();
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Check if any Exception, then throw 500
		if (Objects.isNull(list))
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		log.info("Response to Service : [ " + list + " ]");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	// ------------- POST ------------------//
	@RequestMapping(value = "/testSuite", method = RequestMethod.POST, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonServiceResponse> addData(@RequestBody final TestSuite body,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to PUT Service : MainModules - Data - '" + body + "'");
		String action = "INSERT";

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		CommonServiceResponse response;
		try {
			response = this.service.modifyData(action, body);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	// ------------- PUT ------------------//
	@RequestMapping(value = "/testSuite", method = RequestMethod.PUT, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonServiceResponse> updateData(@RequestBody final TestSuite body,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to PUT Service : MainModules - Data - '" + body + "'");
		String action = "UPDATE";

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		CommonServiceResponse response;
		try {
			response = this.service.modifyData(action, body);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	// ------------- DELETE ------------------//
	@RequestMapping(value = "/testSuite", method = RequestMethod.DELETE, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonServiceResponse> deleteData(@RequestBody final TestSuite body,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to DELETE Service : MainModules - Data - '" + body + "'");
		String action = "DELETE";

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		CommonServiceResponse response;
		try {
			response = this.service.modifyData(action, body);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
