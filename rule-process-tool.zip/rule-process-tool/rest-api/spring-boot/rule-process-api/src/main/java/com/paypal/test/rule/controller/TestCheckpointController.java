package com.paypal.test.rule.controller;

import java.util.List;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.paypal.test.rule.helper.HeaderValidator;
import com.paypal.test.rule.model.CommonServiceResponse;
import com.paypal.test.rule.model.TestCheckpoints;
import com.paypal.test.rule.service.TestCheckpointService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("api")
public class TestCheckpointController {
	final static Logger log = Logger.getLogger(TestCheckpointController.class);
	TestCheckpointService service = new TestCheckpointService();
	HeaderValidator validator = new HeaderValidator();

	// ------------- GET ALL ------------------//
	@RequestMapping(value = "/testCheckpoints", method = RequestMethod.GET, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<TestCheckpoints>> getAllData(@RequestParam(value = "projectName", required = true) String projectName,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to Service : TestCheckpoints - All Data");

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		List<TestCheckpoints> list;
		try {
			list = this.service.getAllData(projectName);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Check if any Exception, then throw 500
		if (Objects.isNull(list))
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		log.info("Response to Service : [ " + list + " ]");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	// ------------- GET ALL ------------------//
	@RequestMapping(value = "/testCheckpointOfComp", method = RequestMethod.GET, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<TestCheckpoints>> getAllDataOfComponent(@RequestParam(value = "componentName", required = true) String componentName,
			@RequestParam(value = "projectName", required = true) String projectName,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to Service : TestCheckpoints - All Data");

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		List<TestCheckpoints> list;
		try {
			list = this.service.getAllDataWithCheckPoint(componentName, projectName);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Check if any Exception, then throw 500
		if (Objects.isNull(list))
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		log.info("Response to Service : [ " + list + " ]");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@RequestMapping(value = "/testCheckpoint", method = RequestMethod.GET, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<TestCheckpoints> getData(@RequestParam(value = "checkpointName", required = true) String checkpointName,
			@RequestParam(value = "componentName", required = true) String componentName,
			@RequestParam(value = "projectName", required = true) String projectName,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to Service : TestCheckpoints - All Data");

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		TestCheckpoints list;
		try {
			list = this.service.getData(checkpointName, componentName, projectName);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Check if any Exception, then throw 500
		if (Objects.isNull(list))
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		log.info("Response to Service : [ " + list + " ]");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	// ------------- POST ------------------//
	@RequestMapping(value = "/testCheckpoint", method = RequestMethod.POST, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonServiceResponse> addData(@RequestBody final TestCheckpoints body,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to PUT Service : MainModules - Data - '" + body + "'");
		String action = "INSERT";

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		CommonServiceResponse response;
		try {
			response = this.service.modifyData(action, body);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	// ------------- PUT ------------------//
	@RequestMapping(value = "/testCheckpoint", method = RequestMethod.PUT, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonServiceResponse> updateData(@RequestBody final TestCheckpoints body,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to PUT Service : MainModules - Data - '" + body + "'");
		String action = "UPDATE";

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		CommonServiceResponse response;
		try {
			response = this.service.modifyData(action, body);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	// ------------- DELETE ------------------//
	@RequestMapping(value = "/testCheckpoint", method = RequestMethod.DELETE, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonServiceResponse> deleteData(@RequestBody final TestCheckpoints body,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to DELETE Service : MainModules - Data - '" + body + "'");
		String action = "DELETE";

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		CommonServiceResponse response;
		try {
			response = this.service.modifyData(action, body);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
