package com.paypal.test.rule.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import com.paypal.test.rule.helper.MysqlDbHelper;
import com.paypal.test.rule.model.CommonServiceResponse;
import com.paypal.test.rule.model.TestCaseDetails;
import com.paypal.test.rule.model.TestCasesAndActionsList;

public class TestCaseService {
	MysqlDbHelper sql = new MysqlDbHelper();
	final static Logger log = Logger.getLogger(TestCaseService.class);

	public List<TestCaseDetails> getAllData(String projectName) throws Exception {
		List<TestCaseDetails> responseList = new ArrayList<>();
		try {
			String query = "SELECT * FROM rule_process.test_cases where project_name='" + projectName + "' order by id desc";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				for (HashMap<String, Object> hashMap : resultHash) {
					TestCaseDetails eachItem = new TestCaseDetails();
					eachItem.setId(hashMap.get("id").toString());
					eachItem.setCaseName(hashMap.get("test_case_name").toString());
					eachItem.setCaseSummary(hashMap.get("test_case_summary").toString());
					eachItem.setCaseSteps(hashMap.get("test_case_desc"));
					// eachItem.setModuleName(hashMap.get("module_name"));
					// eachItem.setSubModuleName(hashMap.get("sub_module"));
					eachItem.setComponentName(hashMap.get("component_name").toString());
					eachItem.setCheckpointName(hashMap.get("checkpoint_name"));
					eachItem.setProjectName(hashMap.get("project_name").toString());

					eachItem.setStage(hashMap.get("stage"));
					eachItem.setComplexity(hashMap.get("test_complex"));
					eachItem.setIsAutomationCase(hashMap.get("is_automation").toString());
					eachItem.setRunMode(hashMap.get("test_run_mode").toString());
					eachItem.setIsRuleBased(hashMap.get("is_rule_based").toString());
					if (hashMap.get("is_test_data_avail") != null) {
						eachItem.setIsTestDataAvailable(hashMap.get("is_test_data_avail").toString());
					}

					eachItem.setActive(hashMap.get("active").toString());
					eachItem.setCreated_tmstmp(hashMap.get("created_tmstmp").toString());
					eachItem.setCreated_by(hashMap.get("created_by").toString());
					eachItem.setUpdated_tmstmp(hashMap.get("updated_tmstmp").toString());
					eachItem.setUpdated_by(hashMap.get("updated_by").toString());
					responseList.add(eachItem);
				}
			} else if (resultHash.size() == 0) {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return responseList;
	}

	public TestCaseDetails getData(String projectName, String data) throws Exception {
		TestCaseDetails response = new TestCaseDetails();
		try {
			String query = "SELECT * FROM rule_process.test_cases where project_name='" + projectName + "' and test_case_name = '" + data + "'";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				for (HashMap<String, Object> hashMap : resultHash) {
					TestCaseDetails eachItem = new TestCaseDetails();
					eachItem.setId(hashMap.get("id").toString());
					eachItem.setCaseName(hashMap.get("test_case_name").toString());
					eachItem.setCaseSummary(hashMap.get("test_case_summary").toString());
					eachItem.setCaseSteps(hashMap.get("test_case_desc"));
					// eachItem.setModuleName(hashMap.get("module_name"));
					// eachItem.setSubModuleName(hashMap.get("sub_module"));
					eachItem.setComponentName(hashMap.get("component_name").toString());
					eachItem.setCheckpointName(hashMap.get("checkpoint_name"));
					eachItem.setProjectName(hashMap.get("project_name").toString());
					eachItem.setStage(hashMap.get("stage"));
					eachItem.setComplexity(hashMap.get("test_complex"));
					eachItem.setIsAutomationCase(hashMap.get("is_automation").toString());
					eachItem.setRunMode(hashMap.get("test_run_mode").toString());
					eachItem.setIsRuleBased(hashMap.get("is_rule_based").toString());
					// eachItem.setIsEndToEndCase(hashMap.get("is_end_to_end").toString());
					if (hashMap.get("is_test_data_avail") != null) {
						eachItem.setIsTestDataAvailable(hashMap.get("is_test_data_avail").toString());
					}
					eachItem.setActive(hashMap.get("active").toString());
					eachItem.setCreated_tmstmp(hashMap.get("created_tmstmp").toString());
					eachItem.setCreated_by(hashMap.get("created_by").toString());
					eachItem.setUpdated_tmstmp(hashMap.get("updated_tmstmp").toString());
					eachItem.setUpdated_by(hashMap.get("updated_by").toString());
				}
			} else if (resultHash.size() == 0) {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return response;
	}

	public TestCasesAndActionsList getListData(String projectName) throws Exception {
		TestCasesAndActionsList response = new TestCasesAndActionsList();
		try {
			String query = "SELECT test_case_name FROM rule_process.test_cases where active = 'true' and project_name='" + projectName + "'";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				Set<String> eachItem = new TreeSet<>();
				for (HashMap<String, Object> hashMap : resultHash) {
					eachItem.add(hashMap.get("test_case_name").toString());
				}
				response.setTestCases(eachItem);
			} else if (resultHash.size() == 0) {
				response.setTestCases(null);
			}

			String query2 = "SELECT action_name FROM rule_process.test_action where active = 'true'and project_name='" + projectName + "'";
			List<HashMap<String, Object>> resultHash2 = sql.executeSelect(query2);

			if (resultHash2.size() > 0) {
				Set<String> eachItem = new TreeSet<>();
				for (HashMap<String, Object> hashMap : resultHash2) {
					eachItem.add(hashMap.get("action_name").toString());
				}
				response.setTestActions(eachItem);
			} else if (resultHash2.size() == 0) {
				response.setTestActions(null);
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return response;
	}

	public CommonServiceResponse modifyData(String action, final TestCaseDetails data) throws Exception {
		CommonServiceResponse response = new CommonServiceResponse();
		String query = null;
		Connection conn = null;
		Statement stmt = null;
		PreparedStatement preparedStmt = null;

		try {
			String jdbcClass = "com.mysql.jdbc.Driver";
			String connectionHostPort = "localhost";
			String schema = "atom";
			String sqlUser = "root";
			String sqlPwd = "root";

			// Load Classname and connection URL
			Class.forName(jdbcClass);
			String connectionUrl = "jdbc:mysql://" + connectionHostPort + "/" + schema + "";

			// Set SQL Properties
			Properties properties = new Properties();
			properties.setProperty("user", sqlUser);
			properties.setProperty("password", sqlPwd);
			properties.setProperty("useSSL", "true");
			properties.setProperty("autoReconnect", "true");
			properties.setProperty("verifyServerCertificate", "false");

			// Create Connection
			conn = DriverManager.getConnection(connectionUrl, properties);
			conn.setAutoCommit(false);
			conn.rollback();

			switch (action.toLowerCase()) {
			case "insert":

				query = "INSERT INTO rule_process.test_cases (`test_case_name`, `test_case_summary`, `test_case_desc`, `component_name`, `checkpoint_name`, "
						+ "`stage`, `test_complex`, `is_automation`, `test_run_mode`, `is_rule_based`,`is_test_data_avail`,`test_data_keys`,`test_data`, "
						+ "`active`, `created_by`, `updated_by`,`project_name`) " + "VALUES " + "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?)";

				preparedStmt = conn.prepareStatement(query);
				preparedStmt.setString(1, data.getCaseName());
				preparedStmt.setObject(2, data.getCaseSummary());
				preparedStmt.setObject(3, data.getCaseSteps());
				preparedStmt.setString(4, data.getComponentName());
				preparedStmt.setObject(5, data.getCheckpointName());
				preparedStmt.setObject(6, data.getStage());
				preparedStmt.setString(7, data.getComplexity().toString());
				preparedStmt.setString(8, data.getIsAutomationCase());
				preparedStmt.setString(9, data.getRunMode());
				preparedStmt.setString(10, data.getIsRuleBased().toString());
				preparedStmt.setString(11, data.getIsTestDataAvailable().toString());
				preparedStmt.setString(12, data.getTestDataColumns().toString());
				preparedStmt.setString(13, data.getTestDataValues().toString());
				preparedStmt.setString(14, data.getActive().toString());
				preparedStmt.setString(15, data.getCreated_by().toString());
				preparedStmt.setString(16, data.getUpdated_by().toString());
				preparedStmt.setString(17, data.getProjectName().toString());

				break;

			case "update":
				query = "UPDATE rule_process.test_cases set test_case_summary=?, test_case_desc=?,component_name=?,checkpoint_name=?,stage=?,test_complex=?,is_automation=?,"
						+ "test_run_mode=?,is_rule_based=?,active=?,updated_by=? where test_case_name =? and project_name=?";

				preparedStmt = conn.prepareStatement(query);

				preparedStmt.setObject(1, data.getCaseSummary());
				preparedStmt.setObject(2, data.getCaseSteps());
				preparedStmt.setString(3, data.getComponentName());
				preparedStmt.setObject(4, data.getCheckpointName());
				preparedStmt.setObject(5, data.getStage());
				preparedStmt.setString(6, data.getComplexity().toString());
				preparedStmt.setString(7, data.getIsAutomationCase());
				preparedStmt.setString(8, data.getRunMode());
				preparedStmt.setString(9, data.getIsRuleBased().toString());
				// preparedStmt.setString(10, data.getIsEndToEndCase().toString());
				// preparedStmt.setString(11, data.getIsTestDataAvailable().toString());
				preparedStmt.setString(10, data.getActive().toString());
				preparedStmt.setString(11, data.getUpdated_by().toString());
				preparedStmt.setString(12, data.getCaseName());
				preparedStmt.setString(13, data.getProjectName());

				break;

			case "delete":
				query = "DELETE FROM rule_process.test_cases where test_case_name=? and project_name=?";
				preparedStmt = conn.prepareStatement(query);

				preparedStmt.setString(1, data.getCaseName());
				preparedStmt.setString(2, data.getProjectName());
				break;

			default:
				log.error("Invalid Action choosen!");
				throw new Exception("Invalid Action choosen. Choose one of the following action : INSERT/UPDATE/DELETE");
			}

			log.info("Executing Update/Delete Query : [ " + query + " ]");

			int count = preparedStmt.executeUpdate();
			conn.commit();

			log.info("Count of Rows Updated/Deleted Successfully : [ " + count + " ]");
			if (count > 0) {
				response.setKey(data.getCaseName().toString());
				// response.setName(data.getSubModuleName().toString());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully");
				response.setCode("200");

			} else if (count == 0) {
				response.setKey(data.getCaseName().toString());
				// response.setName(data.getSubModuleName().toString());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully. No Rows Affected");
				response.setCode("201");

			}

		} catch (SQLIntegrityConstraintViolationException e) {
			e.printStackTrace();
			log.error("SQLIntegrityConstraintViolationException occured while executing Update/Delete Query - " + e.getMessage());
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getCaseName().toString());
			// response.setName(data.getSubModuleName().toString());
			response.setAction(action);
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to SQL Contraint Error - "+e.getMessage());
			response.setCode("500");

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("SQL Exception occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getCaseName().toString());
			// response.setName(data.getSubModuleName().toString());
			response.setAction(action);
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to SQL Exception : "+e.getMessage());
			response.setCode("500");

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Common Exception occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getCaseName().toString());
			// response.setName(data.getSubModuleName().toString());
			response.setAction(action);
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to Common Exception : " +e.getMessage());
			response.setCode("500");

		} finally {
			if (conn != null) {
				conn.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}

		return response;
	}


}
