package com.paypal.test.rule.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class ProjectDetails {

	private String id;
	private String project_name;
	private Object project_desc;
	private String active;
	private String created_tmstmp;
	private String created_by;
	private String updated_tmstmp;
	private String updated_by;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProject_name() {
		return project_name;
	}

	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}

	public Object getProject_desc() {
		return project_desc;
	}

	public void setProject_desc(Object project_desc) {
		this.project_desc = project_desc;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getCreated_tmstmp() {
		return created_tmstmp;
	}

	public void setCreated_tmstmp(String created_tmstmp) {
		this.created_tmstmp = created_tmstmp;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getUpdated_tmstmp() {
		return updated_tmstmp;
	}

	public void setUpdated_tmstmp(String updated_tmstmp) {
		this.updated_tmstmp = updated_tmstmp;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
