package com.paypal.test.rule.controller;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.paypal.test.rule.helper.HeaderValidator;
import com.paypal.test.rule.model.CommonServiceResponse;
import com.paypal.test.rule.model.PostProcessActionAPIRequest;
import com.paypal.test.rule.model.RuleJarUploadAPIRequest;
import com.paypal.test.rule.model.StageProcessAPIRequest;
import com.paypal.test.rule.model.StageSettingAPIRequest;
import com.paypal.test.rule.service.PostProcessDeployService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("api")
public class PostProcessDeployController {
	final static Logger log = Logger.getLogger(PostProcessDeployController.class);
	PostProcessDeployService service = new PostProcessDeployService();
	HeaderValidator validator = new HeaderValidator();

	/*
	 * // ------------- GET ALL ------------------//
	 * 
	 * @RequestMapping(value = "/mainmodules", method = RequestMethod.GET, produces
	 * = org.springframework.http.MediaType.APPLICATION_JSON_VALUE) public
	 * ResponseEntity<List<MainModule>> getAllData(
	 * 
	 * @RequestHeader(value = "accept", required = true) String acceptHeader,
	 * 
	 * @RequestHeader(value = "authorization", required = true) String authToken) {
	 * log.info("Request to Service : MainModules - All Data");
	 * 
	 * // Header Validation HttpStatus headerValidityCode =
	 * validator.validateCommonHeader(acceptHeader, authToken); if
	 * (headerValidityCode != HttpStatus.OK) { return new
	 * ResponseEntity<>(headerValidityCode); }
	 * 
	 * // Get Data from Service Layer List<MainModule> list; try { list =
	 * this.service.getAllData(); } catch (Exception e) { return new
	 * ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR); }
	 * 
	 * // Check if any Exception, then throw 500 if (Objects.isNull(list)) return
	 * new ResponseEntity<>(HttpStatus.NO_CONTENT);
	 * 
	 * log.info("Response to Service : [ " + list + " ]"); return new
	 * ResponseEntity<>(list, HttpStatus.OK); }
	 * 
	 * // ------------- GET ------------------//
	 * 
	 * @RequestMapping(value = "/mainmodule/{input}", method = RequestMethod.GET,
	 * produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE) public
	 * ResponseEntity<MainModule> getData(@PathVariable("input") String input,
	 * 
	 * @RequestHeader(value = "accept", required = true) String acceptHeader,
	 * 
	 * @RequestHeader(value = "authorization", required = true) String authToken) {
	 * log.info("Request to Service : MainModules - Single Data - '" + input + "'");
	 * 
	 * // Header Validation HttpStatus headerValidityCode =
	 * validator.validateCommonHeader(acceptHeader, authToken); if
	 * (headerValidityCode != HttpStatus.OK) { return new
	 * ResponseEntity<>(headerValidityCode); }
	 * 
	 * // Get Data from Service Layer MainModule list; try { list =
	 * this.service.getSingleData(input); } catch (Exception e) { return new
	 * ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR); }
	 * 
	 * // Check if any Exception, then throw 500 if (Objects.isNull(list)) return
	 * new ResponseEntity<>(HttpStatus.NO_CONTENT);
	 * 
	 * log.info("Response to Service : [ " + list + " ]"); return new
	 * ResponseEntity<>(list, HttpStatus.OK); }
	 */

	// ------------- POST ------------------//
	@RequestMapping(value = "/ruleJarUpload", method = RequestMethod.POST, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonServiceResponse> addData(@RequestBody final RuleJarUploadAPIRequest body,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to POST Service : ruleJarUpload - Data - '" + body + "'");
		String action = "INSERT";

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		CommonServiceResponse response;
		try {
			response = this.service.modifyData(action, body);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	// ------------- POST ------------------//
	@RequestMapping(value = "/postProcessAction", method = RequestMethod.POST, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonServiceResponse> postProcessActionData(
			@RequestBody final PostProcessActionAPIRequest body,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to POST Service : ruleJarUpload - Data - '" + body + "'");
		String action = "INSERT";

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		CommonServiceResponse response;
		try {
			response = this.service.modifyPlutoDCData(action, body);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	// ------------- POST ------------------//
	@RequestMapping(value = "/stageProcess", method = RequestMethod.POST, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonServiceResponse> stageConnActionData(@RequestBody final StageProcessAPIRequest body,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to POST Service : ruleJarUpload - Data - '" + body + "'");
		String action = "INSERT";

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		CommonServiceResponse response;
		try {
			response = this.service.modifyStageConnData(action, body);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	// ------------- POST ------------------//
		@RequestMapping(value = "/stageSettings", method = RequestMethod.POST, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<CommonServiceResponse> stageSettingsActionData(@RequestBody final StageSettingAPIRequest body,
				@RequestHeader(value = "accept", required = true) String acceptHeader,
				@RequestHeader(value = "authorization", required = true) String authToken) {
			log.info("Request to POST Service : ruleJarUpload - Data - '" + body + "'");
			String action = "INSERT";

			// Header Validation
			HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
			if (headerValidityCode != HttpStatus.OK) {
				return new ResponseEntity<>(headerValidityCode);
			}

			// Get Data from Service Layer
			CommonServiceResponse response;
			try {
				response = this.service.modifyStageSettingData(action, body);
			} catch (Exception e) {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}

			log.info("Response to Service : [ " + response + " ]");
			return new ResponseEntity<>(response, HttpStatus.OK);
		}

	// ------------- PUT ------------------//
	/*
	 * @RequestMapping(value = "/mainmodule", method = RequestMethod.PUT, produces =
	 * org.springframework.http.MediaType.APPLICATION_JSON_VALUE) public
	 * ResponseEntity<CommonProcessResponse> updateData(@RequestBody final
	 * MainModule body,
	 * 
	 * @RequestHeader(value = "accept", required = true) String acceptHeader,
	 * 
	 * @RequestHeader(value = "authorization", required = true) String authToken) {
	 * log.info("Request to PUT Service : MainModules - Data - '" + body + "'");
	 * String action = "UPDATE";
	 * 
	 * // Header Validation HttpStatus headerValidityCode =
	 * validator.validateCommonHeader(acceptHeader, authToken); if
	 * (headerValidityCode != HttpStatus.OK) { return new
	 * ResponseEntity<>(headerValidityCode); }
	 * 
	 * // Get Data from Service Layer CommonProcessResponse response; try { response
	 * = this.service.modifyData(action, body); } catch (Exception e) { return new
	 * ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR); }
	 * 
	 * log.info("Response to Service : [ " + response + " ]"); return new
	 * ResponseEntity<>(response, HttpStatus.OK); }
	 * 
	 * // ------------- DELETE ------------------//
	 * 
	 * @RequestMapping(value = "/mainmodule", method = RequestMethod.DELETE,
	 * produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE) public
	 * ResponseEntity<CommonProcessResponse> deleteData(@RequestBody final
	 * MainModule body,
	 * 
	 * @RequestHeader(value = "accept", required = true) String acceptHeader,
	 * 
	 * @RequestHeader(value = "authorization", required = true) String authToken) {
	 * log.info("Request to DELETE Service : MainModules - Data - '" + body + "'");
	 * String action = "DELETE";
	 * 
	 * // Header Validation HttpStatus headerValidityCode =
	 * validator.validateCommonHeader(acceptHeader, authToken); if
	 * (headerValidityCode != HttpStatus.OK) { return new
	 * ResponseEntity<>(headerValidityCode); }
	 * 
	 * // Get Data from Service Layer CommonProcessResponse response; try { response
	 * = this.service.modifyData(action, body); } catch (Exception e) { return new
	 * ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR); }
	 * 
	 * log.info("Response to Service : [ " + response + " ]"); return new
	 * ResponseEntity<>(response, HttpStatus.OK); }
	 * 
	 * 
	 * // ------------- GET ALL MODULE SUBMODULE LIST ------------------//
	 * 
	 * @RequestMapping(value = "/moduleSubModuleList", method = RequestMethod.GET,
	 * produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE) public
	 * ResponseEntity<List<ModulesList>> getAllModuleSubModuleData(
	 * 
	 * @RequestHeader(value = "accept", required = true) String acceptHeader,
	 * 
	 * @RequestHeader(value = "authorization", required = true) String authToken) {
	 * log.info("Request to Service : moduleSubModuleList - All Data");
	 * 
	 * // Header Validation HttpStatus headerValidityCode =
	 * validator.validateCommonHeader(acceptHeader, authToken); if
	 * (headerValidityCode != HttpStatus.OK) { return new
	 * ResponseEntity<>(headerValidityCode); }
	 * 
	 * // Get Data from Service Layer List<ModulesList> list; try { list =
	 * this.service.getModuleSubModuleData(); } catch (Exception e) { return new
	 * ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR); }
	 * 
	 * // Check if any Exception, then throw 500 if (Objects.isNull(list)) return
	 * new ResponseEntity<>(HttpStatus.NO_CONTENT);
	 * 
	 * log.info("Response to Service : [ " + list + " ]"); return new
	 * ResponseEntity<>(list, HttpStatus.OK); }
	 */

}
