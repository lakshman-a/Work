package com.paypal.test.rule.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class TestCheckpoints {

	private String id;
	private String checkpoint_name;
	private Object checkpoint_desc;
	private String component_name;
	private String project_name;
	private String active;
	private String created_tmstmp;
	private String created_by;
	private String updated_tmstmp;
	private String updated_by;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCheckpoint_name() {
		return checkpoint_name;
	}

	public void setCheckpoint_name(String checkpoint_name) {
		this.checkpoint_name = checkpoint_name;
	}

	public Object getCheckpoint_desc() {
		return checkpoint_desc;
	}

	public void setCheckpoint_desc(Object checkpoint_desc) {
		this.checkpoint_desc = checkpoint_desc;
	}

	public String getComponent_name() {
		return component_name;
	}

	public void setComponent_name(String component_name) {
		this.component_name = component_name;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getCreated_tmstmp() {
		return created_tmstmp;
	}

	public void setCreated_tmstmp(String created_tmstmp) {
		this.created_tmstmp = created_tmstmp;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getUpdated_tmstmp() {
		return updated_tmstmp;
	}

	public void setUpdated_tmstmp(String updated_tmstmp) {
		this.updated_tmstmp = updated_tmstmp;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

	public String getProject_name() {
		return project_name;
	}

	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}

}
