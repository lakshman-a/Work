package com.paypal.test.rule.main;

import java.io.File;
import java.io.FileInputStream;
import java.util.Arrays;
import java.util.Comparator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.paypal.test.rule.helper.LinuxCommandExecutor;

public class LinuxReadFileLocalBatchFile {
	final static Logger log = Logger.getLogger(LinuxReadFileLocalBatchFile.class);

	public static void main(String[] args) throws Exception {

		String stage = "stage2ma152946.qa.paypal.com";
		String username = "layyakannu";
		String password = "Paypal@123";
		Session session = null;

		File[] listOfFile = null;
		boolean result = false;
		String fileName = null;
		// String fileNameFromExcel = "RequestResponseCheckType1.txt";
		String fileNameStartsWithFromExcel = "server.log";

		String actualText = null;
//		String textValue = "(.*)Each shipping label VO(.*)";
		// String textValue = "(.*)(LAKSHMAN)(.*)";
		String textValue = "(.*)(FINAL_RESPONSE)(.*)";

		Pattern pattern = null;
		String startValue = "server";

		try {
			// Code to Connect SFTP JSCH

			File directory = new File("/x/web/STAGE2MA152946/riskresolutiondecisionserv/logs/");
//			File directory = new File("C:\\Users\\layyakannu\\Desktop\\LOGS\\");
			boolean fileexist = false;
			int fileAppeartime = 0;

			listOfFile = directory.listFiles();
			LinuxReadFileLocalBatchFile obj = new LinuxReadFileLocalBatchFile();
			log.info("Sorted List");
			listOfFile = obj.sortByNumber(listOfFile);
			boolean isPatterFound = false;

			for (int i = 0; i < listOfFile.length; i++) {

				if (listOfFile[i].isFile()) {

					fileName = listOfFile[i].getName();
					log.info("Fetching File name : " + fileName);

					if (fileName.startsWith(fileNameStartsWithFromExcel)) {
						log.info("FileName starts with : server.log");
						log.info("Starting to search the Pattern in the file : " + fileName);

						log.info("Searching Content : " + textValue);
						File ff = new File("C:\\Users\\layyakannu\\Desktop\\LOGS\\" + fileName);
						String fileContent = IOUtils.toString(new FileInputStream(ff), "UTF-8");
						actualText = "Text is not available in log file";
						pattern = Pattern.compile(textValue);
						Matcher matcher = pattern.matcher(fileContent);
						while (matcher.find()) {
							actualText = matcher.group(1) + matcher.group(2) + matcher.group(3);
							log.info("Actual Text : " + actualText);
							log.info("Matched! ");
							log.info("Matched in the file : " + fileName);
							isPatterFound = true;
							return;
						}

						log.info(actualText);
						log.info(actualText + " is not available in the filename '" + startValue + "'");

						result = true;
					}
					if (isPatterFound) {
						log.info("Expected Pattern found in file : " + fileName + "'. SO bReak out the Loop");
						break;
					} else {
						log.info("Expected Pattern not found in file : " + fileName + "'. SO continue to next file");
					}
				}

			}

			log.info("Result : " + fileName);

//			session.disconnect();
		} catch (Exception e) {
			log.error("Exception occured while moving file to Linux STAGE. Exception is");
			e.printStackTrace();
			throw e;
		} finally {
//			if (session != null) {
//				session.disconnect();
//			}

		}

	}

	public File[] sortByNumber(File[] files) {
		Arrays.sort(files, new Comparator<File>() {
			@Override
			public int compare(File o1, File o2) {
				int n1 = extractNumber(o1.getName());
				int n2 = extractNumber(o2.getName());
				return n1 - n2;
			}

			private int extractNumber(String name) {
				int i = 0;
				try {
					int s = 11;
					int e = name.length();
					String number = name.substring(s, e);
					i = Integer.parseInt(number);
				} catch (Exception e) {
					i = 0; // if filename does not match the format
							// then default to 0
				}
				return i;
			}
		});

		for (File f : files) {
			System.out.println(f.getName());
		}
		return files;
	}
}
