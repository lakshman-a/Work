package com.paypal.test.rule.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.paypal.test.rule.helper.MysqlDbHelper;
import com.paypal.test.rule.model.CommonServiceResponse;
import com.paypal.test.rule.model.TestComponents;
import com.paypal.test.rule.model.TestComponentsList;

public class TestComponentService {
	MysqlDbHelper sql = new MysqlDbHelper();
	final static Logger log = Logger.getLogger(TestComponentService.class);

	public List<TestComponents> getAllData(String projectName) throws Exception {
		List<TestComponents> responseList = new ArrayList<>();
		try {
			String query = "SELECT * FROM rule_process.test_component where project_name='" + projectName + "' order by id desc";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				for (HashMap<String, Object> hashMap : resultHash) {
					TestComponents eachItem = new TestComponents();
					eachItem.setId(hashMap.get("id").toString());
					eachItem.setComponent_name(hashMap.get("component_name").toString());
					if (hashMap.get("component_desc") != null) {
						eachItem.setComponent_desc(hashMap.get("component_desc").toString());
					}
					eachItem.setProject_name(hashMap.get("project_name").toString());
					eachItem.setActive(hashMap.get("active").toString());
					eachItem.setCreated_tmstmp(hashMap.get("created_tmstmp").toString());
					eachItem.setCreated_by(hashMap.get("created_by").toString());
					eachItem.setUpdated_tmstmp(hashMap.get("updated_tmstmp").toString());
					eachItem.setUpdated_by(hashMap.get("updated_by").toString());
					responseList.add(eachItem);
				}
			} else if (resultHash.size() == 0) {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return responseList;
	}

	public List<TestComponentsList> getComponentsWithCheckpoints(String projectName) throws Exception {
		List<TestComponentsList> responseList = new ArrayList<>();
		try {
			String query = "SELECT component_name FROM rule_process.test_component where project_name='" + projectName
					+ "' and active='true' order by component_name";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				for (HashMap<String, Object> hashMap : resultHash) {
					TestComponentsList eachItem = new TestComponentsList();
					String componentName = hashMap.get("component_name").toString();
					eachItem.setComponent(componentName);

					String query2 = "SELECT checkpoint_name FROM rule_process.test_checkpoint where component_name='" + componentName
							+ "' and project_name='" + projectName + "' and active='true' order by component_name";
					List<HashMap<String, Object>> resultHash2 = sql.executeSelect(query2);

					if (resultHash.size() > 0) {
						List<String> checkpointArray = new ArrayList<>();
						for (HashMap<String, Object> eachCk : resultHash2) {
							checkpointArray.add(eachCk.get("checkpoint_name").toString());
						}
						eachItem.setCheckpoints(checkpointArray);
					}

					responseList.add(eachItem);
				}
			} else if (resultHash.size() == 0) {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return responseList;
	}

	public TestComponents getData(String componentName, String projectName) throws Exception {
		TestComponents eachItem = new TestComponents();
		try {
			String query = "SELECT * FROM rule_process.test_component where component_name = '" + componentName + "' and project_name='" + projectName
					+ "'";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				for (HashMap<String, Object> hashMap : resultHash) {
					eachItem.setId(hashMap.get("id").toString());
					eachItem.setComponent_name(hashMap.get("component_name").toString());
					if (hashMap.get("component_desc") != null) {
						eachItem.setComponent_desc(hashMap.get("component_desc").toString());
					}
					eachItem.setProject_name(hashMap.get("project_name").toString());
					eachItem.setActive(hashMap.get("active").toString());
					eachItem.setCreated_tmstmp(hashMap.get("created_tmstmp").toString());
					eachItem.setCreated_by(hashMap.get("created_by").toString());
					eachItem.setUpdated_tmstmp(hashMap.get("updated_tmstmp").toString());
					eachItem.setUpdated_by(hashMap.get("updated_by").toString());
				}
			} else if (resultHash.size() == 0) {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return eachItem;
	}

	public CommonServiceResponse modifyData(String action, final TestComponents data) throws Exception {
		CommonServiceResponse response = new CommonServiceResponse();
		String query = null;
		Connection conn = null;
		Statement stmt = null;
		PreparedStatement preparedStmt = null;

		try {
			String jdbcClass = "com.mysql.jdbc.Driver";
			String connectionHostPort = "localhost";
			String schema = "atom";
			String sqlUser = "root";
			String sqlPwd = "root";

			// Load Classname and connection URL
			Class.forName(jdbcClass);
			String connectionUrl = "jdbc:mysql://" + connectionHostPort + "/" + schema + "";

			// Set SQL Properties
			Properties properties = new Properties();
			properties.setProperty("user", sqlUser);
			properties.setProperty("password", sqlPwd);
			properties.setProperty("useSSL", "true");
			properties.setProperty("autoReconnect", "true");
			properties.setProperty("verifyServerCertificate", "false");

			// Create Connection
			conn = DriverManager.getConnection(connectionUrl, properties);
			conn.setAutoCommit(false);
			conn.rollback();

			switch (action.toLowerCase()) {
			case "insert":

				query = "INSERT INTO rule_process.test_component (`component_name`, `component_desc`,`project_name`, `active`, `created_by`, `updated_by`) "
						+ "VALUES " + "(?, ?, ?, ?, ?,?)";

				preparedStmt = conn.prepareStatement(query);
				preparedStmt.setString(1, data.getComponent_name());
				preparedStmt.setObject(2, data.getComponent_desc());
				preparedStmt.setString(3, data.getProject_name());
				preparedStmt.setString(4, data.getActive());
				preparedStmt.setString(5, data.getCreated_by());
				preparedStmt.setString(6, data.getUpdated_by());

				break;

			case "update":
				query = "UPDATE rule_process.test_component set component_desc=?,active=?,updated_by=? where component_name=? and project_name=?";

				preparedStmt = conn.prepareStatement(query);

				preparedStmt.setObject(1, data.getComponent_desc());
				preparedStmt.setString(2, data.getActive());
				preparedStmt.setString(3, data.getUpdated_by());
				preparedStmt.setString(4, data.getComponent_name());
				preparedStmt.setString(5, data.getProject_name());

				break;

			case "delete":
				query = "DELETE FROM rule_process.test_component where component_name=? and project_name=?";
				preparedStmt = conn.prepareStatement(query);
				preparedStmt.setString(1, data.getComponent_name());
				preparedStmt.setString(2, data.getProject_name());
				break;

			default:
				log.error("Invalid Action choosen!");
				throw new Exception("Invalid Action choosen. Choose one of the following action : INSERT/UPDATE/DELETE");
			}

			log.info("Executing Update/Delete Query : [ " + query + " ]");

			int count = preparedStmt.executeUpdate();
			conn.commit();

			log.info("Count of Rows Updated/Deleted Successfully : [ " + count + " ]");
			if (count > 0) {
				response.setKey(data.getComponent_name());
				response.setName(data.getProject_name());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully");
				response.setCode("200");

			} else if (count == 0) {
				response.setKey(data.getComponent_name());
				response.setName(data.getProject_name());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully. No Rows Affected");
				response.setCode("201");

			}

		} catch (SQLIntegrityConstraintViolationException e) {
			e.printStackTrace();
			log.error("SQLIntegrityConstraintViolationException occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getComponent_name());
			response.setName(data.getProject_name());
			response.setAction(action);
			response.setStatus("failure");
			// response.setReason("Insert/Update/Delete failed due to SQL Contraint Error. May be duplicate key Insert or foriegn key constraint");
			response.setReason("Insert/Update/Delete failed due to SQL Contraint Error - " + e.getMessage());
			response.setCode("500");

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("SQL Exception occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getComponent_name());
			response.setName(data.getProject_name());
			response.setAction(action);
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to SQL Exception.");
			response.setCode("500");

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Common Exception occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getComponent_name());
			response.setName(data.getProject_name());
			response.setAction(action);
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to Common Exception.");
			response.setCode("500");

		} finally {
			if (conn != null) {
				conn.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}

		return response;
	}
}
