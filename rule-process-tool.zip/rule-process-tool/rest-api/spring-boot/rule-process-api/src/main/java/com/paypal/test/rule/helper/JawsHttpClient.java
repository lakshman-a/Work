package com.paypal.test.rule.helper;

import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class JawsHttpClient {
	final static Logger log = Logger.getLogger(JawsHttpClient.class);
	public static void main(String[] args) {
		try {
			// Create a HTTPClient to make a rest call
			HttpRestClient client = new HttpRestClient();

			// Get the URL based on JOB or Default stage configured in
			// COnfig.properties
			String restUrl = "https://stage2ma196768.qa.paypal.com:11833/v1/risk/resolution-dispute-initiation-decisions";

			// Adding Headers
			Map<String, String> headerMap = new HashMap<String, String>();
			headerMap
					.put("X-PAYPAL-SECURITY-CONTEXT",
							"{\"scopes\":[\"*\"],\"subjects\":[{\"subject\":{\"auth_state\":\"LOGGEDIN\",\"account_number\":\"1563231917206801357\",\"auth_claims\":[\"USERNAME\",\"PASSWORD\"]}}],\"actor\":{\"id\":\"85390\",\"account_number\":\"1563231917206801357\",\"auth_claims\":[\"USERNAME\",\"PASSWORD\"]}}");
			headerMap.put("Accept", "application/json");
			headerMap.put("Content-Type", "application/json");
			log.info("<b>Request Headers built Successfully</b> : " + headerMap);

			String request = "{\"dispute_action\":\"CREATE\",\"buyer_account_number\":\"1243100937258822770\",\"payment_info\":{\"payment_date\":\"2010-10-27T11:58:22Z\",\"encrypted_seller_payment_id\":\"9E627776BP6201210\",\"seller_payment_id\":\"3322656\",\"encrypted_buyer_payment_id\":\"9218961257597851P\",\"buyer_payment_id\":\"3322655\",\"payment_amount\":{\"value\":\"200\",\"currency\":\"USD\"},\"payment_usd_amount\":\"2\"},\"tracking_info\":{\"id\":\"123\",\"shipping_address_matches_destination_address\":\"MATCH\",\"status\":\"DELIVERED\",\"shipping_address_matches_delivery_address\":\"MATCH\"},\"seller_account_number\":\"1179804269022553017\",\"current_dispute_details\":{\"external_chargeback_details\":{\"chargeback_current_reason_code\":\"chargeback_current_reason_code\",\"is_second_chargeback\":false,\"is_credited_by_processor\":false,\"chargeback_credit_event_count\":0,\"first_chargeback_creation_status\":\"TICKET_RETRIEVAL\",\"sub_processor_name\":\"sub_processor_name\",\"chargeback_original_reason_code\":\"chargeback_original_reason_code\",\"chargeback_debit_event_count\":1,\"chargeback_money_movement\":\"DEBIT\",\"dispute_creation_time_in_processor_file\":\"2010-10-26T11:58:22Z\",\"processor_name\":\"processor_name\",\"credit_card_type\":\"card_type\"},\"seller_protection_criteria\":\"POD\",\"disputed_amount\":{\"value\":\"600\",\"currency\":\"USD\"},\"reason\":\"1\",\"sub_reason\":\"1\",\"time_created\":\"2010-10-27T11:58:22Z\",\"regulation_name\":\"4\",\"dispute_stage_details\":[{\"opened_date\":\"2010-10-27T11:58:22Z\",\"merchant_response\":{\"merchant_response_method\":\"NO_RESPONSE\",\"has_attachments\":false},\"dispute_stage\":2}],\"adjudication_type\":\"PAYPAL\",\"type\":\"2\",\"stage\":\"2\",\"seller_appealed_count\":0,\"id\":\"123\",\"source\":\"RKB\",\"buyer_appealed_count\":0,\"sub_type\":\"2\"}}";
			log.info("<b>Request Payload built Successfully</b> : " + request);

			// Make a HTTP post call to the service with the request and header
			//JSONObject responseAsJsonObject = client.doPost(restUrl, headerMap, request);

			// Validate the Response fields
			//log.info("<b>Response received successfully</b> : " + responseAsJsonObject);

		} catch (Exception e) {
			log.info("Dispute_Initiation RestService Call Failed due to Exception : " + e.getMessage());
			e.printStackTrace();
		}
		
	}
	
}
