package com.paypal.test.rule.helper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;

public class WindowsCommandExecutor {
	final static Logger log = Logger.getLogger(WindowsCommandExecutor.class);

	public String executeWindowsCommand(String directory, String cmd) throws Exception {
		log.info("Method: executeWindowsCommand. Params -cmd");
		log.info("executeWindowsCommand: " + cmd);
		String serverOut = "";
		ProcessBuilder builder=null;
		Process p=null;
		try {
			builder = new ProcessBuilder("cmd.exe", "/c", "cd \"" + directory + "\" && "+cmd);
			builder.redirectErrorStream(true);
			p = builder.start();
			log.info("Cmd Process executing. Log from Server: ");
			BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line;
			while (true) {
				line = r.readLine();
				if (line == null) {
					break;
				}
				log.info(line);
				serverOut = serverOut + line;
			}
			r.close();

		} catch (IOException e) {
			log.error("Exception occured while generating Post process Jar. Exception is");
			e.printStackTrace();
			throw e;
		}finally {
			builder=null;
			p.destroy();
			
		}
		return serverOut;

	}

}
