package com.paypal.test.rule.main;

import java.io.File;
import java.io.FileInputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.paypal.test.rule.helper.LinuxCommandExecutor;

public class LinuxReadFile {
	final static Logger log = Logger.getLogger(LinuxReadFile.class);
	public static void main(String[] args) throws Exception {
		
		String stage = "stage2ma152946.qa.paypal.com";
		String username = "layyakannu";
		String password = "Paypal@123";
		File[] listOfFile = null; 
		boolean result = false;
		String fileName = "server";
		String fileNameFromExcel="server.log";
		stage = stage.toUpperCase();
		Session session = null;
		String actualText = null;
		String textValue="(FINA_RESPONSE)";
		Pattern pattern = null;
		String startValue = "server";
		
		try {
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			session = jsch.getSession(username, stage, 22);
			session.setPassword(password);
			session.setConfig(config);
			try {
				session.connect();
				log.info("Connection Success to the mentioned STAGE! ");
				result = true;
			} catch (JSchException e) {
				log.error("Connection failed to the mentioned STAGE! " + e);
				e.printStackTrace();
				result = false;
			}
			
			File directory = new File("/x/web/STAGE2MA152946/logs/riskresolutiondecisionserv/logs/");
			boolean fileexist=false;
			int fileAppeartime=0;

			while(fileAppeartime<30){
				Thread.sleep(1000);
				 listOfFile = directory.listFiles();
				if(listOfFile.length != 0){
					log.info("Directory has files");
					fileexist=true;
					break;

				}else{
					log.info("No File is available in directory. looping again with 60 secs");
				}

				log.info("No File is available in directory with 60 secs");
				fileAppeartime++;

			}

			if(fileexist){
				log.info("Files avialble in the directiory");

			}else{
				log.error("No File is available in directory for 60secs");
				return;
			}
			
			boolean foundstatus=false;
			int time=0;
			while(time<30){
				Thread.sleep(1000);	
				listOfFile = directory.listFiles();
				for(int i = 0; i<listOfFile.length; i++){
					log.info("i is : "+time);
					if(listOfFile[i].isFile()){

						fileName = listOfFile[i].getName();
						log.info("Found a file and name is : "+fileName);
						if(fileName.equals(fileNameFromExcel)){
							log.info("FileName exact match : "+fileName);
							fileName=fileNameFromExcel;
							foundstatus=true;
							break;
						}
					}
				}
				if(foundstatus){
					log.info("FileName exact match is found. Braking the loop");
					break;
				}else{
					log.info("FileName not found in path. Continue the loop");
				}
				time++;
			}

			if(fileName == null){
				log.info("Searched File is not available in directory");
				return ;
			}

			if(!(fileName.equals(fileNameFromExcel))){
				log.info("Search File is not available in directory");
				return;
			}

			File ff = new File("/x/web/STAGE2MA152946/logs/riskresolutiondecisionserv/logs/" +fileName);
			log.info(ff.getAbsolutePath()+" || "+ff.getName());
			String fileContent = IOUtils.toString(new FileInputStream(ff),"UTF-8");
			actualText = "Text is not available in log file";
			pattern = Pattern.compile(textValue);
			Matcher matcher = pattern.matcher(fileContent);
			while(matcher.find()){
				actualText = matcher.group(1)+matcher.group(2)+matcher.group(3);
				log.info("Text '"+actualText+"' is matched with expected text in the filename of ");
				return;
			}

			log.info(actualText);
			log.info(actualText+" is not available in the filename '"+startValue+"'" );

			session.disconnect();
		} catch (Exception e) {
			log.error("Exception occured while moving file to Linux STAGE. Exception is");
			e.printStackTrace();
			throw e;
		} finally {
			if (session != null) {
				session.disconnect();
			}

		}
		
	}
}
