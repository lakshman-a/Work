package com.paypal.test.rule.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;

import com.paypal.test.rule.helper.MysqlDbHelper;
import com.paypal.test.rule.model.ActionTrnDetail;
import com.paypal.test.rule.model.TestCasesWithReportTrn;
import com.paypal.test.rule.model.TestRunDetails;
import com.paypal.test.rule.model.TestRunWithReportTrnDetails;
import com.paypal.test.rule.model.TestSuiteRunDetails;

public class TestReportService {
	MysqlDbHelper sql = new MysqlDbHelper();
	final static Logger log = Logger.getLogger(TestReportService.class);

	public List<TestRunDetails> getAllData() throws Exception {
		List<TestRunDetails> responseList = new ArrayList<>();
		try {
			String query = "select * from rule_process.test_run_details order by id desc";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				for (HashMap<String, Object> hashMap : resultHash) {
					TestRunDetails eachItem = new TestRunDetails();
					eachItem.setId(hashMap.get("id").toString());
					eachItem.setRun_id(hashMap.get("run_id").toString());
					eachItem.setRun_level(hashMap.get("run_level").toString());
					eachItem.setTest_name(hashMap.get("test_name").toString());
					eachItem.setStage(hashMap.get("stage"));
					eachItem.setCase_count(hashMap.get("case_count").toString());
					eachItem.setStatus(hashMap.get("status").toString());
					eachItem.setResult(hashMap.get("result").toString());
					eachItem.setReport_file(hashMap.get("report_file"));
					eachItem.setComments(hashMap.get("comments"));
					eachItem.setGrid_url(hashMap.get("grid_url"));
					eachItem.setBrowser(hashMap.get("browser"));
					eachItem.setTriggered_by(hashMap.get("triggered_by").toString());
					eachItem.setTriggered_tmstmp(hashMap.get("triggered_tmstmp").toString());
					eachItem.setUpdated_tmstmp(hashMap.get("updated_tmstmp").toString());
					responseList.add(eachItem);
				}
			} else if (resultHash.size() == 0) {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return responseList;
	}

	public TestRunWithReportTrnDetails getLastRunData(String username) throws Exception {
		TestRunWithReportTrnDetails response = new TestRunWithReportTrnDetails();
		try {
			String query = "select * from rule_process.test_run_details where triggered_by='" + username + "' order by id desc LIMIT 1";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				String runId = null;
				for (HashMap<String, Object> hashMap : resultHash) {
					runId = hashMap.get("run_id").toString();
					response.setId(hashMap.get("id").toString());
					response.setRun_id(runId);
					response.setRun_level(hashMap.get("run_level").toString());
					response.setTest_name(hashMap.get("test_name").toString());
					response.setStage(hashMap.get("stage"));
					response.setCase_count(hashMap.get("case_count").toString());
					response.setStatus(hashMap.get("status").toString());
					response.setResult(hashMap.get("result").toString());
					response.setReport_file(hashMap.get("report_file"));
					response.setComments(hashMap.get("comments"));
					response.setGrid_url(hashMap.get("grid_url"));
					response.setBrowser(hashMap.get("browser"));
					response.setTriggered_by(hashMap.get("triggered_by").toString());
					response.setTriggered_tmstmp(hashMap.get("triggered_tmstmp").toString());
					response.setUpdated_tmstmp(hashMap.get("updated_tmstmp").toString());
				}
				//String reportTrnQuery = "select * from rule_process.test_report_trn where run_id = '" + runId + "' order by test_case_num, step_num";
				String reportTrnQuery = "select * from rule_process.test_report_trn where run_id = '" + runId + "' order by id";
				List<HashMap<String, Object>> reportTrnResultHm = sql.executeSelect(reportTrnQuery);
				if (reportTrnResultHm.size() > 0) {
					List<ActionTrnDetail> allActionsOfRun = new ArrayList<>();
					for (HashMap<String, Object> eachReportStep : reportTrnResultHm) {
						ActionTrnDetail reportTrn = new ActionTrnDetail();
						reportTrn.setId(eachReportStep.get("id").toString());
						reportTrn.setRun_id(eachReportStep.get("run_id").toString());
						reportTrn.setTest_case_num(eachReportStep.get("test_case_num").toString());
						reportTrn.setTest_case_name(eachReportStep.get("test_case_name").toString());
						reportTrn.setComp_num(eachReportStep.get("comp_num"));
						reportTrn.setComp_name(eachReportStep.get("comp_name"));
						reportTrn.setTest_data_num(eachReportStep.get("test_data_num").toString());
						reportTrn.setStep_num(eachReportStep.get("step_num").toString());
						reportTrn.setAction_name(eachReportStep.get("action_name").toString());
						reportTrn.setStep_result(eachReportStep.get("step_result").toString());
						reportTrn.setStep_desc(eachReportStep.get("step_desc").toString());
						reportTrn.setScreenshot_path(eachReportStep.get("screenshot_path"));
						reportTrn.setStep_start_time(eachReportStep.get("step_start_time").toString());
						reportTrn.setStep_end_time(eachReportStep.get("step_end_time").toString());
						allActionsOfRun.add(reportTrn);
					}
					Map<String, List<ActionTrnDetail>> groupByTestcase = allActionsOfRun.stream()
							.collect(Collectors.groupingBy(ActionTrnDetail::getTest_case_name));

					List<TestCasesWithReportTrn> testcaseTrnList = new ArrayList<TestCasesWithReportTrn>();

					for (Entry<String, List<ActionTrnDetail>> entry : groupByTestcase.entrySet()) {
						// log.info("Key = " + entry.getKey());
						// log.info("value = " + entry.getValue());
						TestCasesWithReportTrn testcaseTrn = new TestCasesWithReportTrn();
						testcaseTrn.setTestcaseName(entry.getKey());
						testcaseTrn.setTestcaseNum(entry.getValue().get(0).getTest_case_num());
						String testcaseResult = "PASS";
						if (entry.getValue().stream().filter(eachItem -> eachItem.getStep_result().equalsIgnoreCase("FAIL"))
								.collect(Collectors.toList()).size() > 0) {
							testcaseResult = "FAIL";
						}
						if (entry.getValue().stream().filter(eachItem -> eachItem.getStep_result().equalsIgnoreCase("UNKNOWN"))
								.collect(Collectors.toList()).size() > 0) {
							testcaseResult = "UNKNOWN";
						}
						if (entry.getValue().stream().filter(eachItem -> eachItem.getStep_result().equalsIgnoreCase("ERROR"))
								.collect(Collectors.toList()).size() > 0) {
							testcaseResult = "ERROR";
						}
						testcaseTrn.setTestcaseResult(testcaseResult);
						testcaseTrn.setTestcaseStepReport(entry.getValue());
						testcaseTrnList.add(testcaseTrn);

					}

					testcaseTrnList = testcaseTrnList.stream().sorted((o1, o2) -> Integer.valueOf(o1.getTestcaseNum()).compareTo(Integer.valueOf(o2.getTestcaseNum())))
							.collect(Collectors.toList());
					response.setTestCasesReportTrn(testcaseTrnList);
				}

			} else if (resultHash.size() == 0) {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return response;
	}

	public TestRunWithReportTrnDetails getCompleteReportOnRunData(String paramRunId) throws Exception {
		TestRunWithReportTrnDetails response = new TestRunWithReportTrnDetails();
		try {
			String query = "select * from rule_process.test_run_details where run_id='" + paramRunId + "'";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				String runId = null;
				for (HashMap<String, Object> hashMap : resultHash) {
					runId = hashMap.get("run_id").toString();
					response.setId(hashMap.get("id").toString());
					response.setRun_id(runId);
					response.setRun_level(hashMap.get("run_level").toString());
					response.setTest_name(hashMap.get("test_name").toString());
					response.setStage(hashMap.get("stage"));
					response.setCase_count(hashMap.get("case_count").toString());
					response.setStatus(hashMap.get("status").toString());
					response.setResult(hashMap.get("result").toString());
					response.setReport_file(hashMap.get("report_file"));
					response.setComments(hashMap.get("comments"));
					response.setGrid_url(hashMap.get("grid_url"));
					response.setBrowser(hashMap.get("browser"));
					response.setTriggered_by(hashMap.get("triggered_by").toString());
					response.setTriggered_tmstmp(hashMap.get("triggered_tmstmp").toString());
					response.setUpdated_tmstmp(hashMap.get("updated_tmstmp").toString());
				}
				//String reportTrnQuery = "select * from rule_process.test_report_trn where run_id = '" + runId + "' order by test_case_num, step_num";
				String reportTrnQuery = "select * from rule_process.test_report_trn where run_id = '" + runId + "' order by id";
				List<HashMap<String, Object>> reportTrnResultHm = sql.executeSelect(reportTrnQuery);
				if (reportTrnResultHm.size() > 0) {
					List<ActionTrnDetail> allActionsOfRun = new ArrayList<>();
					for (HashMap<String, Object> eachReportStep : reportTrnResultHm) {
						ActionTrnDetail reportTrn = new ActionTrnDetail();
						reportTrn.setId(eachReportStep.get("id").toString());
						reportTrn.setRun_id(eachReportStep.get("run_id").toString());
						reportTrn.setTest_case_num(eachReportStep.get("test_case_num").toString());
						reportTrn.setTest_case_name(eachReportStep.get("test_case_name").toString());
						reportTrn.setComp_num(eachReportStep.get("comp_num"));
						reportTrn.setComp_name(eachReportStep.get("comp_name"));
						reportTrn.setTest_data_num(eachReportStep.get("test_data_num").toString());
						reportTrn.setStep_num(eachReportStep.get("step_num").toString());
						reportTrn.setAction_name(eachReportStep.get("action_name").toString());
						reportTrn.setStep_result(eachReportStep.get("step_result").toString());
						reportTrn.setStep_desc(eachReportStep.get("step_desc").toString());
						reportTrn.setScreenshot_path(eachReportStep.get("screenshot_path"));
						reportTrn.setStep_start_time(eachReportStep.get("step_start_time").toString());
						reportTrn.setStep_end_time(eachReportStep.get("step_end_time").toString());
						allActionsOfRun.add(reportTrn);
					}
					Map<String, List<ActionTrnDetail>> groupByTestcase = allActionsOfRun.stream()
							.collect(Collectors.groupingBy(ActionTrnDetail::getTest_case_name));

					List<TestCasesWithReportTrn> testcaseTrnList = new ArrayList<TestCasesWithReportTrn>();

					for (Entry<String, List<ActionTrnDetail>> entry : groupByTestcase.entrySet()) {
						// log.info("Key = " + entry.getKey());
						// log.info("value = " + entry.getValue());
						TestCasesWithReportTrn testcaseTrn = new TestCasesWithReportTrn();
						testcaseTrn.setTestcaseName(entry.getKey());
						testcaseTrn.setTestcaseNum(entry.getValue().get(0).getTest_case_num());
						String testcaseResult = "PASS";
						if (entry.getValue().stream().filter(eachItem -> eachItem.getStep_result().equalsIgnoreCase("FAIL"))
								.collect(Collectors.toList()).size() > 0) {
							testcaseResult = "FAIL";
						}
						if (entry.getValue().stream().filter(eachItem -> eachItem.getStep_result().equalsIgnoreCase("UNKNOWN"))
								.collect(Collectors.toList()).size() > 0) {
							testcaseResult = "UNKNOWN";
						}
						if (entry.getValue().stream().filter(eachItem -> eachItem.getStep_result().equalsIgnoreCase("ERROR"))
								.collect(Collectors.toList()).size() > 0) {
							testcaseResult = "ERROR";
						}
						testcaseTrn.setTestcaseResult(testcaseResult);
						testcaseTrn.setTestcaseStepReport(entry.getValue());
						testcaseTrnList.add(testcaseTrn);

					}
					
					testcaseTrnList = testcaseTrnList.stream().sorted((o1, o2) -> Integer.valueOf(o1.getTestcaseNum()).compareTo(Integer.valueOf(o2.getTestcaseNum())))
							.collect(Collectors.toList());

					response.setTestCasesReportTrn(testcaseTrnList);
				}

			} else if (resultHash.size() == 0) {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		
		return response;
	}

	public List<TestCasesWithReportTrn> getReportDataForRunId(String runId) throws Exception {
		List<TestCasesWithReportTrn> response = new ArrayList<TestCasesWithReportTrn>();
		try {
			//String reportTrnQuery = "select * from rule_process.test_report_trn where run_id = '" + runId + "' order by test_case_num, step_num";
			String reportTrnQuery = "select * from rule_process.test_report_trn where run_id = '" + runId + "' order by id";
			List<HashMap<String, Object>> reportTrnResultHm = sql.executeSelect(reportTrnQuery);
			if (reportTrnResultHm.size() > 0) {
				List<ActionTrnDetail> allActionsOfRun = new ArrayList<>();
				for (HashMap<String, Object> eachReportStep : reportTrnResultHm) {
					ActionTrnDetail reportTrn = new ActionTrnDetail();
					reportTrn.setId(eachReportStep.get("id").toString());
					reportTrn.setRun_id(eachReportStep.get("run_id").toString());
					reportTrn.setTest_case_num(eachReportStep.get("test_case_num").toString());
					reportTrn.setTest_case_name(eachReportStep.get("test_case_name").toString());
					reportTrn.setComp_num(eachReportStep.get("comp_num"));
					reportTrn.setComp_name(eachReportStep.get("comp_name"));
					reportTrn.setTest_data_num(eachReportStep.get("test_data_num").toString());
					reportTrn.setStep_num(eachReportStep.get("step_num").toString());
					reportTrn.setAction_name(eachReportStep.get("action_name").toString());
					reportTrn.setStep_result(eachReportStep.get("step_result").toString());
					reportTrn.setStep_desc(eachReportStep.get("step_desc").toString());
					reportTrn.setScreenshot_path(eachReportStep.get("screenshot_path"));
					reportTrn.setStep_start_time(eachReportStep.get("step_start_time").toString());
					reportTrn.setStep_end_time(eachReportStep.get("step_end_time").toString());
					allActionsOfRun.add(reportTrn);
				}
				Map<String, List<ActionTrnDetail>> groupByTestcase = allActionsOfRun.stream()
						.collect(Collectors.groupingBy(ActionTrnDetail::getTest_case_name));

				for (Entry<String, List<ActionTrnDetail>> entry : groupByTestcase.entrySet()) {
					TestCasesWithReportTrn testcaseTrn = new TestCasesWithReportTrn();
					testcaseTrn.setTestcaseName(entry.getKey());
					testcaseTrn.setTestcaseNum(entry.getValue().get(0).getTest_case_num());
					String testcaseResult = "PASS";

					if (entry.getValue().stream().filter(eachItem -> eachItem.getStep_result().equalsIgnoreCase("FAIL")).collect(Collectors.toList())
							.size() > 0) {
						testcaseResult = "FAIL";
					}
					if (entry.getValue().stream().filter(eachItem -> eachItem.getStep_result().equalsIgnoreCase("UNKNOWN"))
							.collect(Collectors.toList()).size() > 0) {
						testcaseResult = "UNKNOWN";
					}
					if (entry.getValue().stream().filter(eachItem -> eachItem.getStep_result().equalsIgnoreCase("ERROR")).collect(Collectors.toList())
							.size() > 0) {
						testcaseResult = "ERROR";
					}
					testcaseTrn.setTestcaseResult(testcaseResult);
					testcaseTrn.setTestcaseStepReport(entry.getValue());
					response.add(testcaseTrn);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		response = response.stream().sorted((o1, o2) -> Integer.valueOf(o1.getTestcaseNum()).compareTo(Integer.valueOf(o2.getTestcaseNum())))
				.collect(Collectors.toList());
		return response;
	}

	public List<TestSuiteRunDetails> getSuiteLastFewRunData() throws Exception {
		List<TestSuiteRunDetails> responseList = new ArrayList<>();
		try {
			String query = "select * from rule_process.test_suite where active='true'";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				for (HashMap<String, Object> hashMap : resultHash) {
					TestSuiteRunDetails eachItem = new TestSuiteRunDetails();
					eachItem.setId(hashMap.get("id").toString());
					eachItem.setTest_suite_name(hashMap.get("test_suite_name").toString());
					eachItem.setTest_suite_desc(hashMap.get("test_suite_desc").toString());
					eachItem.setCreated_by(hashMap.get("created_by").toString());
					eachItem.setCreated_tmstmp(hashMap.get("created_tmstmp").toString());

					List<String> lastResults = new ArrayList<String>();
					String resultsQuery = "Select result from rule_process.test_run_details where run_level ='TestSuite' and test_name ='"
							+ hashMap.get("test_suite_name").toString() + "' order by id desc LIMIT 5";
					List<HashMap<String, Object>> resultsQueryHm = sql.executeSelect(resultsQuery);

					if (resultsQueryHm.size() > 0) {
						for (HashMap<String, Object> eachResultsHm : resultsQueryHm) {
							lastResults.add(eachResultsHm.get("result").toString());
						}
					}
					eachItem.setLastResults(lastResults);
					responseList.add(eachItem);
				}
			} else if (resultHash.size() == 0) {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return responseList;
	}

	public List<TestRunDetails> getSuiteAllReportData(String type, String name) throws Exception {
		List<TestRunDetails> responseList = new ArrayList<>();
		try {
			String query = "Select * from rule_process.test_run_details where run_level ='"+type+"' and test_name ='" + name
					+ "' order by id desc LIMIT 65";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				for (HashMap<String, Object> hashMap : resultHash) {
					TestRunDetails eachItem = new TestRunDetails();
					eachItem.setId(hashMap.get("id").toString());
					eachItem.setRun_id(hashMap.get("run_id").toString());
					eachItem.setRun_level(hashMap.get("run_level").toString());
					eachItem.setTest_name(hashMap.get("test_name").toString());
					eachItem.setStage(hashMap.get("stage"));
					eachItem.setCase_count(hashMap.get("case_count").toString());
					eachItem.setStatus(hashMap.get("status").toString());
					eachItem.setResult(hashMap.get("result").toString());
					eachItem.setReport_file(hashMap.get("report_file"));
					eachItem.setComments(hashMap.get("comments"));
					eachItem.setGrid_url(hashMap.get("grid_url"));
					eachItem.setBrowser(hashMap.get("browser"));
					eachItem.setTriggered_by(hashMap.get("triggered_by").toString());
					eachItem.setTriggered_tmstmp(hashMap.get("triggered_tmstmp").toString());
					eachItem.setUpdated_tmstmp(hashMap.get("updated_tmstmp").toString());
					responseList.add(eachItem);
				}
			} else if (resultHash.size() == 0) {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return responseList;
	}

	public static void main(String[] args) throws Exception {
		TestReportService obj = new TestReportService();
		obj.getLastRunData("layyakannu");
	}

}
