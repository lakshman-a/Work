package com.paypal.test.rule.helper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

//import org.apache.http.HttpResponse;
//import org.apache.http.client.HttpClient;
//import org.apache.http.client.methods.HttpPost;
//import org.apache.http.entity.StringEntity;
//import org.apache.http.impl.client.HttpClients;
//import org.apache.log4j.Logger;

import com.paypal.test.rule.model.RuleFireResponse;

public class HttpClientHelper {
//	final static Logger log = Logger.getLogger(HttpClientHelper.class);
//
//	public RuleFireResponse doPost(String url, HashMap<String, Object> headers, String payload) {
//		RuleFireResponse response = new RuleFireResponse();
//		String body = "";
//
//		HttpClient client = HttpClients.createDefault();
//
//		HttpPost post = new HttpPost(url);
//
//		for (Map.Entry<String, Object> entry : headers.entrySet()) {
//			String key = entry.getKey();
//			Object value = entry.getValue();
//			post.addHeader(key, value.toString());
//		}
//
//		try {
//			post.setEntity(new StringEntity(body));
//		} catch (UnsupportedEncodingException e1) {
//			e1.printStackTrace();
//			response.setStatus("error");
//			response.setStatus_reason("Exception during Post Set Entity");
//			response.setLog_trace(e1.getMessage());
//			return response;
//		}
//
//		try {
//			long startTime = System.nanoTime();
//			HttpResponse httpResponse = client.execute(post);
//			long endTime = System.nanoTime();
//			long duration = (endTime - startTime);
//
//			if (httpResponse.getStatusLine().getStatusCode() != 200) {
//				BufferedReader br = new BufferedReader(new InputStreamReader((httpResponse.getEntity().getContent())));
//				String output;
//				log.info("Output from Server .... \n");
//				while ((output = br.readLine()) != null) {
//					log.info(output);
//				}
//				response.setStatus("success");
//				response.setStatus_code(String.valueOf(httpResponse.getStatusLine().getStatusCode()));
//				response.setResponse_time(String.valueOf(duration + " ms"));
//				response.setResponse(output);
//				response.setStatus_reason(httpResponse.getStatusLine().getReasonPhrase());
//				return response;
//			} else {
//				log.info("Status : " + String.valueOf(httpResponse.getStatusLine().getStatusCode()));
//				response.setStatus("fail");
//				response.setStatus_code(String.valueOf(httpResponse.getStatusLine().getStatusCode()));
//				response.setResponse_time(String.valueOf(duration + " ms"));
//				response.setResponse("");
//				response.setStatus_reason(httpResponse.getStatusLine().getReasonPhrase());
//				return response;
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//			response.setStatus("error");
//			response.setStatus_reason("Exception Common");
//			response.setLog_trace(e.getMessage());
//			return response;
//
//		}
//	}
//	
//	public static void main(String[] args) {
//		HttpClientHelper obj = new HttpClientHelper();
//		HashMap<String, Object> headers = new HashMap<>();
//		headers.put("Content-Type", "application/json");
//		headers.put("Accept", "application/json");
//		headers.put("X-PAYPAL-SECURITY-CONTEXT", "{\"scopes\":[\"*\"],\"subjects\":[{\"subject\":{\"auth_state\":\"LOGGEDIN\",\"account_number\":\"1563231917206801357\",\"auth_claims\":[\"USERNAME\",\"PASSWORD\"]}}],\"actor\":{\"id\":\"85390\",\"account_number\":\"1563231917206801357\",\"auth_claims\":[\"USERNAME\",\"PASSWORD\"]}}");
//		String payload ="{\"dispute_action\":\"CREATE\",\"buyer_account_number\":\"1243100937258822770\",\"payment_info\":{\"payment_date\":\"2010-10-27T11:58:22Z\",\"encrypted_seller_payment_id\":\"9E627776BP6201210\",\"seller_payment_id\":\"3322656\",\"encrypted_buyer_payment_id\":\"9218961257597851P\",\"buyer_payment_id\":\"3322655\",\"payment_amount\":{\"value\":\"200\",\"currency\":\"USD\"},\"payment_usd_amount\":\"2\"},\"tracking_info\":{\"id\":\"123\",\"shipping_address_matches_destination_address\":\"MATCH\",\"status\":\"DELIVERED\",\"shipping_address_matches_delivery_address\":\"MATCH\"},\"seller_account_number\":\"1179804269022553017\",\"current_dispute_details\":{\"external_chargeback_details\":{\"chargeback_current_reason_code\":\"chargeback_current_reason_code\",\"is_second_chargeback\":false,\"is_credited_by_processor\":false,\"chargeback_credit_event_count\":0,\"first_chargeback_creation_status\":\"TICKET_RETRIEVAL\",\"sub_processor_name\":\"sub_processor_name\",\"chargeback_original_reason_code\":\"chargeback_original_reason_code\",\"chargeback_debit_event_count\":1,\"chargeback_money_movement\":\"DEBIT\",\"dispute_creation_time_in_processor_file\":\"2010-10-26T11:58:22Z\",\"processor_name\":\"processor_name\",\"credit_card_type\":\"card_type\"},\"seller_protection_criteria\":\"POD\",\"disputed_amount\":{\"value\":\"600\",\"currency\":\"USD\"},\"reason\":\"1\",\"sub_reason\":\"1\",\"time_created\":\"2010-10-27T11:58:22Z\",\"regulation_name\":\"4\",\"dispute_stage_details\":[{\"opened_date\":\"2010-10-27T11:58:22Z\",\"merchant_response\":{\"merchant_response_method\":\"NO_RESPONSE\",\"has_attachments\":false},\"dispute_stage\":2}],\"adjudication_type\":\"PAYPAL\",\"type\":\"2\",\"stage\":\"2\",\"seller_appealed_count\":0,\"id\":\"123\",\"source\":\"RKB\",\"buyer_appealed_count\":0,\"sub_type\":\"2\"}}";
//		System.out.println(obj.doPost("https://stage2ma196768.qa.paypal.com:11833/v1/risk/resolution-dispute-initiation-decisions", headers, payload));
//	}

}
