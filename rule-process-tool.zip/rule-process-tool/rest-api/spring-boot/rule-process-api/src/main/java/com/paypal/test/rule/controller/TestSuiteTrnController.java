package com.paypal.test.rule.controller;

import java.util.List;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.paypal.test.rule.helper.HeaderValidator;
import com.paypal.test.rule.model.CommonServiceResponse;
import com.paypal.test.rule.model.TestSuiteTrn;
import com.paypal.test.rule.service.TestSuiteTrnService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("api")
public class TestSuiteTrnController {
	final static Logger log = Logger.getLogger(TestSuiteTrnController.class);
	TestSuiteTrnService service = new TestSuiteTrnService();
	HeaderValidator validator = new HeaderValidator();

	// ------------- GET ALL ------------------//
	@RequestMapping(value = "/testSuiteTrnList", method = RequestMethod.GET, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<TestSuiteTrn>> getAllData(@RequestParam(value="suiteName",required=true) String input,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to Service : TestCaseTrnDetails - All Data");

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		List<TestSuiteTrn> list;
		try {
			list = this.service.getAllData(input);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Check if any Exception, then throw 500
		if (Objects.isNull(list))
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		log.info("Response to Service : [ " + list + " ]");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	// ------------- POST ------------------//
	@RequestMapping(value = "/testSuiteTrn", method = RequestMethod.POST, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonServiceResponse> addData(@RequestBody final TestSuiteTrn body,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to PUT Service : MainModules - Data - '" + body + "'");
		String action = "INSERT";

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		CommonServiceResponse response;
		try {
			response = this.service.modifyData(action, body);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	// ------------- PUT ------------------//
	@RequestMapping(value = "/testSuiteTrn", method = RequestMethod.PUT, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonServiceResponse> updateData(@RequestBody final TestSuiteTrn body,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to PUT Service : MainModules - Data - '" + body + "'");
		String action = "UPDATE";

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		CommonServiceResponse response;
		try {
			response = this.service.modifyData(action, body);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	// ------------- DELETE ------------------//
	@RequestMapping(value = "/testSuiteTrn", method = RequestMethod.DELETE, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonServiceResponse> deleteData(@RequestBody final TestSuiteTrn body,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to DELETE Service : MainModules - Data - '" + body + "'");
		String action = "DELETE";

		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		CommonServiceResponse response;
		try {
			response = this.service.modifyData(action, body);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
