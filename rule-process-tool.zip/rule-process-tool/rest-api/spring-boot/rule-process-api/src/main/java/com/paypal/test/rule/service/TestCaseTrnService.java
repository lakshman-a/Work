package com.paypal.test.rule.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.json.JSONArray;

import com.paypal.test.rule.helper.MysqlDbHelper;
import com.paypal.test.rule.model.CommonServiceResponse;
import com.paypal.test.rule.model.TestCaseDataDetails;
import com.paypal.test.rule.model.TestCaseTrnActionDetails;
import com.paypal.test.rule.model.TestCaseTrnMainDetails;

public class TestCaseTrnService {
	MysqlDbHelper sql = new MysqlDbHelper();
	final static Logger log = Logger.getLogger(TestCaseTrnService.class);

	public TestCaseTrnMainDetails getAllData(String caseName, String projectName) throws Exception {
		TestCaseTrnMainDetails responseList = new TestCaseTrnMainDetails();
		try {

			String query = "select test_case_name,is_test_data_avail,test_data_keys, test_data from rule_process.test_cases where test_case_name ='"
					+ caseName + "' and project_name='"+projectName+"';";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				for (HashMap<String, Object> hashMap : resultHash) {
					responseList.setCaseName(hashMap.get("test_case_name").toString());
					// responseList.setTestDataFlag(hashMap.get("is_test_data_avail").toString());
					if (hashMap.get("is_test_data_avail") != null) {
						responseList.setTestDataFlag(hashMap.get("is_test_data_avail").toString());
					}
					responseList.setTestDataKeys(hashMap.get("test_data_keys"));
					responseList.setTestData(hashMap.get("test_data"));

					List<TestCaseTrnActionDetails> trnDetails = new ArrayList<>();
					String stepsQuery = "select * from rule_process.test_cases_trn where test_case_name='" + caseName + "' order by step_no";
					List<HashMap<String, Object>> actionsResultHash = sql.executeSelect(stepsQuery);

					if (resultHash.size() > 0) {
						for (HashMap<String, Object> actionshashMap : actionsResultHash) {
							TestCaseTrnActionDetails eachItem = new TestCaseTrnActionDetails();
							eachItem.setId(actionshashMap.get("id").toString());
							eachItem.setCaseName(actionshashMap.get("test_case_name").toString());
							eachItem.setStepNumber(actionshashMap.get("step_no").toString());
							eachItem.setActionName(actionshashMap.get("action_name").toString());
							eachItem.setActive(actionshashMap.get("active").toString());
							eachItem.setCreated_tmstmp(actionshashMap.get("created_tmstmp").toString());
							eachItem.setCreated_by(actionshashMap.get("created_by").toString());
							eachItem.setUpdated_tmstmp(actionshashMap.get("updated_tmstmp").toString());
							eachItem.setUpdated_by(actionshashMap.get("updated_by").toString());
							trnDetails.add(eachItem);
						}

					}
					responseList.setTestcaseTrnDetails(trnDetails);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return responseList;
	}

	public String getTestVariablesOfAction(String actionName) throws Exception {
		String response = null;
		try {

			String query = "SELECT request_params_variables,response_params_variables FROM rule_process.test_action where action_name = '"
					+ actionName + "'";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				for (HashMap<String, Object> hashMap : resultHash) {
					response = joinTwoJsonArray(hashMap.get("request_params_variables"), hashMap.get("response_params_variables"));
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return response;
	}

	public CommonServiceResponse modifyData(String action, final TestCaseTrnActionDetails data) throws Exception {
		CommonServiceResponse response = new CommonServiceResponse();
		String query = null;
		Connection conn = null;
		Statement stmt = null;
		PreparedStatement preparedStmt = null;

		try {
			String jdbcClass = "com.mysql.jdbc.Driver";
			String connectionHostPort = "localhost";
			String schema = "atom";
			String sqlUser = "root";
			String sqlPwd = "root";

			// Load Classname and connection URL
			Class.forName(jdbcClass);
			String connectionUrl = "jdbc:mysql://" + connectionHostPort + "/" + schema + "";

			// Set SQL Properties
			Properties properties = new Properties();
			properties.setProperty("user", sqlUser);
			properties.setProperty("password", sqlPwd);
			properties.setProperty("useSSL", "true");
			properties.setProperty("autoReconnect", "true");
			properties.setProperty("verifyServerCertificate", "false");

			// Create Connection
			conn = DriverManager.getConnection(connectionUrl, properties);
			conn.setAutoCommit(false);
			conn.rollback();

			switch (action.toLowerCase()) {
			case "insert":

				query = "INSERT INTO rule_process.test_cases_trn (`test_case_name`, `step_no`, `action_name`,`active`, `created_by`, `updated_by`) "
						+ "VALUES " + "(?, ?, ?, ?, ?, ?)";

				preparedStmt = conn.prepareStatement(query);
				preparedStmt.setString(1, data.getCaseName());
				preparedStmt.setString(2, data.getStepNumber());
				preparedStmt.setString(3, data.getActionName());
				preparedStmt.setString(4, data.getActive().toString());
				preparedStmt.setString(5, data.getCreated_by().toString());
				preparedStmt.setString(6, data.getUpdated_by().toString());

				break;

			case "update":
				query = "UPDATE rule_process.test_cases_trn set action_name=?,active=?,updated_by=? where test_case_name=? and step_no=?";

				preparedStmt = conn.prepareStatement(query);
				preparedStmt.setString(1, data.getActionName());
				preparedStmt.setString(2, data.getActive().toString());
				preparedStmt.setString(3, data.getUpdated_by().toString());
				preparedStmt.setString(4, data.getCaseName());
				preparedStmt.setString(5, data.getStepNumber());

				break;

			case "delete":
				query = "DELETE FROM rule_process.test_cases_trn where test_case_name=? and step_no=?";

				preparedStmt = conn.prepareStatement(query);
				preparedStmt.setString(1, data.getCaseName());
				preparedStmt.setString(2, data.getStepNumber());

				break;

			default:
				log.error("Invalid Action choosen!");
				throw new Exception("Invalid Action choosen. Choose one of the following action : INSERT/UPDATE/DELETE");
			}

			log.info("Executing Update/Delete Query : [ " + query + " ]");

			int count = preparedStmt.executeUpdate();
			conn.commit();

			log.info("Count of Rows Updated/Deleted Successfully : [ " + count + " ]");
			if (count > 0) {
				response.setKey(data.getCaseName().toString());
				response.setName(data.getStepNumber().toString());
				if (action.equalsIgnoreCase("insert") || action.equalsIgnoreCase("update")) {
					response.setSecondKey(getTestVariablesOfAction(data.getActionName()));
				}
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully");
				response.setCode("200");

			} else if (count == 0) {
				response.setKey(data.getCaseName().toString());
				response.setName(data.getStepNumber().toString());
				if (action.equalsIgnoreCase("insert") || action.equalsIgnoreCase("update")) {
					response.setSecondKey(getTestVariablesOfAction(data.getActionName()));
				}
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully. No Rows Affected");
				response.setCode("201");

			}

		} catch (SQLIntegrityConstraintViolationException e) {
			e.printStackTrace();
			log.error("SQLIntegrityConstraintViolationException occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getCaseName().toString());
			response.setName(data.getStepNumber().toString());
			response.setAction(action);
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to SQL Contraint Error. May be duplicate key Insert or foriegn key constraint");
			response.setCode("500");

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("SQL Exception occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getCaseName().toString());
			response.setName(data.getStepNumber().toString());
			response.setAction(action);
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to SQL Exception.");
			response.setCode("500");

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Common Exception occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getCaseName().toString());
			response.setName(data.getStepNumber().toString());
			response.setAction(action);
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to Common Exception.");
			response.setCode("500");

		} finally {
			if (conn != null) {
				conn.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}

		return response;
	}

	public CommonServiceResponse addTestData(final TestCaseDataDetails data) throws Exception {
		CommonServiceResponse response = new CommonServiceResponse();
		String query = null;
		Connection conn = null;
		Statement stmt = null;
		PreparedStatement preparedStmt = null;

		try {
			String jdbcClass = "com.mysql.jdbc.Driver";
			String connectionHostPort = "localhost";
			String schema = "atom";
			String sqlUser = "root";
			String sqlPwd = "root";

			// Load Classname and connection URL
			Class.forName(jdbcClass);
			String connectionUrl = "jdbc:mysql://" + connectionHostPort + "/" + schema + "";

			// Set SQL Properties
			Properties properties = new Properties();
			properties.setProperty("user", sqlUser);
			properties.setProperty("password", sqlPwd);
			properties.setProperty("useSSL", "true");
			properties.setProperty("autoReconnect", "true");
			properties.setProperty("verifyServerCertificate", "false");

			// Create Connection
			conn = DriverManager.getConnection(connectionUrl, properties);
			conn.setAutoCommit(false);
			conn.rollback();

			query = "UPDATE rule_process.test_cases set is_test_data_avail=?,test_data_keys=?,test_data=?,updated_by=? where test_case_name=?";

			preparedStmt = conn.prepareStatement(query);
			preparedStmt.setString(1, data.getIs_test_data_avail());
			preparedStmt.setObject(2, data.getTest_data_keys());
			preparedStmt.setObject(3, data.getTest_data());
			preparedStmt.setString(4, data.getUpdated_by());
			preparedStmt.setString(5, data.getTest_case_name());

			log.info("Executing Update/Delete Query : [ " + query.toString() + " ]");

			int count = preparedStmt.executeUpdate();
			conn.commit();

			log.info("Count of Rows Updated/Deleted Successfully : [ " + count + " ]");
			if (count > 0) {
				response.setKey(data.getTest_case_name());
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully");
				response.setCode("200");

			} else if (count == 0) {
				response.setKey(data.getTest_case_name());
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully. No Rows Affected");
				response.setCode("201");

			}

		} catch (SQLIntegrityConstraintViolationException e) {
			e.printStackTrace();
			log.error("SQLIntegrityConstraintViolationException occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getTest_case_name());
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to SQL Contraint Error - "+e.getMessage());
			response.setCode("500");

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("SQL Exception occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getTest_case_name());
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to SQL Exception - "+e.getMessage());
			response.setCode("500");

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Common Exception occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getTest_case_name());
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to Common Exception - "+e.getMessage());
			response.setCode("500");

		} finally {
			if (conn != null) {
				conn.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}

		return response;
	}

	private String joinTwoJsonArray(Object requestParams, Object responseParams) throws Exception {
		JSONArray listOfVariables = new JSONArray();
		try {

			if (requestParams != null) {
				JSONArray jsonArr = new JSONArray(requestParams.toString());
				if (jsonArr.length() > 0) {
					for (int i = 0; i < jsonArr.length(); i++) {
						String jsonObj = jsonArr.getString(i);
						listOfVariables.put(jsonObj);
					}
				} else {
					log.info("No Parameter value is Set for the requestParams!");
				}
			}
			if (responseParams != null) {
				JSONArray jsonArr = new JSONArray(responseParams.toString());
				if (jsonArr.length() > 0) {
					for (int i = 0; i < jsonArr.length(); i++) {
						String jsonObj = jsonArr.getString(i);
						listOfVariables.put(jsonObj);
					}
				} else {
					log.info("No Parameter value is Set for the responseParams!");
				}
			}
			log.info("Variable extract done successfully. List : " + listOfVariables);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return listOfVariables.toString();
	}

}
