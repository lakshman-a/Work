package com.paypal.test.rule.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class StageProcessRequest {

	private String stage;
	private String username;
	private String password;
	private String postProcessedJarName;
	private String loggerLevel;
	private String fileBased;
	private String action;

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLoggerLevel() {
		return loggerLevel;
	}

	public void setLoggerLevel(String loggerLevel) {
		this.loggerLevel = loggerLevel;
	}

	public String getFileBased() {
		return fileBased;
	}

	public void setFileBased(String fileBased) {
		this.fileBased = fileBased;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getPostProcessedJarName() {
		return postProcessedJarName;
	}

	public void setPostProcessedJarName(String postProcessedJarName) {
		this.postProcessedJarName = postProcessedJarName;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}