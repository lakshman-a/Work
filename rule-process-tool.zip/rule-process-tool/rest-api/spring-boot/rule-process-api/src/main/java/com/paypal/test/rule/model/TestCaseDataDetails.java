package com.paypal.test.rule.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class TestCaseDataDetails {

	private String is_test_data_avail;
	private Object test_data_keys;
	private Object test_data;
	private String updated_by;
	private String test_case_name;

	public String getIs_test_data_avail() {
		return is_test_data_avail;
	}

	public void setIs_test_data_avail(String is_test_data_avail) {
		this.is_test_data_avail = is_test_data_avail;
	}

	public Object getTest_data() {
		return test_data;
	}

	public void setTest_data(Object test_data) {
		this.test_data = test_data;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}

	public String getTest_case_name() {
		return test_case_name;
	}

	public void setTest_case_name(String test_case_name) {
		this.test_case_name = test_case_name;
	}

	public Object getTest_data_keys() {
		return test_data_keys;
	}

	public void setTest_data_keys(Object test_data_keys) {
		this.test_data_keys = test_data_keys;
	}

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
}
