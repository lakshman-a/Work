package com.paypal.test.rule.controller;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.paypal.test.rule.model.CommonProcessResponse;
import com.paypal.test.rule.model.StageProcessRequest;
import com.paypal.test.rule.service.LinuxProcessService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class StageController {
	final static Logger log = Logger.getLogger(StageController.class);
	LinuxProcessService service = new LinuxProcessService();

	// ------------- POST ------------------//
	@RequestMapping(value = "/checkConn", method = RequestMethod.POST, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonProcessResponse> checkConnection(@RequestBody final StageProcessRequest body) {
		log.info("Request to POST Service : StageController - checkConn - '" + body + "'");

		// Get Data from Service Layer
		CommonProcessResponse response = null;
		try {
			response = this.service.doLinuxConnect(body);
		} catch (Exception e) {
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	// ------------- POST ------------------//
	@RequestMapping(value = "/copyRRDSToStage", method = RequestMethod.POST, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonProcessResponse> checkConnAndCopyFolder(@RequestBody final StageProcessRequest body) {
		log.info("Request to POST Service : StageController - checkConn - '" + body + "'");

		// Get Data from Service Layer
		CommonProcessResponse response = null;
		try {
			response = this.service.doLinuxConnectAndCopy(body);
		} catch (Exception e) {
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	// ------------- POST ------------------//
	@RequestMapping(value = "/propChangeInRRDS", method = RequestMethod.POST, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonProcessResponse> doPropertyChange(@RequestBody final StageProcessRequest body) {
		log.info("Request to POST Service : StageController - propChangeInRRDS - '" + body + "'");

		// Get Data from Service Layer
		CommonProcessResponse response = null;
		try {
			response = this.service.doPropertyChangeInRRDS(body);
		} catch (Exception e) {
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	// ------------- POST ------------------//
		@RequestMapping(value = "/startStopService", method = RequestMethod.POST, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<CommonProcessResponse> doStartStopService(@RequestBody final StageProcessRequest body) {
			log.info("Request to POST Service : StageController - doStartStopService - '" + body + "'");

			// Get Data from Service Layer
			CommonProcessResponse response = null;
			try {
				response = this.service.doStartStopService(body);
			} catch (Exception e) {
				return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}

			log.info("Response to Service : [ " + response + " ]");
			return new ResponseEntity<>(response, HttpStatus.OK);
		}

}
