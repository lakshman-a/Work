package com.paypal.test.rule.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.paypal.test.rule.helper.MysqlDbHelper;
import com.paypal.test.rule.model.CommonServiceResponse;
import com.paypal.test.rule.model.RuleDetails;

public class RuleDetailService {
	MysqlDbHelper sql = new MysqlDbHelper();
	final static Logger log = Logger.getLogger(RuleDetailService.class);

	public List<RuleDetails> getAllData() throws Exception {
		List<RuleDetails> responseList = new ArrayList<>();
		try {
			String query = "SELECT * FROM rule_process.rule_details";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				for (HashMap<String, Object> hashMap : resultHash) {
					RuleDetails eachItem = new RuleDetails();
					eachItem.setId(hashMap.get("id").toString());
					eachItem.setRule_id(hashMap.get("rule_id").toString());
					eachItem.setRule_name(hashMap.get("rule_name").toString());
					eachItem.setRule_desc(hashMap.get("rule_desc"));
					eachItem.setComponent(hashMap.get("component"));
					eachItem.setCheckpoint(hashMap.get("checkpoint"));
					eachItem.setRule(hashMap.get("rule").toString());
					eachItem.setRule_path(hashMap.get("rule_path"));
					eachItem.setActive(hashMap.get("active").toString());
					eachItem.setCreated_tmstmp(hashMap.get("created_tmstmp").toString());
					eachItem.setCreated_by(hashMap.get("created_by").toString());
					eachItem.setUpdated_tmstmp(hashMap.get("updated_tmstmp").toString());
					eachItem.setUpdated_by(hashMap.get("updated_by").toString());
					responseList.add(eachItem);
				}
			} else if (resultHash.size() == 0) {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return responseList;
	}

	public CommonServiceResponse modifyData(String action, final RuleDetails data) throws Exception {
		CommonServiceResponse response = new CommonServiceResponse();
		String query = null;
		String originalRule=data.getRule().toString();
		String escapedRule = originalRule.replace("'","''");
		try {

			switch (action.toLowerCase()) {
			case "insert":
				
				
				query = "INSERT INTO rule_process.rule_details (rule_id, rule_name,rule_desc,component, checkpoint,rule,rule_path,active,created_by,updated_by) values ('"
						+ data.getRule_id() + "','" + data.getRule_name() + "','" + data.getRule_desc() + "','"
						+ data.getComponent() + "','" + data.getCheckpoint() + "','" + escapedRule + "','"
								+ data.getRule_path() + "','"
						+ data.getActive() + "','" + data.getCreated_by() + "','" + data.getCreated_by() + "')";
				break;

			case "update":
				query = "UPDATE rule_process.rule_details set rule_id='" + data.getRule_id() + "',rule_desc='"
						+ data.getRule_desc() + "',component='" + data.getComponent() + "',checkpoint='"
						+ data.getCheckpoint() + "',rule='" + escapedRule+ "',rule_path='" + data.getRule_path() + "',active='" + data.getActive()
						+ "', updated_by='" + data.getUpdated_by() + "' where rule_name='" + data.getRule_name() + "'";
				break;

			case "delete":
				query = "DELETE FROM rule_process.rule_details where rule_name='" + data.getRule_name() + "'";
				break;

			default:
				log.error("Invalid Action choosen!");
				throw new Exception(
						"Invalid Action choosen. Choose one of the following action : INSERT/UPDATE/DELETE");
			}

			int count = sql.executeUpdate(query);

			if (count > 0) {
				response.setKey(data.getRule_name().toString());
				response.setName(data.getRule_id().toString());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully");
				response.setCode("200");

			} else if (count == 0) {
				response.setKey(data.getRule_name().toString());
				response.setName(data.getRule_id().toString());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully. No Rows Affected");
				response.setCode("201");

			} else if (count == -2) {
				response.setKey(data.getRule_name().toString());
				response.setName(data.getRule_id().toString());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason(
						"Insert/Update/Delete failed due to SQL Contraint Error. May be duplicate key Insert or foriegn key constraint");
				response.setCode("500");
			} else if (count == -3) {
				response.setKey(data.getRule_name().toString());
				response.setName(data.getRule_id().toString());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason("Insert/Update/Delete failed due to SQL Exception.");
				response.setCode("500");

			} else if (count == -4) {
				response.setKey(data.getRule_name().toString());
				response.setName(data.getRule_id().toString());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason("Insert/Update/Delete failed due to Common Exception.");
				response.setCode("500");
			} else if (count == -1) {
				response.setKey(data.getRule_name().toString());
				response.setName(data.getRule_id().toString());
				response.setAction(action);
				response.setStatus("failure");
				response.setReason("Unkown Reason.");
				response.setCode("500");
			}

		} catch (Exception e) {
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return response;
	}

}
