package com.paypal.test.rule.model;

import java.util.Set;

import org.apache.commons.lang.builder.ToStringBuilder;

public class TestCasesAndRulesList {

	private Set<String> testCases;
	private Set<String> ruleNames;

	public Set<String> getTestCases() {
		return testCases;
	}

	public void setTestCases(Set<String> testCases) {
		this.testCases = testCases;
	}

	public Set<String> getRuleNames() {
		return ruleNames;
	}

	public void setRuleNames(Set<String> ruleNames) {
		this.ruleNames = ruleNames;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
