package com.paypal.test.rule.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class PostProcessRequest {

	private String ruleJar;
	private String plutoDCVersion;
	private String rboVersion;

	public String getRuleJar() {
		return ruleJar;
	}

	public void setRuleJar(String ruleJar) {
		this.ruleJar = ruleJar;
	}

	public String getPlutoDCVersion() {
		return plutoDCVersion;
	}

	public void setPlutoDCVersion(String plutoDCVersion) {
		this.plutoDCVersion = plutoDCVersion;
	}

	public String getRboVersion() {
		return rboVersion;
	}

	public void setRboVersion(String rboVersion) {
		this.rboVersion = rboVersion;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
