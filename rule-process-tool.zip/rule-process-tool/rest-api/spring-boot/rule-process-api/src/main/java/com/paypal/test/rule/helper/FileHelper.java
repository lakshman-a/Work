package com.paypal.test.rule.helper;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

public class FileHelper {
	final static Logger log = Logger.getLogger(FileHelper.class);

	public List<String> getListOfFilesInFolder(String folderPath, String endsWith) {
		log.info("method: getListOfFilesInFolder, param: folderPath");
		log.info("folderPath: " + folderPath);
		List<String> listOfFilesReturn = new ArrayList<>();
		try {
			File folder = new File(folderPath);
			File[] listOfFiles = folder.listFiles();

			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isFile()) {

					if (listOfFiles[i].getName().endsWith(endsWith)) {
						listOfFilesReturn.add(listOfFiles[i].getName());
//						log.info("File " + listOfFiles[i].getName());
					}

				} else if (listOfFiles[i].isDirectory()) {
					if (listOfFiles[i].getName().endsWith(endsWith)) {
						listOfFilesReturn.add(listOfFiles[i].getName());
//						log.info("Directory " + listOfFiles[i].getName());
					}

				}
			}
		} catch (Exception e) {
			log.error("Exception occured while reading file name list from give path : " + e);
			e.printStackTrace();
			throw e;
		}

		return listOfFilesReturn;
	}

	public synchronized boolean createAndWriteFile(String fileNameWithPath, String content) throws Exception {
		log.info("method: createAndWriteFile, param: fileNameWithPath,content");
		log.info("fileNameWithPath : " + fileNameWithPath);
		log.info("content : " + content);
		BufferedWriter bw = null;
		FileWriter fw = null;
		boolean result = false;
		try {
			Path pathToFile = Paths.get(fileNameWithPath);
			Files.createDirectories(pathToFile.getParent());

			File file = new File(fileNameWithPath);
			if (file.exists()) {
				file.delete();
				Files.createFile(pathToFile);
			} else {
				Files.createFile(pathToFile);
			}
			fw = new FileWriter(fileNameWithPath);
			bw = new BufferedWriter(fw);
			bw.write(content);
			result = true;
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return result;
	}

	public synchronized void copyFileFromSourceToDestination(String src, String dest) throws IOException {
		log.info("Method: copyFileFromSourceToDestination. Params -src, dest");
		log.info("src: " + src);
		log.info("dest: " + dest);
		try {

			File source = new File(src);
			File destination = new File(dest);

			log.info("Source File Path: " + source.getAbsoluteFile());
			log.info("Destination File Path: " + destination.getAbsoluteFile());

			FileUtils.copyFile(source, destination);
			log.info("Copy file from Source to destination Success. ");
		} catch (IOException e) {
			log.error("Exception occured while copying the file. Exception is");
			e.printStackTrace();
			throw e;
		}
	}

	public synchronized void extractJavaJar(String srcJarPath, String extractTgtPath) throws Exception {
		log.info("Method: extractJavaJar. Params -srcJarPath,extractTgtPath");
		log.info("srcJarPath: " + srcJarPath);
		log.info("extractTgtPath: " + extractTgtPath);

		try {

			java.util.jar.JarFile jarfile = new java.util.jar.JarFile(new java.io.File(srcJarPath));
			log.info("Post Processed Jar Path : " + jarfile.getName());

			java.util.Enumeration<java.util.jar.JarEntry> enu = jarfile.entries();
			while (enu.hasMoreElements()) {
				String destdir = extractTgtPath;
				log.info("Post Processed Jar Extract destination Dir : " + destdir);
				java.util.jar.JarEntry je = enu.nextElement();

				log.info(je.getName());

				java.io.File fl = new java.io.File(destdir, je.getName());
				if (!fl.exists()) {
					fl.getParentFile().mkdirs();
					fl = new java.io.File(destdir, je.getName());
				}
				if (je.isDirectory()) {
					continue;
				}
				java.io.InputStream is = jarfile.getInputStream(je);
				java.io.FileOutputStream fo = new java.io.FileOutputStream(fl);
				while (is.available() > 0) {
					fo.write(is.read());
				}
				fo.close();
				is.close();

			}
			jarfile.close();
			log.info("Post Processed Jar Extracted Successfully");

		} catch (Exception e) {
			log.error("Exception occured while extracting the post processing jar. Exception is");
			e.printStackTrace();
			throw e;
		}
	}

}
