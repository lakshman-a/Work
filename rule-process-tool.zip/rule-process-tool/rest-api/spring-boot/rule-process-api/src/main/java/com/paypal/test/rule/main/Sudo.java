package com.paypal.test.rule.main;

import com.jcraft.jsch.*;
import java.awt.*;
import javax.swing.*;
import java.io.*;

public class Sudo {
	public static void main(String[] arg) {
		try {
			JSch jsch = new JSch();

			String host = "stage2ma152946.qa.paypal.com";
			String user = "layyakannu";
			String sudo_pass = "Paypal@123";

			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");

			Session session = jsch.getSession(user, host, 22);
			session.setPassword(sudo_pass);
			session.setConfig(config);
			session.connect();
			
			String command = "pwd";
			Channel channel = session.openChannel("exec");

			// man sudo
			// -S The -S (stdin) option causes sudo to read the password from the
			// standard input instead of the terminal device.
			// -p The -p (prompt) option allows you to override the default
			// password prompt and use a custom one.
			((ChannelExec) channel).setCommand("sudo -S -p '' " + command);

			InputStream in = channel.getInputStream();
			OutputStream out = channel.getOutputStream();
			((ChannelExec) channel).setErrStream(System.err);

			channel.connect();

			out.write((sudo_pass + "\n").getBytes());
			out.flush();

			byte[] tmp = new byte[1024];
			while (true) {
				while (in.available() > 0) {
					int i = in.read(tmp, 0, 1024);
					if (i < 0)
						break;
					System.out.print(new String(tmp, 0, i));
				}
				if (channel.isClosed()) {
					System.out.println("exit-status: " + channel.getExitStatus());
					break;
				}
				try {
					Thread.sleep(1000);
				} catch (Exception ee) {
				}
			}
			channel.disconnect();
			session.disconnect();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}