package com.paypal.test.rule.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import com.paypal.test.rule.helper.MysqlDbHelper;
import com.paypal.test.rule.model.CommonServiceResponse;
import com.paypal.test.rule.model.TestSuite;
import com.paypal.test.rule.model.TestSuitesAndCasesList;

public class TestSuiteService {
	MysqlDbHelper sql = new MysqlDbHelper();
	final static Logger log = Logger.getLogger(TestSuiteService.class);

	public List<TestSuite> getAllData() throws Exception {
		List<TestSuite> responseList = new ArrayList<>();
		try {
			String query = "SELECT * FROM rule_process.test_suite";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				for (HashMap<String, Object> hashMap : resultHash) {
					TestSuite eachItem = new TestSuite();
					eachItem.setId(hashMap.get("id").toString());
					eachItem.setTest_suite_name(hashMap.get("test_suite_name").toString());
					eachItem.setTest_suite_desc(hashMap.get("test_suite_desc").toString());
					eachItem.setActive(hashMap.get("active").toString());
					eachItem.setCreated_tmstmp(hashMap.get("created_tmstmp").toString());
					eachItem.setCreated_by(hashMap.get("created_by").toString());
					eachItem.setUpdated_tmstmp(hashMap.get("updated_tmstmp").toString());
					eachItem.setUpdated_by(hashMap.get("updated_by").toString());
					responseList.add(eachItem);
				}
			} else if (resultHash.size() == 0) {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return responseList;
	}

	public TestSuite getData(String data) throws Exception {
		TestSuite response = new TestSuite();
		try {
			String query = "SELECT * FROM rule_process.test_suite where test_suite_name = '" + data + "'";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				for (HashMap<String, Object> hashMap : resultHash) {
					TestSuite eachItem = new TestSuite();
					eachItem.setId(hashMap.get("id").toString());
					eachItem.setTest_suite_name(hashMap.get("test_suite_name").toString());
					eachItem.setTest_suite_desc(hashMap.get("test_suite_desc").toString());
					eachItem.setActive(hashMap.get("active").toString());
					eachItem.setCreated_tmstmp(hashMap.get("created_tmstmp").toString());
					eachItem.setCreated_by(hashMap.get("created_by").toString());
					eachItem.setUpdated_tmstmp(hashMap.get("updated_tmstmp").toString());
					eachItem.setUpdated_by(hashMap.get("updated_by").toString());
				}
			} else if (resultHash.size() == 0) {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return response;
	}
	
	public TestSuitesAndCasesList getListData() throws Exception {
		TestSuitesAndCasesList response = new TestSuitesAndCasesList();
		try {
			String query = "SELECT test_suite_name FROM rule_process.test_suite where active = 'true'";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				Set<String> eachItem = new TreeSet<>();
				for (HashMap<String, Object> hashMap : resultHash) {
					eachItem.add(hashMap.get("test_suite_name").toString());
				}
				response.setTestSuites(eachItem);
			} else if (resultHash.size() == 0) {
				response.setTestSuites(null);
			}

			String query2 = "SELECT test_case_name FROM rule_process.test_cases where active = 'true'";
			List<HashMap<String, Object>> resultHash2 = sql.executeSelect(query2);

			if (resultHash2.size() > 0) {
				Set<String> eachItem = new TreeSet<>();
				for (HashMap<String, Object> hashMap : resultHash2) {
					eachItem.add(hashMap.get("test_case_name").toString());
				}
				response.setTestCases(eachItem);
			} else if (resultHash2.size() == 0) {
				response.setTestCases(null);
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return response;
	}


	public CommonServiceResponse modifyData(String action, final TestSuite data) throws Exception {
		CommonServiceResponse response = new CommonServiceResponse();
		String query = null;
		Connection conn = null;
		Statement stmt = null;
		PreparedStatement preparedStmt = null;

		try {
			String jdbcClass = "com.mysql.jdbc.Driver";
			String connectionHostPort = "localhost";
			String schema = "atom";
			String sqlUser = "root";
			String sqlPwd = "root";

			// Load Classname and connection URL
			Class.forName(jdbcClass);
			String connectionUrl = "jdbc:mysql://" + connectionHostPort + "/" + schema + "";

			// Set SQL Properties
			Properties properties = new Properties();
			properties.setProperty("user", sqlUser);
			properties.setProperty("password", sqlPwd);
			properties.setProperty("useSSL", "true");
			properties.setProperty("autoReconnect", "true");
			properties.setProperty("verifyServerCertificate", "false");

			// Create Connection
			conn = DriverManager.getConnection(connectionUrl, properties);
			conn.setAutoCommit(false);
			conn.rollback();

			switch (action.toLowerCase()) {
			case "insert":

				query = "INSERT INTO rule_process.test_suite (`test_suite_name`, `test_suite_desc`,"
						+ "`active`, `created_by`, `updated_by`) " + "VALUES "
						+ "(?, ?, ?, ?, ?)";

				preparedStmt = conn.prepareStatement(query);
				preparedStmt.setString(1, data.getTest_suite_name());
				preparedStmt.setObject(2, data.getTest_suite_desc());
				preparedStmt.setString(3, data.getActive().toString());
				preparedStmt.setString(4, data.getCreated_by().toString());
				preparedStmt.setString(5, data.getUpdated_by().toString());

				break;

			case "update":
				query = "UPDATE rule_process.test_suite set test_suite_desc=?,active=?,updated_by=? where test_suite_name =?";
				
				preparedStmt = conn.prepareStatement(query);

				preparedStmt.setObject(1, data.getTest_suite_desc());
				preparedStmt.setString(2, data.getActive().toString());
				preparedStmt.setString(3, data.getUpdated_by().toString());
				preparedStmt.setString(4, data.getTest_suite_name());
				
				break;

			case "delete":
				query = "DELETE FROM rule_process.test_suite where test_suite_name=?";
				preparedStmt = conn.prepareStatement(query);

				preparedStmt.setObject(1, data.getTest_suite_name());
				break;

			default:
				log.error("Invalid Action choosen!");
				throw new Exception(
						"Invalid Action choosen. Choose one of the following action : INSERT/UPDATE/DELETE");
			}

			log.info("Executing Update/Delete Query : [ " + query + " ]");

			int count = preparedStmt.executeUpdate();
			conn.commit();

			log.info("Count of Rows Updated/Deleted Successfully : [ " + count + " ]");
			if (count > 0) {
				response.setKey(data.getTest_suite_name().toString());
				// response.setName(data.getSubModuleName().toString());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully");
				response.setCode("200");

			} else if (count == 0) {
				response.setKey(data.getTest_suite_name().toString());
				// response.setName(data.getSubModuleName().toString());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully. No Rows Affected");
				response.setCode("201");

			}

		} catch (SQLIntegrityConstraintViolationException e) {
			e.printStackTrace();
			log.error("SQLIntegrityConstraintViolationException occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getTest_suite_name().toString());
			// response.setName(data.getSubModuleName().toString());
			response.setAction(action);
			response.setStatus("failure");
			response.setReason(
					"Insert/Update/Delete failed due to SQL Contraint Error. May be duplicate key Insert or foriegn key constraint");
			response.setCode("500");

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("SQL Exception occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getTest_suite_name().toString());
			// response.setName(data.getSubModuleName().toString());
			response.setAction(action);
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to SQL Exception.");
			response.setCode("500");

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Common Exception occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getTest_suite_name().toString());
			// response.setName(data.getSubModuleName().toString());
			response.setAction(action);
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to Common Exception.");
			response.setCode("500");

		} finally {
			if (conn != null) {
				conn.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}

		return response;
	}

	public static void main(String[] args) throws Exception {
		TestSuiteService obj = new TestSuiteService();
		obj.getAllData();
	}

}
