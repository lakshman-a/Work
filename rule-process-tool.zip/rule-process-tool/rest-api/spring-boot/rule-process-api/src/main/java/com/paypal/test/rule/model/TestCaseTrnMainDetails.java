package com.paypal.test.rule.model;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

public class TestCaseTrnMainDetails {

	private String caseName;
	private String testDataFlag;
	private Object testDataKeys;
	private Object testData;
	private List<TestCaseTrnActionDetails> testcaseTrnDetails;



	public String getCaseName() {
		return caseName;
	}

	public void setCaseName(String caseName) {
		this.caseName = caseName;
	}

	public String getTestDataFlag() {
		return testDataFlag;
	}

	public void setTestDataFlag(String testDataFlag) {
		this.testDataFlag = testDataFlag;
	}

	public Object getTestData() {
		return testData;
	}

	public void setTestData(Object testData) {
		this.testData = testData;
	}

	public List<TestCaseTrnActionDetails> getTestcaseTrnDetails() {
		return testcaseTrnDetails;
	}

	public void setTestcaseTrnDetails(List<TestCaseTrnActionDetails> testcaseTrnDetails) {
		this.testcaseTrnDetails = testcaseTrnDetails;
	}

	public Object getTestDataKeys() {
		return testDataKeys;
	}

	public void setTestDataKeys(Object testDataKeys) {
		this.testDataKeys = testDataKeys;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
