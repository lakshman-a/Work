package com.paypal.test.rule.model;

public class ActionResponseExtractParams {

	private String jsonPath;
	private String jsonValue;
	private String variable;


	public String getJsonPath() {
		return jsonPath;
	}

	public void setJsonPath(String jsonPath) {
		this.jsonPath = jsonPath;
	}

	public String getJsonValue() {
		return jsonValue;
	}

	public void setJsonValue(String jsonValue) {
		this.jsonValue = jsonValue;
	}

	public String getVariable() {
		return variable;
	}

	public void setVariable(String variable) {
		this.variable = variable;
	}


	@Override
	public String toString() {
		return "{jsonPath : " + jsonPath + ",variable : " + variable + ", jsonValue : "+jsonValue+"}";
	}


}
