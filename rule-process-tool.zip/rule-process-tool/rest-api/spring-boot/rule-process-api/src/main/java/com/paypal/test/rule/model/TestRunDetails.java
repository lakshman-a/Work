package com.paypal.test.rule.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class TestRunDetails {

	private String id;
	private String run_id;
	private String run_level;
	private String test_name;
	private Object stage;
	private String case_count;
	private String status;
	private String result;
	private Object report_file;
	private Object comments;
	private Object grid_url;
	private Object browser;
	private String triggered_by;
	private String triggered_tmstmp;
	private String updated_tmstmp;
	private String percentComplete;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRun_id() {
		return run_id;
	}

	public void setRun_id(String run_id) {
		this.run_id = run_id;
	}

	public String getRun_level() {
		return run_level;
	}

	public void setRun_level(String run_level) {
		this.run_level = run_level;
	}

	public String getTest_name() {
		return test_name;
	}

	public void setTest_name(String test_name) {
		this.test_name = test_name;
	}

	public Object getStage() {
		return stage;
	}

	public void setStage(Object stage) {
		this.stage = stage;
	}

	public String getCase_count() {
		return case_count;
	}

	public void setCase_count(String case_count) {
		this.case_count = case_count;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Object getReport_file() {
		return report_file;
	}

	public void setReport_file(Object report_file) {
		this.report_file = report_file;
	}

	public Object getComments() {
		return comments;
	}

	public void setComments(Object comments) {
		this.comments = comments;
	}

	public Object getGrid_url() {
		return grid_url;
	}

	public void setGrid_url(Object grid_url) {
		this.grid_url = grid_url;
	}

	public Object getBrowser() {
		return browser;
	}

	public void setBrowser(Object browser) {
		this.browser = browser;
	}

	public String getTriggered_by() {
		return triggered_by;
	}

	public void setTriggered_by(String triggered_by) {
		this.triggered_by = triggered_by;
	}

	public String getTriggered_tmstmp() {
		return triggered_tmstmp;
	}

	public void setTriggered_tmstmp(String triggered_tmstmp) {
		this.triggered_tmstmp = triggered_tmstmp;
	}

	public String getUpdated_tmstmp() {
		return updated_tmstmp;
	}

	public void setUpdated_tmstmp(String updated_tmstmp) {
		this.updated_tmstmp = updated_tmstmp;
	}

	public String getPercentComplete() {
		return percentComplete;
	}

	public void setPercentComplete(String percentComplete) {
		this.percentComplete = percentComplete;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
