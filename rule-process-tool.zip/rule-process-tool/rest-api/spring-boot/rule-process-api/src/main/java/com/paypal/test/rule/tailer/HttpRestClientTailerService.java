package com.paypal.test.rule.tailer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.paypal.test.jaws.http.rest.PayPalRestClientFactory;
import com.paypal.test.jaws.http.rest.impl.EntityRestClient;
import com.paypal.test.rule.model.HeaderPojo;
import com.paypal.test.rule.model.LogPattern;
import com.paypal.test.rule.model.RuleFireResponse;

/**
 * Provides remote tailing facilities via ssh.
 */
public class HttpRestClientTailerService {

	final static Logger log = Logger.getLogger(HttpRestClientTailerService.class);
	private static final String DEFAULT_TAIL_COMMAND = "tail -F";

	private final TailerCallback tailerListener;
	private final Executor executor;
	private final JSch jsch;
	private final CountDownLatch completed;

	private String tailCommand;
	private Session session;
	private String filePath;
	private volatile boolean stopping;
	private volatile Thread inputThread;
	private volatile Thread errorThread;

	BufferedWriter writer = null;
	FileWriter fileWriter = null;
	private static String logContents;
	private static List<String> logContentList;
	private static boolean isLogPatternSuccess;
	private static String logPatternErrorMsg;

	public HttpRestClientTailerService() {
		this.jsch = null;
		this.tailerListener = null;
		this.executor = null;
		completed = null;
		tailCommand = null;
		session = null;
		filePath = null;
		stopping = false;
		errorThread = null;
		logContents = "";

	}

	public HttpRestClientTailerService(JSch jsch, TailerCallback listener, Executor executor, String stage,
			String filePathVariable, String username, String password) throws IOException {
		this.jsch = jsch;
		this.tailerListener = listener;
		this.executor = executor;
		completed = new CountDownLatch(1);

		tailCommand = DEFAULT_TAIL_COMMAND;
		stopping = false;

		filePath = filePathVariable;
		log.info("filePath {} :" + filePath);
		logContents = "";
		logContentList = new ArrayList<>();
		isLogPatternSuccess = false;
		logPatternErrorMsg = null;

		try {

			session = jsch.getSession(username, stage, 22);
			session.setPassword(password);
			session.setConfig("StrictHostKeyChecking", "no");
		} catch (JSchException e) {
			throw new IOException(e);
		}
	}

	public JSch getJsch() {
		return jsch;
	}

	public Session getSession() {
		return session;
	}

	public void setTailCommand(String tailCommand) {
		this.tailCommand = tailCommand;
	}

	/**
	 * Commence tailing.
	 */
	private void start() {

//		try {
//			fileWriter = new FileWriter("C:\\Users\\layyakannu\\Desktop\\log.txt");
//			writer = new BufferedWriter(fileWriter);
//		} catch (IOException e) {
//			log.error("Error while writing to a file");
//			e.printStackTrace();
//		}

		log.debug("start");
		Runnable runnable = new Runnable() {

			@Override
			public void run() {
				inputThread = Thread.currentThread();
				remoteTailWrapped();
			}
		};
		executor.execute(runnable);
	}

	/**
	 * Cease tailing.
	 */
	private void stop() {

//		try {
//			if (writer != null)
//				writer.close();
//			if (fileWriter != null)
//				fileWriter.close();
//		} catch (IOException e) {
//			log.error("File buffer close exception");
//			e.printStackTrace();
//		}

		log.debug("stop");
		stopping = true;
		if (errorThread != null) {
			errorThread.interrupt();
		}
		if (inputThread != null) {
			inputThread.interrupt();
		}
	}

	/**
	 * Wait for tail thread to terminate.
	 * 
	 * @throws InterruptedException
	 */
	private void await() throws InterruptedException {
		completed.await();
	}

	private void remoteTailWrapped() {
		log.debug("start remoteTailWrapped");
		try {
			remoteTail();
		} catch (Exception e) {
			log.debug("exception", e);
			logPatternErrorMsg = e.getMessage();
			if (!stopping) {
				tailerListener.handleException(e);
			}
		

		} finally {
			completed.countDown();
		}
		log.debug("end remoteTailWrapped");
	}

	private void remoteTail() throws Exception {
		session.connect();
		log.info("Session Connected suucessfully");
		ChannelExec channel = (ChannelExec) session.openChannel("exec");
		String command = tailCommand;

		log.info("command: " + command);
		// channel.setPty(true);

		((ChannelExec) channel).setCommand("sudo -S -p '' " + command);

		channel.setInputStream(null);
		InputStream errStream = channel.getErrStream();
		InputStream inputStream = channel.getInputStream();
		OutputStream out = channel.getOutputStream();

		channel.connect();
		log.debug("channel connected");
		
		drainErrorStream(errStream);
		drainInputStream(inputStream, out);

		channel.disconnect();
		session.disconnect();
	}

	private void drainInputStream(final InputStream inputStream, final OutputStream out) throws IOException {

		String sudo_pass = "Paypal@123";
		out.write((sudo_pass + "\n").getBytes());
		out.flush();

		log.info("Password enter done!");

		BufferedReader inputReader = new BufferedReader(new InputStreamReader(inputStream));
		isLogPatternSuccess = true;
		while (!stopping) {
			String line = inputReader.readLine();
			// writer.write(line + "\n");
			// logContents=this.logContents+line+"\n";
			// appeandLogContents(line);
			logContents = logContents + line + "\n";
			if (line != null) {
				logContentList.add(line);
			}

			if (line == null) {
				break;
			}
			tailerListener.handleLine(line);
		}

		log.debug("input stream drained");

	}

	private void drainErrorStream(final InputStream errStream) {

		Runnable drainer = new Runnable() {

			@Override
			public void run() {
				errorThread = Thread.currentThread();
				BufferedReader errReader = new BufferedReader(new InputStreamReader(errStream));

				while (true) {
					String line;
					try {
						line = errReader.readLine();
					} catch (IOException e) {
						//isLogPatternSuccess = false;
						//logPatternErrorMsg = e.getMessage();
						log.debug("exception", e);
						return;
					}
					if (line == null) {
						break;
					}
					log.error("remote process error: " + line);
					tailerListener.handleLine(String.format("[%s]", line));
				}
				log.debug("error stream drained");
			}

		};

		executor.execute(drainer);
	}

	/**
	 * HTTP Methods
	 */

	public RuleFireResponse doPostWithTail(String url, List<HeaderPojo> headers, String payload, String stage,
			String username, String password, List<LogPattern> logPatterns) throws Exception {
		RuleFireResponse response = new RuleFireResponse();
		Object rawHttpResponse = null;

		log.info("********* HTTP POST CALL WITH TAIL ************");
		log.info("Request Details: ");
		log.info("URL: " + url);
		log.info("Headers: " + headers.toString());
		log.info("Payload: " + payload);

		log.info("Full StageName for Log Check : " + stage);
		String onlyStage = stage.substring(0, 14);
		log.info("Extracted StageName: " + onlyStage);

		log.info("Username: " + username);
		byte[] valueDecoded = Base64.getDecoder().decode(password);
		String decodedPassword = new String(valueDecoded, Charset.forName("UTF-8"));

		log.info("LogPatterns: " + logPatterns);

		try {

			String egrepLogsString = "";
			if (logPatterns.size() > 2) {

				int i = 0;
				for (LogPattern eachLogPattern : logPatterns) {

					if (i == 0 | i == logPatterns.size()) {
						egrepLogsString = egrepLogsString + eachLogPattern.getPattern();
					} else {
						egrepLogsString = egrepLogsString + "|" + eachLogPattern.getPattern();
					}

					i++;
				}

			} else if (logPatterns.size() == 2) {
				egrepLogsString = logPatterns.get(0).getPattern() + "|" + logPatterns.get(1).getPattern();
			} else if (logPatterns.size() == 1) {
				egrepLogsString = logPatterns.get(0).getPattern();
			}
			log.info("Grep Pattern after OR'ing : " + egrepLogsString);

			String filePath = "/x/web/" + onlyStage.toUpperCase() + "/riskresolutiondecisionserv/logs";
			String cmd = "tail -n0 -f /x/web/" + onlyStage.toUpperCase()
					+ "/riskresolutiondecisionserv/logs/server.log |unbuffer -p egrep -i '" + egrepLogsString + "'";

			ExecutorService executor = Executors.newFixedThreadPool(10, new DaemonThreadFactory());
			TailerCallback listener = new TailerCallback() {

				@Override
				public void handleLine(String line) {
					log.info("log line: " + line);
				}

				@Override
				public void handleException(Exception ex) {
					log.error("Unexpected exception", ex);
				}
			};

			JSch jsch = new JSch();
			HttpRestClientTailerService tailer = new HttpRestClientTailerService(jsch, listener, executor, stage,
					filePath, username, decodedPassword);
			tailer.setTailCommand(cmd);

			// TAILER STARTS
			tailer.start();
			log.info("Sleeping for 7 Secs : ");
			Thread.sleep(10000);

			// --------------------- HTTP ACTIONS STARTS --------------------------------//

			EntityRestClient<String> testClient = (EntityRestClient<String>) PayPalRestClientFactory
					.createEntityClient(String.class, new URL(url), MediaType.APPLICATION_JSON);

			for (HeaderPojo eachheader : headers) {
				testClient.addHeader(eachheader.getKey(), eachheader.getValue());
			}

			try {
				rawHttpResponse = testClient.simplePost(payload);
				response.setResponse_body(rawHttpResponse);

			} catch (javax.ws.rs.WebApplicationException e) {
				log.info(
						"Response Code for the Request is not 200. So Capturing the response from Exception. Exception is - "
								+ e);
				rawHttpResponse = e.getLocalizedMessage();
				e.printStackTrace();
			}

			response.setStatus_code(String.valueOf(testClient.getStatus().getStatusCode()));
			response.setStatus_phrase(testClient.getStatus().getReasonPhrase());
			response.setResponse_time(String.valueOf(testClient.getElapsedMillis()) + " ms");
			response.setResponse_headers(testClient.getResponseHeaders().toString());

			// --------------------- HTTP ACTIONS END --------------------------------//

			Thread.sleep(10000);
			// TAILER ENDS
			tailer.stop();

			// Process ENds

			tailer.await();
			log.debug("shutdown");
			executor.shutdown();
			log.debug("awaitTermination");
			executor.awaitTermination(1, TimeUnit.MINUTES);
			log.info("normal termination");

			if (isLogPatternSuccess) {
				log.info("Log Pattern retrieval success");
				log.info("Final Extracted Log Contents List: " + logContentList);
				response.setIsLogPatternSuccess("true");
				response.setLogPatternErrorMsg(null);

				for (LogPattern logPattern : logPatterns) {
					int j = 1;
					for (String eachStageLog : logContentList) {
						if (eachStageLog.toLowerCase().contains(logPattern.getPattern().toLowerCase())) {

							if (j > 1) {
								logPattern.setLogValue(logPattern.getLogValue() + " | " + eachStageLog);
							} else {
								logPattern.setLogValue(eachStageLog);
							}
						}
						j++;
					}
				}

				response.setLogPattern(logPatterns);
			} else {
				log.info("Log Pattern retrieval failed");
				log.info("Exception found is : " + logPatternErrorMsg);
				response.setIsLogPatternSuccess("false");
				response.setLogPatternErrorMsg(logPatternErrorMsg);
				response.setLogPattern(logPatterns);
			}

			log.info("Updated Final Log Contents List to send: " + logPatterns);

			log.info("Response Details: ");
			log.info("Status Code: " + testClient.getStatus().getStatusCode());
			log.info("Status Phrase: " + testClient.getStatus().getReasonPhrase());
			log.info("Response Time: " + String.valueOf(testClient.getElapsedMillis()) + " ms");
			log.info("Response Headers: " + String.valueOf(testClient.getResponseHeaders().toString()));
			log.info("Response Body: " + rawHttpResponse);
			log.info("Response Log Patterns: " + logPatterns);

		} catch (Exception e) {
			log.error("Exception occured while involing the POST Request. Exception is : " + e);
			e.printStackTrace();
			throw e;
		}
		return response;
	}

	public static void main(String[] args) throws Exception {
	}

}
