package com.paypal.test.rule.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

public class MysqlDbHelper extends DbHelper {
	final static Logger log = Logger.getLogger(MysqlDbHelper.class);

	public List<HashMap<String, Object>> executeSelect(String query) throws Exception {

		ResultSet rs = null;
		Connection conn = null;
		Statement stmt = null;

		try {
			String jdbcClass = "com.mysql.jdbc.Driver";
			String connectionHostPort = "localhost";
			String schema = "atom";
			String sqlUser = "root";
			String sqlPwd = "root";

			// Load Classname and connection URL
			Class.forName(jdbcClass);
			String connectionUrl = "jdbc:mysql://" + connectionHostPort + "/" + schema + "";

			// Set SQL Properties
			Properties properties = new Properties();
			properties.setProperty("user", sqlUser);
			properties.setProperty("password", sqlPwd);
			properties.setProperty("useSSL", "true");
			properties.setProperty("autoReconnect", "true");
			properties.setProperty("verifyServerCertificate", "false");

			// Create Connection
			conn = DriverManager.getConnection(connectionUrl, properties);

			// Create Statement
			stmt = conn.createStatement();

			log.info("Executing Select Query : [ " + query + " ]");
			rs = stmt.executeQuery(query);

			if (!rs.isBeforeFirst()) {
				rs.close();
				log.info("No Data from Result Set");
				return new ArrayList<HashMap<String, Object>>();
			} else {
				List<HashMap<String, Object>> resultSetToHashTable = convertResultsetToHashList(rs);
				return resultSetToHashTable;
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("SQL Exception occured while executing Select Query : " + e);
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Common Exception occured while executing Select Query : " + e);
			throw e;
		} finally {
			rs.close();
			if (conn != null) {
				conn.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}

	}

	public int executeUpdate(String query) throws Exception {

		int count = -1;
		Connection conn = null;
		Statement stmt = null;

		try {
			String jdbcClass = "com.mysql.jdbc.Driver";
			String connectionHostPort = "localhost";
			String schema = "atom";
			String sqlUser = "root";
			String sqlPwd = "root";

			// Load Classname and connection URL
			Class.forName(jdbcClass);
			String connectionUrl = "jdbc:mysql://" + connectionHostPort + "/" + schema + "";

			// Set SQL Properties
			Properties properties = new Properties();
			properties.setProperty("user", sqlUser);
			properties.setProperty("password", sqlPwd);
			properties.setProperty("useSSL", "true");
			properties.setProperty("autoReconnect", "true");
			properties.setProperty("verifyServerCertificate", "false");

			// Create Connection
			conn = DriverManager.getConnection(connectionUrl, properties);
			conn.setAutoCommit(false);
			conn.rollback();

			//
			log.info("Executing Update/Delete Query : [ " + query + " ]");

			// Create Statement
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			count = stmt.executeUpdate(query);
			conn.commit();

			log.info("Count of Rows Updated/Deleted Successfully : [ " + count + " ]");

		} catch (SQLIntegrityConstraintViolationException e) {
			e.printStackTrace();
			log.error("SQLIntegrityConstraintViolationException occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			return -2;
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("SQL Exception occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			return -3;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Common Exception occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			return -4;
		} finally {
			if (conn != null) {
				conn.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}
		return count;

	}
	
	public List<HashMap<String, Object>> convertResultsetToHashList(ResultSet rs) throws Exception {
		ResultSetMetaData md = rs.getMetaData();
		List<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();

		while (rs.next()) {
			HashMap<String, Object> row = new HashMap<String, Object>(md.getColumnCount());
			for (int i = 1; i <= md.getColumnCount(); i++) {
				row.put(md.getColumnLabel(i), rs.getObject(i));
			}
			list.add(row);
		}
		return list;
	}

	public static void main(String[] args) throws Exception {
		MysqlDbHelper sql = new MysqlDbHelper();
//		List<HashMap<String, Object>> rs = sql.executeSelect("select * from atom.user_data");
//		for (HashMap<String, Object> hashMap : rs) {
//			System.out.println(hashMap.get("email_id"));
//			
//		}

		log.info(sql.executeUpdate("Update atom.user_data set last_name ='AA' where first_name='LAKSHMAN'"));

	}

}
