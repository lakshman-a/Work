package com.paypal.test.rule.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.paypal.test.rule.enums.RequestParamTypes;
import com.paypal.test.rule.helper.MysqlDbHelper;
import com.paypal.test.rule.model.CommonServiceResponse;
import com.paypal.test.rule.model.TestActions;

public class TestActionService {
	MysqlDbHelper sql = new MysqlDbHelper();
	final static Logger log = Logger.getLogger(TestActionService.class);

	public List<TestActions> getAllData() throws Exception {
		List<TestActions> responseList = new ArrayList<>();
		try {
			String query = "SELECT * FROM rule_process.test_action order by id desc";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				for (HashMap<String, Object> hashMap : resultHash) {
					TestActions eachItem = new TestActions();
					eachItem.setId(hashMap.get("id").toString());
					eachItem.setActionName(hashMap.get("action_name").toString());
					eachItem.setActionDesc(hashMap.get("action_desc").toString());
					eachItem.setHttpMethod(hashMap.get("http_method").toString());
					eachItem.setHttpUrlFlag(hashMap.get("http_url_flag").toString());
					eachItem.setHttpUrl(hashMap.get("http_url"));
					eachItem.setComponentName(hashMap.get("component_name"));
					eachItem.setCheckpointName(hashMap.get("checkpoint_name"));
					eachItem.setProjectName(hashMap.get("project_name").toString());
					eachItem.setResponseAction(hashMap.get("response_Action").toString());
					eachItem.setActive(hashMap.get("active").toString());
					eachItem.setCreated_tmstmp(hashMap.get("created_tmstmp").toString());
					eachItem.setCreated_by(hashMap.get("created_by").toString());
					eachItem.setUpdated_tmstmp(hashMap.get("updated_tmstmp").toString());
					eachItem.setUpdated_by(hashMap.get("updated_by").toString());
					responseList.add(eachItem);
				}
			} else if (resultHash.size() == 0) {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return responseList;
	}

	public TestActions getData(String data) throws Exception {
		TestActions eachItem = new TestActions();
		try {
			String query = "SELECT * FROM rule_process.test_action where action_name = '" + data + "'";
			List<HashMap<String, Object>> resultHash = sql.executeSelect(query);

			if (resultHash.size() > 0) {
				for (HashMap<String, Object> hashMap : resultHash) {

					eachItem.setId(hashMap.get("id").toString());
					eachItem.setActionName(hashMap.get("action_name").toString());
					eachItem.setActionDesc(hashMap.get("action_desc").toString());
					eachItem.setHttpMethod(hashMap.get("http_method").toString());

					eachItem.setHttpUrlFlag(hashMap.get("http_url_flag").toString());
					eachItem.setHttpUrl(hashMap.get("http_url"));
					eachItem.setHttpStageProtocol(hashMap.get("http_type"));
					eachItem.setHttpStageName(hashMap.get("http_stage"));
					eachItem.setHttpStagePort(hashMap.get("http_port"));
					eachItem.setHttpStageUri(hashMap.get("http_uri"));

					eachItem.setComponentName(hashMap.get("component_name"));
					eachItem.setCheckpointName(hashMap.get("checkpoint_name"));
					eachItem.setProjectName(hashMap.get("project_name").toString());

					eachItem.setHeaders(hashMap.get("headers").toString());
					eachItem.setRequestBody(hashMap.get("request_Body"));
					eachItem.setRequestParams(hashMap.get("request_Params"));
					if (hashMap.get("request_params_variables") != null) {
						eachItem.setRequestParamsVariables(hashMap.get("request_params_variables").toString());
					}
					eachItem.setResponseAction(hashMap.get("response_Action").toString());
					eachItem.setResponseCodeFlag(hashMap.get("response_code_flag").toString());
					eachItem.setResponseCodeValue(hashMap.get("response_code_value"));
					eachItem.setResponseStatusFlag(hashMap.get("response_status_flag").toString());
					eachItem.setResponseStatusValue(hashMap.get("response_status_value"));

					if (hashMap.get("response_Body") != null) {
						eachItem.setResponseBody(hashMap.get("response_Body").toString());
					}

					eachItem.setResponseAssertParams(hashMap.get("response_Assert_Params"));
					eachItem.setResponseExtractParams(hashMap.get("response_Extract_Params"));
					if (hashMap.get("response_params_variables") != null) {
						eachItem.setResponseParamsVariables(hashMap.get("response_params_variables").toString());
					}
					eachItem.setActive(hashMap.get("active").toString());
					eachItem.setCreated_tmstmp(hashMap.get("created_tmstmp").toString());
					eachItem.setCreated_by(hashMap.get("created_by").toString());
					eachItem.setUpdated_tmstmp(hashMap.get("updated_tmstmp").toString());
					eachItem.setUpdated_by(hashMap.get("updated_by").toString());
				}
			} else if (resultHash.size() == 0) {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured in Service Layer : " + e);
			throw e;
		}
		return eachItem;
	}

	public CommonServiceResponse modifyData(String action, final TestActions data) throws Exception {
		CommonServiceResponse response = new CommonServiceResponse();
		String query = null;
		Connection conn = null;
		Statement stmt = null;
		PreparedStatement preparedStmt = null;

		try {
			String jdbcClass = "com.mysql.jdbc.Driver";
			String connectionHostPort = "localhost";
			String schema = "atom";
			String sqlUser = "root";
			String sqlPwd = "root";

			// Load Classname and connection URL
			Class.forName(jdbcClass);
			String connectionUrl = "jdbc:mysql://" + connectionHostPort + "/" + schema + "";

			// Set SQL Properties
			Properties properties = new Properties();
			properties.setProperty("user", sqlUser);
			properties.setProperty("password", sqlPwd);
			properties.setProperty("useSSL", "true");
			properties.setProperty("autoReconnect", "true");
			properties.setProperty("verifyServerCertificate", "false");

			// Create Connection
			conn = DriverManager.getConnection(connectionUrl, properties);
			conn.setAutoCommit(false);
			conn.rollback();

			switch (action.toLowerCase()) {
			case "insert":

				query = "INSERT INTO rule_process.test_action (`action_name`, `action_desc`, `http_method`,`http_url_flag`,`http_url`,`http_type`,`http_stage`,`http_port`,`http_uri`, `component_name`, "
						+ "`checkpoint_name`, `headers`, `created_by`, `updated_by`, `request_Body`, `request_Params`,`request_params_variables`,`response_action`, "
						+ "`response_Body`,`response_code_flag`,`response_code_value`,`response_status_flag`,`response_status_value`, `response_Assert_Params`, `response_Extract_Params`,`response_params_variables`,`project_name`) "
						+ "VALUES " + "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

				preparedStmt = conn.prepareStatement(query);
				preparedStmt.setString(1, data.getActionName());
				preparedStmt.setObject(2, data.getActionDesc());
				preparedStmt.setString(3, data.getHttpMethod());

				preparedStmt.setString(4, data.getHttpUrlFlag());
				preparedStmt.setObject(5, data.getHttpUrl());
				preparedStmt.setObject(6, data.getHttpStageProtocol());
				preparedStmt.setObject(7, data.getHttpStageName());
				preparedStmt.setObject(8, data.getHttpStagePort());
				preparedStmt.setObject(9, data.getHttpStageUri());

				preparedStmt.setObject(10, data.getComponentName());
				preparedStmt.setObject(11, data.getCheckpointName());

				preparedStmt.setString(12, data.getHeaders());
				preparedStmt.setString(13, data.getCreated_by());
				preparedStmt.setString(14, data.getUpdated_by());
				preparedStmt.setObject(15, data.getRequestBody());
				preparedStmt.setObject(16, data.getRequestParams());
				preparedStmt.setObject(17, extractAllTestDataVaraibles(data.getHttpUrlFlag(), data.getHttpUrl(), data.getHttpStageUri(),
						data.getHeaders(), data.getRequestParams()));

				preparedStmt.setObject(18, data.getResponseAction());
				preparedStmt.setObject(19, data.getResponseBody());
				preparedStmt.setString(20, data.getResponseCodeFlag());
				preparedStmt.setObject(21, data.getResponseCodeValue());
				preparedStmt.setString(22, data.getResponseStatusFlag());
				preparedStmt.setObject(23, data.getResponseStatusValue());
				preparedStmt.setObject(24, data.getResponseAssertParams());
				preparedStmt.setObject(25, data.getResponseExtractParams());
				preparedStmt.setObject(26, extractResponseTestDataVaraibles(data.getResponseAssertParams()));

				preparedStmt.setObject(27, data.getProjectName());

				break;

			case "update":
				query = "UPDATE rule_process.test_action set action_desc=?,http_method=?,http_url_flag=?,http_url=?,http_type=?,http_stage=?,http_port=?,http_uri=?,component_name=?,checkpoint_name=?,"
						+ "headers=?,request_Body=?,request_Params=?,request_params_variables=?,response_action=?,response_Body=?,response_code_flag=?,response_code_value=?,response_status_flag=?,response_status_value=?,"
						+ "response_Assert_Params=?,response_Extract_Params=?,response_params_variables=?,active=?,updated_by=?,project_name=? where action_name=?";

				preparedStmt = conn.prepareStatement(query);

				preparedStmt.setObject(1, data.getActionDesc());
				preparedStmt.setString(2, data.getHttpMethod());

				preparedStmt.setString(3, data.getHttpUrlFlag());
				preparedStmt.setObject(4, data.getHttpUrl());
				preparedStmt.setObject(5, data.getHttpStageProtocol());
				preparedStmt.setObject(6, data.getHttpStageName());
				preparedStmt.setObject(7, data.getHttpStagePort());
				preparedStmt.setObject(8, data.getHttpStageUri());

				preparedStmt.setObject(9, data.getComponentName());
				preparedStmt.setObject(10, data.getCheckpointName());
				preparedStmt.setObject(11, data.getHeaders());
				preparedStmt.setObject(12, data.getRequestBody());
				preparedStmt.setObject(13, data.getRequestParams());
				preparedStmt.setObject(14, extractAllTestDataVaraibles(data.getHttpUrlFlag(), data.getHttpUrl(), data.getHttpStageUri(),
						data.getHeaders(), data.getRequestParams()));

				preparedStmt.setObject(15, data.getResponseAction());
				preparedStmt.setObject(16, data.getResponseBody());
				preparedStmt.setString(17, data.getResponseCodeFlag());
				preparedStmt.setObject(18, data.getResponseCodeValue());
				preparedStmt.setString(19, data.getResponseStatusFlag());
				preparedStmt.setObject(20, data.getResponseStatusValue());
				preparedStmt.setObject(21, data.getResponseAssertParams());
				preparedStmt.setObject(22, data.getResponseExtractParams());
				preparedStmt.setObject(23, extractResponseTestDataVaraibles(data.getResponseAssertParams()));

				preparedStmt.setObject(24, data.getActive());
				preparedStmt.setObject(25, data.getUpdated_by());
				preparedStmt.setObject(26, data.getProjectName());

				preparedStmt.setObject(27, data.getActionName());

				break;

			case "delete":
				query = "DELETE FROM rule_process.test_action where action_name=?";
				preparedStmt = conn.prepareStatement(query);
				preparedStmt.setString(1, data.getActionName());
				break;

			default:
				log.error("Invalid Action choosen!");
				throw new Exception("Invalid Action choosen. Choose one of the following action : INSERT/UPDATE/DELETE");
			}

			log.info("Executing Update/Delete Query : [ " + query + " ]");

			int count = preparedStmt.executeUpdate();
			conn.commit();

			log.info("Count of Rows Updated/Deleted Successfully : [ " + count + " ]");
			if (count > 0) {
				response.setKey(data.getActionName().toString());
				// response.setName(data.getActionDesc().toString());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully");
				response.setCode("200");

			} else if (count == 0) {
				response.setKey(data.getActionName().toString());
				// response.setName(data.getActionDesc().toString());
				response.setAction(action);
				response.setStatus("success");
				response.setReason("Insert/Update/Delete Done successfully. No Rows Affected");
				response.setCode("201");

			}

		} catch (SQLIntegrityConstraintViolationException e) {
			e.printStackTrace();
			log.error("SQLIntegrityConstraintViolationException occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getActionName().toString());
			// response.setName(data.getActionDesc().toString());
			response.setAction(action);
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to SQL Contraint Error - " + e.getMessage());
			response.setCode("500");

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("SQL Exception occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getActionName().toString());
			// response.setName(data.getActionDesc().toString());
			response.setAction(action);
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to SQL Exception - " + e.getMessage());
			response.setCode("500");

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Common Exception occured while executing Update/Delete Query : " + e);
			if (conn != null) {
				conn.rollback();
			}
			response.setKey(data.getActionName().toString());
			// response.setName(data.getActionDesc().toString());
			response.setAction(action);
			response.setStatus("failure");
			response.setReason("Insert/Update/Delete failed due to Common Exception - " + e.getMessage());
			response.setCode("500");

		} finally {
			if (conn != null) {
				conn.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}

		return response;
	}

	private String extractAllTestDataVaraibles(String httpUrlFlag, Object httpUrl, Object stageUri, Object headers, Object requestParams)
			throws Exception {
		JSONArray listOfVariables = new JSONArray();
		List<String> list = new ArrayList<>();
		try {
			// Variables from HttpFlag
			if (httpUrlFlag.equalsIgnoreCase("URL")) {
				if (httpUrl != null) {
					if (!httpUrl.toString().trim().equals("")) {
						list.addAll(extractVariablesFromGivenString(httpUrl.toString()));
					}
				}
			} else if (httpUrlFlag.equalsIgnoreCase("STAGE")) {
				if (stageUri != null) {
					if (!stageUri.toString().trim().equals("")) {
						list.addAll(extractVariablesFromGivenString(stageUri.toString()));
					}
				}
			}

			// Variables from headers
			if (headers != null) {
				if (!headers.toString().trim().equals("")) {
					list.addAll(extractVariablesFromGivenString(headers.toString()));
				}
			}

			list.remove("stage");
			// transforming list to JSON variables
			if (list.size() > 0) {
				for (String paramName : list) {
					listOfVariables.put(paramName);
				}
			}

			// Request Param transform
			if (requestParams != null) {
				JSONArray jsonArr = new JSONArray(requestParams.toString());
				if (jsonArr.length() > 0) {
					for (int i = 0; i < jsonArr.length(); i++) {
						JSONObject jsonObj = jsonArr.getJSONObject(i);
						String type = jsonObj.getString("paramType");
						String paramName = jsonObj.getString("paramName");
						if (type.equalsIgnoreCase(RequestParamTypes.TESTDATA.value())) {
							log.info("Adding Param Name to list : " + paramName);
							listOfVariables.put(paramName);
						}
					}
				} else {
					log.info("No Parameter value is Set for the Request!");
				}
			}
			log.info("Variable extract done successfully. List : " + listOfVariables);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return listOfVariables.toString();
	}

	private String extractResponseTestDataVaraibles(Object requestParams) throws Exception {
		JSONArray listOfVariables = new JSONArray();
		try {
			// Re
			if (requestParams != null) {
				JSONArray jsonArr = new JSONArray(requestParams.toString());
				if (jsonArr.length() > 0) {
					for (int i = 0; i < jsonArr.length(); i++) {
						JSONObject jsonObj = jsonArr.getJSONObject(i);
						String type = jsonObj.getString("paramType");
						String paramName = jsonObj.getString("paramName");
						if (type.equalsIgnoreCase(RequestParamTypes.TESTDATA.value())) {
							log.info("Adding Param Name to list : " + paramName);
							listOfVariables.put(paramName);
						}
					}
				} else {
					log.info("No Parameter value is Set for the Request!");
				}
			}
			log.info("Variable extract done successfully. List : " + listOfVariables);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return listOfVariables.toString();
	}

	private List<String> extractVariablesFromGivenString(String stringToTransform) throws Exception {
		List<String> variablesList = new ArrayList<String>();
		try {
			List<String> allMatchedVariables = new ArrayList<String>();
			Pattern p = Pattern.compile("(.*)#(.*)#(.*)");
			Matcher m = p.matcher(stringToTransform);

			while (m.find()) {
				allMatchedVariables.add(m.group(2));
			}

			if (allMatchedVariables.size() > 0) {
				log.info("Variables found in given String are : " + allMatchedVariables);

				for (String eachVariable : allMatchedVariables) {
					variablesList.add(eachVariable);
				}
				log.info("extractVariablesFromGivenString Testdata done successfully.");

			} else {
				log.info("No Variables found in the given extractVariablesFromGivenString");
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return variablesList;
	}

	public static void main(String[] args) throws Exception {
		TestActionService obj = new TestActionService();
		obj.getAllData();
	}

}
