package com.paypal.test.rule.enums;

public enum RequestParamTypes {
	RUNTIME("runtime"), TESTDATA("testdata");

	private final String item;

	RequestParamTypes(String item) {
		this.item = item;
	}

	public String value() {
		return this.item;
	}

}
