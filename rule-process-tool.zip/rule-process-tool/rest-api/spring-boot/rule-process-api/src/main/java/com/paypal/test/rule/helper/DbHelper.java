package com.paypal.test.rule.helper;

public class DbHelper {

}
