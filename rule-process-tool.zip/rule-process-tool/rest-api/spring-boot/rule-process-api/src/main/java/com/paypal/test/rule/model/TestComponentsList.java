package com.paypal.test.rule.model;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

public class TestComponentsList {

	private String component;
	private List<String> checkpoints;

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public List<String> getCheckpoints() {
		return checkpoints;
	}

	public void setCheckpoints(List<String> checkpoints) {
		this.checkpoints = checkpoints;
	}

}
