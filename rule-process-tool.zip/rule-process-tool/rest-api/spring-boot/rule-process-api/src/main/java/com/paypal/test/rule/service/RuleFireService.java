package com.paypal.test.rule.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.paypal.test.rule.helper.HttpRestClient;
import com.paypal.test.rule.model.HeaderPojo;
import com.paypal.test.rule.model.RuleFireRequest;
import com.paypal.test.rule.model.RuleFireResponse;
import com.paypal.test.rule.tailer.HttpRestClientTailerService;

public class RuleFireService {
	final static Logger log = Logger.getLogger(RuleFireService.class);

	public RuleFireResponse httpRequest(final RuleFireRequest data) {
		RuleFireResponse response = new RuleFireResponse();

		log.info("Method: httpTrigger. Params -RuleFireRequest");
		try {
			String method = data.getMethod();
			String url = data.getUrl();
			List<HeaderPojo> headers = data.getHeaders();
			String request = data.getPayload().toString();

			HttpRestClient client = new HttpRestClient();
			HttpRestClientTailerService clientTailer = new HttpRestClientTailerService();

			boolean isLogCheck = data.isLogCheckFlag();
			if (isLogCheck) {
				if (method.equalsIgnoreCase("POST")) {
					response = clientTailer.doPostWithTail(url, headers, request, data.getStage(), data.getUsername(), data.getPassword(),
							data.getLogPattern());
					return response;
				}
			} else {
				if (method.equalsIgnoreCase("POST")) {
					response = client.doPost(url, headers, request.toString());
					return response;
				}
			}

			return response;
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus_code("0");
			response.setStatus_phrase("Exception occured at Service Layer");
			response.setError_msg(e.getMessage());
			log.error("Exception occured at Service Layer : " + e);
			return response;
		}
	}

	public static void main(String[] args) {
		List<HeaderPojo> headerList = new ArrayList<>();
		HeaderPojo header1 = new HeaderPojo();
		header1.setKey("Content-Type");
		header1.setValue("application/json");
		headerList.add(header1);

		HeaderPojo header2 = new HeaderPojo();
		header2.setKey("Accept");
		header2.setValue("application/json");
		headerList.add(header2);

		RuleFireRequest req = new RuleFireRequest();
		req.setUrl("https://stage2ma152946.qa.paypal.com:11833/v1/risk/resolution-dispute-adjudication-decisions");
		req.setHeaders(headerList);
		req.setPayload("");
		req.setMethod("POST");

		RuleFireService client = new RuleFireService();
		client.httpRequest(req);

	}

}
