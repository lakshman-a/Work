package com.paypal.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.paypal.test.rule.properties.FileStorageProperties;

@SpringBootApplication
@EnableConfigurationProperties({ FileStorageProperties.class })
public class RuleProcessApplication {

	public static void main(String[] args) {
		SpringApplication.run(RuleProcessApplication.class, args);
	}
}
