package com.paypal.test;

import java.util.ArrayList;
import java.util.List;

import com.paypal.test.rule.model.HeaderPojo;

public class SampleCaseCheck {

	public static void main(String[] args) {
		Object json="{\"key\":\"Content-Type\",\"value\":\"application/json\",\"description\":\"\"}";
		HeaderPojo headerObj =(HeaderPojo) json;
		System.out.println("Done");
	}

}
