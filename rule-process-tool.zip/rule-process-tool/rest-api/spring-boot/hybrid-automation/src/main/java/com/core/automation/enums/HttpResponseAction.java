package com.core.automation.enums;

public enum HttpResponseAction {
	BUILDASSERT("assertResponse"), EXTRACTSAVE("extractSaveResponse"), NONE("none");

	private final String item;

	HttpResponseAction(String item) {
		this.item = item;
	}

	public String value() {
		return this.item;
	}

}
