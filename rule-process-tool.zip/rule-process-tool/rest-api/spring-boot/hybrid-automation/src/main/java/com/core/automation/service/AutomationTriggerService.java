package com.core.automation.service;

import org.apache.log4j.Logger;

import com.core.automation.model.AutomationTriggerRequest;
import com.core.automation.model.AutomationTriggerResponse;
import com.core.automation.testNg.TestNgProcessAutomation;

public class AutomationTriggerService {
	final static Logger log = Logger.getLogger(AutomationTriggerService.class);
	static long current = System.currentTimeMillis();

	static public synchronized long getCurrent() {
		return current++;
	}

	public AutomationTriggerResponse triggerAutomation(AutomationTriggerRequest request) {
		AutomationTriggerResponse response = new AutomationTriggerResponse();
		String runId = String.valueOf(AutomationTriggerService.getCurrent());
		TestNgProcessAutomation processAutoObj = new TestNgProcessAutomation();

		switch (request.getTriggerType().toUpperCase()) {
		case "SYNC":
			try {
				log.info("Performing Synchronous Call for the given test...");
				response = processAutoObj.triggerAutomationRun(runId, request);
				response.setTriggerType(request.getTriggerType());
				response.setSuiteLevel(request.getSuiteLevel());
				response.setTestName(request.getTestName());
			} catch (Exception e) {
				response.setRunId(runId);
				response.setStatus("fail");
				response.setMessage("Sync Test Triggered failed due to exception : " + e);
				response.setTriggerType(request.getTriggerType());
				response.setSuiteLevel(request.getSuiteLevel());
				response.setTestName(request.getTestName());
			}
			break;
		case "ASYNC":
			try {
				log.info("Triggering Test with RunID : '" + runId + "' with Request " + request.toString());
				new Thread(() -> processAutoObj.asyncTriggerAutomationRun(runId, request)).start();
				response.setRunId(runId);
				response.setStatus("success");
				response.setMessage("Test Triggered successfully");
				response.setTriggerType(request.getTriggerType());
				response.setSuiteLevel(request.getSuiteLevel());
				response.setTestName(request.getTestName());
			} catch (Exception e) {
				log.error("Exception occured while Triggering Test failed with RunID: '" + runId + "' using ThreadID -> ''"
						+ Thread.currentThread().getId() + ". Exception is : " + e);
				response.setRunId(runId);
				response.setStatus("fail");
				response.setMessage("Async Test Triggered failed due to exception : " + e);
				response.setTriggerType(request.getTriggerType());
				response.setSuiteLevel(request.getSuiteLevel());
				response.setTestName(request.getTestName());
			}
			break;

		default:
			response.setRunId(runId);
			response.setStatus("fail");
			response.setMessage("Invalid Trigger Type.");
			response.setTriggerType(request.getTriggerType());
			response.setSuiteLevel(request.getSuiteLevel());
			response.setTestName(request.getTestName());
			break;
		}
		return response;
	}

}
