package com.core.automation.model;

import java.util.Map;

import org.apache.commons.lang.builder.ToStringBuilder;

public class StepData {

	private String testCaseName;
	private String testCaseSummary;
	private Object moduleName;
	private Object subModule;
	private Object triggerStage;
	private Object testcaseStage;
	private String testCaseActive;
	private Object testDataFlag;
	private String stepNo;
	private String actionName;
	private String actionDesc;
	private String testCaseTrnActive;
	private String layer;
	private Object httpMethod;
	private Object httpUrlFlag;
	private Object httpUrl;
	private Object httpConnType;
	private Object httpStage;
	private Object httpPort;
	private Object httpUri;
	private Object finalRestUrl;
	private Object finalStage;
	private Object component;
	private Object checkpoint;
	private Object httpHeaders;
	private Object requestBody;
	private Object processedRequestBody;
	private Object requestParams;
	private String responseCodeFlag;
	private Object responseCodeValue;
	private String responseStatusFlag;
	private Object responseStatusValue;
	private Object responseAction;
	private Object actualResponseBody;
	private Object responseBody;
	private Object responseAssertParams;
	private Object responseExtractParams;
	private String actionActive;
	private String stepResult;
	private Object resultDescription;
	private Map<String, Object> testData;
	private Map<String, String> builtHttpHeaders;

	public String getTestCaseName() {
		return testCaseName;
	}

	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}

	public String getTestCaseSummary() {
		return testCaseSummary;
	}

	public void setTestCaseSummary(String testCaseSummary) {
		this.testCaseSummary = testCaseSummary;
	}

	public Object getModuleName() {
		return moduleName;
	}

	public void setModuleName(Object moduleName) {
		this.moduleName = moduleName;
	}

	public Object getSubModule() {
		return subModule;
	}

	public void setSubModule(Object subModule) {
		this.subModule = subModule;
	}

	public String getTestCaseActive() {
		return testCaseActive;
	}

	public void setTestCaseActive(String testCaseActive) {
		this.testCaseActive = testCaseActive;
	}

	public String getStepNo() {
		return stepNo;
	}

	public void setStepNo(String stepNo) {
		this.stepNo = stepNo;
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public String getTestCaseTrnActive() {
		return testCaseTrnActive;
	}

	public void setTestCaseTrnActive(String testCaseTrnActive) {
		this.testCaseTrnActive = testCaseTrnActive;
	}

	public String getLayer() {
		return layer;
	}

	public void setLayer(String layer) {
		this.layer = layer;
	}

	public Object getHttpMethod() {
		return httpMethod;
	}

	public void setHttpMethod(Object httpMethod) {
		this.httpMethod = httpMethod;
	}

	public Object getComponent() {
		return component;
	}

	public void setComponent(Object component) {
		this.component = component;
	}

	public Object getCheckpoint() {
		return checkpoint;
	}

	public void setCheckpoint(Object checkpoint) {
		this.checkpoint = checkpoint;
	}

	public Object getRequestBody() {
		return requestBody;
	}

	public void setRequestBody(Object requestBody) {
		this.requestBody = requestBody;
	}

	public Object getRequestParams() {
		return requestParams;
	}

	public void setRequestParams(Object requestParams) {
		this.requestParams = requestParams;
	}

	public Object getResponseAction() {
		return responseAction;
	}

	public void setResponseAction(Object responseAction) {
		this.responseAction = responseAction;
	}

	public Object getResponseBody() {
		return responseBody;
	}

	public void setResponseBody(Object responseBody) {
		this.responseBody = responseBody;
	}

	public Object getResponseAssertParams() {
		return responseAssertParams;
	}

	public void setResponseAssertParams(Object responseAssertParams) {
		this.responseAssertParams = responseAssertParams;
	}

	public Object getResponseExtractParams() {
		return responseExtractParams;
	}

	public void setResponseExtractParams(Object responseExtractParams) {
		this.responseExtractParams = responseExtractParams;
	}

	public String getActionActive() {
		return actionActive;
	}

	public void setActionActive(String actionActive) {
		this.actionActive = actionActive;
	}

	public String getStepResult() {
		return stepResult;
	}

	public void setStepResult(String stepResult) {
		this.stepResult = stepResult;
	}

	public String getActionDesc() {
		return actionDesc;
	}

	public void setActionDesc(String actionDesc) {
		this.actionDesc = actionDesc;
	}

	public Object getHttpUrl() {
		return httpUrl;
	}

	public void setHttpUrl(Object httpUrl) {
		this.httpUrl = httpUrl;
	}

	public Object getHttpStage() {
		return httpStage;
	}

	public void setHttpStage(Object httpStage) {
		this.httpStage = httpStage;
	}

	public Object getHttpPort() {
		return httpPort;
	}

	public void setHttpPort(Object httpPort) {
		this.httpPort = httpPort;
	}

	public Object getHttpUri() {
		return httpUri;
	}

	public void setHttpUri(Object httpUri) {
		this.httpUri = httpUri;
	}

	public Object getHttpUrlFlag() {
		return httpUrlFlag;
	}

	public void setHttpUrlFlag(Object httpUrlFlag) {
		this.httpUrlFlag = httpUrlFlag;
	}

	public Object getTriggerStage() {
		return triggerStage;
	}

	public void setTriggerStage(Object triggerStage) {
		this.triggerStage = triggerStage;
	}

	public Object getTestcaseStage() {
		return testcaseStage;
	}

	public void setTestcaseStage(Object testcaseStage) {
		this.testcaseStage = testcaseStage;
	}

	public Object getHttpHeaders() {
		return httpHeaders;
	}

	public void setHttpHeaders(Object httpHeaders) {
		this.httpHeaders = httpHeaders;
	}

	public Object getTestDataFlag() {
		return testDataFlag;
	}

	public void setTestDataFlag(Object testDataFlag) {
		this.testDataFlag = testDataFlag;
	}

	public Map<String, Object> getTestData() {
		return testData;
	}

	public void setTestData(Map<String, Object> testData) {
		this.testData = testData;
	}

	public String getResponseCodeFlag() {
		return responseCodeFlag;
	}

	public void setResponseCodeFlag(String responseCodeFlag) {
		this.responseCodeFlag = responseCodeFlag;
	}

	public Object getResponseCodeValue() {
		return responseCodeValue;
	}

	public void setResponseCodeValue(Object responseCodeValue) {
		this.responseCodeValue = responseCodeValue;
	}

	public String getResponseStatusFlag() {
		return responseStatusFlag;
	}

	public void setResponseStatusFlag(String responseStatusFlag) {
		this.responseStatusFlag = responseStatusFlag;
	}

	public Object getResponseStatusValue() {
		return responseStatusValue;
	}

	public void setResponseStatusValue(Object responseStatusValue) {
		this.responseStatusValue = responseStatusValue;
	}

	public Object getResultDescription() {
		return resultDescription;
	}

	public void setResultDescription(Object resultDescription) {
		this.resultDescription = resultDescription;
	}

	public Object getFinalRestUrl() {
		return finalRestUrl;
	}

	public void setFinalRestUrl(Object finalRestUrl) {
		this.finalRestUrl = finalRestUrl;
	}

	public Object getFinalStage() {
		return finalStage;
	}

	public void setFinalStage(Object finalStage) {
		this.finalStage = finalStage;
	}

	public Object getHttpConnType() {
		return httpConnType;
	}

	public void setHttpConnType(Object httpConnType) {
		this.httpConnType = httpConnType;
	}

	public Map<String, String> getBuiltHttpHeaders() {
		return builtHttpHeaders;
	}

	public void setBuiltHttpHeaders(Map<String, String> builtHttpHeaders) {
		this.builtHttpHeaders = builtHttpHeaders;
	}

	public Object getProcessedRequestBody() {
		return processedRequestBody;
	}

	public void setProcessedRequestBody(Object processedRequestBody) {
		this.processedRequestBody = processedRequestBody;
	}

	public Object getActualResponseBody() {
		return actualResponseBody;
	}

	public void setActualResponseBody(Object actualResponseBody) {
		this.actualResponseBody = actualResponseBody;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
