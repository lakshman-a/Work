package com.core.automation.utilities;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

public class FileUtil {
	private static final Logger log = Logger.getLogger(FileUtil.class);

	public static Properties loadPropertyFile(String propertyFilename) {
		Properties prop = new Properties();

		try {
			ClassLoader loader = Thread.currentThread().getContextClassLoader();
			try (InputStream resourceStream = loader.getResourceAsStream(propertyFilename)) {
				prop.load(resourceStream);
			}
		} catch (Exception e) {
			log.error("Exception occurec while loading property file '" + propertyFilename + "'. Exception is : " + e);
		}
		return prop;
	}
	
	public synchronized static void reduceHTMLReportSize(String reportFileName) {
		
		try {
			
			File fileTemp = new File(PropertyUtil.getConfigValueOf("ExtentReports_HTML_FilePath") + reportFileName);
			double reportFileSizeInBytes = fileTemp.length();
			double reportFileSizeInKB = (reportFileSizeInBytes / 1024);
			int fileSize = (int) reportFileSizeInKB;
			log.info("FileSize in KB : " + fileSize);
			
			log.info("Reducing the HTML Report File Size...!");
			String contents = FileUtils.readFileToString(new File(PropertyUtil.getConfigValueOf("ExtentReports_HTML_FilePath") + reportFileName), "UTF-8");
			contents = contents.replaceAll("\r\n", "").replaceAll("\n", "").replaceAll("\t", "");
			FileWriter output = new FileWriter(PropertyUtil.getConfigValueOf("ExtentReports_HTML_FilePath") + reportFileName);
			BufferedWriter bw = new BufferedWriter(output);
			bw.write(contents);
			bw.close();

			log.info("Writing the Latest Report in Seperate Path...");
			File lastRunReportdir = new File(PropertyUtil.getConfigValueOf("ExtentReports_HTML_FilePath") +"LastRunReport\\");
			if (!lastRunReportdir.exists()) {
				lastRunReportdir.mkdir();
			}
			for (File file : lastRunReportdir.listFiles())
				if (!file.isDirectory())
					file.delete();

			FileUtils.copyFile(new File( PropertyUtil.getConfigValueOf("ExtentReports_HTML_FilePath") + reportFileName), new File( PropertyUtil.getConfigValueOf("ExtentReports_HTML_FilePath") +"LastRunReport\\"+ reportFileName));
			log.info("File copied");
//			File file = new File(lastRunReportdir + reportFileName);
//			FileWriter fw = new FileWriter(file.getAbsoluteFile());
//			BufferedWriter bw2 = new BufferedWriter(fw);
//			bw2.write(contents);
//			bw2.close();
			log.info("HTML Report File Compressed...!");
		} catch (Exception e) {
			e.printStackTrace();
			log.info("Exception occured while reducing the file Size. Exception " + e);
		}

	}

}
