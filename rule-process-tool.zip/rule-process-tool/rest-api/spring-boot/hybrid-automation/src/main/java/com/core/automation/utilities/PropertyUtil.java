package com.core.automation.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.springframework.util.ResourceUtils;

public class PropertyUtil {

	public Properties loadProperty(String fileName) {

		Properties prop = new Properties();
		InputStream inputStream = null;

		try {
			prop.load(getClass().getClassLoader().getResourceAsStream("src/test/resources/" + fileName));
			// inputStream = new FileInputStream("./src/main/resources/" + fileName);
			prop.load(inputStream);

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return prop;
	}

	public static String getConfigValueOf(String key) {

		Properties prop = new Properties();
		InputStream inputStream = null;
		String value = null;
		try {
			// prop.load(getClass().getClassLoader().getResourceAsStream("src/test/resources/config.properties"));
			// inputStream = new FileInputStream("./src/main/resources/config.properties");
			// prop.load(inputStream);

			File file = ResourceUtils.getFile("classpath:config.properties");
			InputStream in = new FileInputStream(file);
			prop.load(in);

			value = prop.getProperty(key);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return value;
	}

	public static void main(String[] args) {

		System.out.println(PropertyUtil.getConfigValueOf("Dispute.Adjudication"));

	}

}
