package com.core.automation.enums;

public enum Active {
	TRUE("TRUE"), FALSE("FALSE");

	private final String item;

	Active(String item) {
		this.item = item;
	}

	public String value() {
		return this.item;
	}

}
