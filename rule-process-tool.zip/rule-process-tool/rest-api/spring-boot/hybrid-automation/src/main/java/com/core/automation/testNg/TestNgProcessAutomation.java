package com.core.automation.testNg;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.testng.TestNG;
import org.testng.collections.Lists;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.core.automation.enums.Result;
import com.core.automation.enums.RunStatus;
import com.core.automation.model.AutomationTriggerRequest;
import com.core.automation.model.AutomationTriggerResponse;
import com.core.automation.utilities.DbUtil;
import com.core.automation.utilities.PropertyUtil;

public class TestNgProcessAutomation {
	private static final Logger log = Logger.getLogger(TestNgProcessAutomation.class);

	static Long current = System.currentTimeMillis();

	static public synchronized long getCurrent() {
		return current++;
	}

	public AutomationTriggerResponse triggerAutomationRun(String runId, AutomationTriggerRequest request) {
		String testName = request.getTestName();
		String suiteLevel = request.getSuiteLevel();
		String suiteRunType = request.getSuiteRunType();
		String username = request.getUsername();
		String threadCount = request.getThreadCount();
		String stage = request.getStage();

		AutomationTriggerResponse returnObj = new AutomationTriggerResponse();
		TestNgProcessAutomation testNgObj;
		try {
			log.info("Trigger Automation Run Starts...");
			testNgObj = new TestNgProcessAutomation();

			Set<String> allXmls = testNgObj.generateTestNgFiles(runId, testName, suiteLevel, suiteRunType, username, threadCount, stage);

			if (allXmls.size() > 0) {
				String finalTestNgSuiteXML = testNgObj.createFullSuiteTesNGXml(runId, username, allXmls);
				testNgObj.triggerTestNg(finalTestNgSuiteXML);
				deleteExecutedTestNgFiles(allXmls, finalTestNgSuiteXML);
				
				String reportFileName=null;
				String reportFileQuery ="select report_file from rule_process.test_run_details where run_id ='"+runId+"' and status='"+RunStatus.COMPLETED.value()+"'";
				List<HashMap<String, Object>> reportFileHm = DbUtil.executeSelectQuery(reportFileQuery);
				for (HashMap<String, Object> eachItem : reportFileHm) {
					reportFileName = (String) eachItem.get("report_file");
				}
				log.info("RunId Report file name is : : " + reportFileName);

				returnObj.setRunId(runId);
				returnObj.setStatus("success");
				returnObj.setMessage("Triggered Test completed successfully");
				returnObj.setReportFile(reportFileName);

			} else if (allXmls.size() == 0) {
				returnObj.setRunId(runId);
				returnObj.setStatus("fail");
				returnObj.setMessage("No Testcase Tagged for the triggered Testsuite");
				return returnObj;
			}

		} catch (Exception e) {
			returnObj.setRunId(runId);
			returnObj.setStatus("fail");
			returnObj.setMessage("Exception occured in triggerAutomationRun. Exception is : " + e);
			log.error("Exception occured in triggerAutomationRun. Exception is : " + e);
			e.printStackTrace();
		}
		return returnObj;
	}

	public void asyncTriggerAutomationRun(String runId, AutomationTriggerRequest request) {
		String testName = request.getTestName();
		String suiteLevel = request.getSuiteLevel();
		String suiteRunType = request.getSuiteRunType();
		String username = request.getUsername();
		String threadCount = request.getThreadCount();
		String stage = request.getStage();

		TestNgProcessAutomation testNgObj;
		try {
			log.info("Trigger Automation Run Starts...");
			testNgObj = new TestNgProcessAutomation();

			Set<String> allXmls = testNgObj.generateTestNgFiles(runId, testName, suiteLevel, suiteRunType, username, threadCount, stage);

			if (allXmls.size() > 0) {
				String finalTestNgSuiteXML = testNgObj.createFullSuiteTesNGXml(runId, username, allXmls);
				testNgObj.triggerTestNg(finalTestNgSuiteXML);
				deleteExecutedTestNgFiles(allXmls, finalTestNgSuiteXML);

			} else if (allXmls.size() == 0) {
				String runDetailsQuery = "INSERT INTO `rule_process`.`test_run_details` (`run_id`, `run_level`, `test_name`, `case_count`, `status`, `result`,`stage`, `report_file`, `grid_url`, `browser`, `triggered_by`,`comments`) VALUES ('"
						+ runId + "', '" + suiteLevel + "', '" + testName + "', '0', 'COMPLETED', '" + Result.FATAL.value() + "','" + stage
						+ "','', null, null, 'layyakannu','No Testcase Tagged for the triggered Testsuite')";
				if (DbUtil.executeUpdateQuery(runDetailsQuery) == 1)
					log.info("RunID Registered in DB Successfully");
				else
					log.info("RunID was not registered successfully in DB. Kindly verify");
			}

		} catch (Exception e) {
			String runDetailsQuery = "INSERT INTO `rule_process`.`test_run_details` (`run_id`, `run_level`, `test_name`, `case_count`, `status`, `result`,`stage`, `report_file`, `grid_url`, `browser`, `triggered_by`,`comments`) VALUES ('"
					+ runId + "', '" + suiteLevel + "', '" + testName + "', '0', 'COMPLETED', '" + Result.FATAL.value() + "','" + stage
					+ "','', null, null, 'layyakannu','Exception occured while triggering the Suite Asynchronously : " + e + "')";
			if (DbUtil.executeUpdateQuery(runDetailsQuery) == 1)
				log.info("RunID Registered in DB Successfully");
			else
				log.info("RunID was not registered successfully in DB. Kindly verify");
			e.printStackTrace();
		}
	}

	private Set<String> generateTestNgFiles(String runId, String testName, String suiteLevel, String suiteRunType, String username,
			String threadCount, String stage) {
		Set<String> xmlFileNames;

		try {
			TestNgProcessAutomation obj = new TestNgProcessAutomation();
			xmlFileNames = new TreeSet<>();

			log.info("*******  TestNG XML File Creation Starts *********");
			// Test Suite Type XML Generation
			if (suiteLevel.equalsIgnoreCase("testsuite")) {

				String allCaseQuery = "select suite.test_case_name from rule_process.test_suite_trn suite, rule_process.test_cases cases where suite.test_suite_name = '"
						+ testName + "' and suite.test_case_name = cases.test_case_name and cases.active='true'";
				List<HashMap<String, Object>> allCasesForGivenSuite = DbUtil.executeSelectQuery(allCaseQuery);
				int intCaseCount = allCasesForGivenSuite.size();
				String caseCount = String.valueOf(intCaseCount);
				if (intCaseCount > 0) {

					// Parallel Suite Run Mode
					if (suiteRunType.equalsIgnoreCase("Parallel")) {
						// Execute all Parallel Cases with Parallel mode
						String currentFileRunMode = "Serial";
						String serialCaseQuery = "Select suite.test_case_name,cases.test_case_summary,suite.test_case_num from rule_process.test_suite_trn suite, rule_process.test_cases cases where suite.test_suite_name='"
								+ testName
								+ "' and suite.test_case_name=cases.test_case_name and cases.is_automation='true' and cases.test_run_mode='serial'  and cases.active='true' order by test_case_num";
						List<HashMap<String, Object>> serialCasesForGivenSuite = DbUtil.executeSelectQuery(serialCaseQuery);

						if (serialCasesForGivenSuite.size() > 0) {
							String fileName = obj.createTestNg(testName, suiteLevel, currentFileRunMode, suiteRunType, username, runId, threadCount,
									caseCount, stage, serialCasesForGivenSuite);
							xmlFileNames.add(fileName);
						} else {
							log.warn("Cases Count is not greater than 0. Check the Trigger.");
						}

						// Execute all Serial Cases with Parallel mode
						currentFileRunMode = "Parallel";
						String parallelCaseQuery = "Select suite.test_case_name,cases.test_case_summary, suite.test_case_num from rule_process.test_suite_trn suite, rule_process.test_cases cases where suite.test_suite_name='"
								+ testName
								+ "' and suite.test_case_name=cases.test_case_name and cases.is_automation='true' and cases.test_run_mode='parallel'  and cases.active='true' order by test_case_num";
						List<HashMap<String, Object>> parallelCasesForGivenSuite = DbUtil.executeSelectQuery(parallelCaseQuery);
						if (parallelCasesForGivenSuite.size() > 0) {
							String fileName2 = obj.createTestNg(testName, suiteLevel, currentFileRunMode, suiteRunType, username, runId, threadCount,
									caseCount, stage, parallelCasesForGivenSuite);
							xmlFileNames.add(fileName2);
						} else {
							log.warn("Cases Count is not greater than 0. Check the Trigger.");
						}

						// Serial Suite Run Mode
					} else if (suiteRunType.equalsIgnoreCase("serial")) {
						// Execute all cases in serial mode
						String currentFileRunMode = "Serial";
						String caseQuery = "Select suite.test_case_name,cases.test_case_summary, suite.test_case_num from rule_process.test_suite_trn suite, rule_process.test_cases cases where suite.test_suite_name='"
								+ testName + "' and suite.test_case_name=cases.test_case_name and cases.is_automation='true'  and cases.active='true' order by test_case_num";
						List<HashMap<String, Object>> casesForGivenSuite = DbUtil.executeSelectQuery(caseQuery);
						if (casesForGivenSuite.size() > 0) {
							String fileName = obj.createTestNg(testName, suiteLevel, currentFileRunMode, suiteRunType, username, runId, threadCount,
									caseCount, stage, casesForGivenSuite);
							xmlFileNames.add(fileName);
						} else {
							log.warn("Cases Count is not greater than 0. Check the Trigger.");
						}

					}
				} else {
					log.warn("No Cases returned for the suite. Check the Trigger.");
				}
			} else if (suiteLevel.equalsIgnoreCase("testcase")) {
				String caseQuery = "Select cases.test_case_name,cases.test_case_summary from rule_process.test_cases cases where cases.test_case_name='"
						+ testName + "' and  cases.is_automation='true'  and cases.active='true'";
				List<HashMap<String, Object>> caseForGivenTestHm = DbUtil.executeSelectQuery(caseQuery);

				caseForGivenTestHm.get(0).put("test_case_num", "1");
				String fileName = obj.createTestNg(testName, suiteLevel, "Serial", suiteRunType, username, runId, threadCount, "1", stage,
						caseForGivenTestHm);
				xmlFileNames.add(fileName);
			}

			if (xmlFileNames.size() > 0) {
				log.info("Generated TestNG XML Files are : ");
				for (String eachFile : xmlFileNames) {
					log.info(eachFile);
				}

			}

		} catch (Exception e) {
			log.error("Exception occured in TestNgCreateXML : " + e);
			e.printStackTrace();
			return null;
		}

		return xmlFileNames;
	}

	private String createTestNg(String testName, String suiteLevel, String currentFileRunMode, String suiteRunType, String username, String runId,
			String threadCount, String caseCount, String stage, List<HashMap<String, Object>> caseMap) throws Exception {

		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = dbFactory.newDocumentBuilder();
		Document doc = docBuilder.newDocument();

		Element rootElement = doc.createElement("suite");
		rootElement.setAttribute("name", testName + " " + currentFileRunMode);

		Element parameterSuiteName = doc.createElement("parameter");
		parameterSuiteName.setAttribute("name", "suiteName");
		parameterSuiteName.setAttribute("value", testName);
		rootElement.appendChild(parameterSuiteName);

		Element parameterRunId = doc.createElement("parameter");
		parameterRunId.setAttribute("name", "runId");
		parameterRunId.setAttribute("value", runId);
		rootElement.appendChild(parameterRunId);

		Element parameterSuiteLevel = doc.createElement("parameter");
		parameterSuiteLevel.setAttribute("name", "suiteLevel");
		parameterSuiteLevel.setAttribute("value", suiteLevel);
		rootElement.appendChild(parameterSuiteLevel);

		Element parameterRunType = doc.createElement("parameter");
		parameterRunType.setAttribute("name", "suiteRunType");
		parameterRunType.setAttribute("value", suiteRunType);
		rootElement.appendChild(parameterRunType);

		Element parameterStage = doc.createElement("parameter");
		parameterStage.setAttribute("name", "stage");
		parameterStage.setAttribute("value", stage);
		rootElement.appendChild(parameterStage);

		Element parameterUsername = doc.createElement("parameter");
		parameterUsername.setAttribute("name", "user");
		parameterUsername.setAttribute("value", username);
		rootElement.appendChild(parameterUsername);

		Element parameterCaseCount = doc.createElement("parameter");
		parameterCaseCount.setAttribute("name", "count");
		parameterCaseCount.setAttribute("value", caseCount);
		rootElement.appendChild(parameterCaseCount);

		if (suiteRunType.equalsIgnoreCase("serial"))
			rootElement.setAttribute("thread-count", "1");
		else if (suiteRunType.equalsIgnoreCase("parallel")) {
			if (currentFileRunMode.equalsIgnoreCase("parallel")) {
				rootElement.setAttribute("thread-count", threadCount);
				rootElement.setAttribute("parallel", "tests");
			} else if (currentFileRunMode.equalsIgnoreCase("serial")) {
				rootElement.setAttribute("thread-count", "1");
			}

		}

		doc.appendChild(rootElement);

		int row = 0;
		for (HashMap<String, Object> eachItem : caseMap) {
			log.info("Row No [" + row + "] Line Item -> " + eachItem.toString());
			String caseName = (String) eachItem.get("test_case_name");
			String caseSummary = (String) eachItem.get("test_case_summary");
			String caseExecOrder = String.valueOf(eachItem.get("test_case_num"));

			Element test = doc.createElement("test");
			test.setAttribute("name", caseName);
			rootElement.appendChild(test);

			Element parameterCaseName = doc.createElement("parameter");
			parameterCaseName.setAttribute("name", "testcaseName");
			parameterCaseName.setAttribute("value", caseName);
			test.appendChild(parameterCaseName);

			Element parameterCaseSummary = doc.createElement("parameter");
			parameterCaseSummary.setAttribute("name", "testcaseSummary");
			parameterCaseSummary.setAttribute("value", caseSummary);
			test.appendChild(parameterCaseSummary);

			Element parameterCaseOrder = doc.createElement("parameter");
			parameterCaseOrder.setAttribute("name", "testcaseNum");
			parameterCaseOrder.setAttribute("value", caseExecOrder);
			test.appendChild(parameterCaseOrder);

			Element classes = doc.createElement("classes");
			test.appendChild(classes);
			Element singleClass = doc.createElement("class");
			singleClass.setAttribute("name", "com.core.automation.driver.TestNgDriver");
			classes.appendChild(singleClass);
			Element method = doc.createElement("methods");
			singleClass.appendChild(method);
			Element include = doc.createElement("include");
			include.setAttribute("name", "runCases");
			method.appendChild(include);

			row++;
		}

		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer trans = tf.newTransformer();
		trans.setOutputProperty(OutputKeys.INDENT, "yes");
		trans.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "http://testng.org/testng-1.0.dtd");
		DOMSource source = new DOMSource(doc);

		String fileName = runId + "_" + currentFileRunMode + ".xml";
		String exactFilePath = PropertyUtil.getConfigValueOf("TestNg_XML_FilePath") + fileName;
		StreamResult result = new StreamResult(new File(exactFilePath));
		trans.transform(source, result);
		log.info("Generated TestNgFile Successfully. Filename : " + exactFilePath);

		return fileName;
	}

	private String createFullSuiteTesNGXml(String runId, String username, Set<String> xmlFileNames) throws Exception {
		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = dbFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("suite");
			rootElement.setAttribute("name", "TestNg Automation");
			doc.appendChild(rootElement);

			try {
				Element suites = doc.createElement("suite-files");
				rootElement.appendChild(suites);

				for (String eachTestNgFile : xmlFileNames) {
					Element suiteFiles = doc.createElement("suite-file");
					suiteFiles.setAttribute("path", "./" + eachTestNgFile);
					suites.appendChild(suiteFiles);
				}

			} catch (Exception e) {
				log.error("Exception in createFullSuiteTesNGXml creating element for each Suite files - " + e);
				e.printStackTrace();
			}

			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer trans = tf.newTransformer();
			trans.setOutputProperty(OutputKeys.INDENT, "yes");
			trans.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "http://testng.org/testng-1.0.dtd");
			DOMSource source = new DOMSource(doc);

			String fileFullPath = PropertyUtil.getConfigValueOf("TestNg_XML_FilePath") + "TestNg_" + runId + "_" + username + ".xml";
			StreamResult result = new StreamResult(new File(fileFullPath));
			trans.transform(source, result);
			log.info("Generated Collective TestNgFile Successfully. Filename : " + fileFullPath);
			return fileFullPath;

		} catch (Exception e) {
			log.error("Exception in createFullSuiteTesNGXml - " + e);
			e.printStackTrace();
			throw e;
		}
	}

	private void triggerTestNg(String mainTestNgSuiteFile) throws Exception {
		try {
			TestNG runner = new TestNG();
			List<String> suites = Lists.newArrayList();
			suites.add(mainTestNgSuiteFile);
			runner.setTestSuites(suites);
			runner.run();
		} catch (Exception e) {
			e.printStackTrace();
		}

		log.info("Suite TestNG XML file is triggered successfully...");
	}

	private void deleteExecutedTestNgFiles(Set<String> xmlFiles, String mainSuiteXmlFile) {
		log.info("Clearing all TestNg Files...");

		if (xmlFiles.size() > 0) {
			for (String eachXmlFile : xmlFiles) {
				File file = new File(PropertyUtil.getConfigValueOf("TestNg_XML_FilePath") + eachXmlFile);
				if (file.exists()) {
					file.delete();
				}
			}
		}

		File file = new File(mainSuiteXmlFile);
		if (file.exists()) {
			file.delete();
		}
		log.info("TestNg files deleted successfully.");
	}

	public static void main(String[] args) {
		TestNgProcessAutomation obj = new TestNgProcessAutomation();
		AutomationTriggerRequest request = new AutomationTriggerRequest();
		Date date = new Date();
		long timeMilli = date.getTime();
		String runId = String.valueOf(timeMilli);
		request.setTestName("Do Not Notify Response");
		request.setSuiteLevel("Testcase");
		request.setSuiteRunType("Serial");
		request.setUsername("layyakannu");
		request.setThreadCount("1");
		request.setStage("stage2ma196768.qa.paypal.com");

		obj.triggerAutomationRun(runId, request);
//		obj.triggerAutomationRun(String.valueOf(timeMilli), "TC14 FTRB - Do Not Notify Rule", "Testcase", "Parallel",
//				"layyakannu", "2");
		System.out.println("Done!");
	}

}
