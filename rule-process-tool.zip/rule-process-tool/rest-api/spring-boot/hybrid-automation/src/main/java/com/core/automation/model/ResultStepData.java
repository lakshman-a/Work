package com.core.automation.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class ResultStepData {

	private boolean result;
	private StepData stepData;
	private String reason;

	public boolean getResult() {
		return result;
	}

	public void setResult(boolean result) {
		this.result = result;
	}

	public StepData getStepData() {
		return stepData;
	}

	public void setStepData(StepData stepData) {
		this.stepData = stepData;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
}
