package com.core.automation.controller;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.core.automation.helper.HeaderValidator;
import com.core.automation.model.AutomationTriggerRequest;
import com.core.automation.model.AutomationTriggerResponse;
import com.core.automation.service.AutomationTriggerService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("api")
public class AutomationTriggerController {
	final static Logger log = Logger.getLogger(AutomationTriggerController.class);
	AutomationTriggerService service = new AutomationTriggerService();
	HeaderValidator validator = new HeaderValidator();

	// ------------- POST ------------------//
	@RequestMapping(value = "/automationTrigger", method = RequestMethod.POST, produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<AutomationTriggerResponse> addData(@RequestBody final AutomationTriggerRequest body,
			@RequestHeader(value = "accept", required = true) String acceptHeader,
			@RequestHeader(value = "authorization", required = true) String authToken) {
		log.info("Request to POST Service : AutomationTrigger - Data - '" + body + "'");

		log.info("Trigger Type : "+body.getTriggerType());
		// Header Validation
		HttpStatus headerValidityCode = validator.validateCommonHeader(acceptHeader, authToken);
		if (headerValidityCode != HttpStatus.OK) {
			return new ResponseEntity<>(headerValidityCode);
		}

		// Get Data from Service Layer
		AutomationTriggerResponse response;
		try {
			response = this.service.triggerAutomation(body);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("Response to Service : [ " + response + " ]");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
