package com.core.automation.enums;

public enum HttpActions {
	GET("GET"), POST("POST");

	private final String item;

	HttpActions(String item) {
		this.item = item;
	}

	public String value() {
		return this.item;
	}

}
