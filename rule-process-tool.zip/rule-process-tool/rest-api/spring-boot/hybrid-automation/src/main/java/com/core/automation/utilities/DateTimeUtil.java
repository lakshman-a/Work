package com.core.automation.utilities;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DateTimeUtil {

	public static String getTimeStamp() {
		String dateFormatNow = "yyyy-MM-dd-HH:mm:ss:SSS";
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormatNow);
		return sdf.format(cal.getTime());
	}
	
}
