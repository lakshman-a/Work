package com.core.automation.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class AutomationTriggerRequest {

	private String triggerType;
	private String testName;
	private String suiteLevel;
	private String suiteRunType;
	private String username;
	private String threadCount;
	private String stage;

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public String getSuiteLevel() {
		return suiteLevel;
	}

	public void setSuiteLevel(String suiteLevel) {
		this.suiteLevel = suiteLevel;
	}

	public String getSuiteRunType() {
		return suiteRunType;
	}

	public void setSuiteRunType(String suiteRunType) {
		this.suiteRunType = suiteRunType;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getThreadCount() {
		return threadCount;
	}

	public void setThreadCount(String threadCount) {
		this.threadCount = threadCount;
	}

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

	public String getTriggerType() {
		return triggerType;
	}

	public void setTriggerType(String triggerType) {
		this.triggerType = triggerType;
	}

}
