package com.core.automation.utilities;

import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import org.apache.log4j.Logger;

import com.core.automation.report.Report;

public class ProjectProperty {
	final static Logger log = Logger.getLogger(ProjectProperty.class);
	private static Properties projectProperty = new Properties();
	private static String env;

	public ProjectProperty() {
		projectProperty = new Properties();
	}

	public synchronized static void initializeProjectProperty() {
		try {
			projectProperty = new Properties();
			String envDbQuery = "Select * from rule_process.project_property where active='true' and key_name='ENV'";
			List<HashMap<String, Object>> envFromDB = DbUtil.executeSelectQuery(envDbQuery);
			for (HashMap<String, Object> eachItem : envFromDB) {
				env = (String) eachItem.get("value");
			}
			log.info("Environment to Run Test : " + env);
			String propertyQuery = "Select * from rule_process.project_property where active='true' and env='" + env
					+ "'";
			List<HashMap<String, Object>> propertyHashMap = DbUtil.executeSelectQuery(propertyQuery);
			for (HashMap<String, Object> eachItem : propertyHashMap) {
				projectProperty.setProperty((String) eachItem.get("key_name"), (String) eachItem.get("value"));
			}
		} catch (Exception e) {
			log.error("Exception occured while initializeProjectProperty : " + e);
			e.printStackTrace();
			throw e;
		}
	}

	public synchronized static void setKeyValue(String key, String value) {
		Report.info("Setting Runtime Varible '<b>" + key + "</b>' with value '<b>" + value + "</b>'");
		projectProperty.setProperty(key, value);
	}

	public static String getValue(String key) {
		return projectProperty.getProperty(key);
	}

	public static String getEnv() {
		return env;
	}

	public static Properties getProjectProperties() {
		return projectProperty;
	}

	public static void clearProperties() {
		projectProperty.clear();
	}

	public static void printProjectProperties() {
		log.info("Current Properties Stored in Runtime : " + projectProperty);
	}

}
