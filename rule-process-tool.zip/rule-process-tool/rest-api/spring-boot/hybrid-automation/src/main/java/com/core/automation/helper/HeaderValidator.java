package com.core.automation.helper;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;

public class HeaderValidator {
	final static Logger log = Logger.getLogger(HeaderValidator.class);

	public HttpStatus validateCommonHeader(String acceptHeader, String authToken) {
		if (!acceptHeader.equals("application/json")) {
			log.error("Header Validation FAILED - NOT_ACCEPTABLE");
			return HttpStatus.NOT_ACCEPTABLE;
		}
		if (!authToken.equals("ADdSDHhbkHBKHBZCCYVYHKBS")) {
			log.error("Header Validation FAILED - UNAUTHORIZED");
			return HttpStatus.UNAUTHORIZED;
		}
		log.info("Header Validation PASSED - OK");
		return HttpStatus.OK;
	}

}
