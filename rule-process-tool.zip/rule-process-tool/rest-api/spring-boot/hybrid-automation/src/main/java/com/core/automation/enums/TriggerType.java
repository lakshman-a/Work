package com.core.automation.enums;

public enum TriggerType {
	SYNC("SYNC"), ASYNC("ASYNC");

	private final String item;

	TriggerType(String item) {
		this.item = item;
	}

	public String value() {
		return this.item;
	}

}
