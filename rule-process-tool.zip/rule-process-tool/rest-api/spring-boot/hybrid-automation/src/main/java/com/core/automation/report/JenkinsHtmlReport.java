package com.core.automation.report;

import java.io.*;

public class JenkinsHtmlReport {

	public void createJenkinsReport(String suiteName, int testCaseCount, int testDataCount, int casePassedCount, int caseFailedCount, int caseErrorCount) {
		try {
			// define a HTML String Builder
			StringBuilder htmlStringBuilder = new StringBuilder();
			// append html header and title
			htmlStringBuilder.append("<!DOCTYPE html>");
			htmlStringBuilder.append("<html lang=\"en\">");

			// Appead Head
			htmlStringBuilder.append("<head><title>Automation Report</title>");
			htmlStringBuilder.append("<meta charset=\"utf-8\">");
			htmlStringBuilder.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
			htmlStringBuilder.append("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">");
			htmlStringBuilder.append("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>");
			htmlStringBuilder.append("<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>");
			htmlStringBuilder.append("</head>");
			// Append body
			htmlStringBuilder.append("<body>");

			// Container HTML
			htmlStringBuilder.append("<div class=\"container\">");
			htmlStringBuilder.append("<h2>RRDS Component - Automation Report</h2>");
			htmlStringBuilder.append("<p><b>Suite Name : " + suiteName + "</b></p>");

			// Table HTML
			htmlStringBuilder.append("<table class=\"table table-bordered\">");
			//htmlStringBuilder.append("<table border=\"1\">");
			
			// Table Head HTML
			htmlStringBuilder.append("<thead>\n" + "      <tr>\n" + "        <th>Total Modules Executed</th>\n" + "        <th>Total Testcases Executed</th>\n" + "        <th>PASSED</th>\n"
					+ "        <th>FAILED</th>\n" + "        <th>ERROR</th>\n" + "      </tr>\n" + "    </thead>");

			// Table Body HTML
			htmlStringBuilder.append("<tbody>");

			if (caseFailedCount > 0 || caseErrorCount > 0) {
				htmlStringBuilder.append("<tr class=\"danger\">\n" + "        <td>" + String.valueOf(testCaseCount) + "</td>\n" + "        <td>" + String.valueOf(testDataCount) + "</td>\n"
						+ "        <td>" + String.valueOf(casePassedCount) + "</td>\n" + "        <td>" + String.valueOf(caseFailedCount) + "</td>\n" + "        <td>" + String.valueOf(caseErrorCount)
						+ "</td>\n" + "      </tr>");
			} else if (casePassedCount > 0) {
				htmlStringBuilder.append("<tr class=\"success\">\n" + "        <td>" + String.valueOf(testCaseCount) + "</td>\n" + "        <td>" + String.valueOf(testDataCount) + "</td>\n"
						+ "        <td>" + String.valueOf(casePassedCount) + "</td>\n" + "        <td>" + String.valueOf(caseFailedCount) + "</td>\n" + "        <td>" + String.valueOf(caseErrorCount)
						+ "</td>\n" + "      </tr>");
			}

			htmlStringBuilder.append("</tbody>");

			htmlStringBuilder.append("</table>");

			// close Container file
			htmlStringBuilder.append("</div>");
			// close Body file
			htmlStringBuilder.append("</body>");
			// close Html file
			htmlStringBuilder.append("</html>");
			// write html string content to a file
			WriteToFile(htmlStringBuilder.toString(), "HtmlReport.html");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void WriteToFile(String fileContent, String fileName) throws IOException {
		String projectPath = System.getProperty("user.dir");
		String filePath=projectPath + File.separator + "test-output\\html\\";
		String tempFile = filePath + fileName;
		File file = new File(tempFile);
		// if folder does exists, then delete and create a new folder
		File folder = new File(filePath);
		if(!folder.exists()) {
			folder.mkdirs();
		}
		// if file does exists, then delete and create a new file
		if (file.exists()) {
			try {
				File newFileName = new File(projectPath + File.separator + "test-output/html/" + "backup_" + fileName);
				file.renameTo(newFileName);
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}else {
		}
		// write to file with OutputStreamWriter
		OutputStream outputStream = new FileOutputStream(file.getAbsoluteFile());
		Writer writer = new OutputStreamWriter(outputStream);
		writer.write(fileContent);
		writer.close();

	}

	public static void main(String[] args) {
		try {
			// define a HTML String Builder
			StringBuilder htmlStringBuilder = new StringBuilder();
			// append html header and title
			htmlStringBuilder.append("<!DOCTYPE html>");
			htmlStringBuilder.append("<html lang=\"en\">");

			// Appead Head
			htmlStringBuilder.append("<head><title>Automation Report</title>");
			htmlStringBuilder.append("<meta charset=\"utf-8\">");
			htmlStringBuilder.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
			htmlStringBuilder.append("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">");
			htmlStringBuilder.append("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>");
			htmlStringBuilder.append("<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>");
			htmlStringBuilder.append("</head>");
			// Append body
			htmlStringBuilder.append("<body>");

			// Container HTML
			htmlStringBuilder.append("<div class=\"container\">");
			htmlStringBuilder.append("<h2>RRDS Component - Automation Report</h2>");
			htmlStringBuilder.append("<p>Suite Name :  Regression Suite</p>");

			// Table HTML
			htmlStringBuilder.append("<table class=\"table\">");
			// Table Head HTML
			htmlStringBuilder.append("<thead>\n" + "      <tr>\n" + "        <th>Total No. of Test-Case</th>\n" + "        <th>Total No. of Test-Scenarios</th>\n" + "        <th>PASSED</th>\n"
					+ "        <th>FAILED</th>\n" + "        <th>ERROR</th>\n" + "      </tr>\n" + "    </thead>");

			// Table Body HTML
			htmlStringBuilder.append("<tbody>");
			htmlStringBuilder.append("<tr class=\"success\">\n" + "        <td>33</td>\n" + "        <td>33</td>\n" + "        <td>33</td>\n" + "        <td>33</td>\n" + "        <td>0</td>\n"
					+ "      </tr>");
			htmlStringBuilder.append("<tr class=\"danger\">\n" + "        <td>41</td>\n" + "        <td>122</td>\n" + "        <td>41</td>\n" + "        <td>1</td>\n" + "        <td>0</td>\n"
					+ "      </tr>");
			htmlStringBuilder.append("</tbody>");

			htmlStringBuilder.append("</table>");

			// close Container file
			htmlStringBuilder.append("</div>");
			// close Body file
			htmlStringBuilder.append("</body>");
			// close Html file
			htmlStringBuilder.append("</html>");
			// write html string content to a file
			WriteToFile(htmlStringBuilder.toString(), "testfile2.html");
			System.out.println("Done");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
