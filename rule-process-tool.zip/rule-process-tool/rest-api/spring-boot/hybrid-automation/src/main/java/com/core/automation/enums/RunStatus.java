package com.core.automation.enums;

public enum RunStatus {
	NOT_YET_STARTED("NOT_YET_STARTED"), RUNNING("RUNNING"), COMPLETED("COMPLETED"), UNKNOWN("UNKNOWN");

	private final String item;

	RunStatus(String item) {
		this.item = item;
	}

	public String value() {
		return this.item;
	}

}
