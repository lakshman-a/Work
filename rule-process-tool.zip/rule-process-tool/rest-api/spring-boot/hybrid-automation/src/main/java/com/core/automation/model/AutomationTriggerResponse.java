package com.core.automation.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class AutomationTriggerResponse {

	private String runId;
	private String triggerType;
	private String suiteLevel;
	private String testName;
	private String comments;
	private String status;
	private Object message;
	private Object reportFile;

	public String getRunId() {
		return runId;
	}

	public void setRunId(String runId) {
		this.runId = runId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Object getMessage() {
		return message;
	}

	public void setMessage(Object message) {
		this.message = message;
	}

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

	public Object getReportFile() {
		return reportFile;
	}

	public void setReportFile(Object reportFile) {
		this.reportFile = reportFile;
	}

	public String getTriggerType() {
		return triggerType;
	}

	public void setTriggerType(String triggerType) {
		this.triggerType = triggerType;
	}

	public String getSuiteLevel() {
		return suiteLevel;
	}

	public void setSuiteLevel(String suiteLevel) {
		this.suiteLevel = suiteLevel;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

}
