package com.core.automation.enums;

public enum TestLayers {
	UI("UI"), API("API"), DB("DB"), COMMON("COMMON");

	private final String item;

	TestLayers(String item) {
		this.item = item;
	}

	public String value() {
		return this.item;
	}

}
