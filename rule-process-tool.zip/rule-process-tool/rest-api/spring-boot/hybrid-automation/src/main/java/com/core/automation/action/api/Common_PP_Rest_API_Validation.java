package com.core.automation.action.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;

import com.core.automation.enums.Active;
import com.core.automation.enums.HttpResponseAction;
import com.core.automation.enums.HttpURLAction;
import com.core.automation.enums.RequestParamTypes;
import com.core.automation.enums.Result;
import com.core.automation.model.MultiResult;
import com.core.automation.model.ResultStepData;
import com.core.automation.model.StepData;
import com.core.automation.report.Report;
import com.core.automation.service.HttpClientResponse;
import com.core.automation.utilities.HttpRestClient;
import com.core.automation.utilities.RuntimeMap;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

public class Common_PP_Rest_API_Validation {
	final static Logger log = Logger.getLogger(Common_PP_Rest_API_Validation.class);

	public StepData object(StepData stepData) {
		try {
			log.info("******************************************** API COMPONENT CALL STARTS********************************************");
			if (stepData.getComponent() != null) {
				if (stepData.getCheckpoint() != null) {
					Report.info("Component : <b>" + stepData.getComponent() + "</b>, Checkpoint : <b>" + stepData.getCheckpoint() + "</b>");
				} else {
					Report.info("Component : <b>" + stepData.getComponent() + "</b>");
				}
			}

			// Build the Rest API URL
			String restUrl = null;
			ResultStepData urlModuleResult = buildRestUrl(stepData);
			if (urlModuleResult.getResult()) {
				stepData = urlModuleResult.getStepData();
				restUrl = stepData.getFinalRestUrl().toString();
			} else {
				String message = urlModuleResult.getReason();
				Report.fail(message);
				stepData.setStepResult(Result.FAIL.value());
				stepData.setResultDescription(message);
				return stepData;
			}

			// Build the Rest Headers
			Map<String, String> headerMap = new HashMap<String, String>();
			ResultStepData headerModuleResult = buildHeaders(stepData);
			if (headerModuleResult.getResult()) {
				stepData = headerModuleResult.getStepData();
				headerMap = stepData.getBuiltHttpHeaders();
			} else {
				String message = headerModuleResult.getReason();
				Report.fail(message);
				stepData.setStepResult(Result.FAIL.value());
				stepData.setResultDescription(message);
				return stepData;
			}

			// Pre-Request Build and Transformation
			ResultStepData requestModuleResult = buildRequest(stepData);
			if (requestModuleResult.getResult()) {
				stepData = requestModuleResult.getStepData();
			} else {
				String message = requestModuleResult.getReason();
				Report.fail(message);
				stepData.setStepResult(Result.FAIL.value());
				stepData.setResultDescription(message);
				return stepData;
			}

			// Create a HTTPClient and make a rest call
			HttpRestClient client = new HttpRestClient();
			ResultStepData httpActionResult = new ResultStepData();
			String httpMethod = stepData.getHttpMethod().toString().toUpperCase();
			switch (httpMethod) {
			case "GET":
				httpActionResult = doGetAction(stepData, client, restUrl, headerMap);
				break;
			case "POST":
				httpActionResult = doPostAction(stepData, client, restUrl, headerMap);
				break;
			case "PUT":
				httpActionResult = doPutAction(stepData, client, restUrl, headerMap);
				break;
			case "DELETE":
				httpActionResult = doDeleteAction(stepData, client, restUrl, headerMap);
				break;
			default:
				break;
			}

			stepData = httpActionResult.getStepData();
			if (httpActionResult.getResult()) {
			} else {
				String message = httpActionResult.getReason();
				Report.fail(message);
				stepData.setStepResult(Result.FAIL.value());
				stepData.setResultDescription(message);
				return stepData;
			}

			// Pre-Request Build and Transformation
			ResultStepData responseModuleResult = responsePostValidations(stepData);
			String message = responseModuleResult.getReason();
			stepData.setResultDescription(message);
			if (responseModuleResult.getResult()) {
				stepData.setStepResult(Result.PASS.value());
			} else {
				Report.fail(message);
				stepData.setStepResult(Result.FAIL.value());
				stepData.setResultDescription(message);
				return stepData;
			}

			if (stepData.getStepResult().equalsIgnoreCase(Result.PASS.value()))
				Report.pass("<b>HTTP Rest API Action Passed.</b>");
			else
				Report.fail("<b>HTTP Rest API Action Failed.</b>");

		} catch (Exception e) {
			e.printStackTrace();
			Report.error("API Action failed due to Exception : " + e.getMessage());
			stepData.setStepResult(Result.ERROR.value());
			stepData.setResultDescription("API Action failed due to Exception : " + e.getMessage());
		}
		log.info("******************************************** API COMPONENT CALL ENDS ********************************************");
		return stepData;
	}

	private ResultStepData buildRestUrl(StepData stepData) throws Exception {
		ResultStepData response = new ResultStepData();
		String restUrl = null;
		try {
			stepData.setFinalStage(buildStageName(stepData));
			log.info("getHttpUrlFlag : " + stepData.getHttpUrlFlag());

			if (stepData.getHttpUrlFlag().toString().equalsIgnoreCase(HttpURLAction.URL.value())) {
				log.info("getHttpUrl : " + stepData.getHttpUrl());
				if (stepData.getHttpUrl() != null || !stepData.getHttpUrl().toString().equals("")) {
					restUrl = stepData.getHttpUrl().toString();
				} else {
					response.setResult(false);
					response.setReason("Http URL is Missing. Case failed due to Insufficient data.");
					response.setStepData(stepData);
					return response;
				}
			} else if (stepData.getHttpUrlFlag().toString().equalsIgnoreCase(HttpURLAction.STAGE.value())) {
				String port = "";
				String uri = "";
				String httpProtocol = "";
				log.info("getHttpCOnnType : " + stepData.getHttpConnType());
				log.info("getHttpStage : " + stepData.getHttpStage());
				log.info("getHttpPort : " + stepData.getHttpPort());
				log.info("getHttpUri : " + stepData.getHttpUri());

				log.info("getTestcaseStage : " + stepData.getHttpStage());
				log.info("getTriggerStage : " + stepData.getHttpStage());
				if (stepData.getHttpPort() != null)
					port = ":" + stepData.getHttpPort().toString();
				if (stepData.getHttpUri() != null)
					uri = stepData.getHttpUri().toString();
				if (stepData.getHttpConnType() != null)
					httpProtocol = stepData.getHttpConnType().toString();

				String stage = stepData.getFinalStage().toString();
				restUrl = httpProtocol + "://" + stage + port + uri;
			}

			// Transform String URL if any variable is available
			MultiResult resultData = transformGivenStringWithRuntimeAndTestData("URL", restUrl, stepData.getTestData());
			restUrl = resultData.getData();
			if (resultData.getResult()) {
				stepData.setFinalRestUrl(restUrl);
				Report.pass("<b>Request URL is </b>: " + restUrl + "");
				response.setResult(true);
				response.setStepData(stepData);
				return response;
			} else {
				response.setResult(false);
				response.setReason("API's URL build failed while replacing the Parameter with values.");
				response.setStepData(stepData);
				return response;
			}

		} catch (Exception e) {
			Report.error("Exception occured while building the Rest URL : " + e.getMessage());
			throw new Exception("Exception occured while building the Rest URL : " + e.getMessage());
		}

	}

	private String buildStageName(StepData stepData) throws Exception {
		// Defining stage:
		// STAGE Priority -> Trigger, Action, Testcase Stage
		// Setting default stage
		String stage = "msmaster.qa.paypal.com";
		String type = "Default";

		try {
			// Overriding if Action is defined with stage
			if (stepData.getHttpStage() != null) {
				if (!stepData.getHttpStage().toString().equals("")) {
					stage = stepData.getHttpStage().toString();
					type = "Action";
				} else {
					// Report.fail("Stage from Action is selected which holds Empty Value. ");
				}

			}

			// Overriding if Testcase is defined with stage
			if (stepData.getTestcaseStage() != null) {
				if (!stepData.getTestcaseStage().toString().equals("")) {
					stage = stepData.getTestcaseStage().toString();
					type = "Testcase";
				} else {
					// Report.fail("Stage from Testcase is selected which holds Empty Value. ");
				}
			}

			// Overriding if Trigger is defined with stage
			if (stepData.getTriggerStage() != null) {
				if (!stepData.getTriggerStage().toString().equals("")) {
					stage = stepData.getTriggerStage().toString();
					type = "Trigger";
				} else {
					// Report.fail("Stage from Trigger is selected which holds Empty Value. ");
				}
			}

			Report.info("Executing Action in Stage : <b>" + stage + "</b> ( " + type + " )");
			// stepData.setFinalStage(stage);
			Properties props = RuntimeMap.getRunTimeProperties();
			props.put("stage", stage);

		} catch (Exception e) {
			Report.error("Exception occured while building the Stage details : " + e.getMessage());
			e.printStackTrace();
			throw e;
		}
		return stage;
	}

	private ResultStepData buildHeaders(StepData stepData) throws Exception {
		ResultStepData response = new ResultStepData();
		Map<String, String> headerMap = null;
		boolean moduleResult = true;
		try {

			if (stepData.getHttpHeaders() != null) {
				String headerFromTestData = stepData.getHttpHeaders().toString();
				headerMap = new HashMap<String, String>();
				JSONArray jsonArr = new JSONArray(headerFromTestData);
				for (int i = 0; i < jsonArr.length(); i++) {
					JSONObject jsonObj = jsonArr.getJSONObject(i);
					MultiResult result = new MultiResult();
					String transformedValue = null;
					if (jsonObj.getString("value") != null) {
						result = transformGivenStringWithRuntimeAndTestData("Headers", jsonObj.getString("value"), stepData.getTestData());
						if (result.getResult()) {
							transformedValue = result.getData();
						} else {
							if (moduleResult)
								moduleResult = false;
						}
					}
					headerMap.put(jsonObj.getString("key"), transformedValue);
				}
			}

			if (moduleResult) {
				Report.pass("<b>Request Headers are </b>: " + headerMap + "");
				stepData.setBuiltHttpHeaders(headerMap);
				response.setResult(true);
				response.setStepData(stepData);
			} else {
				response.setResult(false);
				response.setReason("Header Parameter transformation failed due to Missing value.");
			}
			response.setStepData(stepData);

		} catch (Exception e) {
			Report.error("Exception occured while building the Headers : " + e.getMessage());
			throw new Exception("Exception occured while building the Headers : " + e.getMessage());
		}
		return response;
	}

	private ResultStepData buildRequest(StepData stepData) throws Exception {
		ResultStepData response = new ResultStepData();
		try {
			if (!stepData.getHttpMethod().toString().equalsIgnoreCase("GET") && !stepData.getHttpMethod().toString().equalsIgnoreCase("DELETE")) {
				String rawRequest = null;
				String processedRequest = null;
				if (stepData.getRequestBody() != null) {
					rawRequest = stepData.getRequestBody().toString();
					if (!rawRequest.trim().equals("")) {
						Report.info("<b>Request Payload before Parameter transformation </b>: " + rawRequest + "");
						// Report.info("Transforming Request with Runtime and Testdata...");
						Object testDataFlag = stepData.getTestDataFlag();
						Map<String, Object> testData = stepData.getTestData();
						Object requestParams = stepData.getRequestParams();
						// Transform the Request body with Run Time data
						MultiResult result = new MultiResult();
						result = transformGivenRequestJsonWithData(rawRequest, requestParams, testDataFlag, testData);
						processedRequest = result.getData();
						stepData.setProcessedRequestBody(processedRequest);
						if (result.getResult()) {
							Report.pass("<b>Request Payload after transformation </b>: " + processedRequest + "");
							response.setResult(true);
						} else {
							response.setResult(false);
							response.setReason("Request Payload parameter transformation failed due to missing value.");
						}
					} else {
						Report.warn("Request Payload is Empty.");
					}
				} else {
					Report.warn("Request Payload is NULL.");
				}
			} else {
				if (stepData.getRequestBody() == null) {
					// Do nothing
					response.setResult(true);
				} else {
					if (stepData.getRequestBody().toString().equals("")) {
						// Do nothing
						response.setResult(true);
					} else {
						response.setResult(false);
						response.setReason("Request Payload not Empty!. " + stepData.getHttpMethod().toString()
								+ " with Request Payload is not supported by Http Client yet. Contact admin Team.");
						Report.fail("Request Payload not Empty!. " + stepData.getHttpMethod().toString()
								+ " with Request Payload is not supported by Http Client yet. Contact admin Team.");
					}
				}
			}
			response.setStepData(stepData);
			log.info("HTTP Request Build ends...");
		} catch (Exception e) {
			Report.error("HTTP Request Build failed due to Exception : " + e.getMessage());
			e.printStackTrace();
			throw new Exception("HTTP Request Build failed due to Exception : " + e.getMessage());
		}
		return response;

	}

	private ResultStepData doGetAction(StepData stepData, HttpRestClient client, String restUrl, Map<String, String> headerMap) throws Exception {
		ResultStepData response = new ResultStepData();
		try {
			Report.info("Submitting GET Request to the API with all the details.");
			// Make a HTTP post call to the service with the request and header
			HttpClientResponse clientResponse = new HttpClientResponse();
			clientResponse = client.doGenericGet(restUrl, headerMap);

			Object responseAsObject = clientResponse.getResponse_body();
			stepData.setActualResponseBody(responseAsObject);
			response.setStepData(stepData);

			// Validate Params such as response code and others
			MultiResult result = new MultiResult();
			boolean responseParamOutput = responseParamsValidations(clientResponse, stepData);
			result = responseObjectValidation(responseParamOutput, responseAsObject, clientResponse.getError_msg());
			if (result.getResult()) {
				response.setResult(true);
			} else {
				response.setResult(false);
				response.setReason(result.getReason());
			}

		} catch (Exception e) {
			Report.error("Submit HTTP GET Action failed due to Exception : " + e.getMessage());
			throw new Exception("Submit HTTP GET Action failed due to Exception : " + e.getMessage());
		}
		return response;
	}

	private ResultStepData doPostAction(StepData stepData, HttpRestClient client, String restUrl, Map<String, String> headerMap) throws Exception {
		ResultStepData response = new ResultStepData();
		try {
			Report.info("Submitting POST Request to the API with all the details.");
			// Make a HTTP post call to the service with the request and header
			HttpClientResponse clientResponse = new HttpClientResponse();
			clientResponse = client.doGenericPost(restUrl, headerMap, stepData.getProcessedRequestBody());
			Object responseAsObject = clientResponse.getResponse_body();
			stepData.setActualResponseBody(responseAsObject);
			response.setStepData(stepData);

			// Validate Params such as response code and others
			MultiResult result = new MultiResult();
			boolean responseParamOutput = responseParamsValidations(clientResponse, stepData);
			result = responseObjectValidation(responseParamOutput, responseAsObject, clientResponse.getError_msg());
			if (result.getResult()) {
				response.setResult(true);
			} else {
				response.setResult(false);
				response.setReason(result.getReason());
			}

		} catch (Exception e) {
			Report.error("Submit HTTP POST Action failed due to Exception : " + e.getMessage());
			throw new Exception("Submit HTTP POST Action failed due to Exception : " + e.getMessage());
		}
		return response;
	}

	private ResultStepData doPutAction(StepData stepData, HttpRestClient client, String restUrl, Map<String, String> headerMap) throws Exception {
		ResultStepData response = new ResultStepData();
		try {
			Report.info("Submitting PUT Request to the API with all the details.");
			// Make a HTTP post call to the service with the request and header
			HttpClientResponse clientResponse = new HttpClientResponse();
			clientResponse = client.doGenericPut(restUrl, headerMap, stepData.getProcessedRequestBody());
			Object responseAsObject = clientResponse.getResponse_body();
			stepData.setActualResponseBody(responseAsObject);
			response.setStepData(stepData);

			// Validate Params such as response code and others
			MultiResult result = new MultiResult();
			boolean responseParamOutput = responseParamsValidations(clientResponse, stepData);
			result = responseObjectValidation(responseParamOutput, responseAsObject, clientResponse.getError_msg());
			if (result.getResult()) {
				response.setResult(true);
			} else {
				response.setResult(false);
				response.setReason(result.getReason());
			}

		} catch (Exception e) {
			Report.error("Submit HTTP PUT Action failed due to Exception : " + e.getMessage());
			throw new Exception("Submit HTTP PUT Action failed due to Exception : " + e.getMessage());
		}
		return response;
	}

	private ResultStepData doDeleteAction(StepData stepData, HttpRestClient client, String restUrl, Map<String, String> headerMap) throws Exception {
		ResultStepData response = new ResultStepData();
		try {
			Report.info("Submitting DELETE Request to the API with all the details.");
			// Make a HTTP post call to the service with the request and header
			HttpClientResponse clientResponse = new HttpClientResponse();
			clientResponse = client.doGenericDelete(restUrl, headerMap, stepData.getProcessedRequestBody());
			Object responseAsObject = clientResponse.getResponse_body();
			stepData.setActualResponseBody(responseAsObject);
			response.setStepData(stepData);

			// Validate Params such as response code and others
			MultiResult result = new MultiResult();
			boolean responseParamOutput = responseParamsValidations(clientResponse, stepData);
			result = responseObjectValidation(responseParamOutput, responseAsObject, clientResponse.getError_msg());
			if (result.getResult()) {
				response.setResult(true);
			} else {
				response.setResult(false);
				response.setReason(result.getReason());
			}

		} catch (Exception e) {
			Report.error("Submit HTTP DELETE Action failed due to Exception : " + e.getMessage());
			throw new Exception("Submit DELETE PUT Action failed due to Exception : " + e.getMessage());
		}
		return response;
	}

	private boolean responseParamsValidations(HttpClientResponse clientResponse, StepData stepData) throws Exception {
		boolean result = false;
		try {
			log.info("HTTP Response Param validation starts...");

			Report.pass("API Response received successfully.");
			Report.info("<b>Response Time </b>: " + clientResponse.getResponse_time() + ".");
			Report.info("<b>Response Headers </b>: " + clientResponse.getResponse_headers() + ".");

			if (stepData.getResponseCodeFlag().equalsIgnoreCase(Active.TRUE.value())) {
				if (stepData.getResponseCodeValue().toString().equalsIgnoreCase(clientResponse.getStatus_code())) {
					Report.pass("<b>Response Status Code </b>: " + stepData.getResponseCodeValue() + ". Status Code Validation Passed.");
					result = true;
				} else {
					String message = "Response Code validation failed. Actual Response Status code is '" + clientResponse.getStatus_code()
							+ "' and expected Status code is '" + stepData.getResponseCodeValue() + "'.";
					Report.fail(message);
					result = false;
					// result.setReason(message);
				}
			} else if (stepData.getResponseCodeFlag().equalsIgnoreCase(Active.FALSE.value())) {
				result = true;
				Report.info("Response Code : " + clientResponse.getStatus_code() + ".");
			}

//			if (stepData.getResponseStatusFlag().equalsIgnoreCase(Active.TRUE.value())) {
//				if (stepData.getResponseStatusValue().toString().equalsIgnoreCase(clientResponse.getStatus_phrase())) {
//					result = true;
//					Report.pass("Response Phrase validation Passed. Response Code : " + stepData.getResponseStatusValue() + ".");
//				} else {
//					String message = "Response Phrase validation Failed. Expected Response Phrase : '" + stepData.getResponseStatusValue()
//							+ "' Received Phrase : " + clientResponse.getStatus_phrase() + ".";
//					Report.fail(message);
//					result = false;
//					// result.setReason(message);
//				}
//			} else if (stepData.getResponseStatusFlag().equalsIgnoreCase(Active.FALSE.value())) {
//				result = true;
//				Report.info("<b>Response Phrase </b>: " + clientResponse.getStatus_phrase() + ".");
//			}

			log.info("Client Error Message : " + clientResponse.getError_msg());

		} catch (Exception e) {
			Report.error("HTTP Response Params validation failed due to Exception : " + e.getMessage());
			throw new Exception("HTTP Response Params validation failed due to Exception : " + e.getMessage());
		}
		return result;

	}

	private MultiResult responseObjectValidation(boolean result, Object responseAsObject, Object clientErrorMessage) throws Exception {
		MultiResult response = new MultiResult();
		try {
			if (result) {
				if (responseAsObject == null) {
					response.setResult(false);
					if (clientErrorMessage != null) {
						response.setReason("Response received Empty. Error is '" + clientErrorMessage + "'");
					} else {
						response.setReason("Response received Empty. Service Call Failed.");
					}
				} else {
					Report.pass("<b>Response Body received is </b>: " + responseAsObject + "");
					response.setResult(true);
				}
			} else {
				response.setResult(false);
				if (responseAsObject == null) {
					if (clientErrorMessage != null) {
						response.setReason("Response Status validation failed & Response is Empty. Error: '" + clientErrorMessage + "'.");
					} else {
						response.setReason("Response Status validation failed & Response is Empty.");
					}
				} else {
					Report.info("<b>Response Body received is </b>: " + responseAsObject + "");
					response.setReason("Response Status validation failed.");
				}
			}

		} catch (Exception e) {
			Report.error("HTTP Response validation failed due to Exception : " + e.getMessage());
			throw new Exception("HTTP Response validation failed due to Exception : " + e.getMessage());
		}
		return response;

	}

	private ResultStepData responsePostValidations(StepData stepData) throws Exception {
		ResultStepData response = new ResultStepData();
		try {
			log.info("HTTP Response validation starts...");
			Object actualResponseAsObject = stepData.getActualResponseBody();
			// Action based on Response actions
			if (stepData.getResponseAction().toString().equalsIgnoreCase(HttpResponseAction.BUILDASSERT.value())) {
				Report.info("<b>Response Action</b> : Build Variable values and Assert Response JSON");
				boolean validateResult = transformResponseAndAssert(stepData, stepData.getTestData(), actualResponseAsObject.toString());
				if (validateResult) {
					response.setResult(true);
					response.setReason("API Response Build and Assertion success.");
				} else {
					response.setResult(false);
					response.setReason("API Response Build and Assertion failed.");
				}
			} else if (stepData.getResponseAction().toString().equalsIgnoreCase(HttpResponseAction.EXTRACTSAVE.value())) {
				Report.info("<b>Response Action </b>: Extract and Save Values from Response JSON");
				boolean validateResult = extractFieldValuesAndSaveFromResponse(stepData, actualResponseAsObject);
				if (validateResult) {
					response.setResult(true);
					response.setReason("API Response Extract and Save value success.");
				} else {
					response.setResult(false);
					response.setReason("API Response Extract and Save value failed.");
				}
			} else if (stepData.getResponseAction().toString().equalsIgnoreCase(HttpResponseAction.NONE.value())) {
				Report.info("Response Action - None. No Extract or Assert actions to perform.");
				response.setResult(true);
				response.setReason("No Action choosen. Rest API validation complete. ");
			} else {
				Report.error("No Response Action available!");
			}

		} catch (Exception e) {
			Report.error("HTTP Post-Response Validation failed due to Exception : " + e.getMessage());
			throw new Exception("HTTP Post-Response Validation failed due to Exception : " + e.getMessage());
		}
		return response;

	}

	private MultiResult transformGivenRequestJsonWithData(String requestJson, Object requestParams, Object testDataFlag, Map<String, Object> testData)
			throws Exception {
		MultiResult result = new MultiResult();
		boolean funcResult = true;
		Properties props = RuntimeMap.getRunTimeProperties();
		try {
			// Sample : [{"paramType":"runtime","paramName":"buyerAccountNumber","paramValue":""}]
			if (requestParams != null) {
				JSONArray jsonArr = new JSONArray(requestParams.toString());
				if (jsonArr.length() > 0) {
					for (int i = 0; i < jsonArr.length(); i++) {
						JSONObject jsonObj = jsonArr.getJSONObject(i);
						String type = jsonObj.getString("paramType");
						String paramName = jsonObj.getString("paramName");
						if (type.equalsIgnoreCase(RequestParamTypes.RUNTIME.value())) {
							String value = props.getProperty(paramName);
							if (value != null) {
								Report.pass("Replacing Request Parameter '<b>" + paramName + "</b>' with value '" + value + "' from Runtime Data.");
								requestJson = requestJson.replaceAll("#" + paramName + "#", value);
							} else {
								Report.fail("Replacing Request Parameter '<b>" + paramName
										+ "</b>' from Runtime failed since no value is set for the variable.");
								// requestJson = requestJson.replaceAll("#" + paramName + "#", null);
								if (funcResult)
									funcResult = false;
							}
						} else if (type.equalsIgnoreCase(RequestParamTypes.TESTDATA.value())) {
							log.info("Replacing from Testdata...");
							if (testData.get(paramName) != null) {
								Report.pass("Replacing Request Parameter '<b>" + paramName + "</b>' with value '" + testData.get(paramName)
										+ "' from Testdata.");
								requestJson = requestJson.replaceAll("#" + paramName + "#", testData.get(paramName).toString());
							} else {
								Report.fail("Replacing Request Parameter '<b>" + paramName
										+ "</b>' from Testdata failed since no value is set for the variable.");
								// requestJson = requestJson.replaceAll("#" + paramName + "#", null);
								if (funcResult)
									funcResult = false;
							}
						}
					}
				} else {
					log.info("No Parameter value is Set for the Request!");
				}
			}

			result.setData(requestJson);
			if (funcResult) {
				result.setResult(true);
			} else {
				result.setResult(false);
			}

			log.info("Request Transformation done successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			Report.error("Request transformation failed due to Exception : " + e.getMessage());
			throw new Exception("Request transformation failed due to Exception : " + e.getMessage());
		}

		return result;
	}

	private boolean extractFieldValuesAndSaveFromResponse(StepData stepData, Object responseJson) throws Exception {
		boolean result = true;
		Properties props = RuntimeMap.getRunTimeProperties();

		try {
			Map<String, String> jsonExtractMap = null;
			if (stepData.getResponseExtractParams() != null) {
				String extractParams = stepData.getResponseExtractParams().toString();
				jsonExtractMap = new HashMap<String, String>();
				JSONArray jsonArr = new JSONArray(extractParams);
				if (jsonArr.length() > 0) {
					for (int i = 0; i < jsonArr.length(); i++) {
						JSONObject jsonObj = jsonArr.getJSONObject(i);
						jsonExtractMap.put(jsonObj.getString("jsonPath"), jsonObj.getString("variable"));
					}
					DocumentContext jsonContext = JsonPath.parse(responseJson.toString());

					for (Map.Entry<String, String> entry : jsonExtractMap.entrySet()) {
						Object jsonPathValue = null;
						try {
							jsonPathValue = jsonContext.read(entry.getKey());
							if (jsonPathValue != null) {
								props.put(entry.getValue(), jsonPathValue.toString());
								Report.pass("JSON Extract : Saving Parameter '<b>" + entry.getValue() + "</b>' with value '"
										+ jsonPathValue.toString() + "'.");
							} else {
								Report.warn("JSON Extract skipped due to JSON Value being NULL for Parameter '<b>" + entry.getValue() + "</b>'");
								// if (result)
								// result = false;
							}
						} catch (com.jayway.jsonpath.PathNotFoundException e) {
							Report.fail("JSON Extract failed for Parameter '<b>" + entry.getValue() + "</b>' due to JSON Path not found. Path : <b>'"
									+ entry.getKey() + "</b>'");
							if (result)
								result = false;
						}
					}

				} else {
					// Report.warn("Response Action is set to Json Extract and Save Params. But No Json extract variables available.");
				}
			}
			log.info("Response Value extraction with Json Paths completed successfully!");
		} catch (Exception e) {
			Report.error("JSON Response - Extract and Save values failed due to Exception : " + e.getMessage());
			e.printStackTrace();
			throw new Exception("JSON Response - Extract and Save values failed due to Exception : " + e.getMessage());
		}
		return result;

	}

	private boolean transformResponseAndAssert(StepData stepData, Map<String, Object> testData, String actualResponseJson) throws Exception {
		boolean result = true;

		Properties props = RuntimeMap.getRunTimeProperties();
		Object requestParams = stepData.getResponseAssertParams();

		try {
			String expectedResponseJson;
			if (stepData.getResponseBody() != null) {
				expectedResponseJson = stepData.getResponseBody().toString();

				if (requestParams != null) {
					JSONArray jsonArr = new JSONArray(requestParams.toString());
					if (jsonArr.length() > 0) {
						for (int i = 0; i < jsonArr.length(); i++) {
							JSONObject jsonObj = jsonArr.getJSONObject(i);
							String type = jsonObj.getString("paramType");
							String paramName = jsonObj.getString("paramName");
							if (type.equalsIgnoreCase(RequestParamTypes.RUNTIME.value())) {
								String value = props.getProperty(paramName);
								if (value != null) {
									Report.pass("Replacing Response Parameter '<b>" + paramName + "</b>' from Runtime with value '" + value + "'.");
									expectedResponseJson = expectedResponseJson.replaceAll("#" + paramName + "#", value);
								} else {
									Report.fail("Replacing Response Parameter '<b>" + paramName
											+ "</b>' from Runtime failed since no value is set for the Parameter.");
									if (result)
										result = false;
									// expectedResponseJson = expectedResponseJson.replaceAll("#" + paramName + "#", null);
								}
							} else if (type.equalsIgnoreCase(RequestParamTypes.TESTDATA.value())) {
								log.info("Replacing from Testdata...");
								if (testData.get(paramName) != null) {
									Report.pass("Replacing Response Parameter '<b>" + paramName + "</b>' from TestData with value '"
											+ testData.get(paramName) + "'.");
									expectedResponseJson = expectedResponseJson.replaceAll("#" + paramName + "#", testData.get(paramName).toString());
								} else {
									Report.fail("Replacing Response Parameter '<b>" + paramName
											+ "' from Testdata failed since no value is set for the Parameter.");
									if (result)
										result = false;
									// expectedResponseJson = expectedResponseJson.replaceAll("#" + paramName + "#", null);
								}
							}
						}
					} else {
						log.info("No Parameter value is Set for the Response!");
					}
				}

				if (result) {
					Report.info("<b>Validating the actual response against the expected response </b> : " + expectedResponseJson + "");
					JSONAssert.assertEquals(expectedResponseJson, actualResponseJson.toString(), false);
					Report.pass("<b>Actual and Expected Response field values Matched. Response Validation Passed.</b> ");
				} else {
					Report.fail("<b>Assertion Skipped as Response Parameter transformation failed.</b>");
					Report.info("<b>Expected Response for reference</b> : " + expectedResponseJson + "");
				}
			} else {
				Report.fail("Expected Response is NULL. Transform and validation failed.");
			}

		} catch (AssertionError e) {
			log.info(e.getLocalizedMessage());
			log.info(e.getMessage());
			result = false;
			Report.fail("First Mis-matched field : <b>" + e.getLocalizedMessage() + "</b>", false);
			Report.fail("<b>Actual and Expected Response field values not matched. Response Validation Failed.</b> ");
		} catch (JSONException e) {
			Report.error("Response Validation failed due to Exception : " + e.getMessage());
			result = false;
			e.printStackTrace();
		} catch (Exception e) {
			Report.error("Response transformation failed due to Exception : " + e.getMessage());
			e.printStackTrace();
			throw new Exception("Response transformation failed due to Exception : " + e.getMessage());
		}

		return result;
	}

	private MultiResult transformGivenStringWithRuntimeAndTestData(String type, String stringToTransform, Map<String, Object> testData)
			throws Exception {
		MultiResult resultData = new MultiResult();
		Properties props = RuntimeMap.getRunTimeProperties();
		boolean result = true;
		// log.info("Request in for Transformation is : " + stringToTransform);
		// log.info("String Transformation Testdata is : " + testData);
		// log.info("String Transformation Properties is : " + props);

		try {
			// Sample : [{"paramType":"runtime","paramName":"buyerAccountNumber","paramValue":""}]
			List<String> allMatchedVariables = new ArrayList<String>();
			Pattern p = Pattern.compile("(.*)#(.*)#(.*)");
			Matcher m = p.matcher(stringToTransform);

			while (m.find()) {
				allMatchedVariables.add(m.group(2));
			}

			if (allMatchedVariables.size() > 0) {
				if (type.equalsIgnoreCase("URL")) {
					Report.pass("<b>Request URL before transformation is </b>: " + stringToTransform + "");
				}

				log.info("Variables found in given String are : " + allMatchedVariables);

				for (String eachVariable : allMatchedVariables) {

					boolean isValueFoundInTestdata = false;
					// log.info("Working on Variable : " + eachVariable);
					Object testDataValue = null;

					// log.info("Checking the variable in Testdata...");
					testDataValue = testData.get(eachVariable);
					if (testDataValue != null) {
						isValueFoundInTestdata = true;
						Report.pass(
								"Replacing Parameter '<b>" + eachVariable + "</b>' in " + type + " with value '" + testDataValue + "' from Testdata");
						stringToTransform = stringToTransform.replaceAll("#" + eachVariable + "#", testDataValue.toString());
					} else {
						log.info("Replacing Parameter : '<b>" + eachVariable
								+ "</b>' with nothing Since No Value is set for the variable in Testdata");
					}

					Object runtimeValue = null;
					boolean isValueFoundInRuntime = false;
					// log.info("Checking the variable in Runtime properties...");
					runtimeValue = props.getProperty(eachVariable);
					if (runtimeValue != null) {
						isValueFoundInRuntime = true;
						Report.pass("Replacing Parameter '<b>" + eachVariable + "</b>' in " + type + " with value '" + runtimeValue.toString()
								+ "' from Runtime Data");
						stringToTransform = stringToTransform.replaceAll("#" + eachVariable + "#", runtimeValue.toString());
					} else {
						log.info("Replacing Variable : '" + eachVariable
								+ "' of Type 'Runtime' with nothing Since No Value is set for the variable in Runtime.");
					}

					if (!isValueFoundInTestdata && !isValueFoundInRuntime) {
						if (result) {
							result = false;
						}
						Report.fail("Parameter '<b>" + eachVariable + "</b>' in " + type + " is not found either in Testdata or Runtime Data");
					}

				}
				// log.info("String Transformation with Runtime and Testdata done successfully.");

			} else {
				log.info("No Variables found in the given string for Transformation with Runtime or Testdata.");
			}
			resultData.setResult(result);
			resultData.setData(stringToTransform);
		} catch (Exception e) {
			Report.error("Parameter replacement with Testdata or RUntime value failed due to Exception : " + e.getMessage());
			e.printStackTrace();
			throw e;
		}

		return resultData;
	}

}
