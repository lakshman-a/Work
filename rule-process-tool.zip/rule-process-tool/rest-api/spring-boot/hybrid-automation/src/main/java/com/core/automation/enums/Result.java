package com.core.automation.enums;

public enum Result {
	PASS("PASS"), FAIL("FAIL"), SKIP("SKIP"), NO_RUN("NO_RUN"), INACTIVE("INACTIVE"), ERROR("ERROR"), FATAL("FATAL"),
	WARN("WARN"), UNKNOWN("UNKNOWN");

	private final String result;

	Result(String result) {
		this.result = result;
	}

	public String value() {
		return this.result;
	}

}
