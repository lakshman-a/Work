package com.core.automation.driver;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.SkipException;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.core.automation.enums.Active;
import com.core.automation.enums.Result;
import com.core.automation.enums.RunStatus;
import com.core.automation.enums.SuiteLevel;
import com.core.automation.enums.TestLayers;
import com.core.automation.model.EmailReportModel;
import com.core.automation.model.StepData;
import com.core.automation.report.JenkinsHtmlReport;
import com.core.automation.report.Report;

import com.core.automation.utilities.DateTimeUtil;
import com.core.automation.utilities.DbUtil;
import com.core.automation.utilities.FileUtil;
import com.core.automation.utilities.ProjectProperty;
import com.core.automation.utilities.PropertyUtil;

public class TestNgDriver {

	final static Logger log = Logger.getLogger(TestNgDriver.class);
	String suiteRunResult;
	String caseRunStatus;
	static String reportFileName;
	static EmailReportModel reportModel;

	private void initializeFiles() {
		log.info("initializeFiles... ");
		try {
			ProjectProperty.initializeProjectProperty();
			reportModel = new EmailReportModel();
			log.info("Initializing files complete.");

		} catch (Exception e) {
			log.info("Exception occured while initializing files. " + e);
			throw e;
		}
	}

	public void createReport(String runId, String suiteName) throws Exception {
		// String serializeTestSuiteName = suiteName.replaceAll(" ", "_");
		// reportFileName = "Report_" + runId + "_" + serializeTestSuiteName + ".html";
		reportFileName = PropertyUtil.getConfigValueOf("ExtentReports_HTML_File_Prefix") + runId + ".html";
		Report.startReportWithFileName(reportFileName);
		Report.addReportInfo("Run ID", runId);
		Report.addReportInfo("Suite Name", suiteName);
	}

	@BeforeSuite
	@Parameters({ "runId", "suiteName", "suiteLevel", "suiteRunType", "stage", "user", "count" })
	public void beforeSuite(String runId, String suiteName, String suiteLevel, String suiteRunType, String stage, String user, String count) {
		try {

			log.info("@BeforeSuite");
			initializeFiles();
			reportModel.setSuiteName(suiteName);
			createReport(runId, suiteName);
			suiteRunResult = Result.PASS.value();

			if (suiteLevel.equalsIgnoreCase(SuiteLevel.TESTSUITE.value()))
				log.info("Test Suite Level Run");
			if (suiteLevel.equalsIgnoreCase(SuiteLevel.TESTCASE.value()))
				log.info("Test CASE Level Run");

			String runDetailsQuery = "INSERT INTO `rule_process`.`test_run_details` (`run_id`, `run_level`, `test_name`, `case_count`, `status`, `result`,`stage`, `report_file`, `grid_url`, `browser`, `triggered_by`) VALUES ('"
					+ runId + "', '" + suiteLevel + "', '" + suiteName + "', '" + count + "', 'RUNNING', '" + Result.UNKNOWN.value() + "','" + stage
					+ "','" + reportFileName + "', null, null, 'layyakannu')";
			if (DbUtil.executeUpdateQuery(runDetailsQuery) == 1)
				log.info("RunID Registered in DB Successfully");
			else
				log.info("RunID was not registered successfully in DB. Kindly verify");
		} catch (Exception e) {
			log.error("Exception occured in @BeforeSuite : " + e);
			throw new SkipException("Skipped execution due to exception in BeforeSuite : " + e);
		}
		log.info("TestBatch execution starts");
	}

	@BeforeTest(alwaysRun = true)
	@Parameters({ "testcaseName", "testcaseSummary", "testcaseNum" })
	public void beforeTest(String testcaseName, String testcaseSummary, String testcaseNum) {
		try {
			log.info("@beforeTest");
			Report.startTestCase(testcaseName, "<b>" + testcaseSummary + "</b>", testcaseNum);
			log.info("Report Model : " + reportModel + " | Count : " + reportModel.getTotalCase());
			reportModel.addCaseCount();
			caseRunStatus = Result.PASS.value();
		} catch (Exception e) {
			log.error("Exception occured in @BeforeTest : " + e);
			throw new SkipException("@BeforeTest Failed with Exception");
		}
	}

	@AfterTest(alwaysRun = true)
	@Parameters({ "testcaseName" })
	public void afterTest(String testcaseName) {
		log.info("@After Test");
		log.info("@After Test. Case RUn status is : " + caseRunStatus);
		try {
			Report.endTestCase();
			// Setting priority for Case status
			if (!caseRunStatus.equals(Result.PASS.value())) {
				if (caseRunStatus.equals(Result.FAIL.value())) {
					suiteRunResult = Result.FAIL.value();
					reportModel.addCaseFailCount();
				}
				if (caseRunStatus.equals(Result.ERROR.value())) {
					suiteRunResult = Result.ERROR.value();
					reportModel.addCaseErrorCount();
				}
				if (caseRunStatus.equalsIgnoreCase(Result.UNKNOWN.value())) {
					suiteRunResult = Result.UNKNOWN.value();
					reportModel.addCaseErrorCount();
				}
			} else {
				reportModel.addCasePassCount();
			}

			log.info("suiteRunResult at the end of Testcase is : " + suiteRunResult);
			log.info("Testcase - '" + testcaseName + "' Status : " + caseRunStatus);
			log.info("Suite Current stauts - Count : '" + reportModel.getTotalCase() + "' PASSED : " + reportModel.getCasePassed() + "' FAILED : "
					+ reportModel.getCaseFailed() + "' ERROR : " + reportModel.getCaseError());

		} catch (Exception e) {
			log.info("Exception occured while @AfterTest : " + e);
			throw new SkipException("Skipped at AfterTest due to exception occured. " + e);
		}
	}

	@AfterSuite(alwaysRun = true)
	@Parameters({ "runId" })
	public void afterSuite(String runId) {
		log.info("@After Suite");
		try {
			String runDetailsUpdateQuery = "Update rule_process.test_run_details set status = '" + RunStatus.COMPLETED.value() + "', result='"
					+ suiteRunResult + "' where run_id = '" + runId + "'";
			DbUtil.executeUpdateQuery(runDetailsUpdateQuery);

			JenkinsHtmlReport reportObj = new JenkinsHtmlReport();
			reportObj.createJenkinsReport(reportModel.getSuiteName(), reportModel.getTotalCase(), reportModel.getTotalData(),
					reportModel.getCasePassed(), reportModel.getCaseFailed(), reportModel.getCaseError());
			FileUtil.reduceHTMLReportSize(reportFileName);

			log.info("TestBatch execution completed.");

		} catch (Exception e) {
			log.info("Exception occured while iafterSuite : " + e);
			throw new SkipException("Skipped at After suite due to exception occured. " + e);
		}
	}

	@Test(alwaysRun = true)
	@Parameters({ "runId", "suiteLevel", "testcaseName", "testcaseNum", "stage" })
	public void runCases(String runId, String suiteLevel, String testcaseName, String testcaseNum, String stage) {

		int id = (int) Thread.currentThread().getId();
		log.info("Thread -> '" + id + "' running case : '" + testcaseName + "' with RunId : '" + runId + "'");
		try {

			String testcaseQuery = "Select c.test_case_name, c.test_case_summary, c.module_name, c.sub_module, c.stage, c.active as 'test_case_active',c.is_test_data_avail,c.test_data_keys,c.test_data "
					+ "from rule_process.test_cases c where c.test_case_name = '" + testcaseName + "'";
			List<HashMap<String, Object>> testcaseDetailsFromDb = DbUtil.executeSelectQuery(testcaseQuery);
			log.info("No. of Items returned for Testcase : " + testcaseDetailsFromDb.size());

			if (testcaseDetailsFromDb.size() == 1) {

				StepData stepData = new StepData();
				stepData.setTestCaseName((String) testcaseDetailsFromDb.get(0).get("test_case_name"));
				stepData.setTestCaseSummary((String) testcaseDetailsFromDb.get(0).get("test_case_summary"));
				stepData.setModuleName(testcaseDetailsFromDb.get(0).get("module_name"));
				stepData.setSubModule(testcaseDetailsFromDb.get(0).get("sub_module"));
				stepData.setTriggerStage(stage);
				stepData.setTestcaseStage((String) testcaseDetailsFromDb.get(0).get("stage"));
				stepData.setTestCaseActive((String) testcaseDetailsFromDb.get(0).get("test_case_active"));

				// Validating Testdata
				List<Map<String, Object>> testDataMap = new ArrayList<Map<String, Object>>();
				if (testcaseDetailsFromDb.get(0).get("test_data") != null) {
					String rawTestDataFromDb = testcaseDetailsFromDb.get(0).get("test_data").toString();
					JSONArray jsonArr = new JSONArray(rawTestDataFromDb);
					for (int i = 0; i < jsonArr.length(); i++) {
						JSONObject jsonObj = jsonArr.getJSONObject(i);
						log.info("TestData Row No : " + i + ". Data : " + jsonObj);
						Map<String, Object> result = toMap(jsonObj);
						testDataMap.add(result);
					}
				}
				log.info("Testdata Map : " + testDataMap);
				log.info("No of TestData  Items to execute : " + testDataMap.size());

				int testDataItr = 1;
				int testDataCount = testDataMap.size();
				
				if(testDataCount == 0) {
					Map<String, Object> sampleMap = new HashMap<String, Object>();
					sampleMap.put("Step", 1);
					testDataMap.add(sampleMap);
				}
				// Iterating for all the testdata
				for (Map<String, Object> eachTestData : testDataMap) {
					log.info("Executing Testdata Map : " + eachTestData);
					String testDataDesc = null;
					if (eachTestData.get("Description") != null)
						testDataDesc = eachTestData.get("Description").toString();
					else
						testDataDesc = "NA";
					stepData.setTestData(eachTestData);

					String testcaseTrnQuery = "Select ctrn.step_no, ctrn.action_name, ctrn.active as 'test_case_trn_active',"
							+ "act.layer,act.action_desc, act.http_method,act.http_url_flag, act.http_url,act.http_type,act.http_stage, act.http_port, act.http_uri, act.component,act.checkpoint,act.headers,act.request_Body,"
							+ "act.request_Params,act.response_Action,act.response_Body,act.response_code_flag,act.response_code_value,act.response_status_flag,act.response_status_value, act.response_Assert_Params,act.response_Extract_Params,"
							+ "act.active as 'action_active' "
							+ "from rule_process.test_cases c,rule_process.test_cases_trn ctrn, rule_process.test_action act where c.test_case_name = '"
							+ testcaseName + "' and c.test_case_name = ctrn.test_case_name and ctrn.action_name = act.action_name "
							+ "order by ctrn.step_no";
					List<HashMap<String, Object>> testcaseTrnDetailsFromDb = DbUtil.executeSelectQuery(testcaseTrnQuery);
					log.info("No. of Actions returned for Testcase : " + testcaseTrnDetailsFromDb.size());
					if (testcaseTrnDetailsFromDb.size() == 0) {
						log.error("No Steps Returned frm DB for the given Testcase!");
						Report.skip("No Actions tagged for the Testcase. SKipping testcase.");
					} else if (testcaseTrnDetailsFromDb.size() > 0) {
						log.info("Executing all actions for the testcase...");
						int actionRowNum = 1;

						for (HashMap<String, Object> eachAction : testcaseTrnDetailsFromDb) {
							// log.info("Executing Step No. [" + rowNum + "] => " + eachAction.toString());
							log.info("Executing Action Step No. [" + actionRowNum + "]");
							String actionStartTime = null;
							String actionEndTime = null;

							stepData.setStepResult(Result.UNKNOWN.value());
							stepData.setResultDescription(null);

							stepData.setStepNo((String) eachAction.get("step_no"));
							stepData.setActionName((String) eachAction.get("action_name"));
							stepData.setActionDesc((String) eachAction.get("action_desc"));
							stepData.setTestCaseTrnActive((String) eachAction.get("test_case_trn_active"));
							stepData.setLayer((String) eachAction.get("layer"));
							stepData.setHttpMethod(eachAction.get("http_method"));
							stepData.setHttpUrlFlag(eachAction.get("http_url_flag"));
							stepData.setHttpUrl(eachAction.get("http_url"));
							stepData.setHttpConnType(eachAction.get("http_type"));
							stepData.setHttpStage(eachAction.get("http_stage"));
							stepData.setHttpPort(eachAction.get("http_port"));
							stepData.setHttpUri(eachAction.get("http_uri"));
							stepData.setComponent(eachAction.get("component"));
							stepData.setCheckpoint(eachAction.get("checkpoint"));
							stepData.setHttpHeaders(eachAction.get("headers"));
							stepData.setRequestBody(eachAction.get("request_Body"));

							stepData.setResponseCodeFlag(eachAction.get("response_code_flag").toString());
							stepData.setResponseCodeValue(eachAction.get("response_code_value"));
							stepData.setResponseStatusFlag(eachAction.get("response_status_flag").toString());
							stepData.setResponseStatusValue(eachAction.get("response_status_value"));

							stepData.setRequestParams(eachAction.get("request_Params"));
							stepData.setResponseAction(eachAction.get("response_Action"));
							stepData.setResponseBody(eachAction.get("response_Body"));
							stepData.setResponseAssertParams(eachAction.get("response_Assert_Params"));
							stepData.setResponseExtractParams(eachAction.get("response_Extract_Params"));
							stepData.setActionActive((String) eachAction.get("action_active"));

							String actionName = stepData.getActionName();
							String actionDesc = stepData.getActionDesc();

							if (testDataCount > 1) {
								if (actionRowNum == 1) {
									Report.startComponent("Test Data Iteration : " + testDataItr + "<br>Description : " + testDataDesc
											+ "<br><hr><br>" + actionName, actionDesc);
								} else {
									Report.startComponent(actionName, actionDesc);
								}
							} else {
								Report.startComponent(actionName, actionDesc);
							}

							if (stepData.getTestCaseActive().equalsIgnoreCase(Active.TRUE.value())) {
								if (stepData.getTestCaseTrnActive().equalsIgnoreCase(Active.TRUE.value())) {
									if (stepData.getActionActive().equalsIgnoreCase(Active.TRUE.value())) {

										String classNameToBeLoaded = null;
										if (stepData.getLayer().equalsIgnoreCase(TestLayers.API.value())) {
											classNameToBeLoaded = "com.core.automation.action.api.Common_PP_Rest_API_Validation";
										} else {
											classNameToBeLoaded = "com.core.automation.action.common." + actionName;
										}
										ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
										Class<?> myClass = classLoader.loadClass(classNameToBeLoaded);
										Object whatInstance = myClass.newInstance();
										actionStartTime = DateTimeUtil.getTimeStamp();
										try {
											Method myMethod = myClass.getMethod("object", new Class[] { StepData.class });
											stepData = (StepData) myMethod.invoke(whatInstance, new Object[] { stepData });

										} catch (NoSuchMethodException e) {
											log.error("Given Action is not available in the Package! : " + e);
											Report.error("No Such Action(name) available in the Package. " + e);
											stepData.setStepResult(Result.ERROR.value());
											stepData.setResultDescription("Given Action is not available in the Package! : " + e);
											e.printStackTrace();
										} catch (Exception e) {
											log.error("General Exception while reflection call! : " + e);
											Report.error("Error occured while triggering Action. " + e);
											stepData.setStepResult(Result.ERROR.value());
											stepData.setResultDescription("Error occured while triggering Action. " + e);
											e.printStackTrace();
										}
										actionEndTime = DateTimeUtil.getTimeStamp();
										// if (stepData.getStepResult() == null) {
										// stepData.setStepResult(Result.UNKNOWN.value());
										// }

										String escapedResultDesc = null;
										if (stepData.getResultDescription() != null) {
											escapedResultDesc = stepData.getResultDescription().toString().replaceAll("'", "''");

										}
										String stepResultQuery = "INSERT INTO `rule_process`.`test_report_trn` ( `run_id`, `test_case_num`, `test_case_name`, `test_data_num`,`comp_num`, `comp_name`, `step_num`, `action_name`, `step_result`, `step_desc`, `screenshot_path`, `step_start_time`, `step_end_time`) VALUES ( '"
												+ runId + "', '" + testcaseNum + "', '" + testcaseName + "','" + testDataItr + "', null, null, '"
												+ stepData.getStepNo() + "', '" + stepData.getActionName() + "', '" + stepData.getStepResult()
												+ "', '" + escapedResultDesc + "', null, '" + actionStartTime + "', '" + actionEndTime + "') ";
										int updateCount = DbUtil.executeUpdateQuery(stepResultQuery);
										if (updateCount < 0) {
											Report.error("Error occured while executing the Step Report DB Query. Check Logs!");
											stepData.setStepResult(Result.ERROR.value());
											stepData.setResultDescription("Error occured while executing the Step Report DB Query. Check Logs!");
										}

										// Setting priority for Case status
										if (!stepData.getStepResult().equals(Result.PASS.value())) {
											if (stepData.getStepResult().equals(Result.FAIL.value())) {
												caseRunStatus = Result.FAIL.value();
											}
											if (stepData.getStepResult().equals(Result.ERROR.value())) {
												caseRunStatus = Result.ERROR.value();
											}
											if (stepData.getStepResult().equalsIgnoreCase(Result.UNKNOWN.value())) {
												caseRunStatus = Result.UNKNOWN.value();
											}
										}

										log.info("caseRunStatus at the end of Testcase is : " + caseRunStatus);

									} else {
										Report.skip("Action is marked as In-Active. Skipping Action execution.");
										log.warn("Action is marked Inactive!");
									}
								} else {
									Report.skip("TestStep is marked as In-Active. Skipping this TestStep from execution.");
									log.warn("Step Action in Testcase is Inactive!");
								}
							} else {
								Report.skip("Testcase is marked as In-Active. Skipping Testcase execution.");
								log.warn("Testcase is Inactive!");
							}

							Report.appendComponent();

							actionRowNum++;
						} // Outer Main foreach - Actions Iteration

					} // testcasedetailsfromDb > 0

					testDataItr++;
				} // Test Data iterations

			} else {
				log.error("More Items returned for the Testcase!");
			}

		} catch (Exception e) {
			log.error("Exception in Runcases @Testmethod. " + e);
			e.printStackTrace();
			throw new SkipException("@Test failed due to exception : " + e);
		}

	}

	public static synchronized Map<String, Object> toMap(JSONObject jsonobj) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		@SuppressWarnings("unchecked")
		Iterator<String> keys = jsonobj.keys();
		while (keys.hasNext()) {
			String key = keys.next();
			Object value = jsonobj.get(key);
			if (value instanceof JSONObject) {
				value = toMap((JSONObject) value);
			}
			// else {
			// System.out.println("Not an istance of Json Object");
			// }
			map.put(key, value);
		}
		return map;
	}

}
