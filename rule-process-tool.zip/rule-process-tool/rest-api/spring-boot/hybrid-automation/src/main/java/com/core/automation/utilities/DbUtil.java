package com.core.automation.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

public class DbUtil {
	final static Logger log = Logger.getLogger(DbUtil.class);
	static String JDBC_DRIVER;
	static String DB_URL;
	static String USER;
	static String PASS;

	public static List<HashMap<String, Object>> executeSelectQuery(String query) {
		Statement stmt = null;
		Connection conn = null;

		try {
			Properties prop = FileUtil.loadPropertyFile("config.properties");
			JDBC_DRIVER = prop.getProperty("mysql_jdbcDriver");
			DB_URL = prop.getProperty("mysql_dbUrl");
			USER = prop.getProperty("mysql_user");
			PASS = prop.getProperty("mysql_pass");

			Class.forName("com.mysql.jdbc.Driver");

			// Set SQL Properties
			Properties properties = new Properties();
			properties.setProperty("user", USER);
			properties.setProperty("password", PASS);
			properties.setProperty("useSSL", "true");
			properties.setProperty("autoReconnect", "true");
			properties.setProperty("verifyServerCertificate", "false");

			conn = DriverManager.getConnection(DB_URL, properties);
			stmt = conn.createStatement();
			log.info("Executing Query : " + query);
			ResultSet rs = stmt.executeQuery(query);

			if (!rs.isBeforeFirst()) {
				rs.close();
				log.info("No Result returned for the select Query!");
				List<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
				return list;
			} else {
				List<HashMap<String, Object>> resultSetToHashMap = convertResultSetToListOfHashMap(rs);
				rs.close();
				return resultSetToHashMap;
			}

		} catch (SQLException e) {
			log.error("SQL Exception occured while executing query. Returning NULL as Response. Exception is : " + e);
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			log.error("Exception occured while executing query. Returning NULL as Response. Exception is : " + e);
			e.printStackTrace();
			return null;
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e2) {

			}
		}
	}

	public static int executeUpdateQuery(String query) {
		Statement stmt = null;
		Connection conn = null;
		int count;
		try {
			Properties prop = FileUtil.loadPropertyFile("config.properties");
			JDBC_DRIVER = prop.getProperty("mysql_jdbcDriver");
			DB_URL = prop.getProperty("mysql_dbUrl");
			USER = prop.getProperty("mysql_user");
			PASS = prop.getProperty("mysql_pass");

			Class.forName("com.mysql.jdbc.Driver");
			// Set SQL Properties
			Properties properties = new Properties();
			properties.setProperty("user", USER);
			properties.setProperty("password", PASS);
			properties.setProperty("useSSL", "true");
			properties.setProperty("autoReconnect", "true");
			properties.setProperty("verifyServerCertificate", "false");
			conn = DriverManager.getConnection(DB_URL, properties);
			
			stmt = conn.createStatement();
			log.info("Executing DML Query : " + query);

			conn.setAutoCommit(false);
			conn.rollback();
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			count = stmt.executeUpdate(query);
			conn.commit();

			log.info("Count of Rows Updated : " + count);
			log.info("DML Executed successfully");

		} catch (SQLException e) {
			log.error("SQL Exception occured while executing query. Returning NULL as Response. Exception is : " + e);
			e.printStackTrace();
			try {
				if (conn != null) {
					conn.rollback();
				}
			} catch (Exception e2) {
				log.error("Exception occured while rollback in SQL Exception catch. Exception is : " + e);
			}
			return -1;
		} catch (Exception e) {
			log.error("Exception occured while executing query. Returning NULL as Response. Exception is : " + e);
			e.printStackTrace();
			try {
				if (conn != null) {
					conn.rollback();
				}
			} catch (Exception e2) {
				log.error("Exception occured while rollback in SQL Exception catch. Exception is : " + e);
			}
			return -2;
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e2) {

			}
		}
		return count;
	}

	private static List<HashMap<String, Object>> convertResultSetToListOfHashMap(ResultSet rs) throws Exception {
		ResultSetMetaData md = rs.getMetaData();
		List<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();

		while (rs.next()) {
			HashMap<String, Object> row = new HashMap<String, Object>(md.getColumnCount());
			for (int i = 1; i <= md.getColumnCount(); ++i) {
				row.put(md.getColumnLabel(i), rs.getObject(i));
			}
			list.add(row);
		}
		return list;
	}

	public static void main(String[] args) {
		System.out.println(executeSelectQuery(
				"Select suite.test_case_name, suite.test_case_num from rule_process.test_suite_trn suite, rule_process.test_cases cases where suite.test_suite_name='Functional Suite' and suite.test_case_name=cases.test_case_name and cases.is_automation='true' and cases.test_run_mode='serial' "));
	}
}
