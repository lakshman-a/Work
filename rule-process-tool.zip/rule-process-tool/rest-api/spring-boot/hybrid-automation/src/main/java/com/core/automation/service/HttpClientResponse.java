package com.core.automation.service;

public class HttpClientResponse {

	private String status_code;
	private String status_phrase;
	private Object response_body;
	private String response_time;
	private String response_headers;
	private String error_msg;

	public String getStatus_code() {
		return status_code;
	}

	public void setStatus_code(String status_code) {
		this.status_code = status_code;
	}

	public String getStatus_phrase() {
		return status_phrase;
	}

	public void setStatus_phrase(String status_phrase) {
		this.status_phrase = status_phrase;
	}

	public Object getResponse_body() {
		return response_body;
	}

	public void setResponse_body(Object response_body) {
		this.response_body = response_body;
	}

	public String getResponse_time() {
		return response_time;
	}

	public void setResponse_time(String response_time) {
		this.response_time = response_time;
	}

	public String getResponse_headers() {
		return response_headers;
	}

	public void setResponse_headers(String response_headers) {
		this.response_headers = response_headers;
	}

	public String getError_msg() {
		return error_msg;
	}

	public void setError_msg(String error_msg) {
		this.error_msg = error_msg;
	}


}
