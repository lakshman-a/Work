package com.core.automation.enums;

public enum SuiteLevel {
	TESTSUITE("TESTSUITE"), TESTCASE("TESTCASE");

	private final String item;

	SuiteLevel(String item) {
		this.item = item;
	}

	public String value() {
		return this.item;
	}

}
