package com.core.automation.enums;

public enum HttpURLAction {
	URL("URL"), STAGE("STAGE");

	private final String item;

	HttpURLAction(String item) {
		this.item = item;
	}

	public String value() {
		return this.item;
	}

}
