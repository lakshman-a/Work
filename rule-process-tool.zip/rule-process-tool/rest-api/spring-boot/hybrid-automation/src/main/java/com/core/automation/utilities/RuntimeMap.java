package com.core.automation.utilities;

import java.util.Properties;
import org.apache.log4j.Logger;

import com.core.automation.report.Report;


public class RuntimeMap {
	final static Logger log = Logger.getLogger(RuntimeMap.class);
	private static Properties runTimeProperty=new Properties();
	
	public RuntimeMap(){
		runTimeProperty=new Properties();
	}
	
	public synchronized static void setKeyValue(String key, String value) {
		Report.info("Setting Runtime Varible '<b>"+key+"</b>' with value '<b>" + value+"</b>'");
		runTimeProperty.setProperty(key, value);
	}

	public static String getValue(String key) {
		return runTimeProperty.getProperty(key);
	}
	
	public static Properties getRunTimeProperties() {
		return runTimeProperty;
	}
	
	public static void clearProperties() {
		runTimeProperty.clear();
	}
	
	public static void printRunTimeProperties() {
		log.info("Current Properties Stored in Runtime : "+runTimeProperty);
	}

}
