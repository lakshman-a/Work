package com.core.automation.utilities;

import java.net.URL;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;

import com.core.automation.report.Report;
import com.core.automation.service.HttpClientResponse;
import com.paypal.test.jaws.http.rest.PayPalRestClientFactory;
import com.paypal.test.jaws.http.rest.impl.EntityRestClient;

public class HttpRestClient {
	final static Logger log = Logger.getLogger(HttpRestClient.class);

	public HttpClientResponse doGenericGet(String url, Map<String, String> headersMap) throws Exception {
		HttpClientResponse clientResponse = new HttpClientResponse();
		String rawHttpResponse = null;
		log.info("Submitting HTTP Action : GET");
		try {
			EntityRestClient<String> testClient = (EntityRestClient<String>) PayPalRestClientFactory.createEntityClient(String.class, new URL(url),
					MediaType.APPLICATION_JSON);
			testClient.addHeaders(headersMap);

			try {
				rawHttpResponse = testClient.simpleGet();
				clientResponse.setResponse_body(rawHttpResponse);
			} catch (javax.ws.rs.WebApplicationException e) {
				log.info("Response Code for the Request is not 200. So Capturing the response from Exception. Exception is - " + e);
				rawHttpResponse = e.getLocalizedMessage();
				clientResponse.setResponse_body(e.getLocalizedMessage());
				e.printStackTrace();
			}

			clientResponse.setStatus_code(String.valueOf(testClient.getStatus().getStatusCode()));
			clientResponse.setStatus_phrase(testClient.getStatus().getReasonPhrase());
			clientResponse.setResponse_time(String.valueOf(testClient.getElapsedMillis()) + " ms");
			clientResponse.setResponse_headers(testClient.getResponseHeaders().toString());

			log.info("Response Details: ");
			log.info("Status Code: " + testClient.getStatus().getStatusCode());
			log.info("Status Phrase: " + testClient.getStatus().getReasonPhrase());
			log.info("Response Time: " + String.valueOf(testClient.getElapsedMillis()) + " ms");
			log.info("Response Headers: " + String.valueOf(testClient.getResponseHeaders().toString()));
			log.info("Response Body: " + rawHttpResponse);

		} catch (Exception e) {
			Report.error("Exception occured while Submittinh GET Request. Exception is : " + e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
		return clientResponse;
	}

	public HttpClientResponse doGenericPost(String url, Map<String, String> headersMap, Object payload) throws Exception {
		HttpClientResponse clientResponse = new HttpClientResponse();
		String rawHttpResponse = null;
		log.info("Submitting HTTP Action : POST");
		try {
			EntityRestClient<String> testClient = (EntityRestClient<String>) PayPalRestClientFactory.createEntityClient(String.class, new URL(url),
					MediaType.APPLICATION_JSON);
			testClient.addHeaders(headersMap);

			try {
				if (payload == null) {
					Report.info("Request Payload Empty. Processing HTTP POST without Payload.");
					rawHttpResponse = testClient.simplePost();
				} else {
					if (!payload.toString().trim().equals("")) {
						rawHttpResponse = testClient.simplePost(payload.toString());
					} else {
						Report.info("Request Payload Empty. Processing HTTP POST without Payload.");
						rawHttpResponse = testClient.simplePost();
					}
				}
				clientResponse.setResponse_body(rawHttpResponse);
			} catch (javax.ws.rs.WebApplicationException e) {
				log.info("Response Code for the Request is not 200. So Capturing the response from Exception. Exception is - " + e);
				rawHttpResponse = e.getLocalizedMessage();
				clientResponse.setResponse_body(e.getLocalizedMessage());
				e.printStackTrace();
			}

			clientResponse.setStatus_code(String.valueOf(testClient.getStatus().getStatusCode()));
			clientResponse.setStatus_phrase(testClient.getStatus().getReasonPhrase());
			clientResponse.setResponse_time(String.valueOf(testClient.getElapsedMillis()) + " ms");
			clientResponse.setResponse_headers(testClient.getResponseHeaders().toString());

			log.info("Response Details: ");
			log.info("Status Code: " + testClient.getStatus().getStatusCode());
			log.info("Status Phrase: " + testClient.getStatus().getReasonPhrase());
			log.info("Response Time: " + String.valueOf(testClient.getElapsedMillis()) + " ms");
			log.info("Response Headers: " + String.valueOf(testClient.getResponseHeaders().toString()));
			log.info("Response Body: " + rawHttpResponse);

		} catch (Exception e) {
			Report.error("Exception occured while Submittinh POST Request. Exception is : " + e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
		return clientResponse;
	}

	public HttpClientResponse doGenericPut(String url, Map<String, String> headersMap, Object payload) throws Exception {
		HttpClientResponse clientResponse = new HttpClientResponse();
		String rawHttpResponse = null;
		log.info("Submitting HTTP Action : PUT");
		try {
			EntityRestClient<String> testClient = (EntityRestClient<String>) PayPalRestClientFactory.createEntityClient(String.class, new URL(url),
					MediaType.APPLICATION_JSON);
			testClient.addHeaders(headersMap);

			try {
				if (payload == null) {
					Report.info("Request Payload Empty. Processing HTTP PUT without Payload.");
					rawHttpResponse = testClient.simplePut();
				} else {
					if (!payload.toString().trim().equals("")) {
						rawHttpResponse = testClient.simplePut(payload.toString());
					} else {
						Report.info("Request Payload Empty. Processing HTTP PUT without Payload.");
						rawHttpResponse = testClient.simplePut();
					}
				}
				clientResponse.setResponse_body(rawHttpResponse);
			} catch (javax.ws.rs.WebApplicationException e) {
				log.info("Response Code for the Request is not 200. So Capturing the response from Exception. Exception is - " + e);
				rawHttpResponse = e.getLocalizedMessage();
				clientResponse.setResponse_body(e.getLocalizedMessage());
				e.printStackTrace();
			}

			clientResponse.setStatus_code(String.valueOf(testClient.getStatus().getStatusCode()));
			clientResponse.setStatus_phrase(testClient.getStatus().getReasonPhrase());
			clientResponse.setResponse_time(String.valueOf(testClient.getElapsedMillis()) + " ms");
			clientResponse.setResponse_headers(testClient.getResponseHeaders().toString());

			log.info("Response Details: ");
			log.info("Status Code: " + testClient.getStatus().getStatusCode());
			log.info("Status Phrase: " + testClient.getStatus().getReasonPhrase());
			log.info("Response Time: " + String.valueOf(testClient.getElapsedMillis()) + " ms");
			log.info("Response Headers: " + String.valueOf(testClient.getResponseHeaders().toString()));
			log.info("Response Body: " + rawHttpResponse);

		} catch (Exception e) {
			Report.error("Exception occured while Submitting PUT Request. Exception is : " + e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
		return clientResponse;
	}

	public HttpClientResponse doGenericDelete(String url, Map<String, String> headersMap, Object payload) throws Exception {
		HttpClientResponse clientResponse = new HttpClientResponse();
		String rawHttpResponse = null;
		log.info("Submitting HTTP Action : DELETE");
		try {
			EntityRestClient<String> testClient = (EntityRestClient<String>) PayPalRestClientFactory.createEntityClient(String.class, new URL(url),
					MediaType.APPLICATION_JSON);
			testClient.addHeaders(headersMap);

			try {
				if (payload == null) {
					rawHttpResponse = testClient.simpleDelete();
				} else {
					if (!payload.toString().trim().equals("")) {
						Report.error("HTTP DELETE with Payload is not supported by Client.");
						// rawHttpResponse = testClient.simpleDelete(payload.toString());
					} else {
						rawHttpResponse = testClient.simpleDelete();
					}
				}
				log.info("Raw Response from API : " + rawHttpResponse);
				clientResponse.setResponse_body(rawHttpResponse);
			} catch (javax.ws.rs.WebApplicationException e) {
				log.info("Response Code for the Request is not 200. So Capturing the response from Exception. Exception is - " + e);
				rawHttpResponse = e.getLocalizedMessage();
				clientResponse.setResponse_body(rawHttpResponse);
				e.printStackTrace();
			}

			clientResponse.setStatus_code(String.valueOf(testClient.getStatus().getStatusCode()));
			clientResponse.setStatus_phrase(testClient.getStatus().getReasonPhrase());
			clientResponse.setResponse_time(String.valueOf(testClient.getElapsedMillis()) + " ms");
			clientResponse.setResponse_headers(testClient.getResponseHeaders().toString());

			log.info("Response Details: ");
			log.info("Status Code: " + testClient.getStatus().getStatusCode());
			log.info("Status Phrase: " + testClient.getStatus().getReasonPhrase());
			log.info("Response Time: " + String.valueOf(testClient.getElapsedMillis()) + " ms");
			log.info("Response Headers: " + String.valueOf(testClient.getResponseHeaders().toString()));
			log.info("Response Body: " + rawHttpResponse);

		} catch (Exception e) {
			Report.error("Exception occured while Submitting DELETE Request. Exception is : " + e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
		return clientResponse;
	}

	public static void main(String[] args) {
		try {
//			HttpRestClient obj = new HttpRestClient();
//			Map<String, String> headerMap = new HashMap<String, String>();
//			headerMap.put("X-PAYPAL-SECURITY-CONTEXT",
//					"{\"actor\":{\"account_number\":\"1932269773897062195\",\"party_id\":\"1932269773897062195\",\"auth_claims\":[\"REFRESH_TOKEN\"],\"auth_state\":\"REMEMBERED\",\"user_type\":\"API_CALLER\"},\"app_id\":\"RZC\",\"auth_token\":\"A015vFaW.3TUVf2bqMRAkjLEGemr0xXNCuKRgniehnWZBiQ\",\"auth_token_type\":\"ACCESS_TOKEN\",\"global_session_id\":\"TF6ItL3zbHS1uPN8A3yX4I2lQ2-efW\",\"last_validated\":1412889075,\"scopes\":[\"https://uri.paypal.com/services/identity/activities\",\"*\"],\"subjects\":[{\"subject\":{\"account_number\":\"1932269773897062195\",\"party_id\":\"1932269773897062195\",\"user_type\":\"CONSUMER\",\"auth_claims\":[\"PASSWORD\"],\"auth_state\":\"LOGGEDIN\"}}]}");
//			headerMap.put("Accept", "application/json");
//			headerMap.put("Content-Type", "application/json");
//
//			ObjectMapper jsonObjectMapper = new ObjectMapper();
//			JsonNode request = jsonObjectMapper.readTree(new File("src/test/resources/request.json"));

			// JSONObject response = obj.doPost("https://stage2ma152946.qa.paypal.com:11833/v1/risk/resolution-regulation-decision", headerMap,
			// request.toString());
			// JSONArray response = obj.doPostGetArray("https://stage2ma152946.qa.paypal.com:11833/v1/risk/resolution-regulation-decision", headerMap,
			// request.toString());

			// System.out.println("Respons : "+response);
//		} catch (JsonProcessingException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
