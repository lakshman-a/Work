package com.core.automation.tests;

import java.util.List;

import org.testng.TestNG;
import org.testng.collections.Lists;

public class SampleTestNgTrigger {

	public static void main(String[] args) {
		
		TestNG runner = new TestNG();
		List<String> suites = Lists.newArrayList();
		//suites.add("C:Project\\LEARNING\\Rule-Process-Tool\\rule-process-tool\\rest-api\\spring-boot\\hybrid-automation\\TestNGXmls\\TestNg_1234566789_layyakannu.xml");
		runner.setTestSuites(suites);
		runner.run();
		
	}
	
}
