import { TestBed, inject } from '@angular/core/testing';

import { HttpTemplateService } from './http-template.service';

describe('HttpTemplateService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HttpTemplateService]
    });
  });

  it('should be created', inject([HttpTemplateService], (service: HttpTemplateService) => {
    expect(service).toBeTruthy();
  }));
});
