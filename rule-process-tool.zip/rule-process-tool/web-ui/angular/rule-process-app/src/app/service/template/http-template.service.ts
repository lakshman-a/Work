
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable({
  providedIn: 'root'
})
export class HttpTemplateService {
  //private _url: string = AppConfig.API_HOST + AppConfig.API_MODULE_MAINMODULE;

  constructor(private http: HttpClient) {

  }

  getHeaders() {
    let httpHeaders = new HttpHeaders({
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authorization': 'ADdSDHhbkHBKHBZCCYVYHKBS'
    });
    return httpHeaders;
  }

  getCall(url: string) {
    return this.http
      .get(url)
      .catch(this.errorHandler);
  }

  postCall(url: string, payload) {
    let httpHeaders = this.getHeaders();
    let options = {
      headers: httpHeaders
    };
    return this.http
      .post(url, payload, options)
      .catch(this.errorHandler);
  }

  postUploadCall(url: string, payload) {
    return this.http
      .post(url, payload)
      .catch(this.errorHandler);
  }

  postUploadCallWithParams(url: string, payload, param) {

    return this.http
      .post(url, payload, { params: param })
      .catch(this.errorHandler);
  }

  errorHandler(error: HttpErrorResponse) {
    return Observable.throw(error || "Server Error");
  }

  postCallWithHeaders(url: string, payload) {
    let httpHeaders = this.getHeaders();
    let options = {
      headers: httpHeaders
    };
    return this.http
      .post(url, payload, options)
      .catch(this.errorHandler);
  }

  putCallWithHeaders(url: string, payload) {
    let httpHeaders = this.getHeaders();
    let options = {
      headers: httpHeaders
    };
    return this.http
      .put(url, payload, options)
      .catch(this.errorHandler);
  }

  deleteCallWithHeaders(url: string, payload) {
    let httpHeaders = this.getHeaders();
    let options = {
      headers: httpHeaders,
      body: payload
    };
    return this.http
      .delete(url, options)
      .catch(this.errorHandler);
  }

  getCallWithHeaders(url: string) {
    let httpHeaders = this.getHeaders();
    let options = {
      headers: httpHeaders
    };
    return this.http
      .get(url, options)
      .catch(this.errorHandler);
  }

  getCallWithHeadersParams(url: string,param) {
    let httpHeaders = this.getHeaders();
    let options = {
      headers: httpHeaders,
      params: param
    };
    return this.http
      .get(url, options)
      .catch(this.errorHandler);
  }

}
