import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckpointsEditModalComponent } from './checkpoints-edit-modal.component';

describe('CheckpointsEditModalComponent', () => {
  let component: CheckpointsEditModalComponent;
  let fixture: ComponentFixture<CheckpointsEditModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckpointsEditModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckpointsEditModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
