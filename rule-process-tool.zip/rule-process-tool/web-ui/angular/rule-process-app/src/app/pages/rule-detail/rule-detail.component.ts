import { HttpParams } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { RuleViewModalComponent } from './rule-view-modal/rule-view-modal.component';
import { RuleDeleteModalComponent } from './rule-delete-modal/rule-delete-modal.component';
import { AppConfig } from './../../app-config.service';
import { HttpTemplateService } from './../../service/template/http-template.service';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { Component, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription } from 'rxjs';
import { RuleEditModalComponent } from './rule-edit-modal/rule-edit-modal.component';

export interface RuleData {
  id: string;
  rule_id: string;
  rule_name: string;
  rule_desc?: string;
  component: string;
  checkpoint: string;
  rule: string;
  rule_path: string;
  active: string;
  created_tmstmp: string;
  created_by: string;
  updated_tmstmp: string;
  updated_by: string;
}

@Component({
  selector: 'app-rule-detail',
  templateUrl: './rule-detail.component.html',
  styleUrls: ['./rule-detail.component.css'],
})
export class RuleDetailComponent {
  _projectName = "Default";
  _componentListApiresponse = null;
  _componentList: string[];
  _checkpointList: string[];

  constructor(private http: HttpTemplateService, private toastr: ToastrService, public dialog: MatDialog) { }

  //MAT:
  displayedColumns: string[] = ['id', 'rule_id', 'rule_name', 'component', 'checkpoint', 'rule_path', 'created_by', 'active', 'action'];
  dataSource: MatTableDataSource<RuleData>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  ngOnInit() {
    //Component Details List
    let params = new HttpParams().set('projectName', this._projectName);
    let subs2: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_API_COMPONENTS_LIST, params).subscribe(response => {
      subs2.unsubscribe;
      let result: any = response;
      this._componentListApiresponse = result;
      this._componentList = result.map(eachItem => eachItem.component);
    }, error => {
      this.notify('error', 'Component Details', 'Error occured while Loadings Rules : ' + error.message);
    });

    //MAT TABLE GRID Data Load:
    let subs: Subscription = this.http.getCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_GET_API_RULE_DETAILS_LIST).subscribe(response => {
      subs.unsubscribe;
      let result: any = response;
      this.dataSource = new MatTableDataSource(result);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;

    }, error => {
      this.notify('error', 'Rule Details', 'Error occured while Loadings Rules : ' + error.message);
    });

  }

  onComponentChange(component: any) {
    this._checkpointList = this._componentListApiresponse.filter(eachItem => eachItem.component === component)[0].checkpoints;
    this._ngNewRuleCheckpoint = null;
  }

  _ngRuleGridApiCallInProgress=null;
  ruleGridRefreshCall() {
    this._ngRuleGridApiCallInProgress=true;
    let subs: Subscription = this.http.getCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_GET_API_RULE_DETAILS_LIST).subscribe(response => {
      subs.unsubscribe;
      this._ngRuleGridApiCallInProgress=false;
      let result: any = response;
      this.dataSource = new MatTableDataSource(result);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this._ngRuleGridApiCallInProgress=false;
      this.notify('error', 'Rule Details', 'Error occured while Refreshing Rule List : ' + error.message);
    });
  }

  //MAT:
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  //ADD RULE
  _ngNewRuleID = null;
  _ngNewRuleName = null;
  _ngNewRuleComponent = null;
  _ngNewRuleCheckpoint = null;
  _ngNewRuleDesc = null;
  _ngNewRule = null;
  _ngNewRulePath = null;
  _ngNewRuleAddInProgress = null;

  onNewRuleSubmit() {
    let newRuleBody: any = {
      rule_id: this._ngNewRuleID,
      rule_name: this._ngNewRuleName,
      component: this._ngNewRuleComponent,
      checkpoint: this._ngNewRuleCheckpoint,
      rule_desc: this._ngNewRuleDesc,
      rule: this._ngNewRule,
      rule_path: this._ngNewRulePath,
      active: "true",
      created_by: "layyakannu",
      updated_by: "layyakannu"
    }

    this._ngNewRuleAddInProgress = true;
    let subs2: Subscription = this.http.postCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_GET_API_RULE_DETAIL_MODIFY, newRuleBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      this._ngNewRuleAddInProgress = false;
      if (result.status && result.status == "success") {
        this.onNewRuleFormReset();
        this.ruleGridRefreshCall();
        this.notify('success', 'Rule Add', 'Rule Added Successfully');
      } else
        this.notify('error', 'Rule Add', 'Rule Add Failed : ' + result.reason);
    },
      error => {
        this._ngNewRuleAddInProgress = false;
        this.notify('error', 'Rule Add', 'Rule Add Failed : ' + error.message);
      });
  }

  onNewRuleFormReset() {
    this._ngNewRuleID = null;
    this._ngNewRuleName = null;
    this._ngNewRuleComponent = null;
    this._ngNewRuleCheckpoint = null;
    this._ngNewRuleDesc = null;
    this._ngNewRule = null;
    this._ngNewRulePath = null;
    this._ngNewRuleAddInProgress = null;
  }

  //EDIT MODAL FEATURE
  openEditDialog(row): void {
    const dialogRef = this.dialog.open(RuleEditModalComponent, {
      width: '850px',
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      console.log("edit modal Dialogs closed!");
      if (result == 'success') {
        console.log("Result is success so refresing grif!");
        this.ruleGridRefreshCall();
      }
    });
  }

  //DELETE MODAL FEATURE
  openDeleteDialog(row): void {
    const dialogRef2 = this.dialog.open(RuleDeleteModalComponent, {
      width: '600px',
      data: row
    });

    dialogRef2.afterClosed().subscribe(result => {
      console.log(result);
      console.log("delete modal Dialogs closed!");
      if (result == 'success') {
        console.log("Result is success so refresing grif!");
        this.ruleGridRefreshCall();
      }
    });
  }

  //View MODAL FEATURE
  openViewDialog(row): void {
    const dialogRef3 = this.dialog.open(RuleViewModalComponent, {
      width: '800px',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
      if (result) {
      }
    });
  }



  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 6000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }



}

