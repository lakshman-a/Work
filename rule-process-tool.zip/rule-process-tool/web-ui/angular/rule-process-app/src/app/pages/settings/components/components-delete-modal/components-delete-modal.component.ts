import { Component, Inject } from '@angular/core';
import { AppConfig } from './../../../../app-config.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpTemplateService } from './../../../../service/template/http-template.service';

import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-components-delete-modal',
  templateUrl: './components-delete-modal.component.html',
  styleUrls: ['./components-delete-modal.component.css']
})
export class ComponentsDeleteModalComponent {

  constructor(
    public dialogRef: MatDialogRef<ComponentsDeleteModalComponent>, private http: HttpTemplateService, private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  _isActionInProgress = null;
  onDeleteClick(data) {
    let deleteSubmitBody: any = {
      component_name: data['component_name'],
      project_name: data['project_name'],
      updated_by: "layyakannu"
    }
    this._isActionInProgress = true;
    let subs2: Subscription = this.http.deleteCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_COMPONENT_UPDATE, deleteSubmitBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      this._isActionInProgress = false;
      if (result.status && result.status == "success") {
        this.notify('success', 'Component Delete', 'Success');
        this.dialogRef.close("success");
      } else
        this.notify('error', 'Component Delete', 'Failed : ' + result.reason);
    },
      error => {
        this._isActionInProgress = false;
        this.notify('error', 'Component Delete', 'Failed : ' + error.message);
      });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 5000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
