import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RuleViewModalComponent } from './rule-view-modal.component';

describe('RuleViewModalComponent', () => {
  let component: RuleViewModalComponent;
  let fixture: ComponentFixture<RuleViewModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RuleViewModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleViewModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
