import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';


@Component({
  selector: 'app-rule-view-modal',
  templateUrl: './rule-view-modal.component.html',
  styleUrls: ['./rule-view-modal.component.css']
})
export class RuleViewModalComponent {

  _ngViewRule = null;

  constructor(
    public dialogRef: MatDialogRef<RuleViewModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this._ngViewRule = data['rule'];
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
