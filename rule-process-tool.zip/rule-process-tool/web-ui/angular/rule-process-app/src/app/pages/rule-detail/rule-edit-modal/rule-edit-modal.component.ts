import { HttpParams } from '@angular/common/http';
import { Component, Inject } from '@angular/core';
import { AppConfig } from './../../../app-config.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpTemplateService } from './../../../service/template/http-template.service';

import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-rule-edit-modal',
  templateUrl: './rule-edit-modal.component.html',
  styleUrls: ['./rule-edit-modal.component.css']
})
export class RuleEditModalComponent {
  _projectName = "Default";
  _ngEditRuleId = null;
  _ngEditRuleComponent = null;
  _ngEditRuleName = null;
  _ngEditRuleCheckpoint = null;
  _ngEditRuleDesc = null;
  _ngEditRule = null;
  _ngEditRulePath = null;
  _componentList = null;
  _checkpointList = null;
  _apiData = null;
  _ngEditRuleActive = null;
  _componentListApiresponse

  constructor(
    public dialogRef: MatDialogRef<RuleEditModalComponent>, private http: HttpTemplateService, private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.apiCallForComponentListLoad(data);
    this._apiData = data;
    this._ngEditRuleId = data['rule_id'];
    this._ngEditRuleName = data['rule_name'];
    this._ngEditRuleComponent = data['component'];
    this._ngEditRuleCheckpoint = data['checkpoint'];
    this._ngEditRuleDesc = data['rule_desc'];
    this._ngEditRule = data['rule'];
    this._ngEditRulePath = data['rule_path'];
    if (data['active'] == 'true') {
      this._ngEditRuleActive = true;
    } else if (data['active'] == 'false') {
      this._ngEditRuleActive = false;
    }
  }

  _ngCompListLoadInProgress = null
  apiCallForComponentListLoad(data) {
    this._ngCompListLoadInProgress = true;
    let params = new HttpParams().set('projectName', this._projectName);
    let subs2: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_API_COMPONENTS_LIST, params).subscribe(response => {
      subs2.unsubscribe;
      this._ngCompListLoadInProgress = false
      let result: any = response;
      this._componentListApiresponse = result;
      this._componentList = result.map(eachItem => eachItem.component);
      this._checkpointList = this._componentListApiresponse.filter(eachItem => eachItem.component === data['component'])[0]['checkpoints'];
    }, error => {
      this._ngCompListLoadInProgress = false
      this.notify('error', 'Component Details', 'Error occured while Loadings Rules : ' + error.message);
    });
  }

  onComponentChange(component: any) {
    this._checkpointList = this._componentListApiresponse.filter(eachItem => eachItem.component === component)[0].checkpoints;
    this._ngEditRuleCheckpoint = null;
  }

  _isActionInProgress = null;
  onUpdateClick(data) {
    let editRuleBody: any = {
      rule_id: this._ngEditRuleId,
      rule_name: this._ngEditRuleName,
      component: this._ngEditRuleComponent,
      checkpoint: this._ngEditRuleCheckpoint,
      rule_desc: this._ngEditRuleDesc,
      rule: this._ngEditRule,
      rule_path: this._ngEditRulePath,
      active: this._ngEditRuleActive,
      updated_by: "layyakannu"
    }
    console.log(editRuleBody);
    this._isActionInProgress = true;
    let subs2: Subscription = this.http.putCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_GET_API_RULE_DETAIL_MODIFY, editRuleBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      this._isActionInProgress = false;
      if (result.status && result.status == "success") {
        this.notify('success', 'Rule Edit', 'Rule Edited Successfully');
        this.dialogRef.close("success");
      } else
        this.notify('error', 'Rule Edit', 'Rule Edit Failed : ' + result.reason);
    },
      error => {
        this._isActionInProgress = false;
        this.notify('error', 'Rule Edit', 'Rule Edit Failed : ' + error.message);
      });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 5000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
