import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SetupDcComponent } from './setup-dc.component';

describe('SetupDcComponent', () => {
  let component: SetupDcComponent;
  let fixture: ComponentFixture<SetupDcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SetupDcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SetupDcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
