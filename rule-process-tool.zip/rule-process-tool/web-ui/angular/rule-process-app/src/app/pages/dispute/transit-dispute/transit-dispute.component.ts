import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transit-dispute',
  templateUrl: './transit-dispute.component.html',
  styleUrls: ['./transit-dispute.component.css']
})
export class TransitDisputeComponent implements OnInit {

  _isUserCreationChecked=false;
  _claimType="INTERNAL";
  _disputeReason="";
  _stageName="msmaster.qa.paypal.com";

  _searchedCaseId="PP-000-023-175-357";
  constructor() {}

  ngOnInit() {
  }

}
