import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransitDisputeComponent } from './transit-dispute.component';

describe('TransitDisputeComponent', () => {
  let component: TransitDisputeComponent;
  let fixture: ComponentFixture<TransitDisputeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransitDisputeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransitDisputeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
