import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rule-jar-extract',
  templateUrl: './rule-jar-extract.component.html',
  styleUrls: ['./rule-jar-extract.component.css']
})
export class RuleJarExtractComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
