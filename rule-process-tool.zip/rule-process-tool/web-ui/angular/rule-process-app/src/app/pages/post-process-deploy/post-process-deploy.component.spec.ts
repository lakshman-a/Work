import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PostProcessDeployComponent } from './post-process-deploy.component';

describe('PostProcessDeployComponent', () => {
  let component: PostProcessDeployComponent;
  let fixture: ComponentFixture<PostProcessDeployComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PostProcessDeployComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PostProcessDeployComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
