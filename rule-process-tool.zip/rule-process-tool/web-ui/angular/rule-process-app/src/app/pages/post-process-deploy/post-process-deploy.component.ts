import { AppConfig } from './../../app-config.service';
import { HttpTemplateService } from './../../service/template/http-template.service';

import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Subscription } from 'rxjs';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormControl, Validators } from '@angular/forms';
import { HttpParams } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

export interface PostProcessRequest {
  ruleJar: string;
  plutoDCVersion: string;
  rboVersion: string
}

export interface StageConnectRequest {
  stage: string;
  username: string;
  password: string;
  postProcessedJarName: any
  loggerLevel: any;
  fileBased: any;
  action: any;
}

@Component({
  selector: 'app-post-process-deploy',
  templateUrl: './post-process-deploy.component.html',
  styleUrls: ['./post-process-deploy.component.css']
})

export class PostProcessDeployComponent implements OnInit {

  //_componentsList: string[] = ['riskresolutiondecisionserv', 'riskdecisionplanningserv', 'disputeapiserv'];
  _componentsList: string[] = ['riskresolutiondecisionserv'];
  _componentsListControl = new FormControl('', [Validators.required]);
  _selectedComponentName: string = "riskresolutiondecisionserv";

  @ViewChild('fileInputBox')
  myInputVariable: ElementRef;

  @ViewChild('RbofileInputBox')
  myRboInputVariable: ElementRef;

  _selectedRuleJarFile = null;
  _ngRuleJarName = "RULE_JAR_";
  _ngRuleJarDesc = null;
  _isJarUploading = null;
  _jarUploadResultPhrase = null;
  _jarUploadResult = null;
  _enableUploadButton = false;
  _uploadedRuleJarName = null;
  _triggerId;

  _plutoDCRboListResponseList: any;
  _plutoDCList: any[];
  _rboVersionList: any[];
  _postProcessedResponseList: any;
  _postProcessedJarList: any;
  isSiglePageModeChecked: true;

  constructor(private http: HttpTemplateService, private spinner: NgxSpinnerService, private toastr: ToastrService) {
    //Get the Unique ID
    this._triggerId = new Date().valueOf();

    //Populate the PlutoDC List
    let subs: Subscription = this.http.getCall(AppConfig.API_HOST + AppConfig.API_PLUTO_DC_LIST).subscribe(response => {
      subs.unsubscribe;
      this._plutoDCRboListResponseList = response;
      this._plutoDCList = this._plutoDCRboListResponseList.map(eachItem => eachItem.name);
      this._plutoDCAndRboListPopulateFailed = false;
    }, error => {
      this._plutoDCAndRboListPopulateFailed = true;
      this.notify('error', 'Pluto-DC Version', 'List Failed to Load : ' + error.message);
    });

    //Populate the Post Processed Jar List
    let subs2: Subscription = this.http.getCall(AppConfig.API_HOST + AppConfig.API_POST_PROCESSED_JAR_LIST).subscribe(response => {
      subs2.unsubscribe;
      this._postProcessedResponseList = response;
      this._postProcessedJarList = this._postProcessedResponseList.map(eachItem => eachItem.name);
    }, error => {
      if (error.status == 0) { }
      else { this.notify('error', 'Post processed Jar', 'List Failed to Load : ' + error.message); }

    });

  }

  ngOnInit() { }

  //Upload Rule JAR Choosed
  onFileSelected(event) {
    this._selectedRuleJarFile = event.target.files[0];
    this._enableUploadButton = true;
  }

  //On Rule JAR upload Button Click
  onRuleJarUploadButtonClick() {
    this._isJarUploading = true;

    //Post body with only file as Input
    let body = new FormData();
    body.append("file", this._selectedRuleJarFile);

    let subs: Subscription = this.http.postUploadCall(AppConfig.API_HOST + AppConfig.API_UPLOAD_RULE_JAR, body).subscribe(response => {
      subs.unsubscribe();
      this._isJarUploading = false;
      if (response['fileName'] && response['fileName'] != "") {
        this._jarUploadResult = true;
        this._uploadedRuleJarName = this._selectedRuleJarFile.name;
        //this.myInputVariable.nativeElement.value = "";
        this._enableUploadButton = false;

        this.notify('success', 'Rule Jar Upload', 'Success');
        this.apiCallForRuleJarUpload("success", response['errorMsg']);
      } else {
        this._jarUploadResult = false;
        this._jarUploadResultPhrase = "Rule jar - " + this._selectedRuleJarFile.name + " upload failed."
        this.apiCallForRuleJarUpload("fail", response['errorMsg']);
      }
    },
      error => {
        this._isJarUploading = false;
        this._jarUploadResult = false;
        if (error.status == 0) { this._jarUploadResultPhrase = "REST API Services are down. Try again later!"; }
        else { this._jarUploadResultPhrase = error.message; }
        this.apiCallForRuleJarUpload("fail", error.message);
      });

    this._enableUploadButton = false;
  }

  //Rule JAR Request Send to DB:
  apiCallForRuleJarUpload(status: string, logTrace: string) {
    //Build Payload 
    let _ruleJarUploadAPIRequestBody = {
      trigger_id: this._triggerId,
      rule_jar_name: this._ngRuleJarName,
      rule_jar_desc: this._ngRuleJarDesc,
      rule_jar_file_name: this._uploadedRuleJarName,
      rule_jar_location: this._uploadedRuleJarName,
      created_by: "layyakannu",
      status: status,
      log_trace: logTrace
    }
    let subs2: Subscription = this.http.postCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_UPLOAD_RBO_JAR, _ruleJarUploadAPIRequestBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      if (result.status && result.status == "success") {
        //
      } else
        this.notify('error', 'Upload Rule Jar', 'DB Insert Failed : ' + result.reason);
    },
      error => {
        this.notify('error', 'Upload Rule Jar', 'Error : ' + error.message);
      });
  }

  //On Rule JAR RESET Button Click
  uploadRuleJarReset() {
    this._isJarUploading = null;
    this.myInputVariable.nativeElement.value = "";
    this._ngRuleJarName = "RULE_JAR_";
    this._ngRuleJarDesc = "";
    this._jarUploadResult = null;
    this._jarUploadResultPhrase = "";
    this._enableUploadButton = false;
    this._uploadedRuleJarName = null;
  }

  // --------------- CARD 2 Post-Process Pluto DC and RBO -------------------- //

  _plutoDCControl = new FormControl('', [Validators.required]);
  _postProcessedJarControl = new FormControl('', [Validators.required]);
  _rboVersionControl = new FormControl('', [Validators.required]);
  _postProcessRequestBody: PostProcessRequest;
  _selectedRboJarFile = null;
  _enableRboJarUploadButton = false;
  _rboJarUploadResult = null;
  _rboJarUploadResultPhrase = "";
  _rboJaruploadedRuleJarName = null;
  _isRboJarUploading = false;
  _plutoDCAndRboListPopulateFailed = null;
  _ngPlutoDcSelectValue = null;
  _ngRboVersionSelectValue = null;
  _isPlutoDCSelected = false;
  _enablePostProcessButton = false;
  _postProcessButtonClick = null;
  _postProcessServiceResult = null;
  _postProcessServiceResultPhrase = null;
  _postProcessServiceResultStack = null;
  _postProcessingCompleted = null;
  _ppJarExtractAndAddPropFilesResult = null;
  _ngSelectPostProcessedJar = false;
  _postProcessResultJarName = null;

  onPlutoDCVersionSelection() {
    this._isPlutoDCSelected = true;
    this._ngRboVersionSelectValue = "--";
    this._rboVersionList = this._plutoDCRboListResponseList.filter(eachItem => eachItem.name === this._ngPlutoDcSelectValue)[0].rboVersionList;
  }

  onRBOVersionSelection() {
    this._enablePostProcessButton = true;
  }

  //On Choosing the RBO JAR File
  onRboJarFileSelected(event) {
    this._selectedRboJarFile = event.target.files[0];
    this._enableRboJarUploadButton = true;
  }

  onRboJarUpload() {
    this._isRboJarUploading = true;

    //HTTP Payload and URL Params
    let params = new HttpParams().set("plutoDCVersion", this._ngPlutoDcSelectValue);
    let body = new FormData();
    body.append("file", this._selectedRboJarFile);

    let subs: Subscription = this.http.postUploadCallWithParams(AppConfig.API_HOST + AppConfig.API_UPLOAD_RBO_JAR, body, params)
      .subscribe(response => {
        subs.unsubscribe();
        if (response['fileName'] && response['fileName'] != "") {
          this._rboJarUploadResult = true;
          this._rboJaruploadedRuleJarName = this._selectedRboJarFile.name;
          this.myRboInputVariable.nativeElement.value = "";
          this._enableRboJarUploadButton = false;

          //Add the Uploaded RBO to the List:
          this._rboVersionList.push(this._rboJaruploadedRuleJarName);
          this._ngRboVersionSelectValue = this._rboJaruploadedRuleJarName;
          this._enablePostProcessButton = true;
          this.notify('success', 'RBO Jar Upload', 'Success');
        } else {
          this._rboJarUploadResult = false;
          this._rboJarUploadResultPhrase = "Rule jar - " + this._selectedRboJarFile.name + " Upload failed."
        }
      },
        error => {
          this._rboJarUploadResult = false;
          if (error.status == 0) {
            this._rboJarUploadResultPhrase = "REST API Services are down. Try again later!";
          } else {
            this._rboJarUploadResult = false;
            this._rboJarUploadResultPhrase = error.message;
          }
        });
    this._isRboJarUploading = false;
  }

  onPostProcessButtonClick() {
    this._postProcessButtonClick = true;
    this._postProcessingCompleted = false;

    //Paylaod
    this._postProcessRequestBody = {
      ruleJar: this._uploadedRuleJarName,
      plutoDCVersion: this._ngPlutoDcSelectValue,
      rboVersion: this._ngRboVersionSelectValue,
    }

    let subs: Subscription = this.http.postUploadCall(AppConfig.API_HOST + AppConfig.API_DO_POST_PROESS, this._postProcessRequestBody)
      .subscribe(response => {
        subs.unsubscribe();
        let result: any = response;
        this._postProcessingCompleted = true;
        if (result.status && result.status == "success") {
          this._postProcessServiceResult = true;
          this._ppJarExtractAndAddPropFilesResult = true;
          this._postProcessResultJarName = response['key'];

          this.notify('success', 'Post Process', 'Success');
          this.apiDBCallForPostProcessAction("success", response['errorMsg']);
        } else {
          this._postProcessServiceResult = false;
          this.apiDBCallForPostProcessAction("fail", response['errorMsg']);
        }
        this._postProcessServiceResultPhrase = result.message;
        this._postProcessServiceResultStack = result.logTrace;
      },
        error => {
          this._postProcessingCompleted = true;
          this._postProcessServiceResult = false;
          if (error.status == 0) { this._postProcessServiceResultPhrase = "REST API Services are down. Try again later!"; }
          else { this._postProcessServiceResultPhrase = error.message; }
          this.apiDBCallForPostProcessAction("error", error.message);
        });
  }

  //Post Process Ation Request Send to DB:
  apiDBCallForPostProcessAction(status: string, logTrace: string) {
    //Build Payload 
    let _postProcessActionAPIRequestBody = {
      trigger_id: this._triggerId,
      pluto_dc_version: this._ngPlutoDcSelectValue,
      rbo_version: this._ngRboVersionSelectValue,
      rbo_jar_name: this._rboJaruploadedRuleJarName,
      rbo_jar_desc: null,
      rbo_jar_file_name: this._rboJaruploadedRuleJarName,
      rbo_jar_location: null,
      component: this._selectedComponentName,
      created_by: "layyakannu",
      status: status,
      log_trace: logTrace
    }
    let subs2: Subscription = this.http.postCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_POST_PROCESS_ACTION, _postProcessActionAPIRequestBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      if (result.status && result.status == "success") {
      } else
        this.notify('error', 'Post Process', 'DB Insert Failed : ' + result.reason);
    },
      error => {
        this.notify('error', 'Post Process', 'Error : ' + error.message);
      });
  }


  _ngPostProcessedSelectedValue = null;
  _ngIsPostProcessedJarSelected = null;


  onPostProcessCheckboxChange(event) {
    if (event.checked) {
      console.log("Post processed Select jar is checked");
    }
  }

  onPostProcessJarSelectProceed() {
    this._ngIsPostProcessedJarSelected = true;
    this._ppJarExtractAndAddPropFilesResult = true;
    this._postProcessServiceResult = true;
    this._postProcessResultJarName = this._ngPostProcessedSelectedValue;
  }

  onSelectPostProcessedJarReset() {
    this._ngPostProcessedSelectedValue = "";
    this._ngIsPostProcessedJarSelected = null;
    this._ppJarExtractAndAddPropFilesResult = null;
    this._postProcessServiceResult = null;
  }

  onPlutoAndRboReset() {
    // this._plutoDCAndRboListPopulateFailed=null;
    this._ngPlutoDcSelectValue = "--";
    this._ngRboVersionSelectValue = "--";
    this._isPlutoDCSelected = false;
    this._enablePostProcessButton = false;
    this._postProcessButtonClick = false;
    this._postProcessServiceResult = null;
    this._postProcessingCompleted = null;
    this._ppJarExtractAndAddPropFilesResult = null;

    if(!this.isSiglePageModeChecked){
      this.myRboInputVariable.nativeElement.value = "";
    }

    this._rboJarUploadResult = null;
    this._rboJarUploadResultPhrase = "";
    this._enableRboJarUploadButton = false;
    this._rboJaruploadedRuleJarName = null;
    this._postProcessResultJarName = null;

    let subs: Subscription = this.http.getCall(AppConfig.API_HOST + AppConfig.API_PLUTO_DC_LIST).subscribe(response => {
      this._plutoDCRboListResponseList = response;
      this._plutoDCList = this._plutoDCRboListResponseList.map(eachItem => eachItem.name);
      this._plutoDCAndRboListPopulateFailed = false;
      subs.unsubscribe;
    }, error => {
      this.notify('error', 'Pluto-DC Version', 'List Load Failed : ' + error.message);
      this._plutoDCAndRboListPopulateFailed = true;
    });

  }

  //------------------- CARD 3 STAGE DETAILS -------------------//
  _ngStageName = null;
  _ngUserName = null;
  _ngPassword = null;
  _checkConnToLinuxServiceCallComplete = null;
  _checkConnToLinuxServiceCallResult = null;
  _checkConnToLinuxServiceCallResultPhrase = null;

  _moveJarToLinuxServiceCallComplete = null;
  _moveJarToLinuxServiceCallResult = null;
  _moveJarToLinuxServiceCallResultPhrase = null;
  _stageConnectionPayload: StageConnectRequest;
  _copyRRDSFolderPayload: StageConnectRequest;

  onCheckConnectionClick() {
    this._checkConnToLinuxServiceCallResultPhrase = null;
    this._checkConnToLinuxServiceCallComplete = null;

    //Payload
    this._stageConnectionPayload = {
      stage: this._ngStageName,
      username: this._ngUserName,
      password: btoa(this._ngPassword),
      postProcessedJarName: this._postProcessResultJarName,
      loggerLevel: null,
      fileBased: null,
      action: null
    }

    this._checkConnToLinuxServiceCallComplete = false;
    let subs: Subscription = this.http.postUploadCall(AppConfig.API_HOST + AppConfig.API_DO_POST_CHECK_CONN, this._stageConnectionPayload)
      .subscribe(response => {
        subs.unsubscribe();
        let result: any = response;
        this._checkConnToLinuxServiceCallComplete = true;
        if (result.status && result.status == "success") {
          this._checkConnToLinuxServiceCallResult = true;
          this.notify('success', 'User Stage Connection', 'Success');
        } else {
          this._checkConnToLinuxServiceCallResult = false;
          this.notify('error', 'User Stage Connection', 'Failed : ' + result.message);
        }
        this._checkConnToLinuxServiceCallResultPhrase = result.message;
      },
        error => {
          this._checkConnToLinuxServiceCallComplete = true;
          this._checkConnToLinuxServiceCallResult = false;
          this._checkConnToLinuxServiceCallResultPhrase = error.message;
          this.notify('error', 'User Stage Connection', 'Failed : ' + error.message);
        });
  }

  OnMoveComponentFolderButtonClick() {
    this._checkConnToLinuxServiceCallResultPhrase = null;
    this._moveJarToLinuxServiceCallResultPhrase = null;
    this._moveJarToLinuxServiceCallComplete = null;

    //Payload
    this._copyRRDSFolderPayload = {
      stage: this._ngStageName,
      username: this._ngUserName,
      password: btoa(this._ngPassword),
      postProcessedJarName: this._postProcessResultJarName,
      loggerLevel: null,
      fileBased: null,
      action: null
    }
    //Verify Connection Params
    this.onCheckConnectionClick();
    this._moveJarToLinuxServiceCallComplete = false;

    let subs: Subscription = this.http.postUploadCall(AppConfig.API_HOST + AppConfig.API_DO_POST_COPY_TO_STAGE, this._copyRRDSFolderPayload)
      .subscribe(response => {
        subs.unsubscribe();
        let result: any = response;
        this._moveJarToLinuxServiceCallComplete = true;
        if (result.status && result.status == "success") {
          this._moveJarToLinuxServiceCallResult = true;
          this.apiDBCallForStageProcess("success", response['errorMsg']);
          this.notify('success', 'Copy Component to Stage', 'Success');
          //Adding below line new - Directky move Comp and Staart the Service
          this.onRestartComponentClick();
        } else {
          this._moveJarToLinuxServiceCallResult = false;
          this._moveJarToLinuxServiceCallResultPhrase = result.message;
          this.apiDBCallForStageProcess("fail", response['errorMsg']);
          this.notify('error', 'Copy Component to Stage', 'Failure : ' + result.message);
        }
      },
        error => {
          this._moveJarToLinuxServiceCallComplete = true;
          this._moveJarToLinuxServiceCallResult = false;
          this._moveJarToLinuxServiceCallResultPhrase = error.message;
          this.apiDBCallForStageProcess("error", error.message);
          this.notify('error', 'Copy Component to Stage', 'Error : ' + error.message);
        });
  }

  //Post Process Ation Request Send to DB:
  apiDBCallForStageProcess(status: string, logTrace: string) {
    //Build Payload 
    let _stageProcessAPIRequestBody = {
      trigger_id: this._triggerId,
      stage_name: this._ngStageName,
      stage_username: this._ngUserName,
      is_check_conn: "true",
      is_move_folder: "true",
      component: this._selectedComponentName,
      created_by: "layyakannu",
      status: status,
      log_trace: logTrace
    }
    let subs2: Subscription = this.http.postCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_STAGE_PROCESS, _stageProcessAPIRequestBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      if (result.status && result.status == "success") {
      } else
        this.notify('error', 'Copy Component to Stage', 'DB Insert Failed : ' + result.reason);
    },
      error => {
        this.notify('error', 'Copy Component to Stage', 'Error : ' + error.message);
      });
  }

  OnStageDetailsClearClick() {
    this._ngStageName = null;
    this._ngUserName = null;
    this._ngPassword = null;
    this._checkConnToLinuxServiceCallComplete = null;
    this._checkConnToLinuxServiceCallResult = null;
    this._moveJarToLinuxServiceCallComplete = null;
    this._moveJarToLinuxServiceCallResult = null;

    //RRDS Restart RESET
    this._ngLoggerLevelSelectValue = "FINE";
    this._ngFileBasedSelectValue = "TRUE";
    this._propertyFileSettingsCallComplete = null;
    this._propertyFileSettingsCallResult = null;
    this._rrdsStartCallResultPhrase = null;
    this._propertyFileSettingsCallResultPhrase = null;
    this._rrdsShutDownCallResultPhrase = null;
    this._rrdsShutDownCallComplete = null;
    this._rrdsShutDownCallResult = null;
    this._rrdsStartCallComplete = null;
    this._rrdsStartCallResult = null;
  }

  // --------------- CARD 4 Select STAGE Properties -------------------- //
  _loggerLevelList: any[] = ["FINE", "INFO", "SEVERE"]
  _fileBasedList: any[] = ["TRUE", "FALSE"]
  _loggerLevelControl = new FormControl('', [Validators.required]);
  _fileBasedControl = new FormControl('', [Validators.required]);
  _ngLoggerLevelSelectValue = "FINE";
  _ngFileBasedSelectValue = "TRUE";

  _propertyFileSettingsCallComplete = null;
  _propertyFileSettingsCallResult = null;
  _propertyFileSettingsCallResultPhrase = null;

  _rrdsShutDownCallComplete = null;
  _rrdsShutDownCallResult = null;
  _rrdsShutDownCallResultPhrase = null;

  _rrdsStartCallComplete = null;
  _rrdsStartCallResult = null;
  _rrdsStartCallResultPhrase = null;


  _stagePropChangeRequest: StageConnectRequest;
  _stageShutdownRequest: StageConnectRequest;
  _stageStartRequest: StageConnectRequest;

  onRestartComponentClick() {

    this._propertyFileSettingsCallResultPhrase = null;
    this._rrdsShutDownCallResultPhrase = null;
    this._rrdsStartCallResultPhrase = null;

    //PROPERTY CHANGE
    this._stagePropChangeRequest = {
      stage: this._ngStageName,
      username: this._ngUserName,
      password: btoa(this._ngPassword),
      postProcessedJarName: null,
      loggerLevel: this._ngLoggerLevelSelectValue,
      fileBased: this._ngFileBasedSelectValue,
      action: null
    }
    //Verify Connection Params
    this.onCheckConnectionClick();

    this._propertyFileSettingsCallComplete = false;
    let subs: Subscription = this.http.postUploadCall(AppConfig.API_HOST + AppConfig.API_DO_RRDS_PROP_CHANGE, this._stagePropChangeRequest)
      .subscribe(response => {
        subs.unsubscribe();
        let result: any = response;
        this._propertyFileSettingsCallComplete = true;
        if (result.status && result.status == "success") {
          this._propertyFileSettingsCallResult = true;

          //Call to Stop Service
          this.apiCallForStopService();
          this.notify('success', 'Component Property Change', 'Success');
        } else {
          this._propertyFileSettingsCallResult = false;
          this._propertyFileSettingsCallResultPhrase = result.message;
          this.apiDBCallForStageSetting('fail', result.message)
          this.notify('error', 'Component Property Change', 'Failure : ' + result.message);
        }
      },
        error => {
          this._propertyFileSettingsCallComplete = true;
          this._propertyFileSettingsCallResult = false;
          this._propertyFileSettingsCallResultPhrase = error.message;
          this.apiDBCallForStageSetting('fail', error.message)
          this.notify('error', 'Component Property Change', 'Error : ' + error.message);
        });
  }

  //STOP SERVICE
  apiCallForStopService() {
    //Payload
    this._stageShutdownRequest = {
      stage: this._ngStageName,
      username: this._ngUserName,
      password: btoa(this._ngPassword),
      postProcessedJarName: null,
      loggerLevel: null,
      fileBased: null,
      action: "stop"
    }

    //Request
    this._rrdsShutDownCallComplete = false;
    let subs2: Subscription = this.http.postUploadCall(AppConfig.API_HOST + AppConfig.API_DO_STARTSTOP_SERVICE, this._stageShutdownRequest)
      .subscribe(response => {
        subs2.unsubscribe();
        let result: any = response;
        this._rrdsShutDownCallComplete = true;
        if (result.status && result.status == "success") {
          this._rrdsShutDownCallResult = true;
          this.notify('success', 'Component Shutdown', 'Success');

          //API Call to start Service:
          this.apiCallForStartService();
        } else {
          this._rrdsShutDownCallResult = false;
          this._rrdsShutDownCallResultPhrase = result.message;
          this.apiDBCallForStageSetting('fail', result.message)
          this.notify('error', 'Component Shutdown', 'Faiure : ' + result.message);
        }
      },
        error => {
          this._rrdsShutDownCallComplete = true;
          this._rrdsShutDownCallResult = false;
          this._rrdsShutDownCallResultPhrase = error.message;
          this.apiDBCallForStageSetting('fail', error.message)
          this.notify('error', 'Component Shutdown', 'Error : ' + error.message);
        });
  }

  //START SERVICE
  apiCallForStartService() {
    //Payload
    this._stageStartRequest = {
      stage: this._ngStageName,
      username: this._ngUserName,
      password: btoa(this._ngPassword),
      postProcessedJarName: null,
      loggerLevel: null,
      fileBased: null,
      action: "start"
    }

    //Request
    this._rrdsStartCallComplete = false;
    let subs3: Subscription = this.http.postUploadCall(AppConfig.API_HOST + AppConfig.API_DO_STARTSTOP_SERVICE, this._stageStartRequest)
      .subscribe(response => {
        subs3.unsubscribe();
        let result: any = response;
        this._rrdsStartCallComplete = true;
        if (result.status && result.status == "success") {
          this._rrdsStartCallResult = true;
          this.apiDBCallForStageSetting('success', result.message)
          this.notify('success', 'Component Start', 'Success');

          if (this.isSiglePageModeChecked) {
            this._singleGoProcessInProgress = false;
            this._singleGoProcessResponseResult = true;
            this._singleGoProcessResponseResultPhrase = "Deployement Success";
          }
        } else {
          this._rrdsStartCallResult = false;
          this._rrdsStartCallResultPhrase = result.message;
          this.apiDBCallForStageSetting('fail', result.message);
          this.notify('error', 'Component Start', 'Failiure : ' + result.message);
        }
      },
        error => {
          this._rrdsStartCallComplete = true;
          this._rrdsStartCallResult = false;
          this._rrdsStartCallResultPhrase = error.message;
          this.apiDBCallForStageSetting('fail', error.message);
          this.notify('error', 'Component Start', 'Error : ' + error.message);
        });
  }

  apiDBCallForStageSetting(status: string, logTrace: string) {
    //Build Payload 
    let _stageSettingsAPIRequestBody = {
      trigger_id: this._triggerId,
      logger_level: this._ngLoggerLevelSelectValue,
      file_based_flag: this._ngFileBasedSelectValue,
      component: this._selectedComponentName,
      created_by: "layyakannu",
      status: status,
      log_trace: logTrace
    }
    let subs2: Subscription = this.http.postCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_STAGE_SETTINGS, _stageSettingsAPIRequestBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      if (result.status && result.status == "success") {
      } else
        this.notify('error', 'Component Start', 'DB Insert Failed : ' + result.reason);
    },
      error => {
        this.notify('error', 'Component Start', 'Failed : ' + error.message);
      });
  }

  onRestartRRDSReset() {
    this._ngLoggerLevelSelectValue = "FINE";
    this._ngFileBasedSelectValue = "TRUE";
    this._propertyFileSettingsCallComplete = null;
    this._propertyFileSettingsCallResult = null;
    this._rrdsStartCallResultPhrase = null;
    this._propertyFileSettingsCallResultPhrase = null;
    this._rrdsShutDownCallResultPhrase = null;
    this._rrdsShutDownCallComplete = null;
    this._rrdsShutDownCallResult = null;
    this._rrdsStartCallComplete = null;
    this._rrdsStartCallResult = null;
  }

  //---------------------------- SINGLE GO ----------------------//
  _singleGoProcessInProgress = null;
  _singleGoProcessResponseResult = null;
  _singleGoProcessResponseResultPhrase = null;

  OnSingleGoSubmitClick() {
    this._singleGoProcessInProgress = true;

    let ruleJarUploadBody = new FormData();
    ruleJarUploadBody.append("file", this._selectedRuleJarFile);

    let ruleJarUploadSubs: Subscription = this.http.postUploadCall(AppConfig.API_HOST + AppConfig.API_UPLOAD_RULE_JAR, ruleJarUploadBody).subscribe(response => {
      ruleJarUploadSubs.unsubscribe();

      if (response['fileName'] && response['fileName'] != "") {
        this._jarUploadResult = true;
        this._uploadedRuleJarName = this._selectedRuleJarFile.name;
        this.notify('success', 'Rule Jar Upload', 'Success');
        this.apiCallForRuleJarUpload("success", response['errorMsg']);

        //Do Post Process
        this._postProcessRequestBody = {
          ruleJar: this._uploadedRuleJarName,
          plutoDCVersion: this._ngPlutoDcSelectValue,
          rboVersion: this._ngRboVersionSelectValue,
        }

        let postProcessSubs: Subscription = this.http.postUploadCall(AppConfig.API_HOST + AppConfig.API_DO_POST_PROESS, this._postProcessRequestBody)
          .subscribe(response => {
            postProcessSubs.unsubscribe();
            let result: any = response;
            if (result.status && result.status == "success") {
              this._postProcessServiceResult = true;
              this._ppJarExtractAndAddPropFilesResult = true;
              this._postProcessResultJarName = response['key'];
              this.notify('success', 'Post Process', 'Success');
              this.apiDBCallForPostProcessAction("success", response['errorMsg']);

              //Move Component
              this._copyRRDSFolderPayload = {
                stage: this._ngStageName,
                username: this._ngUserName,
                password: btoa(this._ngPassword),
                postProcessedJarName: this._postProcessResultJarName,
                loggerLevel: null,
                fileBased: null,
                action: null
              }
              //Verify Connection Params
              //this.onCheckConnectionClick();

              let moveJarSubs: Subscription = this.http.postUploadCall(AppConfig.API_HOST + AppConfig.API_DO_POST_COPY_TO_STAGE, this._copyRRDSFolderPayload)
                .subscribe(response => {
                  moveJarSubs.unsubscribe();
                  let result: any = response;

                  if (result.status && result.status == "success") {
                    this._moveJarToLinuxServiceCallResult = true;
                    this.apiDBCallForStageProcess("success", response['errorMsg']);
                    this.notify('success', 'Copy Component to Stage', 'Success');
                    //Adding below line new - Directly move Comp and Staart the Service
                    this.onRestartComponentClick();
                  } else {
                    this._moveJarToLinuxServiceCallResult = false;
                    this._singleGoProcessResponseResult = false;
                    this._singleGoProcessResponseResultPhrase = result.message;
                    this.apiDBCallForStageProcess("fail", response['errorMsg']);
                    this.notify('error', 'Copy Component to Stage', 'Failure : ' + result.message);
                  }
                },
                  error => {
                    this._moveJarToLinuxServiceCallResult = false;
                    this._singleGoProcessResponseResult = false;
                    this._singleGoProcessResponseResultPhrase = error.message;
                    this.apiDBCallForStageProcess("error", error.message);
                    this.notify('error', 'Copy Component to Stage', 'Error : ' + error.message);
                  });


            } else {
              this._postProcessServiceResult = false;
              this._singleGoProcessResponseResult = false;
              this._singleGoProcessResponseResultPhrase = result.message;
              this.apiDBCallForPostProcessAction("fail", response['errorMsg']);
            }
          },
            error => {
              this._postProcessServiceResult = false;
              this._singleGoProcessResponseResult = false;
              if (error.status == 0) { this._singleGoProcessResponseResultPhrase = "REST API Services are down. Try again later!"; }
              else { this._singleGoProcessResponseResultPhrase = error.message; }
              this.apiDBCallForPostProcessAction("error", error.message);
            });


      } else {
        this._jarUploadResult = false;
        this._singleGoProcessResponseResult = false;
        this._singleGoProcessResponseResultPhrase = "Rule jar - " + this._selectedRuleJarFile.name + " upload failed."
        this.apiCallForRuleJarUpload("fail", response['errorMsg']);
      }
    },
      error => {
        this._jarUploadResult = false;
        this._singleGoProcessResponseResult = false;
        if (error.status == 0) { this._singleGoProcessResponseResultPhrase = "REST API Services are down. Try again later!"; }
        else { this._singleGoProcessResponseResultPhrase = error.message; }
        this.apiCallForRuleJarUpload("fail", error.message);
      });


  }

  OnSingleGoClearClick() {
    this._singleGoProcessInProgress = null;
    this._singleGoProcessResponseResult = null;
    this._singleGoProcessResponseResultPhrase = null;

    //1. Rule Jar Upload
    this.uploadRuleJarReset();
    //2. Postprocess
    this.onPlutoAndRboReset();

    this.onSelectPostProcessedJarReset();

    this.OnStageDetailsClearClick();

    this.onRestartRRDSReset();

    this._ngStageName = null;
    this._ngUserName = null;
    this._ngPassword = null;

  }


  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 5000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }



}
