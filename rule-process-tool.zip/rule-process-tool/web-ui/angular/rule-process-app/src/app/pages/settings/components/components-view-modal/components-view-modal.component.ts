import { Component, OnInit,Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-components-view-modal',
  templateUrl: './components-view-modal.component.html',
  styleUrls: ['./components-view-modal.component.css']
})
export class ComponentsViewModalComponent {

  constructor(
    public dialogRef: MatDialogRef<ComponentsViewModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
