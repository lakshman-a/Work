import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComponentsDeleteModalComponent } from './components-delete-modal.component';

describe('ComponentsDeleteModalComponent', () => {
  let component: ComponentsDeleteModalComponent;
  let fixture: ComponentFixture<ComponentsDeleteModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComponentsDeleteModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComponentsDeleteModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
