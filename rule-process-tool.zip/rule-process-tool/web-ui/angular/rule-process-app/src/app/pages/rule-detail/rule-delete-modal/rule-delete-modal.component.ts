import { Component, Inject } from '@angular/core';
import { AppConfig } from './../../../app-config.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpTemplateService } from './../../../service/template/http-template.service';

import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-rule-delete-modal',
  templateUrl: './rule-delete-modal.component.html',
  styleUrls: ['./rule-delete-modal.component.css']
})
export class RuleDeleteModalComponent {

  _ngEditRuleId = null;
  _ngEditRuleComponent = null;
  _ngEditRuleName = null;
  _ngEditRuleCheckpoint = null;
  _ngEditRuleDesc = null;
  _ngEditRule = null;
  _componentList = null;
  _checkpointList = null;
  _apiData = null;
  _ngEditRuleActive = null;

  constructor(
    public dialogRef: MatDialogRef<RuleDeleteModalComponent>, private http: HttpTemplateService, private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this._ngEditRuleId = data['rule_id'];
    this._ngEditRuleName = data['rule_name'];
    this._ngEditRuleComponent = data['component'];
    this._ngEditRuleCheckpoint = data['checkpoint'];
    this._ngEditRuleDesc = data['rule_desc'];
    this._ngEditRule = data['rule'];
    //this._ngEditRuleActive = data['active'];
    if (data['active'] == 'true') {
      this._ngEditRuleActive = true;
    } else if (data['active'] == 'false') {
      this._ngEditRuleActive = false;
    }
  }
  _isActionInProgress = null;
  onDeleteClick(data) {
    let deleteRuleBody: any = {
      rule_id: this._ngEditRuleId,
      rule_name: this._ngEditRuleName,
      component: this._ngEditRuleComponent,
      checkpoint: this._ngEditRuleCheckpoint,
      rule_desc: this._ngEditRuleDesc,
      rule: this._ngEditRule,
      active: this._ngEditRuleActive,
      updated_by: "layyakannu"
    }
    console.log(deleteRuleBody);
    this._isActionInProgress = true;
    let subs2: Subscription = this.http.deleteCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_GET_API_RULE_DETAIL_MODIFY, deleteRuleBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      this._isActionInProgress = false;
      if (result.status && result.status == "success") {
        this.notify('success', 'Rule Delete', 'Rule Edited Successfully');
        this.dialogRef.close("success");
      } else
        this.notify('error', 'Rule Delete', 'Rule Delete Failed : ' + result.reason);
    },
      error => {
        this._isActionInProgress = false;
        this.notify('error', 'Rule Delete', 'Rule Delete Failed : ' + error.message);
      });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 5000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
