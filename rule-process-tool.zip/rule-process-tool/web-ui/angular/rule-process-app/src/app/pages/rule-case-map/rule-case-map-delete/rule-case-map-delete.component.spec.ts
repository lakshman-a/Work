import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RuleCaseMapDeleteComponent } from './rule-case-map-delete.component';

describe('RuleCaseMapDeleteComponent', () => {
  let component: RuleCaseMapDeleteComponent;
  let fixture: ComponentFixture<RuleCaseMapDeleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RuleCaseMapDeleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleCaseMapDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
