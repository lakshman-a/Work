import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';

@Component({
  selector: 'app-setup-dc',
  templateUrl: './setup-dc.component.html',
  styleUrls: ['./setup-dc.component.css']
})
export class SetupDcComponent implements OnInit {
  options: FormGroup;

  constructor(form: FormBuilder) {
    this.options = form.group({
      floatLabel: '8.8',
    });
  }
  ngOnInit() {
  }

}
