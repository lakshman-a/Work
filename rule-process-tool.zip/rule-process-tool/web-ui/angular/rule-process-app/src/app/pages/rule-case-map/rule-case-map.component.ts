import { AppConfig } from './../../app-config.service';
import { HttpTemplateService } from './../../service/template/http-template.service';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { Component, ViewChild, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription } from 'rxjs';
import { HttpParams } from '@angular/common/http';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { RuleCaseMapDeleteComponent } from './rule-case-map-delete/rule-case-map-delete.component';
import { RuleCaseMapViewComponent } from './rule-case-map-view/rule-case-map-view.component';

export interface RuleData {
  id: string;
  caseName: string;
  ruleName: string;
  active: string;
  created_tmstmp: string;
  created_by: string;
  updated_tmstmp: string;
  updated_by: string;
}


@Component({
  selector: 'app-rule-case-map',
  templateUrl: './rule-case-map.component.html',
  styleUrls: ['./rule-case-map.component.css']
})
export class RuleCaseMapComponent implements OnInit {

  constructor(private http: HttpTemplateService, private toastr: ToastrService, public dialog: MatDialog) { }

  ngOnInit() {
    //Load all the Rule and Testcase List in Input Autocomplete
    let subs2: Subscription = this.http.getCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_TESTCASES_AND_RULES).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;

      if (result['testCases'] && result['ruleNames']) {
        this._ngTestcaseNameList = result['testCases'];
        this._ngRuleNameList = result['ruleNames'];

        this.ruleNamefilteredOptions = this.ruleNameMyControl.valueChanges
          .pipe(
            startWith(''),
            map(value1 => this._ruleNameFilter(value1))
          );

        this.testcaseNamefilteredOptions = this.testcaseNameMyControl.valueChanges
          .pipe(
            startWith(''),
            map(value2 => this._testcaseNamefilter(value2))
          );


      } else {
        this.notify('error', 'Testcase and Rules List Failed', 'List is NULL or Empty.');
      }

    },
      error => {
        this.notify('error', 'Testcase and Rules List Failed', + error.message);
      });

    //Load all the Mapping details details
    let subs: Subscription = this.http.getCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_GET_API_RULECASE_MAP_LIST).subscribe(response => {
      subs.unsubscribe;
      let result: any = response;
      this.dataSource = new MatTableDataSource(result);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      //this.notify('success', 'Rule Details', 'Rule List populated successfully');
    }, error => {
      this.notify('error', 'Rule Case Map', 'Error occured while Loading List : ' + error.message);
    });

  }

  //Field List
  _ngAddMapActive = true;

  //Auto Complete Testcase Name
  _ngTestcaseNameList: string[];
  testcaseNameMyControl = new FormControl();
  testcaseNamefilteredOptions: Observable<string[]>;
  _ngSelectedTestcaseName = null;

  private _testcaseNamefilter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this._ngTestcaseNameList.filter(option => option.toLowerCase().includes(filterValue));
  }
  getTestcaseName = this.testcaseNameMyControl.valueChanges.subscribe(value => { this._ngSelectedTestcaseName = value })

  //Auto Complete Rule Name
  _ngRuleNameList: string[];
  ruleNameMyControl = new FormControl();
  ruleNamefilteredOptions: Observable<string[]>;
  _ngSelectedRuleName = null;

  private _ruleNameFilter(value1: string): string[] {
    const filterValue1 = value1.toLowerCase();
    return this._ngRuleNameList.filter(eachoption => eachoption.toLowerCase().includes(filterValue1));
  }
  getRuleName = this.ruleNameMyControl.valueChanges.subscribe(value => { this._ngSelectedRuleName = value })

  _ngNewRuleCaseMapAddInProgress = null;

  onNewRuleCaseMapSubmit() {
    let newRuleCaseMapBody: any = {
      caseName: this._ngSelectedTestcaseName,
      ruleName: this._ngSelectedRuleName,
      active: "true",
      created_by: "layyakannu",
      updated_by: "layyakannu"
    }
    
    this._ngNewRuleCaseMapAddInProgress = true;
    let subs2: Subscription = this.http.postCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_RULECASE_MAP_MODIFY, newRuleCaseMapBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      this._ngNewRuleCaseMapAddInProgress = false;
      if (result.status && result.status == "success") {
        this.onNewRuleCaseMapFormReset();
        this.ruleGridRefreshCall();
        this.notify('success', 'Rule Case Map Add', 'Success');
      } else
        this.notify('error', 'Rule Case Map Add', 'Failed : ' + result.reason);
    },
      error => {
        this._ngNewRuleCaseMapAddInProgress = false;
        this.notify('error', 'Rule Case Map Add', 'Failed : ' + error.message);
      });
  }

  onNewRuleCaseMapFormReset() {
    this._ngNewRuleCaseMapAddInProgress = null;
    this.ruleNameMyControl.setValue('');
    this.testcaseNameMyControl.setValue('');
    this._ngAddMapActive = true;
  }


  //MAT TABLE:
  displayedColumns: string[] = ['id', 'ruleName', 'caseName', 'active', 'updated_by', 'updated_tmstmp', 'action'];
  dataSource: MatTableDataSource<RuleData>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  ruleGridRefreshCall() {
    let subs: Subscription = this.http.getCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_GET_API_RULECASE_MAP_LIST).subscribe(response => {
      subs.unsubscribe;
      let result: any = response;
      this.dataSource = new MatTableDataSource(result);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this.notify('error', 'Rule Case Map', 'Error occured while Refreshing List : ' + error.message);
    });
  }

  //MAT:
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  //DELETE MODAL FEATURE
  openDeleteDialog(row): void {
    const dialogRef2 = this.dialog.open(RuleCaseMapDeleteComponent, {
      width: '600px',
      data: row
    });

    dialogRef2.afterClosed().subscribe(result => {
     
      console.log(result);
      console.log("delete modal Dialogs closed!");
      if(result=='success'){
        console.log("Result is success so refresing grif!");
        this.ruleGridRefreshCall();
      }
    });
  }

  //View MODAL FEATURE
  openViewDialog(row): void {
    const dialogRef3 = this.dialog.open(RuleCaseMapViewComponent, {
      width: '800px',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
      if (result) {
     }
    });
  }



  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 6000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
