import { HttpTemplateService } from './../../service/template/http-template.service';
import { AppConfig } from './../../app-config.service';

import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

export interface StageConnectRequest {
  stage: string;
  username: string;
  password: string;
  uploadedRuleJar: any
  loggerLevel: any;
  fileBased: any;
  action: any;
}

@Component({
  selector: 'app-rule-validation',
  templateUrl: './rule-validation.component.html',
  styleUrls: ['./rule-validation.component.css']
})
export class RuleValidationComponent implements OnInit {

  _httpActions: string[] = ['POST', 'GET', 'DELETE', 'PUT'];
  _componentsList: string[] = ['riskresolutiondecisionserv', 'disputesapiserv', 'riskdecisionplanningserv'];
  _checkpointsList: string[] = ['DisputeLifecycleInitiation', 'DisputeLifecycleAdjudication', 'DisputeLifecycleEscalation'];
  _ngCheckpoint: string = "";
  _ngComponent: string = "";
  _ngHttpAction: string = 'POST';
  _ngHeaderDetails: any[] = [{ key: "Content-Type", value: "application/json", description: "" }, { key: "Accept", value: "application/json", description: "" }, { key: "", value: "", description: "" }];
  _ngPatternDetails: any[] = [{ name: "Check Total Rules Fired", pattern: "Total rule" }, { name: "Check what rules fired", pattern: "rules fired" }, { name: "", pattern: "" }];
  _ngHttpURL: string;
  _ngHttpBody: string;

  _isResponseBodyExpanded = false;
  _isLogPatternExpanded = false;
  _isHttpResponseComplete = null;
  _ngcheckLogPattern: boolean = false;
  _ngHttpResponseHeaders: string;
  _ngSplittedResponseHeaders: string[];

  constructor(private http: HttpTemplateService, private toastr: ToastrService) { }

  ngOnInit() { }

  addHeader() {
    this._ngHeaderDetails.push({ key: "", value: "" });
  }

  removeHeader(headerDetail) {
    this._ngHeaderDetails = this._ngHeaderDetails.filter(item => item !== headerDetail);
  }

  addPattern() {
    this._ngPatternDetails.push({ key: "", value: "" });
  }
  removePattern(patternDetail) {
    this._ngPatternDetails = this._ngPatternDetails.filter(item => item !== patternDetail);
  }

  // onHeaderToggleClick(){
  //   this._isHeaderExpanded = !this._isHeaderExpanded;
  // }

  onResponseBodyToggleClick() {
    this._isResponseBodyExpanded = !this._isResponseBodyExpanded;
  }

  onLogPatternToggleClick() {
    this._isLogPatternExpanded = !this._isLogPatternExpanded;
  }

  validateRequestJson() {
    try {
      JSON.parse(this._ngHttpBody);
    } catch (e) {
      return false;
    }
    return true;
  }

  prettyPrintRequestJson() {
    var ugly = this._ngHttpBody;
    var obj = JSON.parse(ugly);
    var pretty = JSON.stringify(obj, undefined, 4);
    this._ngHttpBody = pretty;
  }

  _ngFullStageName = null;
  _ngOnlyStageName = null;
  _ngUserName = null;
  _ngPassword = null;
  _checkConnToLinuxCallInProgress = null;
  _checkConnToLinuxServiceCallResult = null;
  _checkConnToLinuxServiceCallResultPhrase = null;
  _stageConnectionPayload: StageConnectRequest;

  onCheckboxChange(event){
    if(event.checked){
      if(this._ngHttpURL && this._ngHttpURL!="" && this._ngHttpURL.length >43){
        this._ngOnlyStageName = this._ngHttpURL.substring(8,22);
        this._ngFullStageName = this._ngHttpURL.substring(8,36);
        console.log(this._ngFullStageName);
        console.log(this._ngOnlyStageName);
      }
    }
  }

  onHttpUrlChange(event){
    let httpUrl=event.target.value;
    console.log(event.target.value);
      if(httpUrl && httpUrl!="" && httpUrl.length >43){
        this._ngOnlyStageName = this._ngHttpURL.substring(8,22);
        this._ngFullStageName = this._ngHttpURL.substring(8,36);
        console.log(this._ngFullStageName);
        console.log(this._ngOnlyStageName);
      }
  }

  onCheckConnectionClick() {
    this._checkConnToLinuxServiceCallResultPhrase = null;
    this._checkConnToLinuxCallInProgress = null;

    //Payload
    this._stageConnectionPayload = {
      stage: this._ngOnlyStageName,
      username: this._ngUserName,
      password: btoa(this._ngPassword),
      uploadedRuleJar: null,
      loggerLevel: null,
      fileBased: null,
      action: null
    }

    this._checkConnToLinuxCallInProgress = true;
    let subs: Subscription = this.http.postUploadCall(AppConfig.API_HOST + AppConfig.API_DO_POST_CHECK_CONN, this._stageConnectionPayload)
      .subscribe(response => {
        subs.unsubscribe();
        let result: any = response;
        this._checkConnToLinuxCallInProgress = false;
        if (result.status && result.status == "success") {
          this._checkConnToLinuxServiceCallResult = true;
          this.notify('success', 'User Stage Connection', 'Success');
        } else {
          this._checkConnToLinuxServiceCallResult = false;
          this.notify('error', 'User Stage Connection', 'Failed : ' + result.message);
        }
        this._checkConnToLinuxServiceCallResultPhrase = result.message;
      },
        error => {
          this._checkConnToLinuxCallInProgress = false;
          this._checkConnToLinuxServiceCallResult = false;
          this._checkConnToLinuxServiceCallResultPhrase = error.message;
          this.notify('error', 'User Stage Connection', 'Failed : ' + error.message);
        });
  }

  _ruleFireResponseInProgress = null;

  _ruleFireResponseContent = null;
  _ruleFireResponseCode = null;
  _ruleFireResponseTime = null;
  _ruleFireResponseReason = null;
  _isValidationDisabled = true;
  _ruleFireResponsePhrase = null;
  _ngResponseLogPatternValues = null;
  _ngResIsLogRetrievalSuccess: boolean;
  _ngResLogRetrievalErrorMsg = null;

  onHttpRequestSubmitClick() {
    let _ngHttpBodyNew
    if (this._ngHttpBody) {
      // var jsonString = this._ngHttpBody.replace(/(\r\n|\n|\r)/g, "");
      // _ngHttpBodyNew = JSON.parse(jsonString);

      //Dummy
      _ngHttpBodyNew = this._ngHttpBody;
    }

    let apiRequestPayload = {
      method: this._ngHttpAction,
      url: this._ngHttpURL,
      headers: this._ngHeaderDetails,
      logCheckFlag: this._ngcheckLogPattern,
      stage: this._ngFullStageName,
      username: this._ngUserName,
      password:  btoa(this._ngPassword),
      logPattern: this._ngPatternDetails.filter(eachItem =>  eachItem['pattern'] !="" && eachItem['pattern'] != null ),
      payload: _ngHttpBodyNew,
      component: "rrds",
      created_by: "layyakannu",
    }
    console.log(apiRequestPayload);
    this._ruleFireResponseInProgress = true;

    let subs: Subscription = this.http.postCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_RULE_FIRE_REQUEST, apiRequestPayload)
      .subscribe(response => {
        subs.unsubscribe();
        console.log(response)
        this._ruleFireResponseInProgress = false;

        if (response['status_code'] && response['status_code'] == "200") {

          //this._ruleFireResponseContent = response['response'];

          var ugly = response['response_body'];
          var obj = JSON.parse(ugly);
          var pretty = JSON.stringify(obj, undefined, 4);
          this._ruleFireResponseContent = pretty;

          this._ruleFireResponseCode = response['status_code'];
          this._ruleFireResponsePhrase = response['status_phrase'];
          this._ruleFireResponseTime = response['response_time'];
          this._ngHttpResponseHeaders = response['response_headers'];
          this._ngSplittedResponseHeaders = this._ngHttpResponseHeaders.split(',');
         
          this._ngResIsLogRetrievalSuccess = response['isLogPatternSuccess'];
          this._ngResLogRetrievalErrorMsg = response['logPatternErrorMsg'];
          this._ngResponseLogPatternValues = response['logPattern'];



          //Expand the Response card:
          this._isResponseBodyExpanded = true;
          this._isLogPatternExpanded = true;
          // this._isHeaderExpanded=false;
          // this._isRequestBodyExpanded=false;

          this.notify('success', 'Rule Fire Request', 'OK Response');
        } else if (response['status_code'] && response['status_code'] == "0") {

          this._ruleFireResponseContent= response['error_msg'];

          this._ruleFireResponseCode = response['status_code'];
          this._ruleFireResponseTime = 'NA';
          this._ngHttpResponseHeaders = 'NA';
          this._ruleFireResponseReason = response['error_msg'];
          this.notify('error', 'Rule Fire Request', this._ruleFireResponseCode + " - " + this._ruleFireResponseReason);

        } else {

          var ugly = response['response_body'];
          var obj = JSON.parse(ugly);
          var pretty = JSON.stringify(obj, undefined, 4);
          this._ruleFireResponseContent = pretty;


          this._ruleFireResponseCode = response['status_code'];
          this._ruleFireResponseTime = response['response_time'];
          this._ngHttpResponseHeaders = response['response_headers'];
          this._ngSplittedResponseHeaders = this._ngHttpResponseHeaders.split(',');
          this._ruleFireResponseReason = response['status_phrase'];
          this.notify('error', 'Rule Fire Request', this._ruleFireResponseCode + " - " + this._ruleFireResponseReason);
        }


      },
        error => {
          this._ruleFireResponseInProgress =false;
          this.notify('error', 'Rule Fire Request', "Service Down! "+error.message);
        });
  }

  onHttpRequestReset() {
    this._ngHttpAction = "POST";
    this._ngHttpURL = "";
    this._ngHttpBody = "";

    this._ngHeaderDetails = [{ key: "Content-Type", value: "application/json", description: "" }, { key: "Accept", value: "application/json", description: "" }, { key: "", value: "", description: "" }];
    this._ngPatternDetails = [{ name: "Check Total Rules Fired", pattern: "Total rule" }, { name: "Check what rules fired", pattern: "rules fired" }, { name: "", pattern: "" }];
    
    this._ruleFireResponseInProgress = null;

    this._ruleFireResponseContent = null;
    this._ruleFireResponseCode = null;
    this._ruleFireResponseTime = null;
    this._ruleFireResponseReason = null;
  }



  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 6000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
