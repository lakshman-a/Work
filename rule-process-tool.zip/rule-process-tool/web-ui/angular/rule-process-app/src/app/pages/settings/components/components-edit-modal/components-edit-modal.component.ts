import { Component, Inject } from '@angular/core';
import { AppConfig } from './../../../../app-config.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpTemplateService } from './../../../../service/template/http-template.service';

import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-components-edit-modal',
  templateUrl: './components-edit-modal.component.html',
  styleUrls: ['./components-edit-modal.component.css']
})
export class ComponentsEditModalComponent {

  //1. Testcase Details
  _ngEditApiData = null;
  _ngComponentName = null;
  _ngComponentDesc = null;
  _ngComponentActiveFlag = true;
  _ngProjectName = null;
  constructor(
    public dialogRef: MatDialogRef<ComponentsEditModalComponent>, private http: HttpTemplateService, private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this._ngEditApiData = data;
    this._ngComponentName = data['component_name'];
    this._ngComponentDesc = data['component_desc'];
    this._ngProjectName = data['project_name'];

    if (data['active'] == 'true') { this._ngComponentActiveFlag = true; }
    else if (data['active'] == 'false') { this._ngComponentActiveFlag = false; }
  }

  _ngUpdateInProgress = null;
  onUpdateClick() {

    let editSubmitBody: any = {
      component_name: this._ngComponentName,
      component_desc: this._ngComponentDesc,
      active: this._ngComponentActiveFlag,
      project_name: this._ngProjectName, 
      updated_by: "layyakannu"
    }
    this._ngUpdateInProgress = true;
    let subs2: Subscription = this.http.putCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_COMPONENT_UPDATE, editSubmitBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      this._ngUpdateInProgress = false;
      if (result.status && result.status == "success") {
        if (result.code && result.code == "201") {
          this.notify('error', 'Component Edit', 'No Rows Updated');
        } else {
          this.notify('success', 'Component Edit', 'Success');
          this.dialogRef.close("success");
        }
      } else
        this.notify('error', 'Component Edit', 'Failed : ' + result.reason);
    },
      error => {
        this._ngUpdateInProgress = false;
        this.notify('error', 'Component Edit', 'Failed : ' + error.message);
      });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 5000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
