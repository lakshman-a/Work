import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckpointsViewModalComponent } from './checkpoints-view-modal.component';

describe('CheckpointsViewModalComponent', () => {
  let component: CheckpointsViewModalComponent;
  let fixture: ComponentFixture<CheckpointsViewModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckpointsViewModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckpointsViewModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
