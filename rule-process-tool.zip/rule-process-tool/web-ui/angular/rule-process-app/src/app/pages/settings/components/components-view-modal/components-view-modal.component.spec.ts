import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComponentsViewModalComponent } from './components-view-modal.component';

describe('ComponentsViewModalComponent', () => {
  let component: ComponentsViewModalComponent;
  let fixture: ComponentFixture<ComponentsViewModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComponentsViewModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComponentsViewModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
