import { CheckpointsEditModalComponent } from './checkpoints-edit-modal/checkpoints-edit-modal.component';
import { CheckpointsDeleteModalComponent } from './checkpoints-delete-modal/checkpoints-delete-modal.component';
import { CheckpointsViewModalComponent } from './checkpoints-view-modal/checkpoints-view-modal.component';
import { ComponentsEditModalComponent } from './components-edit-modal/components-edit-modal.component';
import { ComponentsDeleteModalComponent } from './components-delete-modal/components-delete-modal.component';
import { ComponentsViewModalComponent } from './components-view-modal/components-view-modal.component';
import { FormControl } from '@angular/forms';
import { HttpParams } from '@angular/common/http';
import { HttpTemplateService } from './../../../service/template/http-template.service';
import { AppConfig } from './../../../app-config.service';

import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription, Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';

export interface CheckpointData {
  id: string;
  checkpoint_name: string;
  checkpoint_desc?: string;
  component_name: string;
  project_name: string;
  active: string;
  created_tmstmp: string;
  created_by: string;
  updated_tmstmp: string;
  updated_by: string;
}

export interface ComponentData {
  id: string;
  component_name: string;
  component_desc?: string;
  project_name: string;
  active: string;
  created_tmstmp: string;
  created_by: string;
  updated_tmstmp: string;
  updated_by: string;
}


@Component({
  selector: 'app-components',
  templateUrl: './components.component.html',
  styleUrls: ['./components.component.css']
})
export class ComponentsComponent implements OnInit {

  constructor(
    private http: HttpTemplateService,
    private toastr: ToastrService,
    public dialog: MatDialog) { }

  _projectName = "Default";
  componentDisplayedColumns: string[] = ['component_name', 'created_by', 'active', 'action'];
  componentDataSource: MatTableDataSource<ComponentData>;
  @ViewChild(MatPaginator) componentPaginator: MatPaginator;
  @ViewChild(MatSort) componentSort: MatSort;
  _ngComponentLoadInProgress = null;

  checkpointDisplayedColumns: string[] = ['checkpoint_name', 'component_name', 'active', 'action'];
  checkpointDataSource: MatTableDataSource<CheckpointData>;
  //@ViewChild(MatPaginator) checkpointPaginator: MatPaginator;
  //@ViewChild(MatSort) checkpointSort: MatSort;
  _ngCheckpointLoadInProgress = null;

  ngOnInit() {
    this._ngComponentLoadInProgress = true;
    this._ngCheckpointLoadInProgress = true;
    //Component List Load
    let params = new HttpParams().set('projectName', this._projectName);
    let subs: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_API_COMPONENT_DETAILS, params).subscribe(response => {
      subs.unsubscribe;
      this._ngComponentLoadInProgress = false;
      let result: any = response;
      this.componentDataSource = new MatTableDataSource(result);
      setTimeout(() => this.componentDataSource.paginator = this.componentPaginator);
      this.componentDataSource.sort = this.componentSort;

      this._ngComponentNameList = result.map(eachItem => eachItem.component_name);
      this.componentNamefilteredOptions = this.componentNameMyControl.valueChanges
        .pipe(
          startWith(''),
          map(value => this._componentNameFilter(value))
        );

    }, error => {
      this._ngComponentLoadInProgress = false;
      this.notify('error', 'Components List', 'Error occured while Loading Details : ' + error.message);
    });

    //Checkpoint List Load
    let subs2: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_API_CHECKPOINT_DETAILS, params).subscribe(response => {
      subs2.unsubscribe;
      this._ngCheckpointLoadInProgress = false;
      let result: any = response;
      this.checkpointDataSource = new MatTableDataSource(result);
      //setTimeout(() => this.checkpointDataSource.paginator = this.checkpointPaginator);
      //this.checkpointDataSource.sort = this.checkpointSort;
    }, error => {
      this._ngCheckpointLoadInProgress = false;
      this.notify('error', 'Checkpoint List', 'Error occured while Loading Details : ' + error.message);
    });

  }

  //Add Component
  _ngComponentName = null;
  _ngComponentDesc = null;
  _ngComponentAddInProgress = null;

  _ngComponentAddSubmit() {

    let newComponentSubmitBody: any = {
      component_name: this._ngComponentName,
      component_desc: this._ngComponentDesc,
      project_name: this._projectName,
      active: true,
      created_by: "layyakannu",
      updated_by: "layyakannu"
    }
    this._ngComponentAddInProgress = true;
    let subs3: Subscription = this.http.postCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_COMPONENT_UPDATE, newComponentSubmitBody).subscribe(response => {
      subs3.unsubscribe();
      let result: any = response;
      this._ngComponentAddInProgress = false;
      if (result.status && result.status == "success") {
        this._ngComponentAddReset();
        this.componentGridRefreshCall();
        this.notify('success', 'Component Create', 'Success');
      } else
        this.notify('error', 'Component Create', 'Failed : ' + result.reason);
    },
      error => {
        this._ngComponentAddInProgress = false;
        this.notify('error', 'Component Create', 'Failed : ' + error.message);
      });
  }

  _ngComponentAddReset() {
    this._ngComponentName = null;
    this._ngComponentDesc = null;
    this._ngComponentAddInProgress = null;
  }

  //Add Checkpoint
  _ngComponentNameList: string[];
  componentNameMyControl = new FormControl();
  componentNamefilteredOptions: Observable<string[]>;
  _ngCheckpointName = null;
  _ngCheckpointDesc = null;
  _ngCheckpointAddInProgress = null;
  _ngCheckpointAddComponentName = null;

  private _componentNameFilter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this._ngComponentNameList.filter(option => option.toLowerCase().includes(filterValue));
  }

  getComponentName = this.componentNameMyControl.valueChanges.subscribe(value => { this._ngCheckpointAddComponentName = value })

  _ngCheckpointAddSubmit() {
    let tempCount = this._ngComponentNameList.filter(eachItem => eachItem == this._ngCheckpointAddComponentName).length;
    if (tempCount == 1) {
      let newCheckpointSubmitBody: any = {
        checkpoint_name: this._ngCheckpointName,
        checkpoint_desc: this._ngCheckpointDesc,
        component_name: this._ngCheckpointAddComponentName,
        project_name: this._projectName,
        active: true,
        created_by: "layyakannu",
        updated_by: "layyakannu"
      }
      this._ngCheckpointAddInProgress = true;
      let subs3: Subscription = this.http.postCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_CHECKPOINT_UPDATE, newCheckpointSubmitBody).subscribe(response => {
        subs3.unsubscribe();
        let result: any = response;
        this._ngCheckpointAddInProgress = false;
        if (result.status && result.status == "success") {
          this._ngCheckpointAddReset();
          this.checkpointGridRefreshCall();
          this.notify('success', 'Checkpoint Create', 'Success');
        } else
          this.notify('error', 'Checkpoint Create', 'Failed : ' + result.reason);
      },
        error => {
          this._ngCheckpointAddInProgress = false;
          this.notify('error', 'Checkpoint Create', 'Failed : ' + error.message);
        });
    } else {
      this.notify('error', 'Component Invalid Selection', 'Choose a Valid Item');
      this.componentNameMyControl.setValue('');
      this._ngCheckpointAddComponentName = "";
    }

  }

  _ngCheckpointAddReset() {
    this._ngCheckpointName = null;
    this._ngCheckpointDesc = null;
    this._ngCheckpointAddInProgress = null;
    this.componentNameMyControl.setValue('');
    this._ngCheckpointAddComponentName = null;

  }

  //GRIDS


  componentApplyFilter(filterValue: string) {
    this.componentDataSource.filter = filterValue.trim().toLowerCase();
    if (this.componentDataSource.paginator) {
      this.componentDataSource.paginator.firstPage();
    }
  }

  checkpointApplyFilter(filterValue: string) {
    this.checkpointDataSource.filter = filterValue.trim().toLowerCase();
    if (this.checkpointDataSource.paginator) {
      this.checkpointDataSource.paginator.firstPage();
    }
  }

  componentGridRefreshCall() {
    this._ngComponentLoadInProgress = true;
    let params = new HttpParams().set('projectName', this._projectName);
    let subs: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_API_COMPONENT_DETAILS, params).subscribe(response => {
      subs.unsubscribe;
      this._ngComponentLoadInProgress = false;
      let result: any = response;
      this.componentDataSource = new MatTableDataSource(result);
      //this.componentDataSource.paginator = this.componentPaginator;
      setTimeout(() => this.componentDataSource.paginator = this.componentPaginator);
      this.componentDataSource.sort = this.componentSort;
      this._ngComponentNameList = result.map(eachItem => eachItem.component_name);
      this.componentNamefilteredOptions = this.componentNameMyControl.valueChanges
        .pipe(
          startWith(''),
          map(value => this._componentNameFilter(value))
        );
    }, error => {
      this._ngComponentLoadInProgress = false;
      this.notify('error', 'Components List', 'Error occured while Loading Details : ' + error.message);
    });
  }

  checkpointGridRefreshCall() {
    this._ngCheckpointLoadInProgress = true;
    let params = new HttpParams().set('projectName', this._projectName);
    let subs2: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_API_CHECKPOINT_DETAILS, params).subscribe(response => {
      subs2.unsubscribe;
      this._ngCheckpointLoadInProgress = false;
      let result: any = response;
      this.checkpointDataSource = new MatTableDataSource(result);
      //setTimeout(() => this.checkpointDataSource.paginator = this.checkpointPaginator);
      //this.checkpointDataSource.sort = this.checkpointSort;
    }, error => {
      this._ngCheckpointLoadInProgress = false;
      this.notify('error', 'Checkpoint List', 'Error occured while Loading Details : ' + error.message);
    });
  }

  //Component EDIT MODAL FEATURE
  openComponentEditDialog(row): void {
    const dialogRef = this.dialog.open(ComponentsEditModalComponent, {
      width: '700px',
      maxHeight: 'calc(100vh - 120px)',
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result == 'success') {
        this.componentGridRefreshCall();
      }

    });
  }

  //Component Delete MODAL FEATURE
  openComponentDeleteDialog(row): void {
    const dialogRef2 = this.dialog.open(ComponentsDeleteModalComponent, {
      width: '700px',
      data: row
    });

    dialogRef2.afterClosed().subscribe(result => {
      if (result == 'success') {
        this.componentGridRefreshCall();
      }
    });
  }

  //Component View MODAL FEATURE
  openComponentViewDialog(row): void {
    const dialogRef3 = this.dialog.open(ComponentsViewModalComponent, {
      width: '700px',
      maxHeight: 'calc(100vh - 120px)',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
    });
  }

  //Checkpoint EDIT MODAL FEATURE
  openCheckpointEditDialog(row): void {
    const dialogRef = this.dialog.open(CheckpointsEditModalComponent, {
      width: '700px',
      maxHeight: 'calc(100vh - 120px)',
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result == 'success') {
        this.checkpointGridRefreshCall();
      }

    });
  }

  //Checkpoint Delete MODAL FEATURE
  openCheckpointDeleteDialog(row): void {
    const dialogRef2 = this.dialog.open(CheckpointsDeleteModalComponent, {
      width: '700px',
      data: row
    });

    dialogRef2.afterClosed().subscribe(result => {
      if (result == 'success') {
        this.checkpointGridRefreshCall();
      }
    });
  }

  //Checkpoint View MODAL FEATURE
  openCheckpointViewDialog(row): void {
    const dialogRef3 = this.dialog.open(CheckpointsViewModalComponent, {
      width: '700px',
      maxHeight: 'calc(100vh - 120px)',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
    });
  }
  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 6000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }


}
