import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';

export interface CaseDetails {
  case_id: string;
  test_case: string;
  reason_code: string;
  current_state: string;
  created_by: string;
  created_on: string;
}


@Component({
  selector: 'app-dispute-trn',
  templateUrl: './dispute-trn.component.html',
  styleUrls: ['./dispute-trn.component.css']
})
export class DisputeTrnComponent implements OnInit {

  displayedColumns: string[] = ['case_id', 'reason_code', 'current_state', 'test_case', 'created_by', 'created_on'];
  dataSource: MatTableDataSource<CaseDetails>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor() {
    this.dataSource = new MatTableDataSource(this.jsonObject);
  }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  _isUserCreationChecked = false;
  _claimType = "INTERNAL";
  _disputeReason = "";
  _stageName = "msmaster.qa.paypal.com";

  _searchedCaseId = "PP-000-023-175-357";

  jsonObject: CaseDetails[] = [{
    case_id: "PP-000-023-175-357",
    reason_code: "INR",
    current_state: "PDR",
    test_case: "E2E Execution",
    created_by: "layyakannu",
    created_on: "2019-09-12 12:00:33.122",
  },
  {
    case_id: "PP-000-023-175-357",
    reason_code: "INR",
    current_state: "PDR",
    test_case: "E2E Execution",
    created_by: "layyakannu",
    created_on: "2019-09-12 12:00:33.122",
  },
  {
    case_id: "PP-000-023-175-357",
    reason_code: "INR",
    current_state: "PDR",
    test_case: "E2E Execution",
    created_by: "layyakannu",
    created_on: "2019-09-12 12:00:33.122",
  },
  {
    case_id: "PP-000-023-175-357",
    reason_code: "INR",
    current_state: "PDR",
    test_case: "E2E Execution",
    created_by: "layyakannu",
    created_on: "2019-09-12 12:00:33.122",
  },
  {
    case_id: "PP-000-023-175-357",
    reason_code: "INR",
    current_state: "PDR",
    test_case: "E2E Execution",
    created_by: "layyakannu",
    created_on: "2019-09-12 12:00:33.122",
  },
  {
    case_id: "PP-000-023-175-357",
    reason_code: "INR",
    current_state: "PDR",
    test_case: "E2E Execution",
    created_by: "layyakannu",
    created_on: "2019-09-12 12:00:33.122",
  },
  {
    case_id: "PP-000-023-175-357",
    reason_code: "INR",
    current_state: "PDR",
    test_case: "E2E Execution",
    created_by: "layyakannu",
    created_on: "2019-09-12 12:00:33.122",
  },
  {
    case_id: "PP-000-023-175-357",
    reason_code: "INR",
    current_state: "PDR",
    test_case: "E2E Execution",
    created_by: "layyakannu",
    created_on: "2019-09-12 12:00:33.122",
  },
  {
    case_id: "PP-000-023-175-357",
    reason_code: "INR",
    current_state: "PDR",
    test_case: "E2E Execution",
    created_by: "layyakannu",
    created_on: "2019-09-12 12:00:33.122",
  },
  {
    case_id: "PP-000-023-175-357",
    reason_code: "INR",
    current_state: "PDR",
    test_case: "E2E Execution",
    created_by: "layyakannu",
    created_on: "2019-09-12 12:00:33.122",
  }];
}
