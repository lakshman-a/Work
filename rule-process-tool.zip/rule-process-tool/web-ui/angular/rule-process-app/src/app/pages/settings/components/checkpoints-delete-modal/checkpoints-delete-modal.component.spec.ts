import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckpointsDeleteModalComponent } from './checkpoints-delete-modal.component';

describe('CheckpointsDeleteModalComponent', () => {
  let component: CheckpointsDeleteModalComponent;
  let fixture: ComponentFixture<CheckpointsDeleteModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckpointsDeleteModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckpointsDeleteModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
