import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-dispute',
  templateUrl: './create-dispute.component.html',
  styleUrls: ['./create-dispute.component.css']
})
export class CreateDisputeComponent implements OnInit {

  _isUserCreationChecked=false;
  _claimType="INTERNAL";
  _disputeReason="";
  _stageName="msmaster.qa.paypal.com";
  constructor() {}

  ngOnInit() {
  }

}
