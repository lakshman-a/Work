import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RuleCaseMapViewComponent } from './rule-case-map-view.component';

describe('RuleCaseMapViewComponent', () => {
  let component: RuleCaseMapViewComponent;
  let fixture: ComponentFixture<RuleCaseMapViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RuleCaseMapViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleCaseMapViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
