import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisputeTrnComponent } from './dispute-trn.component';

describe('DisputeTrnComponent', () => {
  let component: DisputeTrnComponent;
  let fixture: ComponentFixture<DisputeTrnComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisputeTrnComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisputeTrnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
