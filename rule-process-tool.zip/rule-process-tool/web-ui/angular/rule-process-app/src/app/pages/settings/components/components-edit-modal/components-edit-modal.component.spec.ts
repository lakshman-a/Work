import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComponentsEditModalComponent } from './components-edit-modal.component';

describe('ComponentsEditModalComponent', () => {
  let component: ComponentsEditModalComponent;
  let fixture: ComponentFixture<ComponentsEditModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComponentsEditModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComponentsEditModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
