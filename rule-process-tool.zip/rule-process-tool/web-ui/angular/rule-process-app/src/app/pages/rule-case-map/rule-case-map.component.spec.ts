import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RuleCaseMapComponent } from './rule-case-map.component';

describe('RuleCaseMapComponent', () => {
  let component: RuleCaseMapComponent;
  let fixture: ComponentFixture<RuleCaseMapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RuleCaseMapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleCaseMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
