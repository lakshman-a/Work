import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RuleEditModalComponent } from './rule-edit-modal.component';

describe('RuleEditModalComponent', () => {
  let component: RuleEditModalComponent;
  let fixture: ComponentFixture<RuleEditModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RuleEditModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleEditModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
