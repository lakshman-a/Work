import { HttpParams } from '@angular/common/http';
import { FormControl } from '@angular/forms';
import { Component, Inject } from '@angular/core';
import { AppConfig } from './../../../../app-config.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpTemplateService } from './../../../../service/template/http-template.service';

import { Subscription, Observable } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { startWith, map } from 'rxjs/operators';

@Component({
  selector: 'app-checkpoints-edit-modal',
  templateUrl: './checkpoints-edit-modal.component.html',
  styleUrls: ['./checkpoints-edit-modal.component.css']
})
export class CheckpointsEditModalComponent {

  _ngEditApiData = null;
  //_ngComponentNameList: string[];
  //ComponentNameMyControl = new FormControl();
  //ComponentNamefilteredOptions: Observable<string[]>;

  _ngCheckpointName = null;
  _ngCheckpointDesc = null;
  _ngTaggedComponentName = null;
  _ngCheckpointActiveFlag = true;
  _ngProjectName = null;

  constructor(
    public dialogRef: MatDialogRef<CheckpointsEditModalComponent>, private http: HttpTemplateService, private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this._ngEditApiData = data;
    this._ngCheckpointName = data['checkpoint_name'];
    this._ngCheckpointDesc = data['checkpoint_desc'];
    //this.ComponentNameMyControl.setValue(data['component_desc']);
    this._ngTaggedComponentName = data['component_name'];
    this._ngProjectName = data['project_name'];

    if (data['active'] == 'true') { this._ngCheckpointActiveFlag = true; }
    else if (data['active'] == 'false') { this._ngCheckpointActiveFlag = false; }
  }

  // ngOnInit() {
  //   let params = new HttpParams().set('projectName', this._ngProjectName);
  //   let subs2: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_API_COMPONENT_DETAILS, params).subscribe(response => {
  //     subs2.unsubscribe();
  //     let result: any = response;
  //     this._ngComponentNameList = result.map(eachItem => eachItem.component_name);
  //     this.ComponentNamefilteredOptions = this.ComponentNameMyControl.valueChanges
  //       .pipe(
  //         startWith(''),
  //         map(value => this._componentNameFilter(value))
  //       );
  //   },
  //     error => {
  //       this.notify('error', 'Components List', 'List Load Failed : ' + error.message);
  //     });
  // }

  // private _componentNameFilter(value: string): string[] {
  //   const filterValue = value.toLowerCase();
  //   return this._ngComponentNameList.filter(option => option.toLowerCase().includes(filterValue));
  // }
  // getActionName = this.ComponentNameMyControl.valueChanges.subscribe(value => { this._ngTaggedComponentName = value })

  _ngUpdateInProgress = null;
  onUpdateClick() {
    //let tempActionCount = this._ngComponentNameList.filter(eachItem => eachItem == this._ngTaggedComponentName).length;
    if (1 == 1) {
      let editSubmitBody: any = {
        checkpoint_name: this._ngCheckpointName,
        checkpoint_desc: this._ngCheckpointDesc,
        component_name: this._ngTaggedComponentName,
        active: this._ngCheckpointActiveFlag,
        project_name: this._ngProjectName,
        updated_by: "layyakannu"
      }
      this._ngUpdateInProgress = true;
      let subs2: Subscription = this.http.putCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_CHECKPOINT_UPDATE, editSubmitBody).subscribe(response => {
        subs2.unsubscribe();
        let result: any = response;
        this._ngUpdateInProgress = false;
        if (result.status && result.status == "success") {
          if (result.code && result.code == "201") {
            this.notify('error', 'Checkpoint Edit', 'No Rows Updated');
          } else {
            this.notify('success', 'Checkpoint Edit', 'Success');
            this.dialogRef.close("success");
          }
        } else
          this.notify('error', 'Checkpoint Edit', 'Failed : ' + result.reason);
      },
        error => {
          this._ngUpdateInProgress = false;
          this.notify('error', 'Checkpoint Edit', 'Failed : ' + error.message);
        });
    } else {
      // this.notify('error', 'Component Invalid Selection', 'Choose a Valid Item');
      // this.ComponentNameMyControl.setValue('');
      // this._ngTaggedComponentName = "";
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 5000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }


}
