import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-rule',
  templateUrl: './create-rule.component.html',
  styleUrls: ['./create-rule.component.css']
})
export class CreateRuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
