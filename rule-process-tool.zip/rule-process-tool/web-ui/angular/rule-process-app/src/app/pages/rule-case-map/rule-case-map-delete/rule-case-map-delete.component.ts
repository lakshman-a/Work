import { Component, Inject } from '@angular/core';
import { AppConfig } from './../../../app-config.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpTemplateService } from './../../../service/template/http-template.service';

import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-rule-case-map-delete',
  templateUrl: './rule-case-map-delete.component.html',
  styleUrls: ['./rule-case-map-delete.component.css']
})
export class RuleCaseMapDeleteComponent {

  _ngCaseName = null;
  _ngRuleName = null;

  constructor(
    public dialogRef: MatDialogRef<RuleCaseMapDeleteComponent>, private http: HttpTemplateService, private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this._ngCaseName = data['caseName'];
    this._ngRuleName = data['ruleName'];
  }
  _isActionInProgress = null;
  onDeleteClick() {
    let deleteRuleBody: any = {
      caseName: this._ngCaseName,
      ruleName: this._ngRuleName,
      updated_by: "layyakannu"
    }
    this._isActionInProgress = true;
    let subs2: Subscription = this.http.deleteCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_RULECASE_MAP_MODIFY, deleteRuleBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      this._isActionInProgress = false;
      if (result.status && result.status == "success") {
        this.notify('success', 'Rule Case Map Delete', 'Success');
        this.dialogRef.close("success");
      } else
        this.notify('error', 'Rule Case Map Delete', 'Failed : ' + result.reason);
    },
      error => {
        this._isActionInProgress = false;
        this.notify('error', 'Rule Case Map Delete', 'Error : ' + error.message);
      });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 5000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
