import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RuleValidationComponent } from './rule-validation.component';

describe('RuleValidationComponent', () => {
  let component: RuleValidationComponent;
  let fixture: ComponentFixture<RuleValidationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RuleValidationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RuleValidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
