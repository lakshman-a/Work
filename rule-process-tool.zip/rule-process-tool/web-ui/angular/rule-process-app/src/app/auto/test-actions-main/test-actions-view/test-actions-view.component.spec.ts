import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestActionsViewComponent } from './test-actions-view.component';

describe('TestActionsViewComponent', () => {
  let component: TestActionsViewComponent;
  let fixture: ComponentFixture<TestActionsViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestActionsViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestActionsViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
