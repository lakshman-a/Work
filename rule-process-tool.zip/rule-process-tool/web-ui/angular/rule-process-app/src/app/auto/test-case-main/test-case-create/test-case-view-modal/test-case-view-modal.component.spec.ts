import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestCaseViewModalComponent } from './test-case-view-modal.component';

describe('TestCaseViewModalComponent', () => {
  let component: TestCaseViewModalComponent;
  let fixture: ComponentFixture<TestCaseViewModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestCaseViewModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestCaseViewModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
