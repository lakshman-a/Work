import { AppConfig } from './../../../../app-config.service';
import { HttpTemplateService } from './../../../../service/template/http-template.service';
import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-suite-tag-edit-modal',
  templateUrl: './suite-tag-edit-modal.component.html',
  styleUrls: ['./suite-tag-edit-modal.component.css']
})
export class SuiteTagEditModalComponent implements OnInit {

  _ngEditApiData = null;
  _ngEditSuiteName = null;

  constructor(
    public dialogRef: MatDialogRef<SuiteTagEditModalComponent>, private http: HttpTemplateService, private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any) {

    this._ngEditApiData = data;
    this._ngEditSuiteName = data['test_suite_name'];
    this._ngSUiteTagCasesStepNum = data['test_case_num'];
    this._ngSuiteTagCaseName = data['test_case_name'];
    this.casesFormControl.setValue(data['test_case_name']);
    if (data['active'] == 'true') { this._ngSuiteTagCaseActiveFlag = true; }
    else if (data['active'] == 'false') { this._ngSuiteTagCaseActiveFlag = false; }
  }

  ngOnInit() {
    let subs2: Subscription = this.http.getCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_TESTSUITE_CASE_LIST).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      if (result['testCases']) {
        this._ngCasesNameList = result['testCases']

        this.casesNameFilteredOptions = this.casesFormControl.valueChanges
          .pipe(
            startWith(''),
            map(value => this._caseNameFilter(value))
          );
      } else {
        this.notify('error', 'Testcase List Failed', 'List is NULL or Empty.');
      }
    },
      error => {
        this.notify('error', 'Testcase List Failed', 'Failed : ' + error.message);
      });

    //this.casesFormControl.reset({ value: '', disabled: true });
  }

  _ngCasesNameList: string[];
  casesFormControl = new FormControl();
  casesNameFilteredOptions: Observable<string[]>;
  _ngSUiteTagCasesStepNum = null;
  _ngSuiteTagCaseName = null;
  _ngSuiteTagCaseActiveFlag = true;

  private _caseNameFilter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this._ngCasesNameList.filter(option => option.toLowerCase().includes(filterValue));
  }

  getCaseName = this.casesFormControl.valueChanges.subscribe(value => { this._ngSuiteTagCaseName = value })

  _isActionInProgress = null;
  onUpdateClick() {
    let tempActionCount = this._ngCasesNameList.filter(eachItem => eachItem == this._ngSuiteTagCaseName).length;
    if (tempActionCount == 1) {
      // Service Call
      let editTagCase: any = {
        test_suite_name: this._ngEditSuiteName,
        test_case_num: this._ngSUiteTagCasesStepNum,
        test_case_name: this._ngSuiteTagCaseName,
        active: this._ngSuiteTagCaseActiveFlag,
        created_by: "layyakannu",
        updated_by: "layyakannu",
      }
      this._isActionInProgress = true;
      let subs2: Subscription = this.http.putCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_TESTSUITE_TRN_MODIFY, editTagCase).subscribe(response => {
        subs2.unsubscribe();
        let result: any = response;
        this._isActionInProgress = false;
        if (result.status && result.status == "success") {
          this.notify('success', 'Edit Tagged Case', 'Success');
          this.dialogRef.close("success");
        } else
          this.notify('error', 'Edit Tagged Case', 'Failed : ' + result.reason);
      },
        error => {
          this._isActionInProgress = false;
          this.notify('error', 'Edit Tagged Case', 'Failed : ' + error.message);
        });

    } else {
      this.notify('error', 'Action Invalid Selection', 'Choose a Valid Item');
      this.casesFormControl.setValue('');
      this._ngSuiteTagCaseName = "";
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 5000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }
}
