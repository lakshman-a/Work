import { TriggerAyncModalComponent } from './../../test-trigger/trigger-aync-modal/trigger-aync-modal.component';
import { SuiteTagViewModalComponent } from './suite-tag-view-modal/suite-tag-view-modal.component';
import { HttpParams } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { HttpTemplateService } from './../../../service/template/http-template.service';
import { Subscription } from 'rxjs';
import { AppConfig } from './../../../app-config.service';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material';
import { SuiteTagDeleteModalComponent } from './suite-tag-delete-modal/suite-tag-delete-modal.component';
import { SuiteTagEditModalComponent } from './suite-tag-edit-modal/suite-tag-edit-modal.component';
import { TestTriggerModalComponent } from '../../test-trigger/test-trigger-modal/test-trigger-modal.component';
import { TriggerResultModalComponent } from '../../test-trigger/trigger-result-modal/trigger-result-modal.component';

export interface TestSuiteTrn {
  id: string;
  test_suite_name: string;
  test_case_num: string;
  test_case_name: string;
  active: string;
  created_tmstmp: string;
  created_by: string;
  updated_tmstmp: string;
  updated_by: string;
}

@Component({
  selector: 'app-test-suite-tag',
  templateUrl: './test-suite-tag.component.html',
  styleUrls: ['./test-suite-tag.component.css']
})
export class TestSuiteTagComponent implements OnInit {

  constructor(private spinner: NgxSpinnerService,
    private http: HttpTemplateService,
    private toastr: ToastrService,
    public dialog: MatDialog) {
  }

  // ----------- TOGGLE Action -------------- //
  searchTestSuiteHeaderToggle = true;
  tagCasesHeaderToggle = true;
  suiteToCaseHeaderToggle = true;

  onSearchSuiteHeaderClick() {
    this.searchTestSuiteHeaderToggle = !this.searchTestSuiteHeaderToggle;
  }

  onTagCasesHeaderClick() {
    this.tagCasesHeaderToggle = !this.tagCasesHeaderToggle;
  }

  onSuiteToCasesHeaderClick() {
    this.suiteToCaseHeaderToggle = !this.suiteToCaseHeaderToggle;
  }
  // ----------- TOGGLE Action End -------------- //

  ngOnInit() {
    this.spinner.show();
    let subs2: Subscription = this.http.getCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_TESTSUITE_CASE_LIST).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      this.spinner.hide();
      if (result['testSuites'] && result['testCases']) {
        this._ngTestSuiteList = result['testSuites']
        this._ngCasesNameList = result['testCases']
        this.testsuiteFilteredOptions = this.testSuiteControl.valueChanges
          .pipe(
            startWith(''),
            map(value => this._testcaseNamefilter(value))
          );
        this.casesNameFilteredOptions = this.casesFormControl.valueChanges
          .pipe(
            startWith(''),
            map(value => this._actionNameFilter(value))
          );
      } else {
        this.notify('error', 'Testcase and Actions List Failed', 'List is NULL or Empty.');
      }

    },
      error => {
        this.spinner.hide();
        this.notify('error', 'Case Create', 'Failed : ' + error.message);
      });

    this.casesFormControl.reset({ value: '', disabled: true });
    //this.testcaseNameMyControl.reset({ value: '', disabled: true })
  }

  // ----------------------- SEARCH TestSuite ------------------------//
  _ngTagSearchTestSuiteName = "";
  _ngSearchTestSuiteSuccess = false;

  testSuiteControl = new FormControl();
  _ngTestSuiteList: string[];
  testsuiteFilteredOptions: Observable<string[]>;

  private _testcaseNamefilter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this._ngTestSuiteList.filter(option => option.toLowerCase().includes(filterValue));
  }

  getTestSuiteName = this.testSuiteControl.valueChanges.subscribe(value => { this._ngTagSearchTestSuiteName = value })

  onSearchedTestSuiteSubmit() {
    let tempTestSuiteCount = this._ngTestSuiteList.filter(eachItem => eachItem == this._ngTagSearchTestSuiteName).length;
    if (tempTestSuiteCount == 1) {
      this._ngSearchTestSuiteSuccess = true;
      //Load the Data for the Tagged Actions for testcase Table
      this.getTaggedCasesForSuite();
      this.casesFormControl.reset({ value: '', disabled: false });
      this.testSuiteControl.reset({ value: this._ngTagSearchTestSuiteName, disabled: true });
    } else {
      this._ngSearchTestSuiteSuccess = false;
      this.notify('error', 'Invalid Selection', 'Choose a Valid Item');
      this.testSuiteControl.setValue('');
      this._ngTagSearchTestSuiteName = null;

    }
  }

  onSearchedTestSuiteReset() {
    this._ngTagSearchTestSuiteName = null;
    this._ngSearchTestSuiteSuccess = false;
    this.testSuiteControl.reset({ value: '', disabled: false });
    this.casesFormControl.reset({ value: '', disabled: true });
    this.OnSuiteTagCaseReset();
  }

  // ----------------------- TAGGING ACTIONS ------------------------//
  _ngCasesNameList: string[];
  casesFormControl = new FormControl();
  casesNameFilteredOptions: Observable<string[]>;
  _ngNewTagCaseInProgress = null;

  _ngSUiteTagCasesStepNum = null;
  _ngSuiteTagCaseName = null;
  _ngSuiteTagCaseActiveFlag = true;

  private _actionNameFilter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this._ngCasesNameList.filter(option => option.toLowerCase().includes(filterValue));
  }

  getCaseName = this.casesFormControl.valueChanges.subscribe(value => { this._ngSuiteTagCaseName = value })

  onSuiteNewTagCaseSubmit() {
    let tempCaseCount = this._ngCasesNameList.filter(eachItem => eachItem == this._ngSuiteTagCaseName).length;
    if (tempCaseCount == 1) {
      // Service Call
      let newTagCase: any = {
        test_suite_name: this._ngTagSearchTestSuiteName,
        test_case_num: this._ngSUiteTagCasesStepNum,
        test_case_name: this._ngSuiteTagCaseName,
        active: this._ngSuiteTagCaseActiveFlag,
        created_by: "layyakannu",
        updated_by: "layyakannu",
      }
      this._ngNewTagCaseInProgress = true;
      let subs2: Subscription = this.http.postCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_TESTSUITE_TRN_MODIFY, newTagCase).subscribe(response => {
        subs2.unsubscribe();
        let result: any = response;

        this._ngNewTagCaseInProgress = false;
        if (result.status && result.status == "success") {
          this.OnSuiteTagCaseReset();
          this.getTaggedCasesForSuite();
          this.notify('success', 'Tag Cases to Suite', 'Success');
        } else
          this.notify('error', 'Tag Cases to Suite', 'Failed : ' + result.reason);
      },
        error => {
          this._ngNewTagCaseInProgress = false;
          this.notify('error', 'Tag Cases to Suite', 'Failed : ' + error.message);
        });

    } else {
      this.notify('error', 'Action Invalid Selection', 'Choose a Valid Item');
      this.casesFormControl.setValue('');
      this._ngSuiteTagCaseName = "";
    }
  }

  OnSuiteTagCaseReset() {
    this._ngSUiteTagCasesStepNum = "";
    this.casesFormControl.setValue('');
    this._ngSuiteTagCaseName = "";
    this._ngSuiteTagCaseActiveFlag = true;
    this._ngNewTagCaseInProgress = null;
  }

  // ----------------------- DISPLAY CASE TO ACTIONS TABLE ------------------------//

  //MAT:
  displayedColumns: string[] = ['test_case_num', 'test_case_name', 'active', 'updated_by', 'updated_tmstmp', 'action'];
  dataSource: MatTableDataSource<TestSuiteTrn>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  _ngTaggedCasesLength = null;

  getTaggedCasesForSuite() {
    let params = new HttpParams().set('suiteName', this._ngTagSearchTestSuiteName);
    let subs: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_API_TESTSUITE_TRN_LIST, params).subscribe(response => {
      subs.unsubscribe;
      let result: any = response;
      this._ngTaggedCasesLength = result.length;
      this.dataSource = new MatTableDataSource(result);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this.notify('error', 'Tagged Actions', 'Error occured while Loading List : ' + error.message);
    });
  }

  //MAT:
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  //EDIT MODAL FEATURE
  openEditDialog(row): void {
    const dialogRef = this.dialog.open(SuiteTagEditModalComponent, {
      width: '900px',
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {

      console.log(result);
      console.log("delete modal Dialogs closed!");
      if (result == 'success') {
        console.log("Result is success so refresing grif!");
        this.getTaggedCasesForSuite();
      }
    });
  }

  //DELETE MODAL FEATURE
  openDeleteDialog(row): void {
    const dialogRef2 = this.dialog.open(SuiteTagDeleteModalComponent, {
      width: '700px',
      data: row
    });

    dialogRef2.afterClosed().subscribe(result => {
      console.log(result);
      console.log("delete modal Dialogs closed!");
      if (result == 'success') {
        console.log("Result is success so refresing grif!");
        this.getTaggedCasesForSuite();
      }
    });
  }

  //View MODAL FEATURE
  openViewDialog(row): void {
    const dialogRef3 = this.dialog.open(SuiteTagViewModalComponent, {
      width: '700px',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
    });
  }

  //View MODAL FEATURE
  openTriggerResultDialog(row): void {
    const dialogRef3 = this.dialog.open(TriggerResultModalComponent, {
      width: '1200px',
      maxHeight: 'calc(100vh - 120px)',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
    });
  }

  //View MODAL FEATURE
  openTriggerRunIdDialog(row): void {
    const dialogRef3 = this.dialog.open(TriggerAyncModalComponent, {
      width: '800px',
      //maxHeight: 'calc(100vh - 120px)',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
    });
  }

  //RUN MODAL FEATURE
  runTestDialog(): void {
    let row: any = {
      test_suite_name: this._ngTagSearchTestSuiteName
    }
    const dialogRef = this.dialog.open(TestTriggerModalComponent, {
      width: '500px',
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log("Trigger RUn Dialog closed");
      console.log(result);
      if (result && result['status'] == 'success' && result['triggerType'] == 'sync') {
        this.openTriggerResultDialog(result);
      }
      if (result && result['status'] == 'success' && result['triggerType'] == 'async') {
        this.openTriggerRunIdDialog(result);
      }
    });
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 6000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
