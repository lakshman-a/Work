import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-suite-main',
  templateUrl: './test-suite-main.component.html',
  styleUrls: ['./test-suite-main.component.css']
})
export class TestSuiteMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
