import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-test-case-view-modal',
  templateUrl: './test-case-view-modal.component.html',
  styleUrls: ['./test-case-view-modal.component.css']
})
export class TestCaseViewModalComponent  {
  
  _ngViewTestcaseDesc = null;
  constructor(
    public dialogRef: MatDialogRef<TestCaseViewModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this._ngViewTestcaseDesc = data['caseSteps'];
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
