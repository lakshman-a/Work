import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestCaseReportsComponent } from './test-case-reports.component';

describe('TestCaseReportsComponent', () => {
  let component: TestCaseReportsComponent;
  let fixture: ComponentFixture<TestCaseReportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestCaseReportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestCaseReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
