import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestCaseMainComponent } from './test-case-main.component';

describe('TestCaseMainComponent', () => {
  let component: TestCaseMainComponent;
  let fixture: ComponentFixture<TestCaseMainComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestCaseMainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestCaseMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
