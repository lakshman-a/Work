import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestReportMainComponent } from './test-report-main.component';

describe('TestReportMainComponent', () => {
  let component: TestReportMainComponent;
  let fixture: ComponentFixture<TestReportMainComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestReportMainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestReportMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
