import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestSuiteMainComponent } from './test-suite-main.component';

describe('TestSuiteMainComponent', () => {
  let component: TestSuiteMainComponent;
  let fixture: ComponentFixture<TestSuiteMainComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestSuiteMainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestSuiteMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
