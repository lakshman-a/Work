import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseTagViewModalComponent } from './case-tag-view-modal.component';

describe('CaseTagViewModalComponent', () => {
  let component: CaseTagViewModalComponent;
  let fixture: ComponentFixture<CaseTagViewModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaseTagViewModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseTagViewModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
