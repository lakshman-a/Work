import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuiteTagDeleteModalComponent } from './suite-tag-delete-modal.component';

describe('SuiteTagDeleteModalComponent', () => {
  let component: SuiteTagDeleteModalComponent;
  let fixture: ComponentFixture<SuiteTagDeleteModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuiteTagDeleteModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuiteTagDeleteModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
