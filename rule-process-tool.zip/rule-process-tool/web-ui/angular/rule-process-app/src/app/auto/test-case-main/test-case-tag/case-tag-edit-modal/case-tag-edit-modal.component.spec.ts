import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseTagEditModalComponent } from './case-tag-edit-modal.component';

describe('CaseTagEditModalComponent', () => {
  let component: CaseTagEditModalComponent;
  let fixture: ComponentFixture<CaseTagEditModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaseTagEditModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseTagEditModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
