import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuiteTagViewModalComponent } from './suite-tag-view-modal.component';

describe('SuiteTagViewModalComponent', () => {
  let component: SuiteTagViewModalComponent;
  let fixture: ComponentFixture<SuiteTagViewModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuiteTagViewModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuiteTagViewModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
