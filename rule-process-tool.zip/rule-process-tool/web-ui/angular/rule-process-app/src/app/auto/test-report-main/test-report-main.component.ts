import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-report-main',
  templateUrl: './test-report-main.component.html',
  styleUrls: ['./test-report-main.component.css']
})
export class TestReportMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
