import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TriggerAyncModalComponent } from './trigger-aync-modal.component';

describe('TriggerAyncModalComponent', () => {
  let component: TriggerAyncModalComponent;
  let fixture: ComponentFixture<TriggerAyncModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TriggerAyncModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TriggerAyncModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
