import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestActionsCreateComponent } from './test-actions-create.component';

describe('TestActionsCreateComponent', () => {
  let component: TestActionsCreateComponent;
  let fixture: ComponentFixture<TestActionsCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestActionsCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestActionsCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
