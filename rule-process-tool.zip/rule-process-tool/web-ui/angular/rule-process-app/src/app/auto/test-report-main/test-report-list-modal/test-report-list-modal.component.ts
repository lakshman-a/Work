
import { HttpTemplateService } from './../../../service/template/http-template.service';
import { AppConfig } from './../../../app-config.service';

import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { ToastrService } from 'ngx-toastr';

import { Subscription } from 'rxjs';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpParams } from '@angular/common/http';
import { Component, ViewChild, Inject, OnInit } from '@angular/core';

export interface ReportDataNew {
  id: string;
  run_id: string;
  run_level: string;
  test_name?: string;
  stage?: any;
  case_count?: any;
  status: string;
  result: string;
  report_file?: any;
  comments?: any;
  grid_url: string;
  browser?: any;
  triggered_by?: any;
  triggered_tmstmp?: any;
  percentComplete: string;
}

@Component({
  selector: 'app-test-report-list-modal',
  templateUrl: './test-report-list-modal.component.html',
  styleUrls: ['./test-report-list-modal.component.css']
})
export class TestReportListModalComponent implements OnInit {

  _apiRunDetails = null;
  _isApiResultInProgress = null;
  _viewReportHostUri = null;
  _saveReportHostUri = null;
  _testType = null;
  _testName = null;

  constructor(
    public dialogRef: MatDialogRef<TestReportListModalComponent>,
    private http: HttpTemplateService,
    private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    console.log(data);
    this._apiRunDetails = data;
    if (data['caseName']) {
      this._testType = 'Testcase';
      this._testName = data['caseName'];
    }
    if (data['test_suite_name']) {
      this._testType = 'TestSuite';
      this._testName = data['test_suite_name'];
    }
    console.log("Test Type is : " + this._testType);
    console.log("TestName is : " + this._testName);
  }

  //MAT:
  displayedColumns: string[] = ['run_id', 'test_name', 'case_count', 'status', 'result', 'report_file', 'triggered_by', 'triggered_tmstmp'];
  dataSource: MatTableDataSource<ReportDataNew>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  ngOnInit() {

    this._isApiResultInProgress = true;
    this._viewReportHostUri = AppConfig.API_HOST + AppConfig.DB_API_OPEN_HTML_REPORT_RUN_ID;
    this._saveReportHostUri = AppConfig.API_HOST + AppConfig.DB_API_SAVE_HTML_REPORT_RUN_ID;

    let params = new HttpParams().set('type', this._testType).set('name', this._testName);
    let subs: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_API_TEST_SUITE_NAME_REPORT, params).subscribe(response => {
      subs.unsubscribe;
      this._isApiResultInProgress = false;
      let result: any = response;
      this.dataSource = new MatTableDataSource(result);
      setTimeout(() => this.dataSource.paginator = this.paginator);
     // this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this._isApiResultInProgress = false;
      this.notify('error', 'Test History', 'Error occured while Loading Details : ' + error.message);
    });

  }

  actionsGridRefreshCall() {
    let params = new HttpParams().set('type', this._testType).set('name', this._testName);
    let subs: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_API_TEST_SUITE_NAME_REPORT, params).subscribe(response => {
      subs.unsubscribe;
      let result: any = response;
      this.dataSource = new MatTableDataSource(result);
      setTimeout(() => this.dataSource.paginator = this.paginator);
      //this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this.notify('error', 'Test History', 'Error occured while Refreshing Actions List : ' + error.message);
    });
  }

  //MAT:
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }


  
  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 6000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
