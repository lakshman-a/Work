import { HttpParams } from '@angular/common/http';
import { Validators, FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { HttpTemplateService } from './../../../service/template/http-template.service';
import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { AppConfig } from './../../../app-config.service';

@Component({
  selector: 'app-test-actions-create',
  templateUrl: './test-actions-create.component.html',
  styleUrls: ['./test-actions-create.component.css']
})
export class TestActionsCreateComponent implements OnInit {

  _ngProjectName = "Default";
  _componentListApiresponse = null;
  _componentList: string[];
  _checkpointList: string[]
  _ngHttpActionList: string[] = ['GET', 'POST', 'PUT', 'DELETE'];
  _ngAddActionURLOptionsList: string[] = ['URL', 'STAGE'];
  _ngCompListLoadInProgress = null;

  constructor(private http: HttpTemplateService, private toastr: ToastrService) { }

  ngOnInit() {
    let params = new HttpParams().set('projectName', this._ngProjectName);
    this._ngCompListLoadInProgress = true;
    let subs2: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_API_COMPONENTS_LIST, params).subscribe(response => {
      subs2.unsubscribe;
      this._ngCompListLoadInProgress = false;
      let result: any = response;
      this._componentListApiresponse = result;
      this._componentList = result.map(eachItem => eachItem.component);
    }, error => {
      this._ngCompListLoadInProgress = false;
      this.notify('error', 'Component Details', 'Error occured while Loadings Rules : ' + error.message);
    });
  }

  actionNameFormControl = new FormControl('', [
    Validators.required
  ]);
  actionDescFormControl = new FormControl('', [
    Validators.required
  ]);

  //Action Details
  _ngAddActionName
  _ngAddActionDesc

  //Request Details
  _ngAddActionHttp = 'POST';
  _ngAddActionOption = 'URL';
  _ngAddActionHttpURL = null;
  _ngAddActionHttpType = null;
  _ngAddActionHttpStage = "msmaster.qa.paypal.com";
  _ngAddActionHttpPort = null;
  _ngAddActionHttpURI = null;
  _ngAddRequestComponent = null;
  _ngAddRequestCheckpoint = null;
  _ngHeaderDetails: any[] = [{ key: "Content-Type", value: "application/json" }, { key: "Accept", value: "application/json" }, { key: "", value: "" }];
  _ngAddRequestBody = null;
  _ngRequestParams: any[] = [{ paramType: 'runtime', paramName: "", paramValue: "" }, { paramType: 'runtime', paramName: "", paramValue: "" }, { paramType: 'runtime', paramName: "", paramValue: "" }, { paramType: 'runtime', paramName: "", paramValue: "" }, { paramType: 'runtime', paramName: "", paramValue: "" }];

  //Response Details
  _ngResponseCodeFlag = true;
  _ngResponseCodeValue = "200";
  _ngResponseAction = 'extractSaveResponse';
  _ngResponseBody = null;
  _ngResponseBuildAssertParams: any[] = [{ paramType: 'runtime', paramName: "", paramValue: "" }, { paramType: 'runtime', paramName: "", paramValue: "" }, { paramType: 'runtime', paramName: "", paramValue: "" }, { paramType: 'runtime', paramName: "", paramValue: "" }, { paramType: 'runtime', paramName: "", paramValue: "" }];
  _ngResponseExtractSaveParams: any[] = [{ jsonPath: "", jsonValue: "", variable: "" }, { jsonPath: "", jsonValue: "", variable: "" }, { jsonPath: "", jsonValue: "", variable: "" }, { jsonPath: "", jsonValue: "", variable: "" }, { jsonPath: "", jsonValue: "", variable: "" }];

  onComponentChange(component: any) {
    if(component){
      this._checkpointList = this._componentListApiresponse.filter(eachItem => eachItem.component === component)[0].checkpoints;
    }
    this._ngAddRequestCheckpoint = null;
  }

  _ngNewAddActionInProgress = null;
  onNewActionSubmit() {
    if (this.actionDescFormControl.untouched && !this._ngAddActionDesc) {
      this.actionDescFormControl.markAsTouched();
      this.notifyWithTime('error', 2000, 'Mandatory field Missing', 'Description');
      return;
    }
    let newActionSubmitBody: any = {
      actionName: this._ngAddActionName,
      actionDesc: this._ngAddActionDesc,
      componentName: this._ngAddRequestComponent,
      checkpointName: this._ngAddRequestCheckpoint,
      projectName: this._ngProjectName,
      httpMethod: this._ngAddActionHttp,
      httpUrlFlag: this._ngAddActionOption,
      httpUrl: this._ngAddActionHttpURL,
      httpStageProtocol: this._ngAddActionHttpType,
      httpStageName: this._ngAddActionHttpStage,
      httpStagePort: this._ngAddActionHttpPort,
      httpStageUri: this._ngAddActionHttpURI,
      headers: JSON.stringify(this._ngHeaderDetails.filter(eachItem => eachItem['key'] != "")),
      requestBody: this._ngAddRequestBody,
      requestParams: JSON.stringify(this._ngRequestParams.filter(eachItem => eachItem['paramName'] != "")),
      responseAction: this._ngResponseAction,
      responseBody: this._ngResponseBody,
      responseCodeFlag: this._ngResponseCodeFlag,
      responseCodeValue: this._ngResponseCodeValue,
      responseStatusFlag: "false",
      responseStatusValue: null,
      responseAssertParams: JSON.stringify(this._ngResponseBuildAssertParams.filter(eachItem => eachItem['paramName'] != "")),
      responseExtractParams: JSON.stringify(this._ngResponseExtractSaveParams.filter(eachItem => eachItem['jsonPath'] != "")),
      active: "true",
      created_by: "layyakannu",
      updated_by: "layyakannu"
    }

    this._ngNewAddActionInProgress = true;
    let subs2: Subscription = this.http.postCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_POST_API_NEW_TEST_ACTION, newActionSubmitBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      this._ngNewAddActionInProgress = false;
      if (result.status && result.status == "success") {
        this.onNewActionReset();
        this.notify('success', 'Action Create', 'Success');
      } else
        this.notify('error', 'Action Create', 'Failed : ' + result.reason);
    },
      error => {
        this._ngNewAddActionInProgress = false;
        this.notify('error', 'Action Create', 'Failed : ' + error.message);
      });
  }

  onNewActionReset() {
    this._ngAddActionName = null;
    this._ngAddActionDesc = null;
    this._ngAddRequestComponent = null;
    this._ngAddRequestCheckpoint = null;
    this._ngAddActionHttp = 'POST';
    this._ngAddActionOption = 'URL';
    this._ngAddActionHttpURL = null;
    this._ngAddActionHttpType = null;
    this._ngAddActionHttpStage = "msmaster.qa.paypal.com";
    this._ngAddActionHttpPort = null;
    this._ngAddActionHttpURI = null;
    this._ngResponseCodeFlag = true;
    this._ngResponseCodeValue = "200";
    this._ngHeaderDetails = [{ key: "Content-Type", value: "application/json", description: "" }, { key: "Accept", value: "application/json", description: "" }, { key: "", value: "", description: "" }];
    this._ngAddRequestBody = null;
    this._ngRequestParams = [{ paramType: 'runtime', paramName: "", paramValue: "" }, { paramType: 'runtime', paramName: "", paramValue: "" }, { paramType: 'runtime', paramName: "", paramValue: "" }, { paramType: 'runtime', paramName: "", paramValue: "" }, { paramType: 'runtime', paramName: "", paramValue: "" }];
    this._ngResponseAction = 'extractSaveResponse';
    this._ngResponseBody = null;
    this._ngResponseBuildAssertParams = [{ paramType: 'runtime', paramName: "", paramValue: "" }, { paramType: 'runtime', paramName: "", paramValue: "" }, { paramType: 'runtime', paramName: "", paramValue: "" }, { paramType: 'runtime', paramName: "", paramValue: "" }, { paramType: 'runtime', paramName: "", paramValue: "" }];
    this._ngResponseExtractSaveParams = [{ jsonPath: "", jsonValue: "", variable: "" }, { jsonPath: "", jsonValue: "", variable: "" }, { jsonPath: "", jsonValue: "", variable: "" }, { jsonPath: "", jsonValue: "", variable: "" }, { jsonPath: "", jsonValue: "", variable: "" }];
    this.actionNameFormControl.markAsUntouched();
    this.actionDescFormControl.markAsUntouched();
  }

  extractValues() {
    console.log("Extract values button clicked. To be implemented!");
  }

  // ----------- PARAMETER ADDITION -------------- //
  actionDetailsHeaderToggle = true;
  actionRequestHeaderToggle = true;
  actionResponseHeaderToggle = true;

  addRequestParamLine() {
    this._ngRequestParams.push({ paramType: 'runtime', paramName: "", paramValue: "" });
  }

  removeRequestParmaLine(param) {
    this._ngRequestParams = this._ngRequestParams.filter(item => item !== param);
  }

  addResponseParamLine() {
    this._ngResponseBuildAssertParams.push({ paramType: 'runtime', paramName: "", paramValue: "" });
  }

  removeResponseParmaLine(param) {
    this._ngResponseBuildAssertParams = this._ngResponseBuildAssertParams.filter(item => item !== param);
  }

  addResponseExtractLine() {
    this._ngResponseExtractSaveParams.push({ jsonPath: "", jsonValue: "", variable: "" });
  }

  removeResponseExtractLine(param) {
    this._ngResponseExtractSaveParams = this._ngResponseExtractSaveParams.filter(item => item !== param);
  }

  addHeader() {
    this._ngHeaderDetails.push({ key: "", value: "" });
  }

  removeHeader(headerDetail) {
    this._ngHeaderDetails = this._ngHeaderDetails.filter(item => item !== headerDetail);
  }

  // ----------- TOGGLE Action -------------- //

  onActionDetailsClick() {
    this.actionDetailsHeaderToggle = !this.actionDetailsHeaderToggle;
  }


  onRequestDetailsClick() {
    this.actionRequestHeaderToggle = !this.actionRequestHeaderToggle;
  }

  onResponseDetailsClick() {
    this.actionResponseHeaderToggle = !this.actionResponseHeaderToggle;
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 6000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

  notifyWithTime(status: string, sec: number, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: sec,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: sec,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: sec,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: sec,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
