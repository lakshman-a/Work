import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuiteCreateViewModalComponent } from './suite-create-view-modal.component';

describe('SuiteCreateViewModalComponent', () => {
  let component: SuiteCreateViewModalComponent;
  let fixture: ComponentFixture<SuiteCreateViewModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuiteCreateViewModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuiteCreateViewModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
