import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestActionsMainComponent } from './test-actions-main.component';

describe('TestActionsMainComponent', () => {
  let component: TestActionsMainComponent;
  let fixture: ComponentFixture<TestActionsMainComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestActionsMainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestActionsMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
