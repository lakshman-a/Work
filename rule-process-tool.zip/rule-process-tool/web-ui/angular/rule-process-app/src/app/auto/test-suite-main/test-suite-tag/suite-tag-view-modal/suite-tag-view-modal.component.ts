import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-suite-tag-view-modal',
  templateUrl: './suite-tag-view-modal.component.html',
  styleUrls: ['./suite-tag-view-modal.component.css']
})
export class SuiteTagViewModalComponent {

  constructor(
    public dialogRef: MatDialogRef<SuiteTagViewModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
