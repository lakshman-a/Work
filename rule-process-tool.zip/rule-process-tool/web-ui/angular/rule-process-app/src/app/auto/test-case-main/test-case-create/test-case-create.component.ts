import { HttpParams } from '@angular/common/http';
import { TestCaseViewModalComponent } from './test-case-view-modal/test-case-view-modal.component';
import { TestCaseDeleteModalComponent } from './test-case-delete-modal/test-case-delete-modal.component';
import { TestCaseEditModalComponent } from './test-case-edit-modal/test-case-edit-modal.component';
import { ToastrService } from 'ngx-toastr';
import { HttpTemplateService } from './../../../service/template/http-template.service';
import { Subscription } from 'rxjs';
import { AppConfig } from './../../../app-config.service';

import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material';
import { TestTriggerModalComponent } from '../../test-trigger/test-trigger-modal/test-trigger-modal.component';
import { TriggerResultModalComponent } from '../../test-trigger/trigger-result-modal/trigger-result-modal.component';
import { TriggerAyncModalComponent } from '../../test-trigger/trigger-aync-modal/trigger-aync-modal.component';

export interface TestcaseDetails {
  id: string;
  caseName: string;
  caseSummary: string;
  caseSteps?: string;
  componentName: string;
  checkpointName?: string;
  projectName: string;
  moduleName?: string;
  subModuleName?: string;
  stage?: string;
  complexity?: number;
  isAutomationCase: string;
  runMode: string;
  isRuleBased: string;
  isEndToEndCase: string;
  isTestDataAvailable: string;
  active: string;
  created_tmstmp: string;
  created_by: string;
  updated_tmstmp: string;
  updated_by: string;
}

@Component({
  selector: 'app-test-case-create',
  templateUrl: './test-case-create.component.html',
  styleUrls: ['./test-case-create.component.css']
})
export class TestCaseCreateComponent implements OnInit {
  createTestcaseHeaderToggle = true;
  testcaseDetailsHeaderToggle = true;

  constructor(private http: HttpTemplateService, private toastr: ToastrService, public dialog: MatDialog) {
  }

  _ngCompListLoadInProgress = null;
  _ngTestcaseLoadInProgress = null;
  ngOnInit() {
    this._ngCompListLoadInProgress = true;
    let params = new HttpParams().set('projectName', this._ngProjectName);
    let subs2: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_API_COMPONENTS_LIST, params).subscribe(response => {
      subs2.unsubscribe;
      this._ngCompListLoadInProgress = false;
      let result: any = response;
      this._componentListApiresponse = result;
      this._componentList = result.map(eachItem => eachItem.component);
    }, error => {
      this._ngCompListLoadInProgress = false;
      this.notify('error', 'Component Details', 'Error occured while Loadings Rules : ' + error.message);
    });

    //Testcase GRID Data Load:
    this._ngTestcaseLoadInProgress = true;
    let subs: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_GET_API_TESTCASES, params).subscribe(response => {
      subs.unsubscribe;
      this._ngTestcaseLoadInProgress = false;
      let result: any = response;
      this.dataSource = new MatTableDataSource(result);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this._ngTestcaseLoadInProgress = false;
      this.notify('error', 'Testcase Details', 'Error occured while Loading List : ' + error.message);
    });
  }

  onComponentChange(component: any) {
    this._checkpointList = this._componentListApiresponse.filter(eachItem => eachItem.component === component)[0].checkpoints;
    this._ngAddCheckpointName=null;
  }


  // ----------- Main Body -------------- //

  _componentListApiresponse = null;
  _componentList: string[];
  _checkpointList: string[];

  //1. Testcase Details
  _ngAddTestcaseName = null;
  _ngAddTestcaseSummary = null;

  _ngAddComponentName = null;
  _ngAddCheckpointName = null;
  _ngProjectName = "Default";

  _ngAddModuleName = null;
  _ngAddSubModuleName = null;
  _ngAddTestcaseStage = null;
  _ngAddTestcaseJiraTagId = null;
  _ngAddTestcaseRuleBasedFlag = true;
  _ngAddTestcaseE2EFlag = false;
  _ngAddTestcaseActiveFlag = true;
  _ngAddTestcaseAutomationFlag = true;
  _ngNewTestcaseTagRuleList: string[] = ['', ''];
  _ngAddTestcaseSteps = null;
  _ngNewAddTestCaseInProgress = null;
  _isActionInProgress = null;
  _ngAddCaseTestDataFlag = true;
  _ngAddCaseTestDataColumn = ['Step', 'Description'];
  _ngAddCaseTestDataValues = [{ Step: '1', Description: 'Testdata Description' }];
  _ngAddTestcaseRunModeOptions: string[] = ['Serial', 'Parallel'];
  _ngAddTestcaseRunMode = 'Serial';
  _ngAddTestcaseTypeOptions: string[] = ['UI', 'API', 'DB', 'E2E', 'BATCH'];
  _ngAddTestcaseType = null;

  _ngAddNewTestcaseSubmit() {
    let newCaseSubmitBody: any = {
      caseName: this._ngAddTestcaseName,
      caseSummary: this._ngAddTestcaseSummary,
      caseSteps: this._ngAddTestcaseSteps,

      componentName: this._ngAddComponentName,
      checkpointName: this._ngAddCheckpointName,
      projectName: this._ngProjectName,

      moduleName: this._ngAddModuleName,
      subModuleName: this._ngAddSubModuleName,
      stage: this._ngAddTestcaseStage,
      complexity: "10",
      isAutomationCase: this._ngAddTestcaseAutomationFlag,
      runMode: this._ngAddTestcaseRunMode,
      isTestDataAvailable: this._ngAddCaseTestDataFlag,
      testDataColumns: JSON.stringify(this._ngAddCaseTestDataColumn),
      testDataValues: JSON.stringify(this._ngAddCaseTestDataValues),
      isRuleBased: this._ngAddTestcaseRuleBasedFlag,
      isEndToEndCase: this._ngAddTestcaseE2EFlag,
      // active: this._ngAddTestcaseActiveFlag,
      active: true,
      created_by: "layyakannu",
      updated_by: "layyakannu"
    }
    this._ngNewAddTestCaseInProgress = true;
    let subs2: Subscription = this.http.postCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_GET_POST_API_TESTCASE, newCaseSubmitBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;

      this._ngNewAddTestCaseInProgress = false;
      if (result.status && result.status == "success") {
        this._ngAddNewTestcaseReset();
        this.ruleGridRefreshCall();
        this.notify('success', 'Case Create', 'Success');
      } else
        this.notify('error', 'Case Create', 'Failed : ' + result.reason);
    },
      error => {
        this._ngNewAddTestCaseInProgress = false;
        this.notify('error', 'Case Create', 'Failed : ' + error.message);
      });
  }

  _ngAddNewTestcaseReset() {
    this._ngAddTestcaseName = null;
    this._ngAddTestcaseSummary = null;
    this._ngAddModuleName = null;
    this._ngAddSubModuleName = null;
    this._ngAddTestcaseStage = null;
    this._ngAddTestcaseRuleBasedFlag = true;
    this._ngAddTestcaseE2EFlag = false;
    this._ngAddTestcaseActiveFlag = true;
    this._ngNewTestcaseTagRuleList = ['', ''];
    this._ngAddTestcaseSteps = null;
    this._ngNewAddTestCaseInProgress = null;
    this._ngAddTestcaseRunMode = 'Serial';
    this._ngAddTestcaseAutomationFlag = true;
    this._ngAddComponentName = null;
    this._ngAddCheckpointName = null
    this._ngAddTestcaseJiraTagId = null;
  }

  //2. Testcase Details:
  //MAT:
  displayedColumns: string[] = ['run', 'caseName', 'componentName', 'checkpointName', 'isRuleBased', 'active', 'created_by', 'updated_tmstmp', 'action'];
  dataSource: MatTableDataSource<TestcaseDetails>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  ruleGridRefreshCall() {
    this._ngTestcaseLoadInProgress = true;
    let params = new HttpParams().set('projectName', this._ngProjectName);
    let subs: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_GET_API_TESTCASES, params).subscribe(response => {
      subs.unsubscribe;
      this._ngTestcaseLoadInProgress = false;
      let result: any = response;
      this.dataSource = new MatTableDataSource(result);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this._ngTestcaseLoadInProgress = false;
      this.notify('error', 'Testcase Details', 'Error occured while Loading List : ' + error.message);
    });
  }

  //MAT:
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  //EDIT MODAL FEATURE
  openEditDialog(row): void {
    const dialogRef = this.dialog.open(TestCaseEditModalComponent, {
      width: '800px',
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result == 'success') {
        this.ruleGridRefreshCall();
      }
    });
  }

  //DELETE MODAL FEATURE
  openDeleteDialog(row): void {
    const dialogRef2 = this.dialog.open(TestCaseDeleteModalComponent, {
      width: '700px',
      data: row
    });

    dialogRef2.afterClosed().subscribe(result => {
      if (result == 'success') {
        this.ruleGridRefreshCall();
      }
    });
  }

  //View MODAL FEATURE
  openViewDialog(row): void {
    const dialogRef3 = this.dialog.open(TestCaseViewModalComponent, {
      width: '1000px',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
    });
  }


  //View MODAL FEATURE
  openTriggerResultDialog(row): void {
    const dialogRef3 = this.dialog.open(TriggerResultModalComponent, {
      width: '1200px',
      maxHeight: 'calc(100vh - 120px)',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
    });
  }

  //View MODAL FEATURE
  openTriggerRunIdDialog(row): void {
    const dialogRef3 = this.dialog.open(TriggerAyncModalComponent, {
      width: '800px',
      //maxHeight: 'calc(100vh - 120px)',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
    });
  }

  //RUN MODAL FEATURE
  runTestDialog(row): void {
    const dialogRef = this.dialog.open(TestTriggerModalComponent, {
      width: '500px',
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result && result['status'] == 'success' && result['triggerType'] == 'sync') {
        this.openTriggerResultDialog(result);
      }
      if (result && result['status'] == 'success' && result['triggerType'] == 'async') {
        this.openTriggerRunIdDialog(result);
      }
    });
  }

  // ----------- TOGGLE Action -------------- //

  onCreateTestcaseHeaderClick() {
    this.createTestcaseHeaderToggle = !this.createTestcaseHeaderToggle;
  }

  onTestCaseDetailsClick() {
    this.testcaseDetailsHeaderToggle = !this.testcaseDetailsHeaderToggle;
  }

  // ----------- PARAMETER ADDITION -------------- //
  addTestcaseTagRuleLine() {
    this._ngNewTestcaseTagRuleList.push('');
  }

  removeTestcaseTagRuleLine(param) {
    this._ngNewTestcaseTagRuleList = this._ngNewTestcaseTagRuleList.filter(item => item !== param);
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 6000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }




}
