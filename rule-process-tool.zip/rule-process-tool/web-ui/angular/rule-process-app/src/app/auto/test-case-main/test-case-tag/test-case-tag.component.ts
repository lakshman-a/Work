import { TriggerAyncModalComponent } from './../../test-trigger/trigger-aync-modal/trigger-aync-modal.component';
import { TriggerResultModalComponent } from './../../test-trigger/trigger-result-modal/trigger-result-modal.component';
import { CaseTagViewModalComponent } from './case-tag-view-modal/case-tag-view-modal.component';
import { CaseTagDeleteModalComponent } from './case-tag-delete-modal/case-tag-delete-modal.component';
import { CaseTagEditModalComponent } from './case-tag-edit-modal/case-tag-edit-modal.component';
import { HttpParams } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { HttpTemplateService } from './../../../service/template/http-template.service';
import { Subscription } from 'rxjs';
import { AppConfig } from './../../../app-config.service';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material';
import { TestTriggerModalComponent } from '../../test-trigger/test-trigger-modal/test-trigger-modal.component';

export interface TestcaseTrnDetails {
  id: string;
  caseName: string;
  stepNumber: string;
  actionName: string;
  active: string;
  created_tmstmp: string;
  created_by: string;
  updated_tmstmp: string;
  updated_by: string;
}

export interface TestData {
  stepNo: string;
  stepDesc: string;
}

@Component({
  selector: 'app-test-case-tag',
  templateUrl: './test-case-tag.component.html',
  styleUrls: ['./test-case-tag.component.css']
})
export class TestCaseTagComponent implements OnInit {
  searchTestcaseHeaderToggle = true;
  tagActionsHeaderToggle = true;
  caseToActionDetailsHeaderToggle = true;
  caseTestdataHeaderToggle = true;
  _ngProjectName = "Default";

  constructor(private spinner: NgxSpinnerService, private http: HttpTemplateService, private toastr: ToastrService, public dialog: MatDialog) {
  }

  ngOnInit() {
    let params = new HttpParams().set('projectName', this._ngProjectName);
    let subs2: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_GET_API_TESTCASE_ACTION_LIST, params).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      if (result['testCases'] && result['testActions']) {
        this._ngTestcaseNameList = result['testCases']
        this._ngActionsNameList = result['testActions']
        this.testcaseNamefilteredOptions = this.testcaseNameMyControl.valueChanges
          .pipe(
            startWith(''),
            map(value => this._testcaseNamefilter(value))
          );
        this.actionNamefilteredOptions = this.actionNameMyControl.valueChanges
          .pipe(
            startWith(''),
            map(value => this._actionNameFilter(value))
          );
      } else {
        this.notify('error', 'Testcase and Actions List Failed', 'List is NULL or Empty.');
      }
    },
      error => {
        this.notify('error', 'Case Create', 'Failed : ' + error.message);
      });
    this.actionNameMyControl.reset({ value: '', disabled: true });
  }

  // ----------- TOGGLE Action -------------- //

  onSearchCaseHeaderClick() {
    this.searchTestcaseHeaderToggle = !this.searchTestcaseHeaderToggle;
  }

  onTagActionsHeaderClick() {
    this.tagActionsHeaderToggle = !this.tagActionsHeaderToggle;
  }

  onCaseToActionsHeaderClick() {
    this.caseToActionDetailsHeaderToggle = !this.caseToActionDetailsHeaderToggle;
  }

  onCaseTestdataHeaderClick() {
    this.caseTestdataHeaderToggle = !this.caseTestdataHeaderToggle;
  }

  // ----------------------- SEARCH TESTCASE ------------------------//
  _ngTagSearchTestcaseName = "";
  _ngSearchTestcaseSuccess = false;
  _isTestCaseSearched = null;

  testcaseNameMyControl = new FormControl();
  _ngTestcaseNameList: string[];
  testcaseNamefilteredOptions: Observable<string[]>;



  private _testcaseNamefilter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this._ngTestcaseNameList.filter(option => option.toLowerCase().includes(filterValue));
  }

  getTestcaseName = this.testcaseNameMyControl.valueChanges.subscribe(value => { this._ngTagSearchTestcaseName = value })

  onSearchedTestcaseSubmit() {
    let tempTestcaseCount = this._ngTestcaseNameList.filter(eachItem => eachItem == this._ngTagSearchTestcaseName).length;
    if (tempTestcaseCount == 1) {
      this._ngSearchTestcaseSuccess = true;
      //Load the Data for the Tagged Actions for testcase Table
      this.getTaggedActionsApiCall();
      this.actionNameMyControl.reset({ value: '', disabled: false });
      this.testcaseNameMyControl.reset({ value: this._ngTagSearchTestcaseName, disabled: true });
    } else {
      this._ngSearchTestcaseSuccess = false;
      this.notify('error', 'Invalid Selection', 'Choose a Valid Item');
      this.testcaseNameMyControl.setValue('');
      this._ngTagSearchTestcaseName = null;

    }
  }

  onSearchedTestcaseReset() {
    this.testcaseNameMyControl.setValue('');
    this._ngTagSearchTestcaseName = null;
    this._ngSearchTestcaseSuccess = false;
    this.testcaseNameMyControl.reset({ value: '', disabled: false });
    this.actionNameMyControl.reset({ value: '', disabled: true });
    this.onCaseNewTagActionRest();
  }

  // ----------------------- TAGGING ACTIONS ------------------------//
  _ngActionsNameList: string[];
  actionNameMyControl = new FormControl();
  actionNamefilteredOptions: Observable<string[]>;
  _ngNewTagActionInProgress

  _ngCaseTagActionStepNo
  _ngCaseTagActionName
  _ngCaseTagActionActiveFlag = true;

  private _actionNameFilter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this._ngActionsNameList.filter(option => option.toLowerCase().includes(filterValue));
  }

  getActionName = this.actionNameMyControl.valueChanges.subscribe(value => { this._ngCaseTagActionName = value })

  onCaseNewTagActionSubmit() {

    let tempActionCount = this._ngActionsNameList.filter(eachItem => eachItem == this._ngCaseTagActionName).length;
    if (tempActionCount == 1) {
      // Service Call
      let newTagAction: any = {
        caseName: this._ngTagSearchTestcaseName,
        stepNumber: this._ngCaseTagActionStepNo,
        actionName: this._ngCaseTagActionName,
        active: this._ngCaseTagActionActiveFlag,
        created_by: "layyakannu",
        updated_by: "layyakannu",
      }

      this._ngNewTagActionInProgress = true;
      let subs2: Subscription = this.http.postCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_GET_POST_API_TESTCASE_TRN, newTagAction).subscribe(response => {
        subs2.unsubscribe();
        let result: any = response;

        this._ngNewTagActionInProgress = false;
        if (result.status && result.status == "success") {
          this.onCaseNewTagActionRest();
          this.getRefreshTaggedActionsApiCall();
          //this.submitTestdata();
          for (let entry of JSON.parse(result.secondKey)) {
            this.bsColumns.push(entry);
          }
          this.notify('success', 'Tag Action to Case', 'Success');
        } else
          this.notify('error', 'Tag Action to Case', 'Failed : ' + result.reason);
      },
        error => {
          this._ngNewTagActionInProgress = false;
          this.notify('error', 'Tag Action to Case', 'Failed : ' + error.message);
        });

    } else {
      this.notify('error', 'Action Invalid Selection', 'Choose a Valid Item');
      this.actionNameMyControl.setValue('');
      this._ngCaseTagActionName = "";
    }
  }

  onCaseNewTagActionRest() {
    this._ngCaseTagActionStepNo = "";
    this.actionNameMyControl.setValue('');
    this._ngCaseTagActionName = "";
    this._ngCaseTagActionActiveFlag = true;
    this._ngNewTagActionInProgress = null;
  }

  // ----------------------- BOOTSTRAP TestData Table ------------------------//
  bsColumns: string[] = null;
  //bsRows: any[] = [{ Step: '1', Description: 'Sample' }];
  bsRows: any[] = null;

  _ngLabel = null;
  addBsColumn() {
    if (this.bsColumns.filter(eachItem => eachItem.toLowerCase() == this._ngLabel.toLowerCase()).length == 1) {
      this.notify('info', 'TestData', "Column '" + this._ngLabel + "' already available.");
    } else {
      this.bsColumns.push(this._ngLabel);
      this._ngLabel = "";
    }
  }

  addBsRow() {
    let rowNum = this.bsRows.length;
    this.bsRows.push({ Step: (rowNum + 1).toString() });
  }

  removeBsRow(row) {
    // if(this.bsRows.length == 1){
    //   this.notify('info', 'TestData', "Atleast one row should be available!");
    // }else{
    //   this.bsRows = this.bsRows.filter(item => item !== row);
    // }
    this.bsRows = this.bsRows.filter(item => item !== row);
  }

  removeBsCol(label) {
    if (label.toLowerCase() != 'step' && label.toLowerCase() != 'description') {
      this.bsColumns = this.bsColumns.filter(item => item !== label);
      let temp: any[] = [];
      for (let item of this.bsRows) {
        item = Object.keys(item).reduce((object, key) => {
          if (key !== label) {
            object[key] = item[key]
          }
          return object
        }, {})
        temp.push(item);
      }
      this.bsRows = temp;
      temp = null;
    } else {
      this.notify('info', 'TestData', "Column '" + label + "' cannot be removed (Mandatory).");
    }
  }

  printData() {
    console.log(this.bsRows);
  }

  _ngTestDataSubmitInProgress = null;

  submitTestdata() {
    let num = this.bsRows.filter(eachItem => eachItem['Step'].trim() == "").length;
    if (num > 0) {
      this.notify('info', 'TestData', "Step Number cannot be Empty!");
    } else {

      let isValidData = true;
      this.bsRows.forEach(element => {
        if (isNaN(element['Step'])) {
          isValidData = false;
        }
      });

      if (isValidData) {
        let ngTestdataSubmitBody: any = {
          is_test_data_avail: "true",
          test_data_keys: JSON.stringify(this.bsColumns),
          test_data: JSON.stringify(this.bsRows.filter(eachItem => eachItem['Step'].trim() != "")),
          test_case_name: this._ngTagSearchTestcaseName,
          updated_by: "layyakannu"
        }
        this._ngTestDataSubmitInProgress = true;
        let subs2: Subscription = this.http.postCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_TEST_DATA_SUBMIT, ngTestdataSubmitBody).subscribe(response => {
          subs2.unsubscribe();
          let result: any = response;
          this._ngTestDataSubmitInProgress = false;
          if (result.status && result.status == "success") {
            this._ngOnApiLoadInitialColumns = JSON.parse(JSON.stringify(this.bsColumns));
            this._ngOnApiLoadInitialData = JSON.parse(JSON.stringify(this.bsRows.filter(eachItem => eachItem['Step'].trim() != "")));
            this.notify('success', 'Testdata Submit', 'Success');
          } else
            this.notify('error', 'Testdata Submit', 'Failed : ' + result.reason);
        },
          error => {
            this._ngTestDataSubmitInProgress = false;
            this.notify('error', 'Testdata Submit', 'Failed : ' + error.message);
          });
      } else {
        this.notify('info', 'TestData', "Step Number cannot be a String!");
      }
    }
  }

  resetTestData() {
    this.bsColumns = JSON.parse(JSON.stringify(this._ngOnApiLoadInitialColumns));;
    this.bsRows = JSON.parse(JSON.stringify(this._ngOnApiLoadInitialData.filter(eachItem => eachItem['Step'].trim() != "")));;
  }
  // ----------------------- DISPLAY CASE TO ACTIONS TABLE ------------------------//

  //MAT:
  displayedColumns: string[] = ['stepNumber', 'actionName', 'active', 'updated_by', 'updated_tmstmp', 'action'];
  dataSource: MatTableDataSource<TestcaseTrnDetails>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  _ngTaggedActionForCaseLength = null;
  _caseTestcaseDataFlag = null;
  _caseTestcaseData = null;
  _ngOnApiLoadInitialColumns = null;
  _ngOnApiLoadInitialData = null;

  getTaggedActionsApiCall() {
    let params = new HttpParams().set('caseName', this._ngTagSearchTestcaseName).set('projectName', this._ngProjectName);
    let subs: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_GET_API_TESTCASES_TRN, params).subscribe(response => {
      subs.unsubscribe;
      let result: any = response['testcaseTrnDetails'];
      this._caseTestcaseDataFlag = response['testDataFlag'];

      if (response['testDataKeys'] && response['testDataKeys'] != "") {
        this.bsColumns = JSON.parse(response['testDataKeys']);
        this._ngOnApiLoadInitialColumns = JSON.parse(response['testDataKeys']);
      } else {
        this.bsColumns = ['Step', 'Description'];
        this._ngOnApiLoadInitialColumns = ['Step', 'Description'];
      }

      if (response['testData'] && response['testData'] != "") {
        this.bsRows = JSON.parse(response['testData']);
        this._ngOnApiLoadInitialData = JSON.parse(response['testData']);
      } else {
        this.bsRows = [{ Step: '1', Description: 'Sample' }];
        this._ngOnApiLoadInitialData = [{ Step: '1', Description: 'Sample' }];
      }

      this._ngTaggedActionForCaseLength = result.length;
      this.dataSource = new MatTableDataSource(result);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this.notify('error', 'Tagged Actions', 'Error occured while Loading List : ' + error.message);
    });
  }

  getRefreshTaggedActionsApiCall() {
    let params = new HttpParams().set('caseName', this._ngTagSearchTestcaseName).set('projectName', this._ngProjectName);
    let subs: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_GET_API_TESTCASES_TRN, params).subscribe(response => {
      subs.unsubscribe;
      let result: any = response['testcaseTrnDetails'];
      this._caseTestcaseDataFlag = response['testDataFlag'];

      this._ngTaggedActionForCaseLength = result.length;
      this.dataSource = new MatTableDataSource(result);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {

      this.notify('error', 'Tagged Actions', 'Error occured while Loading List : ' + error.message);
    });
  }

  //MAT:
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  //EDIT MODAL FEATURE
  openEditDialog(row): void {
    const dialogRef = this.dialog.open(CaseTagEditModalComponent, {
      width: '800px',
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {

      if (result['result'] == 'success') {
        this.getRefreshTaggedActionsApiCall();
        for (let entry of result.list) {
          this.bsColumns.push(entry);
        }
      }
    });
  }

  //DELETE MODAL FEATURE
  openDeleteDialog(row): void {
    const dialogRef2 = this.dialog.open(CaseTagDeleteModalComponent, {
      width: '700px',
      data: row
    });

    dialogRef2.afterClosed().subscribe(result => {
      if (result == 'success') {
        this.getTaggedActionsApiCall();
      }
    });
  }

  //View MODAL FEATURE
  openViewDialog(row): void {
    const dialogRef3 = this.dialog.open(CaseTagViewModalComponent, {
      width: '700px',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
    });
  }

  //View MODAL FEATURE
  openTriggerResultDialog(row): void {
    const dialogRef3 = this.dialog.open(TriggerResultModalComponent, {
      width: '1200px',
      maxHeight: 'calc(100vh - 120px)',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
    });
  }

  //View MODAL FEATURE
  openTriggerRunIdDialog(row): void {
    const dialogRef3 = this.dialog.open(TriggerAyncModalComponent, {
      width: '800px',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
    });
  }

  //RUN MODAL FEATURE
  runTestDialog(): void {
    let row: any = {
      caseName: this._ngTagSearchTestcaseName
    }
    const dialogRef = this.dialog.open(TestTriggerModalComponent, {
      width: '500px',
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result && result['status'] == 'success' && result['triggerType'] == 'sync') {
        this.openTriggerResultDialog(result);
      }
      if (result && result['status'] == 'success' && result['triggerType'] == 'async') {
        this.openTriggerRunIdDialog(result);
      }
    });
  }



  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 6000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
