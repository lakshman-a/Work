import { AppConfig } from './../../../app-config.service';
import { HttpTemplateService } from './../../../service/template/http-template.service';
import { Subscription } from 'rxjs';

import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatRadioChange } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';


export interface TestTrigger {
  triggerType: string;
  testName: string;
  suiteLevel: string;
  suiteRunType: string;
  username: string;
  threadCount: string;
  stage?: string;
  comments?: string;
}

@Component({
  selector: 'app-test-trigger-modal',
  templateUrl: './test-trigger-modal.component.html',
  styleUrls: ['./test-trigger-modal.component.css']
})
export class TestTriggerModalComponent implements OnInit {

  _apiRowDetails: any = null;
  _isTriggerApiCallInProgress = null;
  _triggerSubmitResponse = null;
  _testType = null;
  _testName = null;
  _triggerType = 'async';
  _runMode = 'serial';
  _stage = null;
  _threadCount = "1";
  _comments = null;
  constructor(
    public dialogRef: MatDialogRef<TestTriggerModalComponent>,
    private http: HttpTemplateService,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this._apiRowDetails = data;
    if (data['caseName']) {
      this._testType = 'Testcase';
      this._testName = data['caseName'];
    }
    if (data['test_suite_name']) {
      this._testType = 'TestSuite';
      this._testName = data['test_suite_name'];
    }
    console.log("Test Type is : " + this._testType);
    console.log("TestName is : " + this._testName);

  }

  ngOnInit() {
  }

  onStartRunClick() {
    let triggerRequestBody: TestTrigger = {
      suiteLevel: this._testType,
      testName: this._testName,
      triggerType: this._triggerType,
      suiteRunType: this._runMode,
      username: "layyakannu",
      threadCount: this._threadCount,
      stage: this._stage,
      comments: this._comments
    }

    if (this._triggerType == 'sync') {
      console.log("Sync request submit");
      this._isTriggerApiCallInProgress=true;
      this.spinner.show();
      let subs2: Subscription = this.http.postCallWithHeaders(AppConfig.API_AUTO_HOST + AppConfig.AUTO_API_TRIGGER_TEST_RUN, triggerRequestBody).subscribe(response => {
        subs2.unsubscribe();
        let result: any = response;
        this._triggerSubmitResponse = response;
        this._isTriggerApiCallInProgress=false;
        this.spinner.hide()
        if (result.status && result.status == "success") {

          //this.notify('success', 'Trigger Test', 'Success');
          this.dialogRef.close(this._triggerSubmitResponse);
        } else
          this.notify('error', 'Trigger Test', 'Failed : ' + result.message);
      },
        error => {
          this._isTriggerApiCallInProgress=false;
          this.spinner.hide()
          this.notify('error', 'Trigger Test', 'Failed : ' + error.message);
        });
    } else if (this._triggerType == 'async') {
      console.log("Async request submit")
      this._isTriggerApiCallInProgress=true;
      let subs3: Subscription = this.http.postCallWithHeaders(AppConfig.API_AUTO_HOST + AppConfig.AUTO_API_TRIGGER_TEST_RUN, triggerRequestBody).subscribe(response => {
        subs3.unsubscribe();
        let result: any = response;
        this._triggerSubmitResponse = response;
        this._isTriggerApiCallInProgress=true;
        if (result.status && result.status == "success") {
          //this.notify('success', 'Suite Details Edit', 'Success');
          this.dialogRef.close(this._triggerSubmitResponse);
        } else
        this.notify('error', 'Trigger Test', 'Failed : ' + result.message);
      },
        error => {
          this._isTriggerApiCallInProgress=true;
          this.notify('error', 'Trigger Test', 'Failed : ' + error.message);
        });
    }

  }

  radioChange($event: MatRadioChange) {
    console.log($event.value);

    if ($event.value === 'serial') {
      this._threadCount = "1";
    }
  }


  onNoClick(): void {
    this.dialogRef.close();
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 5000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 10000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
