import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestSuiteTagComponent } from './test-suite-tag.component';

describe('TestSuiteTagComponent', () => {
  let component: TestSuiteTagComponent;
  let fixture: ComponentFixture<TestSuiteTagComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestSuiteTagComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestSuiteTagComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
