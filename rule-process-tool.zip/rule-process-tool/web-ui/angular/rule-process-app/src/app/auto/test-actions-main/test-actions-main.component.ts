import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-actions-main',
  templateUrl: './test-actions-main.component.html',
  styleUrls: ['./test-actions-main.component.css']
})
export class TestActionsMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
