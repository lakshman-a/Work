import { AppConfig } from './../../../../app-config.service';
import { HttpTemplateService } from './../../../../service/template/http-template.service';
import { Component, Inject } from '@angular/core';
import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-actions-delete-modal',
  templateUrl: './actions-delete-modal.component.html',
  styleUrls: ['./actions-delete-modal.component.css']
})
export class ActionsDeleteModalComponent {
  //1. Testcase Details
  _ngEditActionName = null;
  _ngEditActionDesc = null;
_isActionInProgress=null;
  constructor(
    public dialogRef: MatDialogRef<ActionsDeleteModalComponent>, private http: HttpTemplateService, private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any) {

    this._ngEditActionName = data['actionName'];
    this._ngEditActionDesc = data['actionDesc'];

  }

  onDeleteClick() {

    let deleteActionSubmitBody: any = {
      actionName: this._ngEditActionName,
      updated_by: "layyakannu"
    }
    this._isActionInProgress = true;
    let subs2: Subscription = this.http.deleteCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_POST_API_NEW_TEST_ACTION, deleteActionSubmitBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      this._isActionInProgress = false;
      if (result.status && result.status == "success") {
        this.notify('success', 'Action Delete', 'Success');
        this.dialogRef.close("success");
      } else
        this.notify('error', 'Action Delete', 'Failed : ' + result.reason);
    },
      error => {
        this._isActionInProgress = false;
        this.notify('error', 'Action Delete', 'Failed : ' + error.message);
      });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 5000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }
}
