import { TriggerAyncModalComponent } from './../../test-trigger/trigger-aync-modal/trigger-aync-modal.component';
import { SuiteCreateViewModalComponent } from './suite-create-view-modal/suite-create-view-modal.component';
import { SuiteCreateEditModalComponent } from './suite-create-edit-modal/suite-create-edit-modal.component';
import { ToastrService } from 'ngx-toastr';
import { HttpTemplateService } from './../../../service/template/http-template.service';
import { Subscription } from 'rxjs';
import { AppConfig } from './../../../app-config.service';

import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material';
import { SuiteCreateDeleteModalComponent } from './suite-create-delete-modal/suite-create-delete-modal.component';
import { TestTriggerModalComponent } from '../../test-trigger/test-trigger-modal/test-trigger-modal.component';
import { TriggerResultModalComponent } from '../../test-trigger/trigger-result-modal/trigger-result-modal.component';

export interface TestSuite {
  id: string;
  test_suite_name: string;
  test_suite_desc: string;
  active: string;
  created_tmstmp: string;
  created_by: string;
  updated_tmstmp: string;
  updated_by: string;
}


@Component({
  selector: 'app-test-suite-create',
  templateUrl: './test-suite-create.component.html',
  styleUrls: ['./test-suite-create.component.css']
})
export class TestSuiteCreateComponent implements OnInit {

  createTestsuiteHeaderToggle = true;
  testsuiteDetailsHeaderToggle = true;

  constructor(private http: HttpTemplateService, private toastr: ToastrService, public dialog: MatDialog) {
  }

  ngOnInit() {
    //MAT TABLE GRID Data Load:
    let subs: Subscription = this.http.getCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_TESTSUITE_LIST).subscribe(response => {
      subs.unsubscribe;
      let result: any = response;
      this.dataSource = new MatTableDataSource(result);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this.notify('error', 'Test Suite Details', 'Error occured while Loading List : ' + error.message);
    });
  }

  // ----------- TOGGLE Action -------------- //

  onCreateTestsuiteHeaderClick() {
    this.createTestsuiteHeaderToggle = !this.createTestsuiteHeaderToggle;
  }

  onTestSuiteDetailsClick() {
    this.testsuiteDetailsHeaderToggle = !this.testsuiteDetailsHeaderToggle;
  }

  // ----------- Main Body -------------- //

  //1. Testcase Details
  _ngAddTestSuiteName = null;
  _ngAddTestSuiteDesc = null;
  _ngNewAddTestSuiteInProgress = null;

  onAddNewTestSuiteClick() {

    let newSuiteSubmitBody: any = {
      test_suite_name: this._ngAddTestSuiteName,
      test_suite_desc: this._ngAddTestSuiteDesc,
      active: true,
      created_by: "layyakannu",
      updated_by: "layyakannu"
    }
    this._ngNewAddTestSuiteInProgress = true;
    let subs2: Subscription = this.http.postCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_TESTSUITE_MODIFY, newSuiteSubmitBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;

      this._ngNewAddTestSuiteInProgress = false;
      if (result.status && result.status == "success") {
        this.onTestSuiteResetClick();
        this.ruleGridRefreshCall();
        this.notify('success', 'Suite Create', 'Success');
      } else
        this.notify('error', 'Suite Create', 'Failed : ' + result.reason);
    },
      error => {
        this._ngNewAddTestSuiteInProgress = false;
        this.notify('error', 'Suite Create', 'Failed : ' + error.message);
      });
  }

  onTestSuiteResetClick() {
    this._ngAddTestSuiteName = null;
    this._ngAddTestSuiteDesc = null;
    this._ngNewAddTestSuiteInProgress = null;
  }

  //2. Testcase Details:
  //MAT:
  displayedColumns: string[] = ['id', 'run', 'test_suite_name', 'test_suite_desc', 'active', 'created_by', 'updated_tmstmp', 'action'];
  dataSource: MatTableDataSource<TestSuite>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  ruleGridRefreshCall() {
    let subs: Subscription = this.http.getCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_TESTSUITE_LIST).subscribe(response => {
      subs.unsubscribe;
      let result: any = response;
      this.dataSource = new MatTableDataSource(result);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this.notify('error', 'Test Suite Details', 'Error occured while Loading List : ' + error.message);
    });
  }

  //MAT:
  applyFilter(filterValue: string) {
    if (this.dataSource.filter != null) {
      this.dataSource.filter = filterValue.trim().toLowerCase();
      if (this.dataSource.paginator) {
        this.dataSource.paginator.firstPage();
      }
    }

  }

  //EDIT MODAL FEATURE
  openEditDialog(row): void {
    const dialogRef = this.dialog.open(SuiteCreateEditModalComponent, {
      width: '900px',
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {

      console.log(result);
      console.log("delete modal Dialogs closed!");
      if (result == 'success') {
        console.log("Result is success so refresing grif!");
        this.ruleGridRefreshCall();
      }
    });
  }

  //DELETE MODAL FEATURE
  openDeleteDialog(row): void {
    const dialogRef2 = this.dialog.open(SuiteCreateDeleteModalComponent, {
      width: '700px',
      data: row
    });

    dialogRef2.afterClosed().subscribe(result => {
      console.log(result);
      console.log("delete modal Dialogs closed!");
      if (result == 'success') {
        console.log("Result is success so refresing grif!");
        this.ruleGridRefreshCall();
      }
    });
  }

  //View MODAL FEATURE
  openViewDialog(row): void {
    const dialogRef3 = this.dialog.open(SuiteCreateViewModalComponent, {
      width: '900px',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
      if (result) {
        //this.ruleGridRefreshCall();
      }
    });
  }

  //View MODAL FEATURE
  openTriggerResultDialog(row): void {
    const dialogRef3 = this.dialog.open(TriggerResultModalComponent, {
      width: '1200px',
      maxHeight: 'calc(100vh - 120px)',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
    });
  }

  //View MODAL FEATURE
  openTriggerRunIdDialog(row): void {
    const dialogRef3 = this.dialog.open(TriggerAyncModalComponent, {
      width: '800px',
      //maxHeight: 'calc(100vh - 120px)',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
    });
  }

  //RUN MODAL FEATURE
  runTestDialog(row): void {
    const dialogRef = this.dialog.open(TestTriggerModalComponent, {
      width: '500px',
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log("Trigger RUn Dialog closed");
      console.log(result);
      if (result && result['status'] == 'success' && result['triggerType'] == 'sync') {
        this.openTriggerResultDialog(result);
      }
      if (result && result['status'] == 'success' && result['triggerType'] == 'async') {
        this.openTriggerRunIdDialog(result);
      }
    });
  }


  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 6000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }




}
