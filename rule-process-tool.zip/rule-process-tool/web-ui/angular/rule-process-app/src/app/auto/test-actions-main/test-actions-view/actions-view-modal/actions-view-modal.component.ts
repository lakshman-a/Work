import { ToastrService } from 'ngx-toastr';
import { AppConfig } from './../../../../app-config.service';
import { HttpTemplateService } from './../../../../service/template/http-template.service';
import { Subscription } from 'rxjs';
import { HttpParams } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-actions-view-modal',
  templateUrl: './actions-view-modal.component.html',
  styleUrls: ['./actions-view-modal.component.css']
})
export class ActionsViewModalComponent {

  _apiData: any; 

  constructor(
    public dialogRef: MatDialogRef<ActionsViewModalComponent>,private http: HttpTemplateService,private toastr: ToastrService, 
    @Inject(MAT_DIALOG_DATA) public data: any) {

      let params = new HttpParams().set('actionName', data['actionName']);
      let subs: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_POST_API_NEW_TEST_ACTION, params).subscribe(response => {
        subs.unsubscribe;
        this._apiData=response;
  
      }, error => {
        this.notify('error', 'Test Action - '+data['actionName'], 'Error occured while Loading Action Details : ' + error.message);
      });

  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  
  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 5000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
