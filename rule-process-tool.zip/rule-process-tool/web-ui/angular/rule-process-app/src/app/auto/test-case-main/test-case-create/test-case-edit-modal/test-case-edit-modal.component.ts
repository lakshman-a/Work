import { HttpParams } from '@angular/common/http';
import { Component, Inject } from '@angular/core';
import { AppConfig } from './../../../../app-config.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpTemplateService } from './../../../../service/template/http-template.service';

import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-test-case-edit-modal',
  templateUrl: './test-case-edit-modal.component.html',
  styleUrls: ['./test-case-edit-modal.component.css']
})
export class TestCaseEditModalComponent {

  //1. Testcase Details
  _ngEditApiData = null;
  _componentListApiresponse = null;
  _componentList: string[];
  _checkpointList: string[];

  _ngEditTestcaseId = null;
  _ngEditTestcaseName = null;
  _ngEditTestcaseSummary = null;
  _ngAddComponentName = null;
  _ngAddCheckpointName = null;
  _ngProjectName = "Default";
  _ngAddTestcaseJiraTagId = null;
  _ngEditTestcaseStage = null;
  _ngEditTestcaseRuleBasedFlag = true;
  _ngEditTestcaseRunModeOptions: string[] = ['Serial', 'Parallel'];
  _ngEditTestcaseActiveFlag = true;
  _ngEditTestcaseSteps = null;
  _ngEditTestcaseComplexity = '10';
  _ngEditTestcaseAutoFlag = true;
  _ngEditTestcaseRunMode = 'Serial';
  _ngAddTestcaseTypeOptions: string[] = ['UI', 'API', 'DB', 'E2E', 'BATCH'];
  _ngAddTestcaseType = null;

  constructor(
    public dialogRef: MatDialogRef<TestCaseEditModalComponent>, private http: HttpTemplateService, private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.apiCallForComponentListLoad(data)
    this._ngEditApiData = data;
    this._ngEditTestcaseId = data['id'];
    this._ngEditTestcaseName = data['caseName'];
    this._ngEditTestcaseSummary = data['caseSummary'];
    this._ngEditTestcaseSteps = data['caseSteps'];
    this._ngAddComponentName = data['componentName'];
    this._ngAddCheckpointName = data['checkpointName'];
    this._ngProjectName = data['projectName'];
    this._ngEditTestcaseStage = data['stage'];
    this._ngEditTestcaseComplexity = data['complexity'];
    this._ngEditTestcaseRunMode = data['runMode'];

    if (data['isRuleBased'] == 'true') { this._ngEditTestcaseRuleBasedFlag = true; }
    else if (data['isRuleBased'] == 'false') { this._ngEditTestcaseRuleBasedFlag = false; }

    if (data['isAutomationCase'] == 'true') { this._ngEditTestcaseAutoFlag = true; }
    else if (data['isAutomationCase'] == 'false') { this._ngEditTestcaseAutoFlag = false; }

    if (data['active'] == 'true') { this._ngEditTestcaseActiveFlag = true; }
    else if (data['active'] == 'false') { this._ngEditTestcaseActiveFlag = false; }
  }

  _ngCompListLoadInProgress = null
  apiCallForComponentListLoad(data) {
    this._ngCompListLoadInProgress = true;
    let params = new HttpParams().set('projectName', this._ngProjectName);
    let subs2: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_API_COMPONENTS_LIST, params).subscribe(response => {
      subs2.unsubscribe;
      this._ngCompListLoadInProgress = false
      let result: any = response;
      this._componentListApiresponse = result;
      this._componentList = result.map(eachItem => eachItem.component);
      this._checkpointList = this._componentListApiresponse.filter(eachItem => eachItem.component === data['componentName'])[0]['checkpoints'];
    }, error => {
      this._ngCompListLoadInProgress = false
      this.notify('error', 'Component Details', 'Error occured while Loadings Rules : ' + error.message);
    });
  }

  onComponentChange(component: any) {
    this._checkpointList = this._componentListApiresponse.filter(eachItem => eachItem.component === component)[0].checkpoints;
    this._ngAddCheckpointName=null;
  }

  _ngUpdateInProgress = null;
  onUpdateClick() {
    let editCaseSubmitBody: any = {
      caseName: this._ngEditTestcaseName,
      caseSummary: this._ngEditTestcaseSummary,
      caseSteps: this._ngEditTestcaseSteps,
      componentName: this._ngAddComponentName,
      checkpointName: this._ngAddCheckpointName,
      projectName: this._ngProjectName,
      stage: this._ngEditTestcaseStage,
      complexity: this._ngEditTestcaseComplexity,
      isAutomationCase: this._ngEditTestcaseAutoFlag,
      runMode: this._ngEditTestcaseRunMode,
      isRuleBased: this._ngEditTestcaseRuleBasedFlag,
      active: this._ngEditTestcaseActiveFlag,
      updated_by: "layyakannu"
    }

    this._ngUpdateInProgress = true;
    let subs2: Subscription = this.http.putCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_GET_POST_API_TESTCASE, editCaseSubmitBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      this._ngUpdateInProgress = false;
      if (result.status && result.status == "success") {
        if (result.code && result.code == "201") {
        } else {
          this.notify('success', 'Case Edit', 'Success');
          this.dialogRef.close("success");
        }
      } else
        this.notify('error', 'Case Edit', 'Failed : ' + result.reason);
    },
      error => {
        this._ngUpdateInProgress = false;
        this.notify('error', 'Case Edit', 'Failed : ' + error.message);
      });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 5000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
