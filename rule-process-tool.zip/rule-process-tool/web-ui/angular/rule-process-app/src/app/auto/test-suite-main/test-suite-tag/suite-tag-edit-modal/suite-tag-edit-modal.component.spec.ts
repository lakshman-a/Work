import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuiteTagEditModalComponent } from './suite-tag-edit-modal.component';

describe('SuiteTagEditModalComponent', () => {
  let component: SuiteTagEditModalComponent;
  let fixture: ComponentFixture<SuiteTagEditModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuiteTagEditModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuiteTagEditModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
