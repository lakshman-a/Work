import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-case-reports',
  templateUrl: './test-case-reports.component.html',
  styleUrls: ['./test-case-reports.component.css']
})
export class TestCaseReportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
