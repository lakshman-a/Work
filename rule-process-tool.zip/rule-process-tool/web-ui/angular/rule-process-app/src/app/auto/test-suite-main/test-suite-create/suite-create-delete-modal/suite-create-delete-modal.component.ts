import { Component, Inject } from '@angular/core';
import { AppConfig } from './../../../../app-config.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpTemplateService } from './../../../../service/template/http-template.service';

import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-suite-create-delete-modal',
  templateUrl: './suite-create-delete-modal.component.html',
  styleUrls: ['./suite-create-delete-modal.component.css']
})
export class SuiteCreateDeleteModalComponent {

  //1. Testcase Details
 _ngEditTestSuiteName = null;
 _ngEditTestSuiteDesc = null;

 constructor(
   public dialogRef: MatDialogRef<SuiteCreateDeleteModalComponent>, private http: HttpTemplateService, private toastr: ToastrService,
   @Inject(MAT_DIALOG_DATA) public data: any) {

   this._ngEditTestSuiteName = data['test_suite_name'];
   this._ngEditTestSuiteDesc = data['test_suite_desc'];

 }
 _isActionInProgress = null;
 onDeleteClick() {

   let deleteSuiteSubmitBody: any = {
    test_suite_name: this._ngEditTestSuiteName,
     updated_by: "layyakannu"
   }
   this._isActionInProgress = true;
   let subs2: Subscription = this.http.deleteCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_TESTSUITE_MODIFY, deleteSuiteSubmitBody).subscribe(response => {
     subs2.unsubscribe();
     let result: any = response;
     this._isActionInProgress = false;
     if (result.status && result.status == "success") {
       this.notify('success', 'Suite Delete', 'Success');
       this.dialogRef.close("success");
     } else
       this.notify('error', 'Suite Delete', 'Failed : ' + result.reason);
   },
     error => {
      this._isActionInProgress = false;
       this.notify('error', 'Suite Delete', 'Failed : ' + error.message);
     });
 }

 onNoClick(): void {
   this.dialogRef.close();
 }

 //---------------------------- TOASTR NOTIFY ----------------------//

 notify(status: string, headMessage: string, details: any) {
   if (status == 'success') {
     this.toastr.success(details, headMessage, {
       closeButton: true,
       timeOut: 3000,
       positionClass: 'toast-bottom-right',
       progressBar: true
     });
   } else if (status == 'error') {
     this.toastr.error(details, headMessage, {
       closeButton: true,
       timeOut: 5000,
       positionClass: 'toast-bottom-right',
       progressBar: true
     });
   } else if (status == 'info') {
     this.toastr.info(details, headMessage, {
       closeButton: true,
       timeOut: 3000,
       positionClass: 'toast-bottom-right',
       progressBar: true
     });
   } else if (status == 'warn') {
     this.toastr.warning(details, headMessage, {
       closeButton: true,
       timeOut: 3000,
       positionClass: 'toast-bottom-right',
       progressBar: true
     });
   }
 }

}
