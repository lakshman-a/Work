import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuiteCreateDeleteModalComponent } from './suite-create-delete-modal.component';

describe('SuiteCreateDeleteModalComponent', () => {
  let component: SuiteCreateDeleteModalComponent;
  let fixture: ComponentFixture<SuiteCreateDeleteModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuiteCreateDeleteModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuiteCreateDeleteModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
