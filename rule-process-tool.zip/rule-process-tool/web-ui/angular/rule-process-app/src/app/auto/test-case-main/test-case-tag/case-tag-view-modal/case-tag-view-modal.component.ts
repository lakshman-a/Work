import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-case-tag-view-modal',
  templateUrl: './case-tag-view-modal.component.html',
  styleUrls: ['./case-tag-view-modal.component.css']
})
export class CaseTagViewModalComponent {

  _ngViewCaseTagTestname = null;
  constructor(
    public dialogRef: MatDialogRef<CaseTagViewModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this._ngViewCaseTagTestname = data['caseName'];
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
