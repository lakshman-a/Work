import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';


@Component({
  selector: 'app-trigger-aync-modal',
  templateUrl: './trigger-aync-modal.component.html',
  styleUrls: ['./trigger-aync-modal.component.css']
})
export class TriggerAyncModalComponent implements OnInit {

  _apiRunDetails: any = null;
  _apiTriggerResponse: any=null;
  _apiRunsTestCasesList: any[] = null;
  _isRunDetailsApiCallInProgress = null;
  viewReporthrefLink = null;
  saveReporthrefLink = null;

  constructor(
    public dialogRef: MatDialogRef<TriggerAyncModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this._apiTriggerResponse = data;
  }

  ngOnInit() {
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
