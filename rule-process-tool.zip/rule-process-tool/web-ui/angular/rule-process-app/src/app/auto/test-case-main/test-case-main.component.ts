import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-case-main',
  templateUrl: './test-case-main.component.html',
  styleUrls: ['./test-case-main.component.css']
})
export class TestCaseMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
