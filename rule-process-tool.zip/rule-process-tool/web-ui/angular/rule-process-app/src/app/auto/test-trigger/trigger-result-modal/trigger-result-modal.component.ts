import { AppConfig } from './../../../app-config.service';
import { HttpTemplateService } from './../../../service/template/http-template.service';

import { HttpParams } from '@angular/common/http';

import { Subscription } from 'rxjs';

import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-trigger-result-modal',
  templateUrl: './trigger-result-modal.component.html',
  styleUrls: ['./trigger-result-modal.component.css']
})
export class TriggerResultModalComponent implements OnInit {

  _apiRunDetails: any = null;
  _apiTriggerResponse: any=null;
  _apiRunsTestCasesList: any[] = null;
  _isRunDetailsApiCallInProgress = null;
  viewReporthrefLink = null;
  saveReporthrefLink = null;

  constructor(
    public dialogRef: MatDialogRef<TriggerResultModalComponent>,
    private http: HttpTemplateService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this._apiTriggerResponse = data;
    this.viewReporthrefLink = AppConfig.API_HOST+AppConfig.DB_API_OPEN_HTML_REPORT_RUN_ID+data["reportFile"];
    this.saveReporthrefLink = AppConfig.API_HOST+AppConfig.DB_API_SAVE_HTML_REPORT_RUN_ID+data["reportFile"];
    console.log("Constructor of modal loaded with href also");
    console.log(this.viewReporthrefLink);
  }

  ngOnInit() {
    let params = new HttpParams().set('runId', this._apiTriggerResponse["runId"]);
    let subs: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_API_FULL_REPORT_FOR_RUN_ID, params).subscribe(response => {
      subs.unsubscribe;
      let result: any = response;
      this._apiRunDetails=result
      this._apiRunsTestCasesList = result['testCasesReportTrn'];
      this._isRunDetailsApiCallInProgress = false;
    }, error => {
      this._isRunDetailsApiCallInProgress = false;
    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }


}
