
import { Component, Inject } from '@angular/core';
import { AppConfig } from './../../../../app-config.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpTemplateService } from './../../../../service/template/http-template.service';

import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-case-tag-delete-modal',
  templateUrl: './case-tag-delete-modal.component.html',
  styleUrls: ['./case-tag-delete-modal.component.css']
})
export class CaseTagDeleteModalComponent  {

//1. Testcase Details
_ngEditCaseTagStepNo = null;
_ngEditCaseTagTestcaseName = null;

constructor(
  public dialogRef: MatDialogRef<CaseTagDeleteModalComponent>, private http: HttpTemplateService, private toastr: ToastrService,
  @Inject(MAT_DIALOG_DATA) public data: any) {

  this._ngEditCaseTagStepNo = data['stepNumber'];
  this._ngEditCaseTagTestcaseName = data['caseName'];

}

_isActionInProgress = null;
onDeleteClick() {

  let deleteCaseTagSubmitBody: any = {
    caseName: this._ngEditCaseTagTestcaseName,
    stepNumber: this._ngEditCaseTagStepNo,
    updated_by: "layyakannu"
  }
  this._isActionInProgress = true;
  let subs2: Subscription = this.http.deleteCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_GET_POST_API_TESTCASE_TRN, deleteCaseTagSubmitBody).subscribe(response => {
    subs2.unsubscribe();
    let result: any = response;
    this._isActionInProgress = false;
    if (result.status && result.status == "success") {
      this.notify('success', 'Case Delete', 'Success');
      this.dialogRef.close("success");
    } else
      this.notify('error', 'Case Delete', 'Failed : ' + result.reason);
  },
    error => {
      this._isActionInProgress = false;
      this.notify('error', 'Case Delete', 'Failed : ' + error.message);
    });
}

onNoClick(): void {
  this.dialogRef.close();
}

//---------------------------- TOASTR NOTIFY ----------------------//

notify(status: string, headMessage: string, details: any) {
  if (status == 'success') {
    this.toastr.success(details, headMessage, {
      closeButton: true,
      timeOut: 3000,
      positionClass: 'toast-bottom-right',
      progressBar: true
    });
  } else if (status == 'error') {
    this.toastr.error(details, headMessage, {
      closeButton: true,
      timeOut: 5000,
      positionClass: 'toast-bottom-right',
      progressBar: true
    });
  } else if (status == 'info') {
    this.toastr.info(details, headMessage, {
      closeButton: true,
      timeOut: 3000,
      positionClass: 'toast-bottom-right',
      progressBar: true
    });
  } else if (status == 'warn') {
    this.toastr.warning(details, headMessage, {
      closeButton: true,
      timeOut: 3000,
      positionClass: 'toast-bottom-right',
      progressBar: true
    });
  }
}

}
