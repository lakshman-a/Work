import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestCaseTagComponent } from './test-case-tag.component';

describe('TestCaseTagComponent', () => {
  let component: TestCaseTagComponent;
  let fixture: ComponentFixture<TestCaseTagComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestCaseTagComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestCaseTagComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
