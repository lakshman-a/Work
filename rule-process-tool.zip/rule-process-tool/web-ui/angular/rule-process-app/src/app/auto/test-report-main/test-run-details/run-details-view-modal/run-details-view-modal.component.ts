import { HttpTemplateService } from './../../../../service/template/http-template.service';
import { HttpParams } from '@angular/common/http';
import { AppConfig } from './../../../../app-config.service';
import { Subscription } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-run-details-view-modal',
  templateUrl: './run-details-view-modal.component.html',
  styleUrls: ['./run-details-view-modal.component.css']
})
export class RunDetailsViewModalComponent implements OnInit {
  _apiRunDetails: any = null;
  _apiRunsTestCasesList: any[] = null;
  _isRunDetailsApiCallInProgress = null;
  viewReporthrefLink = null;
  saveReporthrefLink = null;

  constructor(
    public dialogRef: MatDialogRef<RunDetailsViewModalComponent>,
    private http: HttpTemplateService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this._apiRunDetails = data;
    this.viewReporthrefLink = AppConfig.API_HOST+AppConfig.DB_API_OPEN_HTML_REPORT_RUN_ID+data["report_file"];
    this.saveReporthrefLink = AppConfig.API_HOST+AppConfig.DB_API_SAVE_HTML_REPORT_RUN_ID+data["report_file"];
    console.log("Constructor of modal loaded with href also");
    console.log(this.viewReporthrefLink);
  }

  ngOnInit() {
    let params = new HttpParams().set('runId', this._apiRunDetails["run_id"]);
    let subs: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_API_TEST_REPORT_FOR_RUN_ID, params).subscribe(response => {
      subs.unsubscribe;
      let result: any = response;
      this._apiRunsTestCasesList = result;
      this._isRunDetailsApiCallInProgress = false;
    }, error => {
      this._isRunDetailsApiCallInProgress = false;
    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }


}
