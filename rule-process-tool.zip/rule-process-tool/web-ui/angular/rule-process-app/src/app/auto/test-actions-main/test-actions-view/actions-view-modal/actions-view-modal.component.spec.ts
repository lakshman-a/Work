import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActionsViewModalComponent } from './actions-view-modal.component';

describe('ActionsViewModalComponent', () => {
  let component: ActionsViewModalComponent;
  let fixture: ComponentFixture<ActionsViewModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActionsViewModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActionsViewModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
