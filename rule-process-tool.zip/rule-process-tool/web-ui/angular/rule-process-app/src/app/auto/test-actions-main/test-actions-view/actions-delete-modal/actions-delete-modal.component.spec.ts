import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActionsDeleteModalComponent } from './actions-delete-modal.component';

describe('ActionsDeleteModalComponent', () => {
  let component: ActionsDeleteModalComponent;
  let fixture: ComponentFixture<ActionsDeleteModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActionsDeleteModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActionsDeleteModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
