import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestSuiteReportsComponent } from './test-suite-reports.component';

describe('TestSuiteReportsComponent', () => {
  let component: TestSuiteReportsComponent;
  let fixture: ComponentFixture<TestSuiteReportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestSuiteReportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestSuiteReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
