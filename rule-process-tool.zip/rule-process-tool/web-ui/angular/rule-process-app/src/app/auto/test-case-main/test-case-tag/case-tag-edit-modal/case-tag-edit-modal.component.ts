import { AppConfig } from './../../../../app-config.service';
import { HttpTemplateService } from './../../../../service/template/http-template.service';
import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

export interface modalResult {
  result: string;
  list: string[];
}

@Component({
  selector: 'app-case-tag-edit-modal',
  templateUrl: './case-tag-edit-modal.component.html',
  styleUrls: ['./case-tag-edit-modal.component.css']
})
export class CaseTagEditModalComponent implements OnInit {

  _ngEditApiData = null;
  _ngActionsNameList: string[];
  actionNameMyControl = new FormControl();
  actionNamefilteredOptions: Observable<string[]>;

  _ngEditCaseTagTestcaseName = null;
  _ngEditCaseTagActionStepNo = null;
  _ngEditCaseTagActionName = null;
  _ngEditCaseTagActionActiveFlag = null;

  private _actionNameFilter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this._ngActionsNameList.filter(option => option.toLowerCase().includes(filterValue));
  }

  getActionName = this.actionNameMyControl.valueChanges.subscribe(value => { this._ngEditCaseTagActionName = value })

  ngOnInit() {

    let subs2: Subscription = this.http.getCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_GET_API_TESTCASE_ACTION_LIST).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      if (result['testActions']) {
        this._ngActionsNameList = result['testActions']
        this.actionNamefilteredOptions = this.actionNameMyControl.valueChanges
          .pipe(
            startWith(''),
            map(value => this._actionNameFilter(value))
          );
      } else {
        this.notify('error', 'Test Actions Load Failed', 'List is NULL or Empty.');
      }
    },
      error => {
        this.notify('error', 'Case Create', 'Failed : ' + error.message);
      });
  }

  constructor(
    public dialogRef: MatDialogRef<CaseTagEditModalComponent>, private http: HttpTemplateService, private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any) {

    this._ngEditApiData = data;
    this._ngEditCaseTagTestcaseName = data['caseName'];
    this._ngEditCaseTagActionStepNo = data['stepNumber'];
    this.actionNameMyControl.setValue(data['actionName']);
    this._ngEditCaseTagActionName = data['actionName'];
    if (data['active'] == 'true') { this._ngEditCaseTagActionActiveFlag = true; }
    else if (data['active'] == 'false') { this._ngEditCaseTagActionActiveFlag = false; }
  }
  bsColumns: string[] = [];
  _isActionInProgress = null;
  modalResultToRet: modalResult = null;
  onUpdateClick() {
    let tempActionCount = this._ngActionsNameList.filter(eachItem => eachItem == this._ngEditCaseTagActionName).length;
    if (tempActionCount == 1) {
      // Service Call
      let newTagAction: any = {
        caseName: this._ngEditCaseTagTestcaseName,
        stepNumber: this._ngEditCaseTagActionStepNo,
        actionName: this._ngEditCaseTagActionName,
        active: this._ngEditCaseTagActionActiveFlag,
        created_by: "layyakannu",
        updated_by: "layyakannu",
      }
      console.log(newTagAction);

      this._isActionInProgress = true;
      let subs2: Subscription = this.http.putCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_GET_POST_API_TESTCASE_TRN, newTagAction).subscribe(response => {
        subs2.unsubscribe();
        let result: any = response;
        this._isActionInProgress = false;
        if (result.status && result.status == "success") {
          this.notify('success', 'Edit Tagged Action', 'Success');
          for (let entry of JSON.parse(result.secondKey)) {
            console.log(entry);
            this.bsColumns.push(entry);
          }
          this.modalResultToRet = {
            result: "success",
            list: this.bsColumns
          }
          //this.dialogRef.close("success");
          this.dialogRef.close(this.modalResultToRet);
        } else
          this.notify('error', 'Edit Tagged Action', 'Failed : ' + result.reason);
      },
        error => {
          this._isActionInProgress = false;
          this.notify('error', 'Edit Tagged Action', 'Failed : ' + error.message);
        });

    } else {
      this.notify('error', 'Action Invalid Selection', 'Choose a Valid Item');
      this.actionNameMyControl.setValue('');
      this._ngEditCaseTagActionName = "";
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 5000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }
}
