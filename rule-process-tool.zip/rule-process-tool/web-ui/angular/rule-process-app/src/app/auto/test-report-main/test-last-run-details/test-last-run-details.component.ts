import { HttpParams } from '@angular/common/http';
import { AppConfig } from './../../../app-config.service';
import { HttpTemplateService } from './../../../service/template/http-template.service';
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-test-last-run-details',
  templateUrl: './test-last-run-details.component.html',
  styleUrls: ['./test-last-run-details.component.css']
})
export class TestLastRunDetailsComponent implements OnInit {
  _apiLastRunDetails: any = null;
  _apiRunsTestCasesList: any[] = null;
  _isLastRunDetailsApiCallInProgress = null;
  viewReporthrefLink = null;
  saveReporthrefLink = null;

  constructor(private http: HttpTemplateService, private toastr: ToastrService) {
  }

  ngOnInit() {
    let params = new HttpParams().set('username', "layyakannu");
    this._isLastRunDetailsApiCallInProgress = true;
    let subs: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_API_TEST_LAST_RUN_DETAILS, params).subscribe(response => {
      subs.unsubscribe;
      this._apiLastRunDetails = response;
      this._apiRunsTestCasesList = response["testCasesReportTrn"];
      this.viewReporthrefLink = AppConfig.API_HOST+AppConfig.DB_API_OPEN_HTML_REPORT_RUN_ID+this._apiLastRunDetails["report_file"];
      this.saveReporthrefLink = AppConfig.API_HOST+AppConfig.DB_API_SAVE_HTML_REPORT_RUN_ID+this._apiLastRunDetails["report_file"];
      this._isLastRunDetailsApiCallInProgress = false;
      console.log("Constructor of modal loaded with href also");
    console.log(this.viewReporthrefLink);
    }, error => {
      this._isLastRunDetailsApiCallInProgress = false;
      this.notify('error', 'Last Run Details', 'List Failed to Load : ' + error.message);
    });
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 5000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
