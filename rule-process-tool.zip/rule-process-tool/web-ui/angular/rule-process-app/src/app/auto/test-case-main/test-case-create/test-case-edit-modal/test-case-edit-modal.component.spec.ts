import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestCaseEditModalComponent } from './test-case-edit-modal.component';

describe('TestCaseEditModalComponent', () => {
  let component: TestCaseEditModalComponent;
  let fixture: ComponentFixture<TestCaseEditModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestCaseEditModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestCaseEditModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
