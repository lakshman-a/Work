import { Validators, FormControl } from '@angular/forms';
import { HttpParams } from '@angular/common/http';
import { AppConfig } from './../../../../app-config.service';
import { ToastrService } from 'ngx-toastr';
import { HttpTemplateService } from './../../../../service/template/http-template.service';
import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-actions-edit-modal',
  templateUrl: './actions-edit-modal.component.html',
  styleUrls: ['./actions-edit-modal.component.css']
})
export class ActionsEditModalComponent {

  actionRequestHeaderToggle = true;
  actionResponseHeaderToggle = true;
  isActionPositive = false;
  _ngProjectName = "Default";
  _componentListApiresponse = null;
  _componentList: string[];
  _checkpointList: string[];

  actionDescFormControl = new FormControl('', [
    Validators.required
  ]);

  _ngHttpActionList: string[] = ['GET', 'POST', 'PUT', 'DELETE'];
  _ngEditActionURLOptionsList: string[] = ['URL', 'STAGE'];
  _apiDataFromParent = null;

  //1. Action Details
  _ngEditActionName = null;
  _ngEditActionDesc = null;

  //Request Actions
  _ngEditActionHttp = null;
  _ngEditActionOption = null;
  _ngEditActionHttpURL = null;
  _ngEditActionHttpType = null;
  _ngEditActionHttpStage = null;
  _ngEditActionHttpPort = null;
  _ngEditActionHttpURI = null;
  _ngEditRequestComponent = null;
  _ngEditRequestCheckpoint = null;
  _ngEditHeaderDetails = null;
  _ngEditRequestBody = null;
  _ngEditRequestParams = null;

  //Response Actions
  _ngEditResponseAction = null;
  _ngEditResponseBody = null;
  _ngEditResponseCodeFlag = null;
  _ngEditResponseCodeValue = null;
  _ngEditResponseStatusFlag = null;
  _ngEditResponseStatusValue = null;
  _ngEditResponseBuildAssertParams = null;
  _ngEditResponseExtractSaveParams = null;
  _ngEditaActionActive = null;

  _ngEditAddActionInProgress = null;

  constructor(
    public dialogRef: MatDialogRef<ActionsEditModalComponent>, private http: HttpTemplateService, private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this._apiDataFromParent = data;
    let params = new HttpParams().set('actionName', data['actionName']);
    let subs: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_POST_API_NEW_TEST_ACTION, params).subscribe(response => {
      subs.unsubscribe;
      let result: any = response;
      this.apiCallForComponentListLoad(data);
      this._ngEditActionName = result['actionName'];
      this._ngEditActionDesc = result['actionDesc'];
      this._ngProjectName = result['projectName'];
      this._ngEditRequestComponent = result['componentName'];
      this._ngEditRequestCheckpoint = result['checkpointName'];
      this._ngEditActionHttp = result['httpMethod'];
      this._ngEditActionOption = result['httpUrlFlag'];
      this._ngEditActionHttpURL = result['httpUrl'];
      this._ngEditActionHttpType = result['httpStageProtocol'];
      this._ngEditActionHttpStage = result['httpStageName'];
      this._ngEditActionHttpPort = result['httpStagePort'];
      this._ngEditActionHttpURI = result['httpStageUri'];

      this._ngEditResponseCodeValue = result['responseCodeValue'];
      this._ngEditResponseStatusFlag = result['responseStatusFlag'];
      this._ngEditResponseStatusValue = result['responseStatusValue'];
      this._ngEditResponseAction = result['responseAction'];
      this._ngEditResponseBody = result['responseBody'];

      if (result['headers']) {
        this._ngEditHeaderDetails = JSON.parse(result['headers']);
      }

      this._ngEditRequestBody = result['requestBody'];
      if (result['requestParams']) {
        this._ngEditRequestParams = JSON.parse(result['requestParams']);
      }

      if (result['responseAssertParams']) {
        this._ngEditResponseBuildAssertParams = JSON.parse(result['responseAssertParams']);
      }
      if (result['responseExtractParams']) {
        this._ngEditResponseExtractSaveParams = JSON.parse(result['responseExtractParams']);
      }

      if (result['active'] == 'true') {
        this._ngEditaActionActive = true;
      } else if (result['active'] == 'false') {
        this._ngEditaActionActive = false;
      }

      if (result['responseCodeFlag'] == 'true') {
        this._ngEditResponseCodeFlag = true;
      } else if (result['responseCodeFlag'] == 'false') {
        this._ngEditResponseCodeFlag = false;
      }
    }, error => {
      this.notify('error', 'Test Action - ' + this._apiDataFromParent['actionName'], 'Error occured while Action Details : ' + error.message);
    });
  }

  _ngCompListLoadInProgress = null
  apiCallForComponentListLoad(data) {
    this._ngCompListLoadInProgress = true;
    let params = new HttpParams().set('projectName', this._ngProjectName);
    let subs2: Subscription = this.http.getCallWithHeadersParams(AppConfig.API_HOST + AppConfig.DB_API_COMPONENTS_LIST, params).subscribe(response => {
      subs2.unsubscribe;
      this._ngCompListLoadInProgress = false
      let result: any = response;
      this._componentListApiresponse = result;
      this._componentList = result.map(eachItem => eachItem.component);
      if (data['componentName']) {
        this._checkpointList = this._componentListApiresponse.filter(eachItem => eachItem.component === data['componentName'])[0]['checkpoints'];
      }
    }, error => {
      this._ngCompListLoadInProgress = false
      this.notify('error', 'Component Details', 'Error occured while Loadings Rules : ' + error.message);
    });
  }

  onComponentChange(component: any) {
    if (component) {
      this._checkpointList = this._componentListApiresponse.filter(eachItem => eachItem.component === component)[0].checkpoints;
    }
    this._ngEditRequestCheckpoint = null;
  }

  _isActionInProgress = null;
  onUpdateClick() {
    if (this.actionDescFormControl.untouched && !this._ngEditActionDesc) {
      this.actionDescFormControl.markAsTouched();
      this.notifyWithTime('error', 2000, 'Mandatory field Missing', 'Description');
      return;
    }
    if (this.actionDescFormControl.touched && this._ngEditActionDesc == '') {
      this.actionDescFormControl.markAsTouched();
      this.notifyWithTime('error', 2000, 'Mandatory field Missing', 'Description');
      return;
    }
    let editActionSubmitBody: any = {
      actionName: this._ngEditActionName,
      actionDesc: this._ngEditActionDesc,
      projectName: this._ngProjectName,
      httpMethod: this._ngEditActionHttp,

      httpUrlFlag: this._ngEditActionOption,
      httpUrl: this._ngEditActionHttpURL,
      httpStageProtocol: this._ngEditActionHttpType,
      httpStageName: this._ngEditActionHttpStage,
      httpStagePort: this._ngEditActionHttpPort,
      httpStageUri: this._ngEditActionHttpURI,

      componentName: this._ngEditRequestComponent,
      checkpointName: this._ngEditRequestCheckpoint,
      headers: JSON.stringify(this._ngEditHeaderDetails.filter(eachItem => eachItem['key'] != "")),
      requestBody: this._ngEditRequestBody,
      requestParams: JSON.stringify(this._ngEditRequestParams.filter(eachItem => eachItem['paramName'] != "")),
      responseAction: this._ngEditResponseAction,
      responseBody: this._ngEditResponseBody,
      responseCodeFlag: this._ngEditResponseCodeFlag,
      responseCodeValue: this._ngEditResponseCodeValue,
      responseStatusFlag: this._ngEditResponseStatusFlag,
      responseStatusValue: this._ngEditResponseStatusValue,
      responseAssertParams: JSON.stringify(this._ngEditResponseBuildAssertParams.filter(eachItem => eachItem['paramName'] != "")),
      responseExtractParams: JSON.stringify(this._ngEditResponseExtractSaveParams.filter(eachItem => eachItem['jsonPath'] != "")),
      active: this._ngEditaActionActive,
      created_by: "layyakannu",
      updated_by: "layyakannu"
    }

    this._isActionInProgress = true;
    let subs2: Subscription = this.http.putCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_POST_API_NEW_TEST_ACTION, editActionSubmitBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      this._isActionInProgress = false;
      if (result.status && result.status == "success") {
        this.notify('success', 'Action Update', 'Success');
        this.isActionPositive = true;
        this.dialogRef.close("success");
      } else {
        this.notify('error', 'Action Update', 'Failed : ' + result.reason);
        this.isActionPositive = false;
      }
    },
      error => {
        this._isActionInProgress = false;
        this.notify('error', 'Action Update', 'Failed : ' + error.message);
        this.isActionPositive = false;
      });

  }

  extractValues() {
    console.log("Extract values button clicked. To be implemented!");
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  // ----------- PARAMETER ADDITION -------------- //
  addRequestParamLine() {
    this._ngEditRequestParams.push({ paramType: 'runtime', paramName: "", paramValue: "" });
  }

  removeRequestParmaLine(param) {
    this._ngEditRequestParams = this._ngEditRequestParams.filter(item => item !== param);
  }

  addResponseParamLine() {
    this._ngEditResponseBuildAssertParams.push({ paramType: 'runtime', paramName: "", paramValue: "" });
  }

  removeResponseParmaLine(param) {
    this._ngEditResponseBuildAssertParams = this._ngEditResponseBuildAssertParams.filter(item => item !== param);
  }

  addResponseExtractLine() {
    this._ngEditResponseExtractSaveParams.push({ jsonPath: "", jsonValue: "", variable: "" });
  }

  removeResponseExtractLine(param) {
    this._ngEditResponseExtractSaveParams = this._ngEditResponseExtractSaveParams.filter(item => item !== param);
  }

  addHeader() {
    this._ngEditHeaderDetails.push({ key: "", value: "" });
  }

  removeHeader(headerDetail) {
    this._ngEditHeaderDetails = this._ngEditHeaderDetails.filter(item => item !== headerDetail);
  }

  // ----------- TOGGLE Action -------------- //

  onRequestDetailsClick() {
    this.actionRequestHeaderToggle = !this.actionRequestHeaderToggle;
  }

  onResponseDetailsClick() {
    this.actionResponseHeaderToggle = !this.actionResponseHeaderToggle;
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 5000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }


  notifyWithTime(status: string, sec: number, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: sec,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: sec,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: sec,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: sec,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
