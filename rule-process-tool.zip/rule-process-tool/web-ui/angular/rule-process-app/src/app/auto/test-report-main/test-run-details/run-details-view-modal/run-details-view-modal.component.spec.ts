import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RunDetailsViewModalComponent } from './run-details-view-modal.component';

describe('RunDetailsViewModalComponent', () => {
  let component: RunDetailsViewModalComponent;
  let fixture: ComponentFixture<RunDetailsViewModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RunDetailsViewModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RunDetailsViewModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
