import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TriggerResultModalComponent } from './trigger-result-modal.component';

describe('TriggerResultModalComponent', () => {
  let component: TriggerResultModalComponent;
  let fixture: ComponentFixture<TriggerResultModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TriggerResultModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TriggerResultModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
