import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestLastRunDetailsComponent } from './test-last-run-details.component';

describe('TestLastRunDetailsComponent', () => {
  let component: TestLastRunDetailsComponent;
  let fixture: ComponentFixture<TestLastRunDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestLastRunDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestLastRunDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
