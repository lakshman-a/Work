import { TestReportListModalComponent } from './../test-report-list-modal/test-report-list-modal.component';
import { RunDetailsViewModalComponent } from './../test-run-details/run-details-view-modal/run-details-view-modal.component';
import { HttpTemplateService } from './../../../service/template/http-template.service';
import { AppConfig } from './../../../app-config.service';

import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material';
import { Subscription } from 'rxjs';

export interface SuiteAllReportData {
  id: string;
  test_suite_name: string;
  test_suite_desc: string;
  lastResults?: string[];
  created_by?: any;
  created_tmstmp?: any;
}

@Component({
  selector: 'app-test-suite-reports',
  templateUrl: './test-suite-reports.component.html',
  styleUrls: ['./test-suite-reports.component.css']
})
export class TestSuiteReportsComponent implements OnInit {

  _isApiResultInProgress = null;
  constructor(private http: HttpTemplateService, private toastr: ToastrService, public dialog: MatDialog) { }

  //MAT:
  displayedColumns: string[] = ['id','test_suite_name', 'test_suite_desc','lastResults', 'created_by',  'created_tmstmp'];
  dataSource: MatTableDataSource<SuiteAllReportData>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  ngOnInit() {
    this._isApiResultInProgress = true;
    let subs: Subscription = this.http.getCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_TEST_SUITE_ALL_REPORT).subscribe(response => {
      subs.unsubscribe;
      this._isApiResultInProgress = false;
      let result: any = response;
      this.dataSource = new MatTableDataSource(result);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this._isApiResultInProgress = false;
      this.notify('error', 'Test Suite Runs', 'Error occured while Loading Details : ' + error.message);
    });

  }

  actionsGridRefreshCall() {
    console.log("Refresh activated for Test Actions!")
    let subs: Subscription = this.http.getCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_TEST_SUITE_ALL_REPORT).subscribe(response => {
      subs.unsubscribe;
      let result: any = response;
      this.dataSource = new MatTableDataSource(result);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this.notify('error', 'Test Suite Runs', 'Error occured while Refreshing Actions List : ' + error.message);
    });
  }

  //MAT:
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  //View MODAL FEATURE
  openViewDialog(row): void {
    const dialogRef3 = this.dialog.open(TestReportListModalComponent, {
      width: '1200px',
      maxHeight: 'calc(100vh - 120px)',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
    });
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 6000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }
}
