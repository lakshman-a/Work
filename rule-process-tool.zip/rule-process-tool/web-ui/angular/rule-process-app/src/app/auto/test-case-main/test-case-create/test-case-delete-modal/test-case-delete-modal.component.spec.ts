import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestCaseDeleteModalComponent } from './test-case-delete-modal.component';

describe('TestCaseDeleteModalComponent', () => {
  let component: TestCaseDeleteModalComponent;
  let fixture: ComponentFixture<TestCaseDeleteModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestCaseDeleteModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestCaseDeleteModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
