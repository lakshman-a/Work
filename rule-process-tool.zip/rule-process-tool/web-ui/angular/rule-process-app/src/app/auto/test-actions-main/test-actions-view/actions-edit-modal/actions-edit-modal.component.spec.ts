import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActionsEditModalComponent } from './actions-edit-modal.component';

describe('ActionsEditModalComponent', () => {
  let component: ActionsEditModalComponent;
  let fixture: ComponentFixture<ActionsEditModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActionsEditModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActionsEditModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
