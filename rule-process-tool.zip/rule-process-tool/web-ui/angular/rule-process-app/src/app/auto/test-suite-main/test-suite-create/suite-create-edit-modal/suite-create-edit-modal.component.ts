import { Component, Inject } from '@angular/core';
import { AppConfig } from './../../../../app-config.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpTemplateService } from './../../../../service/template/http-template.service';

import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-suite-create-edit-modal',
  templateUrl: './suite-create-edit-modal.component.html',
  styleUrls: ['./suite-create-edit-modal.component.css']
})
export class SuiteCreateEditModalComponent {

  _ngEditSuiteName = null;
  _ngEditSuiteDesc = null;
  _ngEditSuiteActiveFlag = null;

  constructor(
    public dialogRef: MatDialogRef<SuiteCreateEditModalComponent>, private http: HttpTemplateService, private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any) {

    this._ngEditSuiteName = data['test_suite_name'];
    this._ngEditSuiteDesc = data['test_suite_desc'];

    if (data['active'] == 'true') { this._ngEditSuiteActiveFlag = true; }
    else if (data['active'] == 'false') { this._ngEditSuiteActiveFlag = false; }
  }
  _isActionInProgress = null;
  onUpdateClick() {

    let editSuiteSubmitBody: any = {
      test_suite_name: this._ngEditSuiteName,
      test_suite_desc: this._ngEditSuiteDesc,
      active: this._ngEditSuiteActiveFlag,
      updated_by: "layyakannu"
    }
    this._isActionInProgress = true;
    let subs2: Subscription = this.http.putCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_TESTSUITE_MODIFY, editSuiteSubmitBody).subscribe(response => {
      subs2.unsubscribe();
      let result: any = response;
      this._isActionInProgress = false;
      if (result.status && result.status == "success") {
        this.notify('success', 'Suite Details Edit', 'Success');
        this.dialogRef.close("success");
      } else
        this.notify('error', 'Suite Details Edit', 'Failed : ' + result.reason);
    },
      error => {
        this._isActionInProgress = false;
        this.notify('error', 'Suite Details Edit', 'Failed : ' + error.message);
      });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 5000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 3000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
