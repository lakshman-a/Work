import { ActionsEditModalComponent } from './actions-edit-modal/actions-edit-modal.component';
import { ActionsDeleteModalComponent } from './actions-delete-modal/actions-delete-modal.component';
import { ActionsViewModalComponent } from './actions-view-modal/actions-view-modal.component';
import { HttpTemplateService } from './../../../service/template/http-template.service';
import { AppConfig } from './../../../app-config.service';

import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription } from 'rxjs';

export interface RuleData {
  id: string;
  actionDesc: string;
  actionName: string;
  checkpointName?: any;
  componentName?: any;
  projectName: string;
  headers?: any;
  httpMethod: string;
  httpUrl: string;
  requestBody?: any;
  requestParams?: any;
  responseAction: string;
  responseBody?: any;
  responseAssertParams?: any;
  responseExtractParams?: any;
  active: string;
  created_tmstmp: string;
  created_by: string;
  updated_tmstmp: string;
  updated_by: string;
}

@Component({
  selector: 'app-test-actions-view',
  templateUrl: './test-actions-view.component.html',
  styleUrls: ['./test-actions-view.component.css']
})
export class TestActionsViewComponent implements OnInit {

  constructor(private http: HttpTemplateService, private toastr: ToastrService, public dialog: MatDialog) { }

  //MAT:
  displayedColumns: string[] = ['actionName', 'actionDesc', 'httpMethod', 'responseAction', 'active', 'projectName', 'created_by', 'action'];
  dataSource: MatTableDataSource<RuleData>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  _ngActionsLoadInProgress = null;
  ngOnInit() {
    this._ngActionsLoadInProgress = true;
    let subs: Subscription = this.http.getCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_GET_API_TEST_ACTIONS).subscribe(response => {
      subs.unsubscribe;
      this._ngActionsLoadInProgress = false;
      let result: any = response;
      this.dataSource = new MatTableDataSource(result);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this._ngActionsLoadInProgress = false;
      this.notify('error', 'Test Actions', 'Error occured while Loading Details : ' + error.message);
    });

  }

  actionsGridRefreshCall() {
    let subs: Subscription = this.http.getCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_GET_API_TEST_ACTIONS).subscribe(response => {
      subs.unsubscribe;
      let result: any = response;
      this.dataSource = new MatTableDataSource(result);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }, error => {
      this.notify('error', 'Test Actions', 'Error occured while Refreshing Actions List : ' + error.message);
    });
  }

  //MAT:
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  //EDIT MODAL FEATURE
  openEditDialog(row): void {
    const dialogRef = this.dialog.open(ActionsEditModalComponent, {
      width: '1500px',
      //maxHeight: '100vh',
      maxHeight: 'calc(100vh - 120px)',
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result == 'success') {
        this.actionsGridRefreshCall();
      }

    });
  }

  //DELETE MODAL FEATURE
  openDeleteDialog(row): void {
    const dialogRef2 = this.dialog.open(ActionsDeleteModalComponent, {
      width: '800px',
      data: row
    });

    dialogRef2.afterClosed().subscribe(result => {
      if (result == 'success') {
        this.actionsGridRefreshCall();
      }
    });
  }

  //View MODAL FEATURE
  openViewDialog(row): void {
    const dialogRef3 = this.dialog.open(ActionsViewModalComponent, {
      width: '1000px',
      maxHeight: 'calc(100vh - 120px)',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
    });
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 6000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }

}
