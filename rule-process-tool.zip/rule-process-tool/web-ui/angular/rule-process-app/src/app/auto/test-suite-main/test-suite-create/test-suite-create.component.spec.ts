import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestSuiteCreateComponent } from './test-suite-create.component';

describe('TestSuiteCreateComponent', () => {
  let component: TestSuiteCreateComponent;
  let fixture: ComponentFixture<TestSuiteCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestSuiteCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestSuiteCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
