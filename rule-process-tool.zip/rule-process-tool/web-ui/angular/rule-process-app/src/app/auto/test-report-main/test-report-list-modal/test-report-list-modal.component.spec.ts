import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestReportListModalComponent } from './test-report-list-modal.component';

describe('TestReportListModalComponent', () => {
  let component: TestReportListModalComponent;
  let fixture: ComponentFixture<TestReportListModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestReportListModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestReportListModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
