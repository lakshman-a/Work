import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuiteCreateEditModalComponent } from './suite-create-edit-modal.component';

describe('SuiteCreateEditModalComponent', () => {
  let component: SuiteCreateEditModalComponent;
  let fixture: ComponentFixture<SuiteCreateEditModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuiteCreateEditModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuiteCreateEditModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
