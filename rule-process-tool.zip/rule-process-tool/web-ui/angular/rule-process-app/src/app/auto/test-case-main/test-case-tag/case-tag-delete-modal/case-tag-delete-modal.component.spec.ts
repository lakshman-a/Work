import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseTagDeleteModalComponent } from './case-tag-delete-modal.component';

describe('CaseTagDeleteModalComponent', () => {
  let component: CaseTagDeleteModalComponent;
  let fixture: ComponentFixture<CaseTagDeleteModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaseTagDeleteModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseTagDeleteModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
