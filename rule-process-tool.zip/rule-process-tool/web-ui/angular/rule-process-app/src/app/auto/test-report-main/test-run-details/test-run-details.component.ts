import { RunDetailsViewModalComponent } from './run-details-view-modal/run-details-view-modal.component';
import { HttpTemplateService } from './../../../service/template/http-template.service';
import { AppConfig } from './../../../app-config.service';

import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material';
import { Subscription } from 'rxjs';

export interface ReportData {
  id: string;
  run_id: string;
  run_level: string;
  test_name?: string;
  stage?: any;
  case_count?: any;
  status: string;
  result: string;
  report_file?: any;
  comments?: any;
  grid_url: string;
  browser?: any;
  triggered_by?: any;
  triggered_tmstmp?: any;
  percentComplete: string;
}

@Component({
  selector: 'app-test-run-details',
  templateUrl: './test-run-details.component.html',
  styleUrls: ['./test-run-details.component.css']
})
export class TestRunDetailsComponent implements OnInit {

  _viewReportHostUri = null;
  _saveReportHostUri = null;
  _isApiResultInProgress = null;
  constructor(private http: HttpTemplateService, private toastr: ToastrService, public dialog: MatDialog) { }

  //MAT:
  displayedColumns: string[] = ['run_id','run_level', 'test_name',  'case_count', 'status', 'result', 'report_file', 'triggered_by','triggered_tmstmp' ];
  dataSource: MatTableDataSource<ReportData>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  ngOnInit() {
    this._isApiResultInProgress = true;
    this._viewReportHostUri= AppConfig.API_HOST+AppConfig.DB_API_OPEN_HTML_REPORT_RUN_ID;
    this._saveReportHostUri= AppConfig.API_HOST+AppConfig.DB_API_SAVE_HTML_REPORT_RUN_ID;
    console.log(AppConfig.API_HOST + AppConfig.DB_API_TESTRUN_LIST);
    let subs: Subscription = this.http.getCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_TESTRUN_LIST).subscribe(response => {
      subs.unsubscribe;
      this._isApiResultInProgress = false;
      let result: any = response;
      this.dataSource = new MatTableDataSource(result);
      setTimeout(() => this.dataSource.paginator = this.paginator);
      this.dataSource.sort = this.sort;
    }, error => {
      this._isApiResultInProgress = false;
      this.notify('error', 'Test Run History', 'Error occured while Loading Details : ' + error.message);
    });

  }

  actionsGridRefreshCall() {
    console.log("Refresh activated for Test Actions!")
    let subs: Subscription = this.http.getCallWithHeaders(AppConfig.API_HOST + AppConfig.DB_API_TESTRUN_LIST).subscribe(response => {
      subs.unsubscribe;
      let result: any = response;
      this.dataSource = new MatTableDataSource(result);
      setTimeout(() => this.dataSource.paginator = this.paginator);
      this.dataSource.sort = this.sort;
    }, error => {
      this.notify('error', 'Test Run History', 'Error occured while Refreshing Actions List : ' + error.message);
    });
  }

  //MAT:
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  //View MODAL FEATURE
  openViewDialog(row): void {
    const dialogRef3 = this.dialog.open(RunDetailsViewModalComponent, {
      width: '1200px',
      maxHeight: 'calc(100vh - 120px)',
      data: row
    });

    dialogRef3.afterClosed().subscribe(result => {
    });
  }

  //---------------------------- TOASTR NOTIFY ----------------------//

  notify(status: string, headMessage: string, details: any) {
    if (status == 'success') {
      this.toastr.success(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'error') {
      this.toastr.error(details, headMessage, {
        closeButton: true,
        timeOut: 6000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'info') {
      this.toastr.info(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    } else if (status == 'warn') {
      this.toastr.warning(details, headMessage, {
        closeButton: true,
        timeOut: 4000,
        positionClass: 'toast-bottom-right',
        progressBar: true
      });
    }
  }
}
