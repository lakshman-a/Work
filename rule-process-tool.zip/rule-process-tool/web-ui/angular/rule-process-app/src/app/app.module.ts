import { RuleJarExtractComponent } from './pages/rule-jar-extract/rule-jar-extract.component';
import { RuleValidationComponent } from './pages/rule-validation/rule-validation.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule, MatCheckboxModule, MatSlideToggleModule, MatAutocompleteModule, MatToolbarModule, MatTooltipModule, MatSidenavModule, MatButtonToggleModule, MatIconModule, MatListModule, MatGridListModule, MatCardModule, MatMenuModule, MatTableModule, MatPaginatorModule, MatSortModule, MatFormFieldModule, MatSelectModule, MatOptionModule, MatInputModule, MatProgressBarModule, MatProgressSpinnerModule, MatTabsModule, MatSnackBarModule, MAT_DIALOG_DATA, MatDialogRef, MatExpansionModule, MatRadioModule, MatSliderModule, MatChipsModule, MatBadgeModule } from '@angular/material';
import { HttpClientModule } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';
import { ChartsModule } from 'ng2-charts/ng2-charts';
import { ChartModule } from 'angular-highcharts';

import { AppComponent } from './app.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { LayoutModule } from '@angular/cdk/layout';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';
import { MatDialogModule } from '@angular/material/dialog';
import { ComponentModalComponent } from './nav-bar/component-modal/component-modal.component';
import { AgGridModule } from 'ag-grid-angular';
import { PostProcessDeployComponent } from './pages/post-process-deploy/post-process-deploy.component';
import { RuleDetailComponent } from './pages/rule-detail/rule-detail.component';
import { CreateRuleComponent } from './pages/create-rule/create-rule.component';
import { SetupDcComponent } from './pages/setup-dc/setup-dc.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { CreateDisputeComponent } from './pages/dispute/create-dispute/create-dispute.component';
import { TransitDisputeComponent } from './pages/dispute/transit-dispute/transit-dispute.component';
import { DisputeTrnComponent } from './pages/dispute/dispute-trn/dispute-trn.component';
import { RuleEditModalComponent } from './pages/rule-detail/rule-edit-modal/rule-edit-modal.component';
import { RuleDeleteModalComponent } from './pages/rule-detail/rule-delete-modal/rule-delete-modal.component';
import { RuleViewModalComponent } from './pages/rule-detail/rule-view-modal/rule-view-modal.component';
import { TestActionsMainComponent } from './auto/test-actions-main/test-actions-main.component';
import { TestActionsCreateComponent } from './auto/test-actions-main/test-actions-create/test-actions-create.component';
import { TestActionsViewComponent } from './auto/test-actions-main/test-actions-view/test-actions-view.component';
import { TestCaseMainComponent } from './auto/test-case-main/test-case-main.component';
import { TestCaseCreateComponent } from './auto/test-case-main/test-case-create/test-case-create.component';
import { TestCaseTagComponent } from './auto/test-case-main/test-case-tag/test-case-tag.component';
import { TestCaseEditModalComponent } from './auto/test-case-main/test-case-create/test-case-edit-modal/test-case-edit-modal.component';
import { TestCaseViewModalComponent } from './auto/test-case-main/test-case-create/test-case-view-modal/test-case-view-modal.component';
import { TestCaseDeleteModalComponent } from './auto/test-case-main/test-case-create/test-case-delete-modal/test-case-delete-modal.component';
import { CaseTagEditModalComponent } from './auto/test-case-main/test-case-tag/case-tag-edit-modal/case-tag-edit-modal.component';
import { CaseTagViewModalComponent } from './auto/test-case-main/test-case-tag/case-tag-view-modal/case-tag-view-modal.component';
import { CaseTagDeleteModalComponent } from './auto/test-case-main/test-case-tag/case-tag-delete-modal/case-tag-delete-modal.component';
import { ActionsEditModalComponent } from './auto/test-actions-main/test-actions-view/actions-edit-modal/actions-edit-modal.component';
import { ActionsViewModalComponent } from './auto/test-actions-main/test-actions-view/actions-view-modal/actions-view-modal.component';
import { ActionsDeleteModalComponent } from './auto/test-actions-main/test-actions-view/actions-delete-modal/actions-delete-modal.component';
import { RuleCaseMapComponent } from './pages/rule-case-map/rule-case-map.component';
import { RuleCaseMapDeleteComponent } from './pages/rule-case-map/rule-case-map-delete/rule-case-map-delete.component';
import { RuleCaseMapViewComponent } from './pages/rule-case-map/rule-case-map-view/rule-case-map-view.component';
import { TestSuiteMainComponent } from './auto/test-suite-main/test-suite-main.component';
import { TestSuiteCreateComponent } from './auto/test-suite-main/test-suite-create/test-suite-create.component';
import { TestSuiteTagComponent } from './auto/test-suite-main/test-suite-tag/test-suite-tag.component';
import { SuiteTagViewModalComponent } from './auto/test-suite-main/test-suite-tag/suite-tag-view-modal/suite-tag-view-modal.component';
import { SuiteTagDeleteModalComponent } from './auto/test-suite-main/test-suite-tag/suite-tag-delete-modal/suite-tag-delete-modal.component';
import { SuiteTagEditModalComponent } from './auto/test-suite-main/test-suite-tag/suite-tag-edit-modal/suite-tag-edit-modal.component';
import { SuiteCreateViewModalComponent } from './auto/test-suite-main/test-suite-create/suite-create-view-modal/suite-create-view-modal.component';
import { SuiteCreateDeleteModalComponent } from './auto/test-suite-main/test-suite-create/suite-create-delete-modal/suite-create-delete-modal.component';
import { SuiteCreateEditModalComponent } from './auto/test-suite-main/test-suite-create/suite-create-edit-modal/suite-create-edit-modal.component';
import { TestReportMainComponent } from './auto/test-report-main/test-report-main.component';
import { TestRunDetailsComponent } from './auto/test-report-main/test-run-details/test-run-details.component';
import { TestCaseReportsComponent } from './auto/test-report-main/test-case-reports/test-case-reports.component';
import { TestSuiteReportsComponent } from './auto/test-report-main/test-suite-reports/test-suite-reports.component';
import { TestLastRunDetailsComponent } from './auto/test-report-main/test-last-run-details/test-last-run-details.component';
import { RunDetailsViewModalComponent } from './auto/test-report-main/test-run-details/run-details-view-modal/run-details-view-modal.component';
import { TestTriggerModalComponent } from './auto/test-trigger/test-trigger-modal/test-trigger-modal.component';
import { TriggerResultModalComponent } from './auto/test-trigger/trigger-result-modal/trigger-result-modal.component';
import { TriggerAyncModalComponent } from './auto/test-trigger/trigger-aync-modal/trigger-aync-modal.component';
import { TestReportListModalComponent } from './auto/test-report-main/test-report-list-modal/test-report-list-modal.component';
import { ProjectsComponent } from './pages/settings/projects/projects.component';
import { ComponentsComponent } from './pages/settings/components/components.component';
import { ComponentsViewModalComponent } from './pages/settings/components/components-view-modal/components-view-modal.component';
import { CheckpointsViewModalComponent } from './pages/settings/components/checkpoints-view-modal/checkpoints-view-modal.component';
import { CheckpointsEditModalComponent } from './pages/settings/components/checkpoints-edit-modal/checkpoints-edit-modal.component';
import { CheckpointsDeleteModalComponent } from './pages/settings/components/checkpoints-delete-modal/checkpoints-delete-modal.component';
import { ComponentsDeleteModalComponent } from './pages/settings/components/components-delete-modal/components-delete-modal.component';
import { ComponentsEditModalComponent } from './pages/settings/components/components-edit-modal/components-edit-modal.component';

const appRoutes: Routes = [
  { path: 'post-process-deploy', component: PostProcessDeployComponent },
  { path: 'rule-detail', component: RuleDetailComponent },
  { path: 'rule-case-map', component: RuleCaseMapComponent },
  { path: 'rule-fire', component: RuleValidationComponent },
  { path: 'create-rule', component: CreateRuleComponent },
  { path: 'setup-dc', component: SetupDcComponent },
  { path: 'rule-jar-extract', component: RuleJarExtractComponent },
  { path: 'dispute-create', component: CreateDisputeComponent },
  { path: 'dispute-transit', component: TransitDisputeComponent },
  { path: 'dispute-trn', component: DisputeTrnComponent },
  { path: 'test-actions', component: TestActionsMainComponent },
  { path: 'test-case', component: TestCaseMainComponent },
  { path: 'test-suite', component: TestSuiteMainComponent },
  { path: 'test-report-main', component: TestReportMainComponent },
  { path: 'test-case-reports', component: TestCaseReportsComponent },
  { path: 'test-suite-reports', component: TestSuiteReportsComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'test-actions-view', component: TestActionsViewComponent },
  { path: 'test-actions-create', component: TestActionsCreateComponent },
  { path: 'component-config', component: ComponentsComponent },
  { path: 'project-config', component: ProjectsComponent },
  { path: '', component: DashboardComponent }

];

@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    ComponentModalComponent,
    PostProcessDeployComponent,
    RuleDetailComponent,
    RuleValidationComponent,
    CreateRuleComponent,
    SetupDcComponent,
    RuleJarExtractComponent,
    DashboardComponent,
    CreateDisputeComponent,
    TransitDisputeComponent,
    DisputeTrnComponent,
    RuleEditModalComponent,
    RuleDeleteModalComponent,
    RuleViewModalComponent,
    TestActionsMainComponent,
    TestActionsCreateComponent,
    TestActionsViewComponent,
    TestCaseMainComponent,
    TestCaseCreateComponent,
    TestCaseTagComponent,
    TestCaseEditModalComponent,
    TestCaseViewModalComponent,
    TestCaseDeleteModalComponent,
    CaseTagEditModalComponent,
    CaseTagViewModalComponent,
    CaseTagDeleteModalComponent,
    ActionsEditModalComponent,
    ActionsViewModalComponent,
    ActionsDeleteModalComponent,
    RuleCaseMapComponent,
    RuleCaseMapDeleteComponent,
    RuleCaseMapViewComponent,
    TestSuiteMainComponent,
    TestSuiteCreateComponent,
    TestSuiteTagComponent,
    SuiteTagViewModalComponent,
    SuiteTagDeleteModalComponent,
    SuiteTagEditModalComponent,
    SuiteCreateViewModalComponent,
    SuiteCreateDeleteModalComponent,
    SuiteCreateEditModalComponent,
    TestReportMainComponent,
    TestRunDetailsComponent,
    TestCaseReportsComponent,
    TestSuiteReportsComponent,
    TestLastRunDetailsComponent,
    RunDetailsViewModalComponent,
    TestTriggerModalComponent,
    TriggerResultModalComponent,
    TriggerAyncModalComponent,
    TestReportListModalComponent,
    ProjectsComponent,
    ComponentsComponent,
    ComponentsViewModalComponent,
    CheckpointsViewModalComponent,
    CheckpointsEditModalComponent,
    CheckpointsDeleteModalComponent,
    ComponentsDeleteModalComponent,
    ComponentsEditModalComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatRadioModule,
    MatExpansionModule,
    MatCheckboxModule,
    FormsModule,
    MatButtonModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatSliderModule,
    LayoutModule,
    HttpClientModule,
    MatToolbarModule,
    MatButtonToggleModule,
    MatSidenavModule,
    MatIconModule,
    MatAutocompleteModule,
    MatSlideToggleModule,
    MatChipsModule,
    MatListModule,
    MatGridListModule,
    MatBadgeModule,
    MatCardModule,
    MatMenuModule,
    RouterModule.forRoot(appRoutes),
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatFormFieldModule,
    MatSelectModule,
    MatOptionModule,
    MatInputModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    NgxSpinnerModule,
    ReactiveFormsModule,
    MatTabsModule,
    MatDialogModule,
    MatSnackBarModule,
    MatToolbarModule,
    ChartsModule,
    ChartModule,
    ToastrModule.forRoot(),
    AgGridModule.withComponents([])
  ],
  providers: [{ provide: MAT_DIALOG_DATA, useValue: {} },
  { provide: MatDialogRef, useValue: {} }],
  bootstrap: [AppComponent],
  entryComponents: [RuleEditModalComponent,
    RuleDeleteModalComponent,
    RuleViewModalComponent,
    TestCaseEditModalComponent,
    TestCaseViewModalComponent,
    TestCaseDeleteModalComponent,
    CaseTagEditModalComponent,
    CaseTagViewModalComponent,
    CaseTagDeleteModalComponent,
    ActionsViewModalComponent,
    ActionsDeleteModalComponent,
    ActionsEditModalComponent,
    RuleCaseMapDeleteComponent,
    RuleCaseMapViewComponent,
    SuiteCreateDeleteModalComponent,
    SuiteCreateEditModalComponent,
    SuiteCreateViewModalComponent,
    SuiteTagEditModalComponent,
    SuiteTagDeleteModalComponent,
    SuiteTagViewModalComponent,
    RunDetailsViewModalComponent,
    TestTriggerModalComponent,
    TriggerResultModalComponent,
    TriggerAyncModalComponent,
    TestReportListModalComponent,
    ComponentsDeleteModalComponent,
    ComponentsEditModalComponent,
    ComponentsViewModalComponent,
    CheckpointsDeleteModalComponent,
    CheckpointsEditModalComponent,
    CheckpointsViewModalComponent
  ]
})
export class AppModule { }

