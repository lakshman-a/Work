export class AppConfig {

  //public static get API_HOST_PORT(): string { return "http://10.239.60.233:8080"; };
  public static get API_HOST_PORT(): string { return "http://localhost:8080"; };
  public static get API_PROJECT(): string { return "/rule-prcoess-api"; };
  public static get API_HOST(): string { return (AppConfig.API_HOST_PORT + AppConfig.API_PROJECT); };

  //public static get API_AUTO_HOST_PORT(): string { return "http://10.239.60.233:8081"; };
  public static get API_AUTO_HOST_PORT(): string { return "http://localhost:8081"; };
  public static get API_AUTO_PROJECT(): string { return "/hybrid-automation"; };
  public static get API_AUTO_HOST(): string { return (AppConfig.API_AUTO_HOST_PORT + AppConfig.API_AUTO_PROJECT); };

  public static get API_PLUTO_DC_LIST(): string { return "/plutoDCList"; };
  public static get API_POST_PROCESSED_JAR_LIST(): string { return "/postProcessedJarList"; };
  public static get API_UPLOAD_RULE_JAR(): string { return "/uploadFile"; };
  public static get API_DO_POST_PROESS(): string { return "/doPostProcess"; };
  public static get API_DO_POST_CHECK_CONN(): string { return "/checkConn"; };
  public static get API_DO_POST_COPY_TO_STAGE(): string { return "/copyRRDSToStage"; };
  public static get API_DO_RRDS_PROP_CHANGE(): string { return "/propChangeInRRDS"; };
  public static get API_DO_STARTSTOP_SERVICE(): string { return "/startStopService"; };
  public static get API_UPLOAD_RBO_JAR(): string { return "/rboJaruploadFile"; };

  //DB APIs
  public static get DB_API_UPLOAD_RBO_JAR(): string { return "/api/ruleJarUpload"; };
  public static get DB_API_POST_PROCESS_ACTION(): string { return "/api/postProcessAction"; };
  public static get DB_API_STAGE_PROCESS(): string { return "/api/stageProcess"; };
  public static get DB_API_STAGE_SETTINGS(): string { return "/api/stageSettings"; };
  public static get DB_API_RULE_FIRE_REQUEST(): string { return "/api/fireRuleRequest"; };
  public static get DB_GET_API_RULE_DETAILS_LIST(): string { return "/api/ruleDetailsList"; };
  public static get DB_GET_API_RULE_DETAIL_MODIFY(): string { return "/api/ruleDetail"; };
  public static get DB_GET_API_TEST_ACTIONS(): string { return "/api/testActions"; };
  public static get DB_POST_API_NEW_TEST_ACTION(): string { return "/api/testAction"; };
  public static get DB_GET_API_TESTCASES(): string { return "/api/testcaseList"; };
  public static get DB_GET_POST_API_TESTCASE(): string { return "/api/testcase"; };
  public static get DB_GET_API_TESTCASES_TRN(): string { return "/api/testcaseTrnList"; };
  public static get DB_GET_POST_API_TESTCASE_TRN(): string { return "/api/testcaseTrn"; };
  public static get DB_GET_API_TESTCASE_ACTION_LIST(): string { return "/api/testcasesAndActions"; };
  public static get DB_GET_API_RULECASE_MAP_LIST(): string { return "/api/ruleToCaseMapList"; };
  public static get DB_API_RULECASE_MAP_MODIFY(): string { return "/api/ruleToCase"; };
  public static get DB_API_TESTCASES_AND_RULES(): string { return "/api/testcasesAndRules"; };
  public static get DB_API_TESTSUITE_LIST(): string { return "/api/testSuiteList"; };
  public static get DB_API_TESTSUITE_MODIFY(): string { return "/api/testSuite"; };
  public static get DB_API_TESTSUITE_TRN_LIST(): string { return "/api/testSuiteTrnList"; };
  public static get DB_API_TESTSUITE_TRN_MODIFY(): string { return "/api/testSuiteTrn"; };
  public static get DB_API_TESTSUITE_CASE_LIST(): string { return "/api/testSuiteAndCases"; };
  public static get DB_API_TESTRUN_LIST(): string { return "/api/testReports"; };
  public static get DB_API_TEST_LAST_RUN_DETAILS(): string { return "/api/lastRunReport"; };
  public static get DB_API_FULL_REPORT_FOR_RUN_ID(): string { return "/api/reportForRunId"; };
  public static get DB_API_TEST_REPORT_FOR_RUN_ID(): string { return "/api/testReportsForRunId"; };
  public static get DB_API_OPEN_HTML_REPORT_RUN_ID(): string { return "/download/view/testReportFile/"; };
  public static get DB_API_SAVE_HTML_REPORT_RUN_ID(): string { return "/download/save/testReportFile/"; };
  public static get AUTO_API_TRIGGER_TEST_RUN(): string { return "/api/automationTrigger"; };
  public static get DB_API_TEST_SUITE_ALL_REPORT(): string { return "/api/reports/testSuites"; };
  public static get DB_API_TEST_SUITE_NAME_REPORT(): string { return "/api/reports/test"; };
  public static get DB_API_TEST_DATA_SUBMIT(): string { return "/api/testcaseData"; };
  public static get DB_API_COMPONENT_DETAILS(): string { return "/api/testComponents"; };
  public static get DB_API_COMPONENT_UPDATE(): string { return "/api/testComponent"; };
  public static get DB_API_CHECKPOINT_DETAILS(): string { return "/api/testCheckpoints"; };
  public static get DB_API_CHECKPOINT_UPDATE(): string { return "/api/testCheckpoint"; };
  public static get DB_API_COMPONENTS_LIST(): string { return "/api/testComponentsList"; };




}
