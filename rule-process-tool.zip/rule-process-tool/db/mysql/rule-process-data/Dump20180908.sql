CREATE DATABASE  IF NOT EXISTS `rule_process` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `rule_process`;
-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: rule_process
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `post_process_action`
--

DROP TABLE IF EXISTS `post_process_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `post_process_action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trigger_id` varchar(100) NOT NULL,
  `pluto_dc_version` varchar(100) NOT NULL,
  `rbo_version` varchar(100) NOT NULL,
  `rbo_jar_name` varchar(100) NOT NULL,
  `rbo_jar_desc` longtext,
  `rbo_jar_file_name` varchar(100) DEFAULT NULL,
  `rbo_jar_location` longtext,
  `component` varchar(45) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_tmstmp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(45) DEFAULT NULL,
  `log_trace` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_process_action`
--

LOCK TABLES `post_process_action` WRITE;
/*!40000 ALTER TABLE `post_process_action` DISABLE KEYS */;
INSERT INTO `post_process_action` VALUES (1,'1536320837852','pluto_postprocessing_20140926_0832','rbo-api-4.58.jar','null','null','null','null','null','layyakannu','2018-09-07 11:47:42','success','null'),(2,'1536320837852','pluto_postprocessing_20140926_0832','rbo-api-4.58.jar','rbo-api-4.58.jar','null','rbo-api-4.58.jar','null','null','layyakannu','2018-09-07 11:58:58','success','null'),(3,'1536320837852','pluto_postprocessing_20140926_0832','rbo-api-4.58.jar','null','null','null','null','null','layyakannu','2018-09-07 11:59:13','success','null'),(4,'1536320837852','pluto_postprocessing_20140926_0832','rbo-api-4.58.jar','rbo-api-4.58.jar','null','rbo-api-4.58.jar','null','null','layyakannu','2018-09-07 11:59:51','success','null'),(5,'1536320837852','pluto_postprocessing_20140926_0832','rbo-api-4.58.jar','rbo-api-4.58.jar','null','rbo-api-4.58.jar','null','null','layyakannu','2018-09-07 11:59:57','success','null'),(6,'1536321677264','pluto_postprocessing_20140926_0832','rbo-api-4.58.jar','null','null','null','null','null','layyakannu','2018-09-07 12:02:02','success','null'),(7,'1536321748166','pluto_postprocessing_20140926_0832','rbo-api-4.58.jar','rbo-api-4.58.jar','null','rbo-api-4.58.jar','null','null','layyakannu','2018-09-07 12:02:57','success','null'),(8,'1536343289441','pluto_postprocessing_20140926_0832','rbo-api-4.54.jar','null','null','null','null','null','layyakannu','2018-09-07 18:06:27','success','null'),(9,'1536343919947','pluto_postprocessing_20140926_0832','rbo-api-4.58.jar','null','null','null','null','null','layyakannu','2018-09-07 18:14:57','success','null');
/*!40000 ALTER TABLE `post_process_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_process_deploy`
--

DROP TABLE IF EXISTS `post_process_deploy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `post_process_deploy` (
  `trigger_id` varchar(100) NOT NULL,
  `rule_jar_file_name` varchar(100) DEFAULT NULL,
  `rule_jar_name` varchar(100) DEFAULT NULL,
  `rule_jar_desc` longtext,
  `pluto_dc_version` varchar(100) DEFAULT NULL,
  `rbo_jar_file_name` varchar(100) DEFAULT NULL,
  `rbo_jar_name` varchar(100) DEFAULT NULL,
  `stage_name` varchar(45) DEFAULT NULL,
  `stage_username` varchar(45) DEFAULT NULL,
  `comp_logger_level` varchar(45) DEFAULT NULL,
  `comp_file_based_flag` varchar(45) DEFAULT NULL,
  `component` varchar(45) DEFAULT NULL,
  `created_tmstmp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`trigger_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_process_deploy`
--

LOCK TABLES `post_process_deploy` WRITE;
/*!40000 ALTER TABLE `post_process_deploy` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_process_deploy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_process_runs`
--

DROP TABLE IF EXISTS `post_process_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `post_process_runs` (
  `trigger_id` int(11) NOT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_tmstmp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`trigger_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_process_runs`
--

LOCK TABLES `post_process_runs` WRITE;
/*!40000 ALTER TABLE `post_process_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_process_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rule_details`
--

DROP TABLE IF EXISTS `rule_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `rule_details` (
  `rule_id` int(11) NOT NULL,
  `rule_name` varchar(100) DEFAULT NULL,
  `rule_desc` varchar(100) DEFAULT NULL,
  `component` varchar(100) DEFAULT NULL,
  `checkoint` varchar(45) DEFAULT NULL,
  `rule` longtext,
  `created_tmstmp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(45) DEFAULT NULL,
  `updated_tmstmp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`rule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rule_details`
--

LOCK TABLES `rule_details` WRITE;
/*!40000 ALTER TABLE `rule_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `rule_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rule_jar_upload`
--

DROP TABLE IF EXISTS `rule_jar_upload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `rule_jar_upload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trigger_id` varchar(45) NOT NULL,
  `rule_jar_name` varchar(100) NOT NULL,
  `rule_jar_desc` longtext,
  `rule_jar_file_name` varchar(100) DEFAULT NULL,
  `rule_jar_location` longtext,
  `created_by` varchar(45) NOT NULL,
  `created_tmstmp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(45) DEFAULT NULL,
  `log_trace` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rule_jar_upload`
--

LOCK TABLES `rule_jar_upload` WRITE;
/*!40000 ALTER TABLE `rule_jar_upload` DISABLE KEYS */;
INSERT INTO `rule_jar_upload` VALUES (1,'1536257563286','RULE_JAR_Sample','Sample','dispute_20180828_170000_riskresolutiondecisionserv.jar','dispute_20180828_170000_riskresolutiondecisionserv.jar','layyakannun','2018-09-06 18:12:56','success','null'),(2,'1536257633515','RULE_JAR_1234','Sample 11123','dispute_20180828_170000_riskresolutiondecisionserv.jar','dispute_20180828_170000_riskresolutiondecisionserv.jar','layyakannun','2018-09-06 18:14:08','success','null'),(3,'1536257779338','RULE_JAR_Name','1123','dispute_20180828_170000_riskresolutiondecisionserv.jar','dispute_20180828_170000_riskresolutiondecisionserv.jar','layyakannu','2018-09-06 18:16:28','success','null'),(4,'1536257812061','RULE_JAR_1222','null','dispute_20180827_190500_riskresolutiondecisionserv.jar','dispute_20180827_190500_riskresolutiondecisionserv.jar','layyakannu','2018-09-06 18:19:36','success','null'),(5,'1536320263500','RULE_JAR_','null','dispute_20180828_170000_riskresolutiondecisionserv.jar','dispute_20180828_170000_riskresolutiondecisionserv.jar','layyakannu','2018-09-07 11:37:51','success','null'),(6,'1536320383670','RULE_JAR_','null','dispute_20180828_170000_riskresolutiondecisionserv.jar','dispute_20180828_170000_riskresolutiondecisionserv.jar','layyakannu','2018-09-07 11:44:04','success','null'),(7,'1536320837852','RULE_JAR_','null','dispute_20180828_170000_riskresolutiondecisionserv.jar','dispute_20180828_170000_riskresolutiondecisionserv.jar','layyakannu','2018-09-07 11:47:31','success','null'),(8,'1536320837852','RULE_JAR_123','Sam','dispute_20180828_170000_riskresolutiondecisionserv.jar','dispute_20180828_170000_riskresolutiondecisionserv.jar','layyakannu','2018-09-07 11:59:35','success','null'),(9,'1536321677264','RULE_JAR_','null','dispute_20180828_170000_riskresolutiondecisionserv.jar','dispute_20180828_170000_riskresolutiondecisionserv.jar','layyakannu','2018-09-07 12:01:47','success','null'),(10,'1536321748166','RULE_JAR_','null','dispute_20180828_170000_riskresolutiondecisionserv.jar','dispute_20180828_170000_riskresolutiondecisionserv.jar','layyakannu','2018-09-07 12:02:36','success','null'),(11,'1536343289441','RULE_JAR_','null','dispute_20180828_170000_riskresolutiondecisionserv.jar','dispute_20180828_170000_riskresolutiondecisionserv.jar','layyakannu','2018-09-07 18:05:52','success','null'),(12,'1536343919947','RULE_JAR_','null','dispute_20180828_170000_riskresolutiondecisionserv.jar','dispute_20180828_170000_riskresolutiondecisionserv.jar','layyakannu','2018-09-07 18:14:42','success','null');
/*!40000 ALTER TABLE `rule_jar_upload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stage_comp_settings`
--

DROP TABLE IF EXISTS `stage_comp_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `stage_comp_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trigger_id` varchar(45) NOT NULL,
  `logger_level` varchar(45) DEFAULT NULL,
  `file_based_flag` varchar(45) DEFAULT NULL,
  `component` varchar(45) DEFAULT NULL,
  `created_by` varchar(45) DEFAULT NULL,
  `created_tmstmp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(45) DEFAULT NULL,
  `log_trace` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stage_comp_settings`
--

LOCK TABLES `stage_comp_settings` WRITE;
/*!40000 ALTER TABLE `stage_comp_settings` DISABLE KEYS */;
INSERT INTO `stage_comp_settings` VALUES (1,'1536343919947','stage2ma152946','layyakannu','null','layyakannu','2018-09-07 18:43:03','success','RRDS Component - start done successfully.'),(2,'1536343919947','stage2ma152946','layyakannu','null','layyakannu','2018-09-07 18:43:34','success','RRDS Component - start done successfully.'),(3,'1536343919947','stage2ma152946','layyakannu','null','layyakannu','2018-09-07 18:43:59','success','RRDS Component - start done successfully.');
/*!40000 ALTER TABLE `stage_comp_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stage_copy_process`
--

DROP TABLE IF EXISTS `stage_copy_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `stage_copy_process` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trigger_id` varchar(100) NOT NULL,
  `stage_name` varchar(45) DEFAULT NULL,
  `stage_username` varchar(45) DEFAULT NULL,
  `is_check_conn` enum('true','false') DEFAULT NULL,
  `is_move_folder` enum('true','false') DEFAULT NULL,
  `component` varchar(45) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_tmstmp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(45) DEFAULT NULL,
  `log_trace` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stage_copy_process`
--

LOCK TABLES `stage_copy_process` WRITE;
/*!40000 ALTER TABLE `stage_copy_process` DISABLE KEYS */;
INSERT INTO `stage_copy_process` VALUES (1,'1536343919947','stage2ma152946','layyakannu','true','true','null','layyakannu','2018-09-07 18:15:46','success','null');
/*!40000 ALTER TABLE `stage_copy_process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `user` (
  `username` varchar(50) NOT NULL,
  `password` varchar(75) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `created_tmstmp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `active` enum('true','false') DEFAULT 'true',
  `previlages` varchar(75) DEFAULT 'false',
  PRIMARY KEY (`username`),
  UNIQUE KEY `email_id_UNIQUE` (`email_id`),
  KEY `indx_user_name` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'rule_process'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-09-08  8:58:29
