package com.paypal.risk.resolution.checkpoints;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.paypal.risk.resolution.constants.RUDSConstants;
import com.paypal.risk.resolution.model.ResponseEntity;
import com.paypal.risk.resolution.report.Report;
import com.paypal.risk.resolution.utils.ExcelUtils;
import com.paypal.risk.resolution.utils.HttpRestClient;

public class IssueInitiationUnAuthDC extends RUDSBaseTest {

	final static Logger log = Logger.getLogger(IssueInitiationUnAuthDC.class);
	Map<String, String> headerMap = new HashMap<String, String>();
	String checkpointName = RUDSConstants.ATO_UNAUTH_DC_CP;
	String excelPath = rudsDataExcelPath + checkpointName + ".xlsx";
	String schemaPath = rudsDataScehmaPath + checkpointName + ".json";
	String sheetName = checkpointName;

	@DataProvider(name = "dataProvider")
	public Object[][] testDataProvider() throws Exception {
		Object[][] testData = ExcelUtils.getTableArrayAsMap(excelPath, sheetName);
		return testData;
	}

	@Test(dataProvider = "dataProvider")
	public void test(Map<String, String> testData) throws Exception {
		HttpRestClient client = new HttpRestClient();
		String actualResponse = null;
		Map<String, String> preconditionData = new HashMap<>();
		Report.startComponent(testData.get("key"), testData.get("testcaseName"));

		try {

			// Pre-Condition Test Data Preparation (Create Buyer and Seller and perform transaction):
			if (testData.get("preconditionFlag").equalsIgnoreCase("Y")) {
				preconditionData = preconditionDataPrep(excelPath, testData, hostname);
				Report.info("<b><u>Issue Initiation UNAUTH DC Testcase validation starts...</b></u>");
			}

			// Setup URL
			String restUrl = rudsProtocal + hostname + ":" + port + "/" + RUDSConstants.ATO_UNAUTH_DC_URI;
			Report.info("<b>Rest URL =  <u>" + restUrl + "</b></u>");

			// Setup Headers
			Map<String, String> headerMap = setupHeader(testData.get("header"), preconditionData);
			Report.info("<b>Request Headers = </b> " + headerMap);

			// Setup Request [Column Name - request in Testdata sheet]
			String request = buildRequestJsonWithData(testData, preconditionData);
			Report.info("<b>Request Payload = </b>" + request);

			// Trigger API Request
			ResponseEntity responseEntity = client.doGenericPost(restUrl, headerMap, request);

			// Validation of Response
			if (responseEntity.getStatusCode() == 200) {

				if (responseEntity.getResponse() != null) {
					actualResponse = responseEntity.getResponse().toString();
					if (actualResponse.equalsIgnoreCase("")) {
						Report.fail("<b>API Response received Empty! Skipping response validation. </b> Check the Request details");
					} else {
						Report.pass("<b>API Response received = </b>" + actualResponse);
						validateResponseFields(actualResponse, testData);
					}
				}

			} else {
				String failureMessage = "<b>API Response code validation failed. Response Code = " + responseEntity.getStatusCode() + "</b>";
				Report.fail(failureMessage);
				throw new Exception(failureMessage);
			}

		} catch (Exception e) {
			Report.fail("Testcase failed due to reason : " + e);
			throw e;
		} finally {
			Report.appendComponent();
		}

	}

	@SuppressWarnings("unchecked")
	private String buildRequestJsonWithData(Map<String, String> testData, Map<String, String> preconditionData) throws Exception {
		JSONObject request = null;
		try {
			FileReader reader = new FileReader(schemaPath);

			JSONParser jsonParser = new JSONParser();
			request = (JSONObject) jsonParser.parse(reader);

			request.put("id", testData.get("id"));
			request.put("type", testData.get("type"));

			if (preconditionData.get("sellerOutputAccountNumber") != null)
				request.put("sender_account_number", preconditionData.get("sellerOutputAccountNumber"));
			else
				request.put("sender_account_number", testData.get("sender_account_number"));

			// customer_provided_data
			JSONObject customer_provided_data = (JSONObject) request.get("customer_provided_data");
			JSONArray entities_affected = (JSONArray) customer_provided_data.get("entities_affected");
			if (testData.get("customer_provided_data.entities_affected").equalsIgnoreCase("true")) {
				JSONObject entities_affected0 = (JSONObject) entities_affected.get(0);
				entities_affected0.put("entity_id", testData.get("customer_provided_data.entities_affected.entity_id"));
				entities_affected0.put("entity_type", testData.get("customer_provided_data.entities_affected.entity_id.entity_type"));
				entities_affected0.put("suspicious_activity_on_entity", testData.get("customer_provided_data.entities_affected.entity_id.suspicious_activity_on_entity"));
			}

		} catch (NullPointerException e) {
			Report.fail("<b>Issue Initiation UnAuth DC request build failed due to either Missing field in response or Testdata not available</b>");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			Report.error("Issue Initiation UnAuth DC JSON request building failed. Reason : " + e.getMessage());
			throw e;
		}

		return request.toString();
	}

	private boolean validateResponseFields(String responseObject, Map<String, String> rowDataMap) throws Exception {
		boolean result = true;
		List<Boolean> resultArr = new ArrayList<Boolean>();
		JSONObject responseJson = null;

		try {

			JSONParser jsonParser = new JSONParser();
			responseJson = (JSONObject) jsonParser.parse(responseObject);

			JSONObject actions = (JSONObject) responseJson.get("actions");
			if (rowDataMap.get("res.actions.entity_actions").equalsIgnoreCase("true")) {
				JSONArray entity_actions = (JSONArray) actions.get("entity_actions");
				JSONObject entity_action = (JSONObject) entity_actions.get(0);

				if (!rowDataMap.get("res.actions.entity_actions0.entity_id").equalsIgnoreCase(""))
					resultArr.add(Report.assertEquals("actions.entity_actions0.entity_id", entity_action.get("entity_id").toString(), rowDataMap.get("res.actions.entity_actions0.entity_id")));
				if (!rowDataMap.get("res.actions.entity_actions0.action_on_entity").equalsIgnoreCase(""))
					resultArr.add(Report.assertEquals("actions.entity_actions0.action_on_entity", entity_action.get("action_on_entity").toString(), rowDataMap.get("res.actions.entity_actions0.action_on_entity")));
			}

			if (resultArr.contains(false)) {
				result = false;
				Report.fail("Response fields validation failed.");
			} else {
				Report.pass("Response fields validation passed.");
			}

		} catch (NullPointerException | IndexOutOfBoundsException e) {
			Report.fail("<b>Issue Initiation UnAuth DC request build failed due to either Missing field in response or Testdata not available</b>");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			Report.error("Issue Initiation UnAuth DC response field validation failed. Reason : " + e.getMessage());
			e.printStackTrace();
			throw e;
		}

		return result;
	}

}
