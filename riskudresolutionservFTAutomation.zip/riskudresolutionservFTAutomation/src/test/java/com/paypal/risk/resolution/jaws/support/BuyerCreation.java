package com.paypal.risk.resolution.jaws.support;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.paypal.risk.resolution.report.Report;
import com.paypal.risk.resolution.utils.HttpRestClient;
import com.paypal.risk.resolution.utils.PropertyUtil;

/**
 * @author layyakannu Check the user if already exist, if not create the user and transaction
 */
public class BuyerCreation {

	/**
	 * Dispute_Adjudication
	 * 
	 * @param rowTestData
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> createbuyerIfNotExist(Map<String, String> rowTestData, String hostname) throws Exception {

		try {
			// Report.info("<b>Check User if Exist in JAWS</b>");

			// Create a HTTPClient to make a rest call
			HttpRestClient client = new HttpRestClient();

			// Get the URL based on JOB or Default stage configured in Config Prop
			String restUrl = PropertyUtil.getConfigValueOf("jaws.api.checkUser") + rowTestData.get("buyerEmailAddress");
			Report.info("<b>JAWS Rest API URL = </b><u>" + restUrl+"</u>");

			// Setup Headers
			Map<String, String> headerMap = setupHeadersForRequest(hostname);
			Report.info("<b>JAWS Request Headers = </b>" + headerMap);

			// Make a HTTP post call to the service with the request and header
			JSONObject responseAsJsonObject;
			try {
				responseAsJsonObject = client.doGet(restUrl, headerMap);
				Report.pass("<b>JAWS Response received successfully with Code 200. User Already Exist = </b>" + responseAsJsonObject);

				// Set the Response fields to the Run time O/P variables
				setOutputFieldsUsingRuntimeVariables(responseAsJsonObject, rowTestData);

			} catch (javax.ws.rs.WebApplicationException e) {
				JSONParser parser = new JSONParser();
				responseAsJsonObject = (JSONObject) parser.parse(e.getLocalizedMessage());
				Report.info("<b>JAWS Response received successfully as = </b>" + responseAsJsonObject);

				if (responseAsJsonObject.get("errorMessage").toString().equalsIgnoreCase("DATA_NOT_EXIST")) {
					Report.info("User Does not Exist, Creating the User...");

					// Get the URL based on JOB or Default stage configured in Config Prop
					String restPostUrl = PropertyUtil.getConfigValueOf("jaws.api.createUserProfile");
					Report.info("<b>JAWS Rest API URL = </b>" + restPostUrl);

					// Create a User and Do a Transaction
					JSONObject request = cookJsonUserAccountRequestWithData(rowTestData);
					Report.info("<b>JAWS Request Payload = </b>" + request);

					// Make a HTTP post call to the service with the request and header
					JSONObject postResponseAsJsonObject = client.doPost(restPostUrl, headerMap, request.toString());
					// Report.info("Creating user as buyer with the details as in posted Request.");

					// Set the Response fields to the Run time O/P variables
					Report.pass("<b>JAWS Response received successfully = </b>" + postResponseAsJsonObject);
					setOutputFieldsUsingRuntimeVariables(postResponseAsJsonObject, rowTestData);
				} else {
					Report.error("JAWS unexpected or unhandled response received!");
				}

			}

		} catch (Exception e) {
			Report.error(this.getClass().getSimpleName() + " RestService Call Failed due to Exception : " + e);
			e.printStackTrace();
		}

		return rowTestData;
	}

	private Map<String, String> setupHeadersForRequest(String hostName) throws Exception {
		Map<String, String> headerMap = new HashMap<String, String>();
		try {
			if (hostName == null) {
				hostName = "msmaster.qa.paypal.com";
			}
			if (hostName.equals("")) {
				hostName = "msmaster.qa.paypal.com";
			}

			headerMap.put("Accept", "application/json");
			headerMap.put("Content-Type", "application/json");
			headerMap.put("hostName", hostName);

		} catch (Exception e) {
			Report.error(this.getClass().getSimpleName() + " Request Header Building - Failed due to exception : " + e);
			e.printStackTrace();
			throw e;
		}

		return headerMap;
	}

	/**
	 * @param rowDataMap
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	private JSONObject cookJsonUserAccountRequestWithData(Map<String, String> rowDataMap) throws Exception {

		JSONObject jsonObject = null;
		try {
			jsonObject = new JSONObject();

			// Set the Request values if value is available in Testdata sheet
			if (!rowDataMap.get("buyerAccountType").equals(""))
				jsonObject.put("accountType", rowDataMap.get("buyerAccountType"));
			if (!rowDataMap.get("buyerCountry").equals(""))
				jsonObject.put("country", rowDataMap.get("buyerCountry"));
			if (!rowDataMap.get("buyerCurrency").equals(""))
				jsonObject.put("currency", rowDataMap.get("buyerCurrency"));
			if (!rowDataMap.get("buyerConfirmEmail").equals(""))
				jsonObject.put("confirmEmail", rowDataMap.get("buyerConfirmEmail"));

			if (!rowDataMap.get("buyerEmailAddress").equals("")) {
				jsonObject.put("emailAddress", rowDataMap.get("buyerEmailAddress"));
			} else {
				jsonObject.put("emailAddress", generateRandomEmail(rowDataMap));
			}

			if (rowDataMap.get("buyerFirstName") != null)
				if (!rowDataMap.get("buyerFirstName").equals(""))
					jsonObject.put("firstName", rowDataMap.get("buyerFirstName"));
			if (rowDataMap.get("buyerLastName") != null)
				if (!rowDataMap.get("buyerLastName").equals(""))
					jsonObject.put("lastName", rowDataMap.get("buyerLastName"));

			// Add Bank details if set to yes in TestData
			if (rowDataMap.get("buyerAddBank").equalsIgnoreCase("Yes")) {

				JSONObject eachBankList = new JSONObject();
				eachBankList.put("bankAccountType", rowDataMap.get("buyerBankAccountType"));
				eachBankList.put("country", rowDataMap.get("buyerBankCountry"));
				eachBankList.put("currency", rowDataMap.get("buyerBankCurrency"));
				eachBankList.put("confirmed", rowDataMap.get("buyerBankConfirmed"));
				if (rowDataMap.get("buyerFirstName") != null)
					if (!rowDataMap.get("buyerFirstName").equals(""))
						eachBankList.put("firstName", rowDataMap.get("buyerFirstName"));
				if (rowDataMap.get("buyerLastName") != null)
					if (!rowDataMap.get("buyerLastName").equals(""))
						eachBankList.put("lastName", rowDataMap.get("buyerLastName"));

				JSONArray bankList = new JSONArray();
				bankList.add(eachBankList);

				jsonObject.put("bank", bankList);
			}

			// Add CC details if set to yes in TestData
			if (rowDataMap.get("buyerAddCreditCard").equalsIgnoreCase("Yes")) {

				JSONObject eachCreditCardDetails = new JSONObject();
				eachCreditCardDetails.put("cardType", rowDataMap.get("buyerCcCardType"));
				eachCreditCardDetails.put("country", rowDataMap.get("buyerCcCountry"));
				eachCreditCardDetails.put("currency", rowDataMap.get("buyerCcCurrency"));
				if (rowDataMap.get("buyerFirstName") != null)
					if (!rowDataMap.get("buyerFirstName").equals(""))
						eachCreditCardDetails.put("firstName", rowDataMap.get("buyerFirstName"));
				if (rowDataMap.get("buyerLastName") != null)
					if (!rowDataMap.get("buyerLastName").equals(""))
						eachCreditCardDetails.put("lastName", rowDataMap.get("buyerLastName"));

				JSONArray creditcardList = new JSONArray();
				creditcardList.add(eachCreditCardDetails);

				jsonObject.put("creditcard", creditcardList);
			}

			if (rowDataMap.get("buyerAddFund").equalsIgnoreCase("Yes")) {

				JSONObject eachFundDetails = new JSONObject();
				eachFundDetails.put("currency", rowDataMap.get("buyerFundCurrency"));
				eachFundDetails.put("fundsInCents", rowDataMap.get("buyerFundsInCents"));

				JSONArray fundList = new JSONArray();
				fundList.add(eachFundDetails);

				jsonObject.put("fund", fundList);
			}

		} catch (Exception e) {
			Report.error(this.getClass().getSimpleName() + " Request JSON Building - Failed due to exception" + e.getMessage());
			e.printStackTrace();
			throw e;
		}

		return jsonObject;
	}

	private boolean setOutputFieldsUsingRuntimeVariables(JSONObject responseJson, Map<String, String> rowDataMap) {
		boolean result = true;
		try {
			rowDataMap.put("buyerOutputAccountNumber", responseJson.get("accountNumber").toString());
			rowDataMap.put("buyerOutputEmailAddress", responseJson.get("emailAddress").toString());
			rowDataMap.put("buyerOutputFirstName", responseJson.get("firstName").toString());
			rowDataMap.put("buyerOutputLastName", responseJson.get("lastName").toString());

			Report.pass("Field 'accountNumber' value '" + responseJson.get("accountNumber").toString() + "' is saved in key 'buyerOutputAccountNumber'.");
			Report.pass("Field 'emailAddress' value '" + responseJson.get("emailAddress").toString() + "' is saved in key 'buyerOutputEmailAddress'.");
			Report.pass("Field 'firstName' value '" + responseJson.get("firstName").toString() + "' is saved in key 'buyerOutputFirstName'.");
			Report.pass("Field 'lastName' value '" + responseJson.get("lastName").toString() + "' is saved in key 'buyerOutputLastName'.");

		} catch (Exception e) {
			Report.error(this.getClass().getSimpleName() + " validateResponseFields - Failed due to exception" + e.getMessage());
			e.printStackTrace();
		}

		return result;
	}

	private String generateRandomEmail(Map<String, String> rowDataMap) {
		String email = null;
		String emailPrefixFromData = "";
		try {
			if (!rowDataMap.get("buyerEmailPrefix").equals("")) {
				emailPrefixFromData = rowDataMap.get("buyerEmailPrefix") + "_";
			}
			String prefix = "rrds";
			long middle = System.nanoTime();
			String suffix = "buyer";
			String country = rowDataMap.get("buyerCountry");
			email = emailPrefixFromData + prefix + "_" + middle + "_" + suffix + "_" + country + "@paypal.com";
		} catch (Exception e) {
			Report.error(this.getClass().getSimpleName() + " Email Generation Failed due to exception" + e.getMessage());
			e.printStackTrace();
		}
		return email;

	}

}
