package com.paypal.risk.resolution.checkpoints;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.apache.log4j.Logger;

import com.paypal.risk.resolution.constants.RUDSConstants;
import com.paypal.risk.resolution.model.ResponseEntity;
import com.paypal.risk.resolution.report.Report;
import com.paypal.risk.resolution.utils.ExcelUtils;
import com.paypal.risk.resolution.utils.HttpRestClient;

public class RestAPITestcase extends RUDSBaseTest {

	final static Logger log = Logger.getLogger(RestAPITestcase.class);
	Map<String, String> headerMap = new HashMap<String, String>();
	String checkpointName = RUDSConstants.COMMON_API_TESTCASE;
	String excelPath = rudsDataExcelPath + checkpointName + ".xlsx";
	String sheetName = checkpointName;

	@DataProvider(name = "dataProvider")
	public Object[][] testDataProvider() throws Exception {
		Object[][] testData = ExcelUtils.getTableArrayAsMap(excelPath, sheetName);
		return testData;
	}

	@Test(dataProvider = "dataProvider")
	public void test(Map<String, String> testData) throws Exception {
		HttpRestClient client = new HttpRestClient();
		String actualResponse = null;
		String expectedResponse = null;

		Report.startComponent(testData.get("key"), testData.get("testcaseName"));
		// Report.info("Test Data [" + testData + "]");

		try {

			// Setup URL
			String restUri = testData.get("uri");
			if (restUri.equals("")) {
				Report.error("URI is empty in Testdata. Cannot proceed");
				throw new Exception("URI is empty in Testdata. Cannot proceed");
			}
			String restUrl = rudsProtocal + hostname + ":" + port + "/" + restUri;

			// Setup Headers
			Map<String, String> headerMap = setupHeader(testData.get("header"), null);

			// Setup Request [Column Name - request in Testdata sheet]
			String rawRequest = testData.get("request");
			String transformedRequest = rawRequest;

			// Pre-Condition Test Data Preparation (Create Buyer and Seller and perform transaction):
			if (testData.get("preconditionFlag").equalsIgnoreCase("Y")) {
				Map<String, String> preconditionData = preconditionDataPrep(excelPath, testData, hostname);

				// Request Transformation
				transformedRequest = transformedRequest.replaceAll("#v_buyerAccountNumber#", preconditionData.get("buyerOutputAccountNumber"));
				transformedRequest = transformedRequest.replaceAll("#v_sellerAccountNumber#", preconditionData.get("sellerOutputAccountNumber"));
				transformedRequest = transformedRequest.replaceAll("#v_encryptedBuyerPaymentId#", preconditionData.get("trnEncryptedBuyerTransactionId"));
				transformedRequest = transformedRequest.replaceAll("#v_sellerPaymentId#", preconditionData.get("trnSellerTransId"));
				transformedRequest = transformedRequest.replaceAll("#v_buyerPaymentId#", preconditionData.get("trnReceiverTransId"));

			}

			// Reporting Informations
			Report.info("<b>Rest URL = </b><u>" + restUrl + "</u>");
			Report.info("<b>Request Headers = </b>" + headerMap);
			Report.info("<b>Request Body = </b>" + transformedRequest);

			// Trigger API Request
			ResponseEntity responseEntity = client.doGenericPost(restUrl, headerMap, transformedRequest);

			// Validation of Response
			if (responseEntity.getStatusCode() == 200) {
				actualResponse = responseEntity.getResponse().toString();
				expectedResponse = testData.get("response");
				Report.pass("<b>Actual API Response received = </b>" + actualResponse);
				Report.info("<b>Expected API Response = </b>" + expectedResponse);
				commonResponseValidation(actualResponse, expectedResponse);
			} else {
				String failureMessage = "<b>API Response Validation failed. Response Code = </b>" + responseEntity.getStatusCode();
				Report.fail(failureMessage);
				throw new Exception(failureMessage);
			}

		} catch (Exception e) {
			Report.fail("<b>Testcase failed. Reason is : " + e + "</b>");
			throw e;
		} finally {
			Report.appendComponent();
		}

	}

}
