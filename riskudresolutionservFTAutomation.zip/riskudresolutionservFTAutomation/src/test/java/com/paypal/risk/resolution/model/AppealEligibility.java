package com.paypal.risk.resolution.model;

public class AppealEligibility {

	private String Key;
	private String runMode;
	private String testcaseName;
	private String isRuleBasedCase;
	private String rule;
	private String preconditionFlag;

	private String header;
	private String request;
	private String response;
	private String owner;

	public String getRunMode() {
		return runMode;
	}

	public void setRunMode(String runMode) {
		this.runMode = runMode;
	}

	public String getTestcaseName() {
		return testcaseName;
	}

	public void setTestcaseName(String testcaseName) {
		this.testcaseName = testcaseName;
	}

	public String getIsRuleBasedCase() {
		return isRuleBasedCase;
	}

	public void setIsRuleBasedCase(String isRuleBasedCase) {
		this.isRuleBasedCase = isRuleBasedCase;
	}

	public String getRule() {
		return rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}

	public String getPreconditionFlag() {
		return preconditionFlag;
	}

	public void setPreconditionFlag(String preconditionFlag) {
		this.preconditionFlag = preconditionFlag;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getKey() {
		return Key;
	}

	public void setKey(String key) {
		Key = key;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

}
