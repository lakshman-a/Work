package com.paypal.risk.resolution.checkpoints;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.paypal.risk.resolution.constants.RUDSConstants;
import com.paypal.risk.resolution.model.ResponseEntity;
import com.paypal.risk.resolution.report.Report;
import com.paypal.risk.resolution.utils.ExcelUtils;
import com.paypal.risk.resolution.utils.HttpRestClient;

public class AppealEligibilityTestCase extends RUDSBaseTest {

	final static Logger log = Logger.getLogger(AppealEligibilityTestCase.class);
	Map<String, String> headerMap = new HashMap<String, String>();
	String checkpointName = RUDSConstants.APPEAL_ELIGIBILITY_CP;
	String excelPath = rudsDataExcelPath + checkpointName + ".xlsx";
	String schemaPath = rudsDataScehmaPath + checkpointName + ".json";
	String sheetName = checkpointName;

	@DataProvider(name = "dataProvider")
	public Object[][] testDataProvider() throws Exception {
		Object[][] testData = ExcelUtils.getTableArrayAsMap(excelPath, sheetName);
		return testData;
	}

	@Test(dataProvider = "dataProvider")
	public void test(Map<String, String> testData) throws Exception {
		HttpRestClient client = new HttpRestClient();
		String actualResponse = null;
		Map<String, String> preconditionData = new HashMap<>();
		Report.startComponent(testData.get("key"), testData.get("testcaseName"));

		try {

			// Pre-Condition Test Data Preparation (Create Buyer and Seller and perform transaction):
			if (testData.get("preconditionFlag").equalsIgnoreCase("Y")) {
				preconditionData = preconditionDataPrep(excelPath, testData, hostname);
				Report.info("<b><u>Appeal Eligibility Testcase validation starts...</b></u>");
			}

			// Setup URL
			String restUrl = rudsProtocal + hostname + ":" + port + "/" + RUDSConstants.APPEAL_ELIGIBILITY_URI;
			Report.info("<b>Rest URL =  <u>" + restUrl + "</b></u>");

			// Setup Headers
			Map<String, String> headerMap = setupHeader(testData.get("header"), preconditionData);
			Report.info("<b>Request Headers = </b> " + headerMap);

			// Setup Request [Column Name - request in Testdata sheet]
			String request = buildRequestJsonWithData(testData, preconditionData);
			Report.info("<b>Request Payload = </b>" + request);

			// Trigger API Request
			ResponseEntity responseEntity = client.doGenericPost(restUrl, headerMap, request);

			// Validation of Response
			if (responseEntity.getStatusCode() == 200) {

				if (responseEntity.getResponse() != null) {
					actualResponse = responseEntity.getResponse().toString();
					if (actualResponse.equalsIgnoreCase("")) {
						Report.fail("<b>API Response received Empty! Skipping response validation. </b> Check the Request details");
					} else {
						Report.pass("<b>API Response received = </b>" + actualResponse);
						validateResponseFields(actualResponse, testData);
					}
				}

			} else {
				String failureMessage = "<b>API Response code validation failed. Response Code = " + responseEntity.getStatusCode() + "</b>";
				Report.fail(failureMessage);
				throw new Exception(failureMessage);
			}

		} catch (Exception e) {
			Report.fail("Testcase failed due to reason : " + e);
			e.printStackTrace();
			throw e;
		} finally {
			Report.appendComponent();
		}

	}

	@SuppressWarnings("unchecked")
	private String buildRequestJsonWithData(Map<String, String> testData, Map<String, String> preconditionData) throws Exception {
		JSONObject request = null;
		try {
			System.out.println("Schema path : " + schemaPath);
			FileReader reader = new FileReader(schemaPath);

			JSONParser jsonParser = new JSONParser();
			request = (JSONObject) jsonParser.parse(reader);

			// dispute_event
			JSONObject disputeDetailsJson = (JSONObject) request.get("dispute_event");
			disputeDetailsJson.put("event_name", testData.get("event_name"));

			if (preconditionData.get("buyerOutputAccountNumber") != null)
				request.put("receiver_account_number", preconditionData.get("buyerOutputAccountNumber"));
			else
				request.put("receiver_account_number", testData.get("receiver_account_number"));

			if (preconditionData.get("sellerOutputAccountNumber") != null)
				request.put("sender_account_number", preconditionData.get("sellerOutputAccountNumber"));
			else
				request.put("sender_account_number", testData.get("sender_account_number"));

			if (preconditionData.get("trnEncryptedBuyerTransactionId") != null)
				request.put("encrypted_receiver_transaction_id", preconditionData.get("trnEncryptedBuyerTransactionId"));
			else
				request.put("encrypted_receiver_transaction_id", testData.get("encrypted_receiver_transaction_id"));

			if (preconditionData.get("trnReceiverTransId") != null)
				request.put("receiver_transaction_id", preconditionData.get("trnReceiverTransId"));
			else
				request.put("receiver_transaction_id", testData.get("receiver_transaction_id"));

			if (preconditionData.get("trnSellerTransId") != null)
				request.put("sender_transaction_id", preconditionData.get("trnSellerTransId"));
			else
				request.put("sender_transaction_id", testData.get("sender_transaction_id"));

			request.put("encrypted_sender_transaction_id", testData.get("encrypted_sender_transaction_id"));
			request.put("ramp_on", testData.get("ramp_on"));

			// participant_profile_settings
			JSONObject participant_profile_settings = (JSONObject) request.get("participant_profile_settings");
			JSONObject merchant_profile_settings = (JSONObject) participant_profile_settings.get("merchant_profile_settings");
			merchant_profile_settings.put("profile_type", testData.get("profile_type"));

			// current_dispute
			JSONObject current_dispute = (JSONObject) request.get("current_dispute");
			current_dispute.put("id", testData.get("id"));
			current_dispute.put("category", testData.get("category"));
			current_dispute.put("sub_category", testData.get("sub_category"));
			current_dispute.put("reason", testData.get("reason"));
			current_dispute.put("stage", testData.get("stage"));
			current_dispute.put("regulation_name", testData.get("regulation_name"));
			current_dispute.put("create_time", testData.get("create_time"));
			current_dispute.put("creation_channel", testData.get("creation_channel"));
			current_dispute.put("seller_appeal_count", testData.get("seller_appeal_count"));

			// reported_amount
			JSONObject reported_amount = (JSONObject) current_dispute.get("reported_amount");
			reported_amount.put("currency_code", testData.get("currency_code"));
			reported_amount.put("value", testData.get("value"));

			// adjudication_decisions
			JSONArray adjudication_decisions = (JSONArray) current_dispute.get("adjudication_decisions");
			JSONObject sender_adjudication_decisions = (JSONObject) adjudication_decisions.get(0);
			sender_adjudication_decisions.put("participant_type", testData.get("participant_type"));
			sender_adjudication_decisions.put("outcome", testData.get("outcome"));

			// participant_actions
			JSONArray participant_actions = (JSONArray) current_dispute.get("participant_actions");
			JSONObject participant_action = (JSONObject) participant_actions.get(0);
			participant_action.put("dispute_stage", testData.get("dispute_stage"));

			JSONArray merchant_actions = (JSONArray) participant_action.get("merchant_actions");
			JSONObject merchant_action = (JSONObject) merchant_actions.get(0);
			merchant_action.put("action", testData.get("action"));

		} catch (NullPointerException e) {
			Report.fail("<b>Appeal Eligibility request build failed due to either Missing field in response or Testdata not available</b>");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			Report.error("Appeal Eligibility JSON request building failed. Reason : " + e.getMessage());
			throw e;
		}

		return request.toString();
	}

	private boolean validateResponseFields(String responseObject, Map<String, String> rowDataMap) throws Exception {
		boolean result = true;
		List<Boolean> resultArr = new ArrayList<Boolean>();
		JSONObject responseJson = null;

		try {

			JSONParser jsonParser = new JSONParser();
			responseJson = (JSONObject) jsonParser.parse(responseObject);

			JSONObject decision = (JSONObject) responseJson.get("decision");
			resultArr.add(Report.assertEquals("code", decision.get("code").toString(), rowDataMap.get("res.code")));

			if (!rowDataMap.get("res.reason").equals("")) {
				resultArr.add(Report.assertEquals("reason", decision.get("reason").toString(), rowDataMap.get("res.reason")));
			}

			if (!rowDataMap.get("res.details.time_to_respond").equals("")) {
				JSONObject details = (JSONObject) decision.get("details");
				resultArr.add(Report.assertEquals("time_to_respond", details.get("time_to_respond").toString(), rowDataMap.get("res.details.time_to_respond")));
			}

			if (resultArr.contains(false)) {
				result = false;
				Report.fail("Response fields validation failed.");
			} else {
				Report.pass("Response fields validation passed.");
			}

		} catch (NullPointerException e) {
			Report.fail("<b>Appeal Eligibility response field validation failed due to either Missing field in response or Testdata not available</b>");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			Report.error("Appeal Eligibility response field validation failed. Reason : " + e.getMessage());
			e.printStackTrace();
			throw e;
		}

		return result;
	}

}
