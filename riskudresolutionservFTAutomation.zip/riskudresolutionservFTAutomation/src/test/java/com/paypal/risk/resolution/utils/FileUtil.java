package com.paypal.risk.resolution.utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.paypal.risk.resolution.report.Report;

public class FileUtil {
	final static Logger log = Logger.getLogger(HttpRestClient.class);

	public static String readAllBytesJava7(String filePath) {
		String content = "";
		try {
			content = new String(Files.readAllBytes(Paths.get(filePath)));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return content;
	}

	public static void main(String args[]) throws ParseException {
		String HTMLSTring = readAllBytesJava7("C:\\Users\\layyakannu\\Desktop\\sampleHtml.html");
		Document html = Jsoup.parse(HTMLSTring);
		String h1 = html.body().getElementsByTag("b").text();
		log.info("After parsing, Heading : " + h1);

		Element TBody = html.body().getElementsByTag("TBody").first();
		Map<Date, String> allFilesMapTime = new HashMap<>();
		List<Date> formattedTimeStmps = new ArrayList<Date>();

		DateFormat dateFormatter = new SimpleDateFormat("E MMM dd HH:mm:ss yyyy");

		int fileCount = 0;
		Elements allRows = TBody.getElementsByTag("tr");
		for (Element eachRow : allRows) {
			String tmstmp = eachRow.getElementsByTag("td").get(2).text();
			String fileName = eachRow.getElementsByTag("td").get(1).getElementsByTag("a").first().text();
			if (fileName.contains("RBO_DUMP")) {
				log.info("No. " + fileCount + " | Time : " + tmstmp + " | FileName : " + fileName);
				fileCount++;
				formattedTimeStmps.add(dateFormatter.parse(tmstmp));
				allFilesMapTime.put(dateFormatter.parse(tmstmp), fileName);

			} else {
				log.info("Not a RBO_DUMP file");
			}
		}

		Collections.sort(formattedTimeStmps);

		Date timeOfLastFile = formattedTimeStmps.get(formattedTimeStmps.size() - 1);
		log.info("Latest File time is  : " + timeOfLastFile.toString());
		String latestFileName = allFilesMapTime.get(timeOfLastFile);
		log.info("Latest filename is : " + latestFileName);
	}

}
