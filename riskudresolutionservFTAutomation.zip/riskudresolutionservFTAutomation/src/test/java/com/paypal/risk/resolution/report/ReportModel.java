package com.paypal.risk.resolution.report;

public class ReportModel {

	private String projectName;
	private String suiteName;
	private int totalCase=0;
	private int totalData=0;
	private int casePassed=0;
	private int dataPassed=0;
	private int caseFailed=0;
	private int dataFailed=0;
	private int caseError=0;
	private int dataError=0;

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getSuiteName() {
		return suiteName;
	}

	public void setSuiteName(String suiteName) {
		this.suiteName = suiteName;
	}

	public int getTotalCase() {
		return totalCase;
	}

	public void setTotalCase(int totalCase) {
		this.totalCase = totalCase;
	}
	
	public void addCaseCount() {
		this.totalCase = totalCase+1;
	}

	public int getTotalData() {
		return totalData;
	}

	public void setTotalData(int totalData) {
		this.totalData = totalData;
	}
	
	public void addDataCount() {
		this.totalData = totalData+1;
	}

	public int getCasePassed() {
		return casePassed;
	}

	public void setCasePassed(int casePassed) {
		this.casePassed = casePassed;
	}
	
	public void addCasePassCount() {
		this.casePassed = casePassed+1;
	}

	public int getDataPassed() {
		return dataPassed;
	}

	public void setDataPassed(int dataPassed) {
		this.dataPassed = dataPassed;
	}
	
	public void addDataPassCount() {
		this.dataPassed = dataPassed+1;
	}

	public int getCaseFailed() {
		return caseFailed;
	}

	public void setCaseFailed(int caseFailed) {
		this.caseFailed = caseFailed;
	}
	
	public void addCaseFailCount() {
		this.caseFailed = caseFailed+1;
	}

	public int getDataFailed() {
		return dataFailed;
	}

	public void setDataFailed(int dataFailed) {
		this.dataFailed = dataFailed;
	}
	
	public void addDataFailCount() {
		this.dataFailed = dataFailed+1;
	}

	public int getCaseError() {
		return caseError;
	}

	public void setCaseError(int caseError) {
		this.caseError = caseError;
	}
	
	public void addCaseErrorCount() {
		this.caseError = caseError+1;
	}

	public int getDataError() {
		return dataError;
	}

	public void setDataError(int dataError) {
		this.dataError = dataError;
	}
	
	public void addDataErrorCount() {
		this.dataError = dataError+1;
	}

}
