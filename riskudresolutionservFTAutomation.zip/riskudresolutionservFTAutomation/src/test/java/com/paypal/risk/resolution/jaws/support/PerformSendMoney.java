package com.paypal.risk.resolution.jaws.support;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.paypal.risk.resolution.report.Report;
import com.paypal.risk.resolution.utils.HttpRestClient;
import com.paypal.risk.resolution.utils.PropertyUtil;

/**
 * @author layyakannu
 * 
 */
public class PerformSendMoney {
	final static Logger log = Logger.getLogger(PerformSendMoney.class);

	public Map<String, String> performTransaction(Map<String, String> rowTestData, String hostname) throws Exception {

		try {

			HttpRestClient client = new HttpRestClient();

			/*---------------------ADD FUND --------------------------*/
			Report.info("Performing Add Fund for the Buyer Account");

			// Create a HTTPClient to make a rest call
			String restUrl = PropertyUtil.getConfigValueOf("jaws.api.addFund") + rowTestData.get("buyerOutputAccountNumber") + "/funds";
			Report.info("<b>JAWS Rest API URL - Add Fund = <b><u>" + restUrl + "</u>");

			// Setup Headers
			Map<String, String> headerMap = setupHeadersForRequest(hostname);
			Report.info("<b>JAWS Request Headers = </b>" + headerMap);

			// Request Payload created using the Data from Excel
			JSONObject request = cookJsonAddFundRequestWithData(rowTestData);
			Report.info("<b>JAWS Request Payload = </b>" + request);

			// Make a HTTP post call to the service with the request and header
			JSONObject addFundResponseAsJsonObject = client.doPost(restUrl, headerMap, request.toString());
			Report.pass("<b>Added Fund Successfully to the buyer before performing Transactions = </b>" + addFundResponseAsJsonObject);

			/*---------------------Do Transaction --------------------------*/
			Report.info("Performing Send Money between Buyer and Sender Account");

			String sendMoneyRestUrl = PropertyUtil.getConfigValueOf("jaws.api.performSendMoney");
			Report.info("<b>JAWS Rest API URL - Send Money = </b><u>" + sendMoneyRestUrl + "<u>");

			// Request Payload created using the Data from Excel
			JSONObject sendMoneyRequest = cookJsonSendMoneyRequestWithData(rowTestData);
			Report.info("<b>JAWS Request Payload for Send Money = </b>" + sendMoneyRequest);

			// Make a HTTP post call to the service with the request and header
			JSONObject sendMoneyResponseAsJsonObject = client.doPost(sendMoneyRestUrl, headerMap, sendMoneyRequest.toString());
			Report.pass("<b>JAWS Response received : </b>" + sendMoneyResponseAsJsonObject);

			// Set the Response fields to the Run time O/P variables
			setOutputFieldsUsingRuntimeVariables(sendMoneyResponseAsJsonObject, rowTestData);

		} catch (Exception e) {
			Report.error(this.getClass().getSimpleName() + " RestService Call Failed due to Exception : " + e);
			e.printStackTrace();
		}

		return rowTestData;
	}

	private Map<String, String> setupHeadersForRequest(String hostName) throws Exception {
		Map<String, String> headerMap = new HashMap<String, String>();
		try {
			if (hostName == null) {
				hostName = "msmaster.qa.paypal.com";
			}
			if (hostName.equals("")) {
				hostName = "msmaster.qa.paypal.com";
			}

			headerMap.put("Accept", "application/json");
			headerMap.put("Content-Type", "application/json");
			headerMap.put("hostName", hostName);

		} catch (Exception e) {
			Report.error(this.getClass().getSimpleName() + "Request Header Building - Failed due to exception : " + e);
			e.printStackTrace();
			throw e;
		}

		return headerMap;
	}

	@SuppressWarnings("unchecked")
	private JSONObject cookJsonAddFundRequestWithData(Map<String, String> rowDataMap) throws Exception {
		JSONObject jsonObject = null;
		try {
			jsonObject = new JSONObject();

			JSONObject eachFundDetails = new JSONObject();
			eachFundDetails.put("currency", rowDataMap.get("trnAddFundCurrency"));
			eachFundDetails.put("fundsInCents", rowDataMap.get("trnAddFundsInCents"));

			JSONArray fundList = new JSONArray();
			fundList.add(eachFundDetails);

			jsonObject.put("fund", fundList);

		} catch (Exception e) {
			Report.error(this.getClass().getSimpleName() + " Request JSON Building - Failed due to exception" + e.getMessage());
			e.printStackTrace();
			throw e;
		}

		return jsonObject;
	}

	/**
	 * @param rowDataMap
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	private JSONObject cookJsonSendMoneyRequestWithData(Map<String, String> rowDataMap) throws Exception {

		JSONObject jsonObject = null;
		try {
			jsonObject = new JSONObject();

			if (rowDataMap.get("trnAmount").equals(""))
				throw new Exception("Mandatory values for the request are NULL in the TestData Spreadsheet");

			// Set the Request values if value is available in Testdata sheet
			jsonObject.put("recipient", rowDataMap.get("sellerOutputAccountNumber"));
			jsonObject.put("sender", rowDataMap.get("buyerOutputAccountNumber"));
			jsonObject.put("amount", rowDataMap.get("trnAmount"));

			if (!rowDataMap.get("trnCurrencyCode").equals(""))
				jsonObject.put("currencyCode", rowDataMap.get("trnCurrencyCode"));
			if (!rowDataMap.get("trnType").equals(""))
				jsonObject.put("transactionType", rowDataMap.get("trnType"));
			if (!rowDataMap.get("trnSubType").equals(""))
				jsonObject.put("transactionSubType", rowDataMap.get("trnSubType"));
			if (!rowDataMap.get("trnFundingSourceType").equals(""))
				jsonObject.put("fundingSourceType", rowDataMap.get("trnFundingSourceType"));
			if (rowDataMap.get("trnFundingSourceId") != null)
				if (!rowDataMap.get("trnFundingSourceId").equals(""))
					jsonObject.put("fundingSourceId", rowDataMap.get("trnFundingSourceId"));

		} catch (Exception e) {
			Report.error(this.getClass().getSimpleName() + " Request JSON Building - Failed due to exception" + e.getMessage());
			e.printStackTrace();
			throw e;
		}

		return jsonObject;
	}

	@SuppressWarnings("unchecked")
	private boolean setOutputFieldsUsingRuntimeVariables(JSONObject responseJson, Map<String, String> rowDataMap) throws Exception {
		boolean result = true;
		try {
			rowDataMap.put("trnReceiverTransId", responseJson.get("receiverTransId").toString());
			rowDataMap.put("trnSellerTransId", responseJson.get("senderTransId").toString());

			Report.pass("Field 'receiverTransId' value '" + responseJson.get("receiverTransId").toString() + "' is saved in key 'trnReceiverTransId'.");
			Report.pass("Field 'senderTransId' value '" + responseJson.get("senderTransId").toString() + "' is saved in key 'trnSellerTransId'.");

			LinkedHashMap<String, String> paymentResponse = (LinkedHashMap<String, String>) responseJson.get("paymentResponse");
			rowDataMap.put("trnEncryptedBuyerTransactionId", paymentResponse.get("encryptedTransactionId").toString());
			Report.pass("Field 'encryptedTransactionId' value '" + paymentResponse.get("encryptedTransactionId").toString() + "' is saved in key 'trnEncryptedBuyerTransactionId'.");

		} catch (Exception e) {
			Report.error(this.getClass().getSimpleName() + " validateResponseFields - Failed due to exception" + e.getMessage());
			e.printStackTrace();
			throw e;
		}

		return result;
	}
}
