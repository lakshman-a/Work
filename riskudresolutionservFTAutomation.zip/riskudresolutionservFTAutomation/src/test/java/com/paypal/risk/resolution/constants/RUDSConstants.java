package com.paypal.risk.resolution.constants;

public class RUDSConstants {

	// CheckpointNames
	public final static String COMMON_API_TESTCASE = "RestAPITestcases";
	public final static String APPEAL_ELIGIBILITY_CP = "AppealEligibility";
	public final static String ATO_UNAUTH_CP = "IssueInitiationUnAuth";
	public final static String ATO_UNAUTH_DC_CP = "IssueInitiationUnAuthDC";
	public final static String DISPUTE_INITIATION_CP = "DisputeInitiation";
	public final static String DISPUTE_ADJUDICATION_CP = "DisputeAdjudication";
	public final static String DISPUTE_ELIGIBILITY_CP = "DisputeEligibility";

	// URIs
	public final static String APPEAL_ELIGIBILITY_URI = "v1/riskudresolutionserv/resolution/evaluate_appeal_eligibility";
	public final static String ATO_UNAUTH_URI = "v1/riskudresolutionserv/resolution/evaluate_unauth_dispute";
	public final static String ATO_UNAUTH_DC_URI = "v1/riskudresolutionserv/resolution/evaluate_unauth_dispute";
	public final static String DISPUTE_INITIATION_URI = "v1/riskudresolutionserv/resolution/evaluate_dispute";
	public final static String DISPUTE_ADJUDICATION_URI = "v1/riskudresolutionserv/resolution/evaluate_dispute";
	public final static String DISPUTE_ELIGIBILITY_URI = "v1/riskudresolutionserv/resolution/dispute_eligibility";

	
	//RBO_DUMP
	public final static String RBO_DUMP_VALIDATOR_SHEET_NAME = "RBO_DUMP_VALIDATOR";
}
