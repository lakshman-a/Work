package com.paypal.risk.resolution.jaws.support;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.paypal.risk.resolution.report.Report;
import com.paypal.risk.resolution.utils.HttpRestClient;
import com.paypal.risk.resolution.utils.PropertyUtil;

/**
 * @author layyakannu Check the user if already exist, if not create the user and transaction
 */
public class SellerCreation {
	final static Logger log = Logger.getLogger(SellerCreation.class);

	/**
	 * Dispute_Adjudication
	 * 
	 * @param rowTestData
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> createSellerIfNotExist(Map<String, String> rowTestData, String hostname) throws Exception {

		try {
			// Report.info("<b>Check User if Exist in JAWS</b>");

			// Create a HTTPClient to make a rest call
			HttpRestClient client = new HttpRestClient();

			// Get the URL based on JOB or Default stage configured in Config Prop
			String restUrl = PropertyUtil.getConfigValueOf("jaws.api.checkUser") + rowTestData.get("sellerEmailAddress");
			Report.info("<b>JAWS Rest API URL = </b><u>" + restUrl + "</u>");

			// Setup Headers
			Map<String, String> headerMap = setupHeadersForRequest(hostname);
			Report.info("<b>JAWS Request Headers = </b>" + headerMap);

			// Make a HTTP post call to the service with the request and header
			JSONObject responseAsJsonObject;
			try {
				responseAsJsonObject = client.doGet(restUrl, headerMap);
				Report.pass("<b>JAWS Response received successfully with Code 200. User Already Exist = </b>" + responseAsJsonObject);

				// Set the Response fields to the Run time O/P variables
				setOutputFieldsUsingRuntimeVariables(responseAsJsonObject, rowTestData);

			} catch (javax.ws.rs.WebApplicationException e) {
				JSONParser parser = new JSONParser();
				responseAsJsonObject = (JSONObject) parser.parse(e.getLocalizedMessage());
				Report.info("<b>JAWS Response received successfully as = </b>" + responseAsJsonObject);

				if (responseAsJsonObject.get("errorMessage").toString().equalsIgnoreCase("DATA_NOT_EXIST")) {
					Report.info("User Does not Exist, Creating the User...");

					// Get the URL based on JOB or Default stage configured in Config Prop
					String restPostUrl = PropertyUtil.getConfigValueOf("jaws.api.createUserProfile");
					Report.info("<b>JAWS Rest API URL = </b>" + restPostUrl);

					// Create a User and Do a Transaction
					JSONObject request = cookJsonUserAccountRequestWithData(rowTestData);
					Report.info("<b>JAWS Request Payload = </b>" + request);

					// Make a HTTP post call to the service with the request and header
					JSONObject postResponseAsJsonObject = client.doPost(restPostUrl, headerMap, request.toString());
					// Report.info("<b>Creating user as seller with the details as in posted Request...</b>");

					// Set the Response fields to the Run time O/P variables
					Report.pass("<b>JAWS Response received successfully = </b>" + postResponseAsJsonObject);
					setOutputFieldsUsingRuntimeVariables(postResponseAsJsonObject, rowTestData);
				}

			}

		} catch (Exception e) {
			Report.error(this.getClass().getSimpleName() + " RestService Call Failed due to Exception : " + e);
			e.printStackTrace();
		}

		return rowTestData;
	}

	private Map<String, String> setupHeadersForRequest(String hostName) throws Exception {
		Map<String, String> headerMap = new HashMap<String, String>();
		try {
			if (hostName == null) {
				hostName = "msmaster.qa.paypal.com";
			}
			if (hostName.equals("")) {
				hostName = "msmaster.qa.paypal.com";
			}

			headerMap.put("Accept", "application/json");
			headerMap.put("Content-Type", "application/json");
			headerMap.put("hostName", hostName);

		} catch (Exception e) {
			Report.error(this.getClass().getSimpleName() + " Request Header Building - Failed due to exception : " + e);
			e.printStackTrace();
			throw e;
		}

		return headerMap;
	}

	/**
	 * @param rowDataMap
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	private JSONObject cookJsonUserAccountRequestWithData(Map<String, String> rowDataMap) throws Exception {

		JSONObject jsonObject = null;
		try {
			jsonObject = new JSONObject();

			// Set the Request values if value is available in Testdata sheet
			if (!rowDataMap.get("sellerAccountType").equals(""))
				jsonObject.put("accountType", rowDataMap.get("sellerAccountType"));
			if (!rowDataMap.get("sellerCountry").equals(""))
				jsonObject.put("country", rowDataMap.get("sellerCountry"));
			if (!rowDataMap.get("sellerCurrency").equals(""))
				jsonObject.put("currency", rowDataMap.get("sellerCurrency"));
			if (!rowDataMap.get("sellerConfirmEmail").equals(""))
				jsonObject.put("confirmEmail", rowDataMap.get("sellerConfirmEmail"));

			if (!rowDataMap.get("sellerEmailAddress").equals("")) {
				jsonObject.put("emailAddress", rowDataMap.get("sellerEmailAddress"));
			} else {
				jsonObject.put("emailAddress", generateRandomEmail(rowDataMap));
			}

			if (rowDataMap.get("sellerFirstName") != null)
				if (!rowDataMap.get("sellerFirstName").equals(""))
					jsonObject.put("firstName", rowDataMap.get("sellerFirstName"));
			if (rowDataMap.get("sellerLastName") != null)
				if (!rowDataMap.get("sellerLastName").equals(""))
					jsonObject.put("lastName", rowDataMap.get("sellerLastName"));

			// Add Bank details if set to yes in TestData
			if (rowDataMap.get("sellerAddBank").equalsIgnoreCase("Yes")) {

				JSONObject eachBankList = new JSONObject();
				eachBankList.put("bankAccountType", rowDataMap.get("sellerBankAccountType"));
				eachBankList.put("country", rowDataMap.get("sellerBankCountry"));
				eachBankList.put("currency", rowDataMap.get("sellerBankCurrency"));
				eachBankList.put("confirmed", rowDataMap.get("sellerBankConfirmed"));
				if (rowDataMap.get("sellerFirstName") != null)
					if (!rowDataMap.get("sellerFirstName").equals(""))
						eachBankList.put("firstName", rowDataMap.get("sellerFirstName"));
				if (rowDataMap.get("sellerLastName") != null)
					if (!rowDataMap.get("sellerLastName").equals(""))
						eachBankList.put("lastName", rowDataMap.get("sellerLastName"));

				JSONArray bankList = new JSONArray();
				bankList.add(eachBankList);

				jsonObject.put("bank", bankList);
			}

			// Add CC details if set to yes in TestData
			if (rowDataMap.get("sellerAddCreditCard").equalsIgnoreCase("Yes")) {

				JSONObject eachCreditCardDetails = new JSONObject();
				eachCreditCardDetails.put("cardType", rowDataMap.get("sellerCcCardType"));
				eachCreditCardDetails.put("country", rowDataMap.get("sellerCcCountry"));
				eachCreditCardDetails.put("currency", rowDataMap.get("sellerCcCurrency"));
				if (rowDataMap.get("sellerFirstName") != null)
					if (!rowDataMap.get("sellerFirstName").equals(""))
						eachCreditCardDetails.put("firstName", rowDataMap.get("sellerFirstName"));
				if (rowDataMap.get("sellerLastName") != null)
					if (!rowDataMap.get("sellerLastName").equals(""))
						eachCreditCardDetails.put("lastName", rowDataMap.get("sellerLastName"));

				JSONArray creditcardList = new JSONArray();
				creditcardList.add(eachCreditCardDetails);

				jsonObject.put("creditcard", creditcardList);
			}

			if (rowDataMap.get("sellerAddFund").equalsIgnoreCase("Yes")) {

				JSONObject eachFundDetails = new JSONObject();
				eachFundDetails.put("currency", rowDataMap.get("sellerFundCurrency"));
				eachFundDetails.put("fundsInCents", rowDataMap.get("sellerFundsInCents"));

				JSONArray fundList = new JSONArray();
				fundList.add(eachFundDetails);

				jsonObject.put("fund", fundList);
			}

		} catch (Exception e) {
			Report.error(this.getClass().getSimpleName() + " Request JSON Building - Failed due to exception" + e.getMessage());
			e.printStackTrace();
			throw e;
		}

		return jsonObject;
	}

	private boolean setOutputFieldsUsingRuntimeVariables(JSONObject responseJson, Map<String, String> rowDataMap) {
		boolean result = true;
		try {
			rowDataMap.put("sellerOutputAccountNumber", responseJson.get("accountNumber").toString());
			rowDataMap.put("sellerOutputEmailAddress", responseJson.get("emailAddress").toString());
			rowDataMap.put("sellerOutputFirstName", responseJson.get("firstName").toString());
			rowDataMap.put("sellerOutputLastName", responseJson.get("lastName").toString());

			Report.pass("Field 'accountNumber' value '" + responseJson.get("accountNumber").toString() + "' is saved in key 'sellerOutputAccountNumber'.");
			Report.pass("Field 'emailAddress' value '" + responseJson.get("emailAddress").toString() + "' is saved in key 'sellerOutputEmailAddress'.");
			Report.pass("Field 'firstName' value '" + responseJson.get("firstName").toString() + "' is saved in key 'sellerOutputFirstName'.");
			Report.pass("Field 'lastName' value '" + responseJson.get("lastName").toString() + "' is saved in key 'sellerOutputLastName'.");

		} catch (Exception e) {
			Report.error(this.getClass().getSimpleName() + " validateResponseFields - Failed due to exception" + e.getMessage());
			e.printStackTrace();
		}

		return result;
	}

	private String generateRandomEmail(Map<String, String> rowDataMap) {
		String email = null;
		String emailPrefixFromData = "";
		try {
			if (!rowDataMap.get("sellerEmailPrefix").equals("")) {
				emailPrefixFromData = rowDataMap.get("sellerEmailPrefix") + "_";
			}
			String prefix = "rrds";
			long middle = System.nanoTime();
			String suffix = "seller";
			String country = rowDataMap.get("sellerCountry");
			email = emailPrefixFromData + prefix + "_" + middle + "_" + suffix + "_" + country + "@paypal.com";
		} catch (Exception e) {
			Report.error(this.getClass().getSimpleName() + " Email Generation Failed due to exception" + e.getMessage());
			e.printStackTrace();
		}
		return email;

	}

}
