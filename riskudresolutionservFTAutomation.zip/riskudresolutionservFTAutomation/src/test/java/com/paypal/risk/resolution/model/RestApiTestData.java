package com.paypal.risk.resolution.model;

public class RestApiTestData {

	private String runMode;
	private String testcaseName;
	private String isRuleBasedCase;
	private String rule;
	private String localStage;
	private String localPort;
	private String createBuyer;
	private String createSeller;
	private String performTrn;

	private String buyerAccountType;
	private String buyerCountry;
	private String buyerCurrency;
	private String buyerConfirmEmail;
	private String buyerEmailAddress;
	private String buyerEmailPrefix;
	private String buyerFirstName;
	private String buyerLastName;
	private String buyerOutputEmailAddress;
	private String buyerOutputAccountNumber;
	private String buyerOutputFirstName;
	private String buyerOutputLastName;
	private String buyerAddBank;
	private String buyerBankAccountType;
	private String buyerBankCountry;
	private String buyerBankCurrency;
	private String buyerBankConfirmed;
	private String buyerAddCreditCard;
	private String buyerCcCardType;
	private String buyerCcCountry;
	private String buyerCcCurrency;
	private String buyerAddFund;
	private String buyerFundsInCents;
	private String buyerFundCurrency;

	private String sellerAccountType;
	private String sellerCountry;
	private String sellerCurrency;
	private String sellerConfirmEmail;
	private String sellerEmailAddress;
	private String sellerEmailPrefix;
	private String sellerFirstName;
	private String sellerLastName;
	private String sellerOutputEmailAddress;
	private String sellerOutputAccountNumber;
	private String sellerOutputFirstName;
	private String sellerOutputLastName;
	private String sellerAddBank;
	private String sellerBankAccountType;
	private String sellerBankCountry;
	private String sellerBankCurrency;
	private String sellerBankConfirmed;
	private String sellerAddCreditCard;
	private String sellerCcCardType;
	private String sellerCcCountry;
	private String sellerCcCurrency;
	private String sellerAddFund;
	private String sellerFundsInCents;
	private String sellerFundCurrency;

	private String trnAddFundsInCents;
	private String trnAddFundCurrency;
	private String trnSender;
	private String trnRecipient;
	private String trnCurrencyCode;
	private String trnAmount;
	private String trnType;
	private String trnSubType;
	private String trnFundingSourceType;
	private String trnFundingSourceId;
	private String trnEncryptedBuyerTransactionId;
	private String trnReceiverTransId;
	private String trnSellerTransId;

	private String header;
	private String request;
	private String response;

	public String getRunMode() {
		return runMode;
	}

	public void setRunMode(String runMode) {
		this.runMode = runMode;
	}

	public String getTestcaseName() {
		return testcaseName;
	}

	public void setTestcaseName(String testcaseName) {
		this.testcaseName = testcaseName;
	}

	public String getIsRuleBasedCase() {
		return isRuleBasedCase;
	}

	public void setIsRuleBasedCase(String isRuleBasedCase) {
		this.isRuleBasedCase = isRuleBasedCase;
	}

	public String getRule() {
		return rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}

	public String getBuyerAccountType() {
		return buyerAccountType;
	}

	public void setBuyerAccountType(String buyerAccountType) {
		this.buyerAccountType = buyerAccountType;
	}

	public String getBuyerCountry() {
		return buyerCountry;
	}

	public void setBuyerCountry(String buyerCountry) {
		this.buyerCountry = buyerCountry;
	}

	public String getBuyerCurrency() {
		return buyerCurrency;
	}

	public void setBuyerCurrency(String buyerCurrency) {
		this.buyerCurrency = buyerCurrency;
	}

	public String getBuyerConfirmEmail() {
		return buyerConfirmEmail;
	}

	public void setBuyerConfirmEmail(String buyerConfirmEmail) {
		this.buyerConfirmEmail = buyerConfirmEmail;
	}

	public String getBuyerEmailAddress() {
		return buyerEmailAddress;
	}

	public void setBuyerEmailAddress(String buyerEmailAddress) {
		this.buyerEmailAddress = buyerEmailAddress;
	}

	public String getBuyerEmailPrefix() {
		return buyerEmailPrefix;
	}

	public void setBuyerEmailPrefix(String buyerEmailPrefix) {
		this.buyerEmailPrefix = buyerEmailPrefix;
	}

	public String getBuyerFirstName() {
		return buyerFirstName;
	}

	public void setBuyerFirstName(String buyerFirstName) {
		this.buyerFirstName = buyerFirstName;
	}

	public String getBuyerLastName() {
		return buyerLastName;
	}

	public void setBuyerLastName(String buyerLastName) {
		this.buyerLastName = buyerLastName;
	}

	public String getBuyerOutputEmailAddress() {
		return buyerOutputEmailAddress;
	}

	public void setBuyerOutputEmailAddress(String buyerOutputEmailAddress) {
		this.buyerOutputEmailAddress = buyerOutputEmailAddress;
	}

	public String getBuyerOutputAccountNumber() {
		return buyerOutputAccountNumber;
	}

	public void setBuyerOutputAccountNumber(String buyerOutputAccountNumber) {
		this.buyerOutputAccountNumber = buyerOutputAccountNumber;
	}

	public String getBuyerOutputFirstName() {
		return buyerOutputFirstName;
	}

	public void setBuyerOutputFirstName(String buyerOutputFirstName) {
		this.buyerOutputFirstName = buyerOutputFirstName;
	}

	public String getBuyerAddBank() {
		return buyerAddBank;
	}

	public void setBuyerAddBank(String buyerAddBank) {
		this.buyerAddBank = buyerAddBank;
	}

	public String getBuyerBankAccountType() {
		return buyerBankAccountType;
	}

	public void setBuyerBankAccountType(String buyerBankAccountType) {
		this.buyerBankAccountType = buyerBankAccountType;
	}

	public String getBuyerBankCountry() {
		return buyerBankCountry;
	}

	public void setBuyerBankCountry(String buyerBankCountry) {
		this.buyerBankCountry = buyerBankCountry;
	}

	public String getBuyerBankCurrency() {
		return buyerBankCurrency;
	}

	public void setBuyerBankCurrency(String buyerBankCurrency) {
		this.buyerBankCurrency = buyerBankCurrency;
	}

	public String getBuyerBankConfirmed() {
		return buyerBankConfirmed;
	}

	public void setBuyerBankConfirmed(String buyerBankConfirmed) {
		this.buyerBankConfirmed = buyerBankConfirmed;
	}

	public String getBuyerAddCreditCard() {
		return buyerAddCreditCard;
	}

	public void setBuyerAddCreditCard(String buyerAddCreditCard) {
		this.buyerAddCreditCard = buyerAddCreditCard;
	}

	public String getBuyerCcCardType() {
		return buyerCcCardType;
	}

	public void setBuyerCcCardType(String buyerCcCardType) {
		this.buyerCcCardType = buyerCcCardType;
	}

	public String getBuyerCcCountry() {
		return buyerCcCountry;
	}

	public void setBuyerCcCountry(String buyerCcCountry) {
		this.buyerCcCountry = buyerCcCountry;
	}

	public String getBuyerCcCurrency() {
		return buyerCcCurrency;
	}

	public void setBuyerCcCurrency(String buyerCcCurrency) {
		this.buyerCcCurrency = buyerCcCurrency;
	}

	public String getBuyerAddFund() {
		return buyerAddFund;
	}

	public void setBuyerAddFund(String buyerAddFund) {
		this.buyerAddFund = buyerAddFund;
	}

	public String getBuyerFundsInCents() {
		return buyerFundsInCents;
	}

	public void setBuyerFundsInCents(String buyerFundsInCents) {
		this.buyerFundsInCents = buyerFundsInCents;
	}

	public String getBuyerFundCurrency() {
		return buyerFundCurrency;
	}

	public void setBuyerFundCurrency(String buyerFundCurrency) {
		this.buyerFundCurrency = buyerFundCurrency;
	}

	public String getSellerAccountType() {
		return sellerAccountType;
	}

	public void setSellerAccountType(String sellerAccountType) {
		this.sellerAccountType = sellerAccountType;
	}

	public String getSellerCountry() {
		return sellerCountry;
	}

	public void setSellerCountry(String sellerCountry) {
		this.sellerCountry = sellerCountry;
	}

	public String getSellerCurrency() {
		return sellerCurrency;
	}

	public void setSellerCurrency(String sellerCurrency) {
		this.sellerCurrency = sellerCurrency;
	}

	public String getSellerConfirmEmail() {
		return sellerConfirmEmail;
	}

	public void setSellerConfirmEmail(String sellerConfirmEmail) {
		this.sellerConfirmEmail = sellerConfirmEmail;
	}

	public String getSellerEmailAddress() {
		return sellerEmailAddress;
	}

	public void setSellerEmailAddress(String sellerEmailAddress) {
		this.sellerEmailAddress = sellerEmailAddress;
	}

	public String getSellerEmailPrefix() {
		return sellerEmailPrefix;
	}

	public void setSellerEmailPrefix(String sellerEmailPrefix) {
		this.sellerEmailPrefix = sellerEmailPrefix;
	}

	public String getSellerFirstName() {
		return sellerFirstName;
	}

	public void setSellerFirstName(String sellerFirstName) {
		this.sellerFirstName = sellerFirstName;
	}

	public String getSellerLastName() {
		return sellerLastName;
	}

	public void setSellerLastName(String sellerLastName) {
		this.sellerLastName = sellerLastName;
	}

	public String getSellerOutputEmailAddress() {
		return sellerOutputEmailAddress;
	}

	public void setSellerOutputEmailAddress(String sellerOutputEmailAddress) {
		this.sellerOutputEmailAddress = sellerOutputEmailAddress;
	}

	public String getSellerOutputAccountNumber() {
		return sellerOutputAccountNumber;
	}

	public void setSellerOutputAccountNumber(String sellerOutputAccountNumber) {
		this.sellerOutputAccountNumber = sellerOutputAccountNumber;
	}

	public String getSellerOutputFirstName() {
		return sellerOutputFirstName;
	}

	public void setSellerOutputFirstName(String sellerOutputFirstName) {
		this.sellerOutputFirstName = sellerOutputFirstName;
	}

	public String getSellerOutputLastName() {
		return sellerOutputLastName;
	}

	public void setSellerOutputLastName(String sellerOutputLastName) {
		this.sellerOutputLastName = sellerOutputLastName;
	}

	public String getSellerAddBank() {
		return sellerAddBank;
	}

	public void setSellerAddBank(String sellerAddBank) {
		this.sellerAddBank = sellerAddBank;
	}

	public String getSellerBankAccountType() {
		return sellerBankAccountType;
	}

	public void setSellerBankAccountType(String sellerBankAccountType) {
		this.sellerBankAccountType = sellerBankAccountType;
	}

	public String getSellerBankCountry() {
		return sellerBankCountry;
	}

	public void setSellerBankCountry(String sellerBankCountry) {
		this.sellerBankCountry = sellerBankCountry;
	}

	public String getSellerBankCurrency() {
		return sellerBankCurrency;
	}

	public void setSellerBankCurrency(String sellerBankCurrency) {
		this.sellerBankCurrency = sellerBankCurrency;
	}

	public String getSellerBankConfirmed() {
		return sellerBankConfirmed;
	}

	public void setSellerBankConfirmed(String sellerBankConfirmed) {
		this.sellerBankConfirmed = sellerBankConfirmed;
	}

	public String getSellerAddCreditCard() {
		return sellerAddCreditCard;
	}

	public void setSellerAddCreditCard(String sellerAddCreditCard) {
		this.sellerAddCreditCard = sellerAddCreditCard;
	}

	public String getSellerCcCardType() {
		return sellerCcCardType;
	}

	public void setSellerCcCardType(String sellerCcCardType) {
		this.sellerCcCardType = sellerCcCardType;
	}

	public String getSellerCcCountry() {
		return sellerCcCountry;
	}

	public void setSellerCcCountry(String sellerCcCountry) {
		this.sellerCcCountry = sellerCcCountry;
	}

	public String getSellerCcCurrency() {
		return sellerCcCurrency;
	}

	public void setSellerCcCurrency(String sellerCcCurrency) {
		this.sellerCcCurrency = sellerCcCurrency;
	}

	public String getSellerAddFund() {
		return sellerAddFund;
	}

	public void setSellerAddFund(String sellerAddFund) {
		this.sellerAddFund = sellerAddFund;
	}

	public String getSellerFundsInCents() {
		return sellerFundsInCents;
	}

	public void setSellerFundsInCents(String sellerFundsInCents) {
		this.sellerFundsInCents = sellerFundsInCents;
	}

	public String getSellerFundCurrency() {
		return sellerFundCurrency;
	}

	public void setSellerFundCurrency(String sellerFundCurrency) {
		this.sellerFundCurrency = sellerFundCurrency;
	}

	public String getTrnAddFundsInCents() {
		return trnAddFundsInCents;
	}

	public void setTrnAddFundsInCents(String trnAddFundsInCents) {
		this.trnAddFundsInCents = trnAddFundsInCents;
	}

	public String getTrnAddFundCurrency() {
		return trnAddFundCurrency;
	}

	public void setTrnAddFundCurrency(String trnAddFundCurrency) {
		this.trnAddFundCurrency = trnAddFundCurrency;
	}

	public String getTrnSender() {
		return trnSender;
	}

	public void setTrnSender(String trnSender) {
		this.trnSender = trnSender;
	}

	public String getTrnRecipient() {
		return trnRecipient;
	}

	public void setTrnRecipient(String trnRecipient) {
		this.trnRecipient = trnRecipient;
	}

	public String getTrnCurrencyCode() {
		return trnCurrencyCode;
	}

	public void setTrnCurrencyCode(String trnCurrencyCode) {
		this.trnCurrencyCode = trnCurrencyCode;
	}

	public String getTrnAmount() {
		return trnAmount;
	}

	public void setTrnAmount(String trnAmount) {
		this.trnAmount = trnAmount;
	}

	public String getTrnType() {
		return trnType;
	}

	public void setTrnType(String trnType) {
		this.trnType = trnType;
	}

	public String getTrnSubType() {
		return trnSubType;
	}

	public void setTrnSubType(String trnSubType) {
		this.trnSubType = trnSubType;
	}

	public String getTrnFundingSourceType() {
		return trnFundingSourceType;
	}

	public void setTrnFundingSourceType(String trnFundingSourceType) {
		this.trnFundingSourceType = trnFundingSourceType;
	}

	public String getTrnFundingSourceId() {
		return trnFundingSourceId;
	}

	public void setTrnFundingSourceId(String trnFundingSourceId) {
		this.trnFundingSourceId = trnFundingSourceId;
	}

	public String getTrnEncryptedBuyerTransactionId() {
		return trnEncryptedBuyerTransactionId;
	}

	public void setTrnEncryptedBuyerTransactionId(String trnEncryptedBuyerTransactionId) {
		this.trnEncryptedBuyerTransactionId = trnEncryptedBuyerTransactionId;
	}

	public String getTrnReceiverTransId() {
		return trnReceiverTransId;
	}

	public void setTrnReceiverTransId(String trnReceiverTransId) {
		this.trnReceiverTransId = trnReceiverTransId;
	}

	public String getTrnSellerTransId() {
		return trnSellerTransId;
	}

	public void setTrnSellerTransId(String trnSellerTransId) {
		this.trnSellerTransId = trnSellerTransId;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getLocalStage() {
		return localStage;
	}

	public void setLocalStage(String localStage) {
		this.localStage = localStage;
	}

	public String getCreateBuyer() {
		return createBuyer;
	}

	public void setCreateBuyer(String createBuyer) {
		this.createBuyer = createBuyer;
	}

	public String getCreateSeller() {
		return createSeller;
	}

	public void setCreateSeller(String createSeller) {
		this.createSeller = createSeller;
	}

	public String getPerformTrn() {
		return performTrn;
	}

	public void setPerformTrn(String performTrn) {
		this.performTrn = performTrn;
	}


	public String getBuyerOutputLastName() {
		return buyerOutputLastName;
	}

	public void setBuyerOutputLastName(String buyerOutputLastName) {
		this.buyerOutputLastName = buyerOutputLastName;
	}
	
	@Override
	public String toString() {
		return "TestData [Testcase Name = "+testcaseName+", header= " + header + ", request=" + request + ", response=" + response + "]";
	}

	public String getLocalPort() {
		return localPort;
	}

	public void setLocalPort(String localPort) {
		this.localPort = localPort;
	}

}
