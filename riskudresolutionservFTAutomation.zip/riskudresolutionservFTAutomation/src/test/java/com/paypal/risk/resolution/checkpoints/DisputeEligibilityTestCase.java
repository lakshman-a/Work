package com.paypal.risk.resolution.checkpoints;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.paypal.risk.resolution.constants.RUDSConstants;
import com.paypal.risk.resolution.model.ResponseEntity;
import com.paypal.risk.resolution.report.Report;
import com.paypal.risk.resolution.utils.ExcelUtils;
import com.paypal.risk.resolution.utils.HttpRestClient;

public class DisputeEligibilityTestCase extends RUDSBaseTest {

	/*--------------------- RETD -------------------- */

	final static Logger log = Logger.getLogger(DisputeEligibilityTestCase.class);
	Map<String, String> headerMap = new HashMap<String, String>();
	String checkpointName = RUDSConstants.DISPUTE_ELIGIBILITY_CP;
	String excelPath = rudsDataExcelPath + checkpointName + ".xlsx";
	String schemaPath = rudsDataScehmaPath + checkpointName + ".json";
	String sheetName = checkpointName;

	@DataProvider(name = "dataProvider")
	public Object[][] testDataProvider() throws Exception {
		Object[][] testData = ExcelUtils.getTableArrayAsMap(excelPath, sheetName);
		return testData;
	}

	@Test(dataProvider = "dataProvider")
	public void test(Map<String, String> testData) throws Exception {
		HttpRestClient client = new HttpRestClient();
		String actualResponse = null;
		Map<String, String> preconditionData = new HashMap<>();
		Report.startComponent(testData.get("key"), testData.get("testcaseName"));

		try {

			// Pre-Condition Test Data Preparation (Create Buyer and Seller and perform
			// transaction):
			if (testData.get("preconditionFlag").equalsIgnoreCase("Y")) {
				preconditionData = preconditionDataPrep(excelPath, testData, hostname);
				Report.info("<b><u>Dispute Eligibility Testcase validation starts...</b></u>");
			}

			// Setup URL
			String restUrl = rudsProtocal + hostname + ":" + port + "/" + RUDSConstants.DISPUTE_ELIGIBILITY_URI;
			Report.info("<b>Rest URL =  <u>" + restUrl + "</b></u>");

			// Setup Headers
			Map<String, String> headerMap = setupHeader(testData.get("header"), preconditionData);
			Report.info("<b>Request Headers = </b> " + headerMap);

			// Setup Request [Column Name - request in Testdata sheet]
			String request = buildRequestJsonWithData(testData, preconditionData);
			Report.info("<b>Request Payload = </b>" + request);

			// Trigger API Request
			ResponseEntity responseEntity = client.doGenericPost(restUrl, headerMap, request);

			// Validation of Response
			if (responseEntity.getStatusCode() == 200) {

				if (responseEntity.getResponse() != null) {
					actualResponse = responseEntity.getResponse().toString();
					if (actualResponse.equalsIgnoreCase("")) {
						Report.fail(
								"<b>API Response received Empty! Skipping response validation. </b> Check the Request details");
					} else {
						Report.pass("<b>API Response received = </b>" + actualResponse);

						validateResponseFields(actualResponse, testData);

						// RBO Dump Validation
						triggerRBODumpValidation(excelPath,testData.get("key"));
						
					}
				}

			} else {
				String failureMessage = "<b>API Response code validation failed. Response Code = "
						+ responseEntity.getStatusCode() + "</b>";
				Report.fail(failureMessage);
				throw new Exception(failureMessage);
			}

		} catch (Exception e) {
			Report.fail("Testcase failed due to reason : " + e);
			throw e;
		} finally {
			Report.appendComponent();
		}

	}

	@SuppressWarnings("unchecked")
	private String buildRequestJsonWithData(Map<String, String> testData, Map<String, String> preconditionData)
			throws Exception {
		JSONObject request = null;
		try {
			FileReader reader = new FileReader(schemaPath);

			JSONParser jsonParser = new JSONParser();
			request = (JSONObject) jsonParser.parse(reader);

			// ---------
			if (testData.get("reported_transactions").equalsIgnoreCase("true")) {
				JSONArray reported_transactions = (JSONArray) request.get("reported_transactions");
				reported_transactions.set(0, testData.get("reported_transactions0"));

				if (!testData.get("reported_transactions1").equals(""))
					reported_transactions.set(1, testData.get("reported_transactions1"));

				if (!testData.get("reported_transactions2").equals(""))
					reported_transactions.set(2, testData.get("reported_transactions2"));

			}
		} catch (Exception e) {
			Report.error("Dispute Eligibility JSON request building failed. Reason : " + e.getMessage());
			throw e;
		}

		return request.toString();
	}

	private boolean validateResponseFields(String responseObject, Map<String, String> rowDataMap) throws Exception {
		boolean result = true;
		List<Boolean> resultArr = new ArrayList<Boolean>();
		JSONObject responseJson = null;
		ArrayList<String> availableDisputeTypes = new ArrayList<String>(Arrays.asList("ITEM_NOT_RECEIVED",
				"SIGNIFICANTLY_NOT_AS_DESCRIBED", "CREDIT_NOT_PROCESSED", "DUPLICATE", "DOES_NOT_RECOGNIZE",
				"INCORRECT_TRANSACTION_AMOUNT", "CANCELLED_RECURRING_BILLING", "NEED_MORE_INFORMATION",
				"PAID_BY_OTHER_MEANS", "UNAUTHORIZED_ON_DEBIT_CARDS", "PROBLEM_WITH_REMITTANCE", "OTHER"));
		try {

			JSONParser jsonParser = new JSONParser();
			responseJson = (JSONObject) jsonParser.parse(responseObject);

			// dispute_eligibility_decisions
			if (rowDataMap.get("res.dispute_eligibility_decisions").equalsIgnoreCase("true")) {

				JSONArray dispute_eligibility_decisions = (JSONArray) responseJson.get("dispute_eligibility_decisions");
				JSONObject dispute_eligibility_decisions0 = (JSONObject) dispute_eligibility_decisions.get(0);

				// transaction_id
				if (!rowDataMap.get("res.dispute_eligibility_decisions0.transaction_id").equals("")) {
					resultArr.add(Report.assertEquals("dispute_eligibility_decisions.transaction_id",
							dispute_eligibility_decisions0.get("transaction_id").toString(),
							rowDataMap.get("res.dispute_eligibility_decisions0.transaction_id")));
				}

				JSONArray allowed_disputes = null;
				JSONArray denied_disputes = null;
				// allowed_disputes
				if (rowDataMap.get("res.dispute_eligibility_decisions0.allowed_disputes").equalsIgnoreCase("true")) {
					resultArr.add(Report.assertFieldPresent("dispute_eligibility_decisions0.allowed_disputes",
							dispute_eligibility_decisions0.containsKey("allowed_disputes")));
					allowed_disputes = (JSONArray) dispute_eligibility_decisions0.get("allowed_disputes");
				}

				// allowed_disputes
				if (rowDataMap.get("res.dispute_eligibility_decisions0.denied_disputes").equalsIgnoreCase("true")) {
					resultArr.add(Report.assertFieldPresent("dispute_eligibility_decisions0.denied_disputes",
							dispute_eligibility_decisions0.containsKey("denied_disputes")));
					denied_disputes = (JSONArray) dispute_eligibility_decisions0.get("denied_disputes");
				}

				for (String eachDispute : availableDisputeTypes) {
					if (rowDataMap.get("type." + eachDispute).equalsIgnoreCase("ALLOW")) {
						boolean found = false;
						for (Object eachItem : allowed_disputes) {
							JSONObject disputeObject = (JSONObject) eachItem;
							String disputeType = disputeObject.get("type").toString();
							if (disputeType.equalsIgnoreCase(eachDispute)) {
								found = true;
								resultArr.add(true);
								Report.pass("Assert Passed. Dispute Type <b>'" + eachDispute
										+ "'</b> is found in  <b>'Allowed Disputes'</b> in Dispute Eligibility RTED Response.");
								if (!rowDataMap.get("type." + eachDispute + ".dispute_settings.auto_escalate")
										.equalsIgnoreCase("")) {
									if (rowDataMap.get("type." + eachDispute + ".dispute_settings.auto_escalate")
											.equalsIgnoreCase("NOT_PRESENT"))
										resultArr.add(Report.assertFieldAbsent(
												"allowed_disputes.type." + eachDispute
														+ ".dispute_settings.auto_escalate",
												disputeObject.containsKey("dispute_settings")));
									else {
										JSONObject dispute_settings = (JSONObject) disputeObject
												.get("dispute_settings");
										resultArr.add(Report.assertEquals(
												"allowed_disputes.type." + eachDispute
														+ ".dispute_settings.auto_escalate",
												dispute_settings.get("auto_escalate").toString(), rowDataMap.get(
														"type." + eachDispute + ".dispute_settings.auto_escalate")));
									}
								}
								break;
							}
						}
						if (!found) {
							resultArr.add(false);
							Report.fail("Assert Failed. Dispute Type <b>'" + eachDispute
									+ "'</b> is not found in <b>'Allowed Disputes'</b> in Dispute Eligibility RTED Response.");
						}
					} else if (rowDataMap.get("type." + eachDispute + "").equalsIgnoreCase("DISALLOW")) {
						boolean found = false;
						for (Object eachItem : denied_disputes) {
							JSONObject disputeObject = (JSONObject) eachItem;
							String disputeType = disputeObject.get("type").toString();
							if (disputeType.equalsIgnoreCase(eachDispute)) {
								found = true;
								resultArr.add(true);
								Report.pass("Assert Passed. Dispute Type '" + eachDispute
										+ "' is found in <b>'Denied Disputes'</b> in Dispute Eligibility RTED Response.");
								if (!rowDataMap.get("type." + eachDispute + ".deny_reason").equalsIgnoreCase("")) {
									if (rowDataMap.get("type." + eachDispute + ".deny_reason")
											.equalsIgnoreCase("NOT_PRESENT"))
										resultArr.add(Report.assertFieldAbsent(
												"denied_disputes.type." + eachDispute + ".deny_reason",
												disputeObject.containsKey("deny_reason")));
									else
										resultArr.add(Report.assertEquals(
												"denied_disputes.type." + eachDispute + ".deny_reason",
												disputeObject.get("deny_reason").toString(),
												rowDataMap.get("type." + eachDispute + ".deny_reason")));
								}
								break;
							}
						}
						if (!found) {
							resultArr.add(false);
							Report.fail("Assert Failed. Dispute Type <b>'" + eachDispute
									+ "'</b> is not found in <b>'Denied Disputes'</b> in Dispute Eligibility RTED Response.");
						}

					} else {
						resultArr.add(false);
						Report.fail("Assert Failed. Dispute Type <b>'" + eachDispute
								+ "'</b> should either be in <b>'Allowed Disputes' or 'Denied Disputes'</b> Type in Dispute Eligibility RTED Response.");
					}
				}

			}

			if (resultArr.contains(false)) {
				result = false;
				Report.fail("<b>Response fields validation failed.</b>");
			} else {
				Report.pass("<b>Response fields validation passed.</b>");
			}

		} catch (NullPointerException | IndexOutOfBoundsException e) {
			Report.fail(
					"<b>Dispute Eligibility response field validation failed due to either Missing field in response or Testdata not available</b>");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			Report.fail("Dispute Eligibility response field validation failed. Reason : " + e.getMessage());
			e.printStackTrace();
			throw e;
		}

		return result;
	}

}
