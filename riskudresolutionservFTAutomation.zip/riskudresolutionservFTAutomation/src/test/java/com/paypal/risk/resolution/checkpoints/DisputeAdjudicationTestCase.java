package com.paypal.risk.resolution.checkpoints;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.paypal.risk.resolution.constants.RUDSConstants;
import com.paypal.risk.resolution.model.ResponseEntity;
import com.paypal.risk.resolution.report.Report;
import com.paypal.risk.resolution.utils.ExcelUtils;
import com.paypal.risk.resolution.utils.HttpRestClient;

public class DisputeAdjudicationTestCase extends RUDSBaseTest {

	final static Logger log = Logger.getLogger(DisputeAdjudicationTestCase.class);
	Map<String, String> headerMap = new HashMap<String, String>();
	String checkpointName = RUDSConstants.DISPUTE_ADJUDICATION_CP;
	String excelPath = rudsDataExcelPath + checkpointName + ".xlsx";
	String schemaPath = rudsDataScehmaPath + checkpointName + ".json";
	String sheetName = checkpointName;

	@DataProvider(name = "dataProvider")
	public Object[][] testDataProvider() throws Exception {
		Object[][] testData = ExcelUtils.getTableArrayAsMap(excelPath, sheetName);
		return testData;
	}

	@Test(dataProvider = "dataProvider")
	public void test(Map<String, String> testData) throws Exception {
		HttpRestClient client = new HttpRestClient();
		String actualResponse = null;
		Map<String, String> preconditionData = new HashMap<>();
		Report.startComponent(testData.get("key"), testData.get("testcaseName"));

		try {

			// Pre-Condition Test Data Preparation (Create Buyer and Seller and perform transaction):
			if (testData.get("preconditionFlag").equalsIgnoreCase("Y")) {
				preconditionData = preconditionDataPrep(excelPath, testData, hostname);
				Report.info("<b><u>Dispute Adjudication Testcase validation starts...</b></u>");
			}

			// Setup URL
			String restUrl = rudsProtocal + hostname + ":" + port + "/" + RUDSConstants.DISPUTE_ADJUDICATION_URI;
			Report.info("<b>Rest URL =  <u>" + restUrl + "</b></u>");

			// Setup Headers
			Map<String, String> headerMap = setupHeader(testData.get("header"), preconditionData);
			Report.info("<b>Request Headers = </b> " + headerMap);

			// Setup Request [Column Name - request in Testdata sheet]
			String request = buildRequestJsonWithData(testData, preconditionData);
			Report.info("<b>Request Payload = </b>" + request);

			// Trigger API Request
			ResponseEntity responseEntity = client.doGenericPost(restUrl, headerMap, request);

			// Validation of Response
			if (responseEntity.getStatusCode() == 200) {

				if (responseEntity.getResponse() != null) {
					actualResponse = responseEntity.getResponse().toString();
					if (actualResponse.equalsIgnoreCase("")) {
						Report.fail("<b>API Response received Empty! Skipping response validation. </b> Check the Request details");
					} else {
						Report.pass("<b>API Response received = </b>" + actualResponse);
						validateResponseFields(actualResponse, testData);
					}
				}

			} else {
				String failureMessage = "<b>API Response code validation failed. Response Code = " + responseEntity.getStatusCode() + "</b>";
				Report.fail(failureMessage);
				throw new Exception(failureMessage);
			}

		} catch (Exception e) {
			Report.fail("Testcase failed due to reason : " + e);
			throw e;
		} finally {
			Report.appendComponent();
		}

	}

	@SuppressWarnings("unchecked")
	private String buildRequestJsonWithData(Map<String, String> testData, Map<String, String> preconditionData) throws Exception {
		JSONObject request = null;
		try {
			System.out.println("Schema path : " + schemaPath);
			FileReader reader = new FileReader(schemaPath);

			JSONParser jsonParser = new JSONParser();
			request = (JSONObject) jsonParser.parse(reader);

			// ------------ dispute_event
			JSONObject disputeDetailsJson = (JSONObject) request.get("dispute_event");
			disputeDetailsJson.put("event_name", testData.get("event_name"));
			if (!testData.get("event_reason").equals(""))
				disputeDetailsJson.put("event_reason", testData.get("event_reason"));
			else
				disputeDetailsJson.remove("event_reason");

			if (preconditionData.get("buyerOutputAccountNumber") != null)
				request.put("receiver_account_number", preconditionData.get("buyerOutputAccountNumber"));
			else
				request.put("receiver_account_number", testData.get("receiver_account_number"));

			if (preconditionData.get("sellerOutputAccountNumber") != null)
				request.put("sender_account_number", preconditionData.get("sellerOutputAccountNumber"));
			else
				request.put("sender_account_number", testData.get("sender_account_number"));

			if (preconditionData.get("trnEncryptedBuyerTransactionId") != null)
				request.put("encrypted_receiver_transaction_id", preconditionData.get("trnEncryptedBuyerTransactionId"));
			else
				request.put("encrypted_receiver_transaction_id", testData.get("encrypted_receiver_transaction_id"));

			if (preconditionData.get("trnReceiverTransId") != null)
				request.put("receiver_transaction_id", preconditionData.get("trnReceiverTransId"));
			else
				request.put("receiver_transaction_id", testData.get("receiver_transaction_id"));

			if (preconditionData.get("trnSellerTransId") != null)
				request.put("sender_transaction_id", preconditionData.get("trnSellerTransId"));
			else
				request.put("sender_transaction_id", testData.get("sender_transaction_id"));

			request.put("encrypted_sender_transaction_id", testData.get("encrypted_sender_transaction_id"));

			if (!testData.get("encrypted_billing_agreement_id").equals(""))
				request.put("encrypted_billing_agreement_id", testData.get("encrypted_billing_agreement_id"));
			else
				request.remove("encrypted_billing_agreement_id");

			if (!testData.get("wait_retry_count").equals(""))
				request.put("wait_retry_count", testData.get("wait_retry_count"));
			else
				request.remove("wait_retry_count");

			request.put("ramp_on", testData.get("ramp_on"));

			// participant_profile_settings
			JSONObject participant_profile_settings = (JSONObject) request.get("participant_profile_settings");
			JSONObject merchant_profile_settings = (JSONObject) participant_profile_settings.get("merchant_profile_settings");
			if (!testData.get("pps.mps.profile_type").equalsIgnoreCase(""))
				merchant_profile_settings.put("profile_type", testData.get("pps.mps.profile_type"));
			else
				merchant_profile_settings.remove("profile_type");

			if (!testData.get("pps.mps.high_risk_recoup").equalsIgnoreCase(""))
				merchant_profile_settings.put("high_risk_recoup", testData.get("pps.mps.high_risk_recoup"));
			else
				merchant_profile_settings.remove("high_risk_recoup");

			// ------------ dispute_stats
			JSONObject dispute_stats = (JSONObject) request.get("dispute_stats");
			if (testData.get("dispute_stats").equalsIgnoreCase("true")) {
				dispute_stats.put("no_fault_payout_buyer", testData.get("dispute_stats.no_fault_payout_buyer"));
				dispute_stats.put("no_fault_payout_seller", testData.get("dispute_stats.no_fault_payout_seller"));
			} else {
				request.remove("dispute_stats");
			}

			// ------------ current_dispute
			JSONObject current_dispute = (JSONObject) request.get("current_dispute");
			current_dispute.put("id", testData.get("id"));
			if (!testData.get("category").equals(""))
				current_dispute.put("category", testData.get("category"));
			else
				current_dispute.remove("category");

			if (!testData.get("sub_category").equals(""))
				current_dispute.put("sub_category", testData.get("sub_category"));
			else
				current_dispute.remove("sub_category");

			if (!testData.get("reason").equals(""))
				current_dispute.put("reason", testData.get("reason"));
			else
				current_dispute.remove("reason");

			if (!testData.get("stage").equals(""))
				current_dispute.put("stage", testData.get("stage"));
			else
				current_dispute.remove("stage");

			if (!testData.get("duplicate_transaction_id").equals(""))
				current_dispute.put("duplicate_transaction_id", testData.get("duplicate_transaction_id"));
			else
				current_dispute.remove("duplicate_transaction_id");

			if (!testData.get("create_time").equals(""))
				current_dispute.put("create_time", testData.get("create_time"));
			else
				current_dispute.remove("create_time");

			if (!testData.get("creation_channel").equals(""))
				current_dispute.put("creation_channel", testData.get("creation_channel"));
			else
				current_dispute.remove("creation_channel");

			if (!testData.get("seller_protection_eligibile_proof").equals(""))
				current_dispute.put("seller_protection_eligibile_proof", testData.get("seller_protection_eligibile_proof"));
			else
				current_dispute.remove("seller_protection_eligibile_proof");

			if (!testData.get("reported_usd_amount").equals(""))
				current_dispute.put("reported_usd_amount", testData.get("reported_usd_amount"));
			else
				current_dispute.remove("reported_usd_amount");

			// ------------ reported_amount
			JSONObject reported_amount = (JSONObject) current_dispute.get("reported_amount");
			reported_amount.put("currency_code", testData.get("reported_amount.currency_code"));
			reported_amount.put("value", testData.get("reported_amount.value"));

			// ------------ adjudication_decisions
			if (testData.get("adjudication_decisions").equalsIgnoreCase("true")) {
				JSONArray adjudication_decisions = (JSONArray) current_dispute.get("adjudication_decisions");
				JSONObject sender_adjudication_decisions = (JSONObject) adjudication_decisions.get(0);
				if (!testData.get("adjudication_decisions.participant_type").equals("")) {
					sender_adjudication_decisions.put("participant_type", testData.get("adjudication_decisions.participant_type"));
					sender_adjudication_decisions.put("outcome", testData.get("adjudication_decisions.outcome"));
				} else
					adjudication_decisions.remove(0);

			} else {
				current_dispute.remove("adjudication_decisions");
			}

			// ------------ participant_actions
			if (testData.get("participant_actions").equalsIgnoreCase("true")) {
				JSONArray participant_actions = (JSONArray) current_dispute.get("participant_actions");
				JSONObject participant_action = (JSONObject) participant_actions.get(0);
				participant_action.put("dispute_stage", testData.get("participant_actions0.dispute_stage"));

				// ------------ participant_actions.buyer_actions
				if (testData.get("participant_actions0.buyer_actions").equalsIgnoreCase("true")) {
					JSONArray buyer_actions = (JSONArray) participant_action.get("buyer_actions");
					JSONObject buyer_action = (JSONObject) buyer_actions.get(0);
					buyer_action.put("response_time", testData.get("participant_actions0.buyer_actions0.response_time"));
					buyer_action.put("notes", testData.get("participant_actions0.buyer_actions0.notes"));
					buyer_action.put("action", testData.get("participant_actions0.buyer_actions0.action"));
					buyer_action.put("attachments", testData.get("participant_actions0.buyer_actions0.attachments"));
					if (testData.get("participant_actions0.buyer_actions0.tracking_info").equals("true")) {
						JSONObject tracking_info = (JSONObject) buyer_action.get("tracking_info");
						tracking_info.put("id", testData.get("participant_actions0.buyer_actions0.tracking_info.id"));
						tracking_info.put("update_time", testData.get("participant_actions0.buyer_actions0.tracking_info.update_time"));
						tracking_info.put("shipping_carrier", testData.get("participant_actions0.buyer_actions0.tracking_info.shipping_carrier"));
						tracking_info.put("shipping_address_id", testData.get("participant_actions0.buyer_actions0.tracking_info.shipping_address_id"));
					} else {
						buyer_action.remove("tracking_info");
					}
				}

				// ------------ participant_actions.merchant_actions
				if (testData.get("participant_actions0.merchant_actions").equalsIgnoreCase("true")) {
					JSONArray merchant_actions = (JSONArray) participant_action.get("merchant_actions");
					JSONObject merchant_action = (JSONObject) merchant_actions.get(0);
					merchant_action.put("response_time", testData.get("participant_actions0.merchant_actions0.response_time"));
					merchant_action.put("notes", testData.get("participant_actions0.merchant_actions0.notes"));
					merchant_action.put("action", testData.get("participant_actions0.merchant_actions0.action"));
					merchant_action.put("attachments", testData.get("participant_actions0.merchant_actions0.attachments"));
					if (!testData.get("participant_actions0.merchant_actions0.offer_amount.currency_code").equals("")) {
						JSONObject offer_amount = (JSONObject) merchant_action.get("offer_amount");
						offer_amount.put("currency_code", testData.get("participant_actions0.merchant_actions0.offer_amount.currency_code"));
						offer_amount.put("value", testData.get("participant_actions0.merchant_actions0.offer_amount.value"));
					} else
						merchant_action.remove("offer_amount");

				}

				// ------------ participant_actions.notes
				JSONObject notes = (JSONObject) participant_action.get("notes");
				if (testData.get("participant_actions0.notes.seller_notes").equalsIgnoreCase("true")) {
					JSONArray seller_notes = (JSONArray) notes.get("seller_notes");
					JSONObject seller_note = (JSONObject) seller_notes.get(0);
					seller_note.put("note", testData.get("participant_actions0.notes.seller_notes0.note"));
					seller_note.put("update_time", testData.get("participant_actions0.notes.seller_notes0.update_time"));
				} else {
					notes.remove("seller_notes");
				}

				if (testData.get("participant_actions0.notes.buyer_notes").equalsIgnoreCase("true")) {
					JSONArray buyer_notes = (JSONArray) notes.get("buyer_notes");
					JSONObject buyer_note = (JSONObject) buyer_notes.get(0);
					buyer_note.put("note", testData.get("participant_actions0.notes.buyer_notes0.note"));
					buyer_note.put("update_time", testData.get("participant_actions0.notes.buyer_notes0.update_time"));
				} else {
					notes.remove("buyer_notes");
				}

				if (testData.get("participant_actions0.notes.teammate_notes").equalsIgnoreCase("true")) {
					JSONArray teammate_notes = (JSONArray) notes.get("teammate_notes");
					JSONObject teammate_note = (JSONObject) teammate_notes.get(0);
					teammate_note.put("note", testData.get("participant_actions0.notes.teammate_notes0.note"));
					teammate_note.put("update_time", testData.get("participant_actions0.notes.teammate_notes0.update_time"));
				} else {
					notes.remove("teammate_notes");
				}

			} else {
				current_dispute.remove("participant_actions");
			}

		} catch (Exception e) {
			Report.error("Dispute Adjudication JSON request building failed. Reason : " + e.getMessage());
			throw e;
		}

		return request.toString();
	}

	private boolean validateResponseFields(String responseObject, Map<String, String> rowDataMap) throws Exception {
		boolean result = true;
		List<Boolean> resultArr = new ArrayList<Boolean>();
		JSONObject responseJson = null;

		try {

			JSONParser jsonParser = new JSONParser();
			responseJson = (JSONObject) jsonParser.parse(responseObject);

			// decision
			JSONObject decision = (JSONObject) responseJson.get("decision");
			resultArr.add(Report.assertEquals("code", decision.get("code").toString(), rowDataMap.get("res.decision.code")));

			if (!rowDataMap.get("res.decision.reason").equals(""))
				resultArr.add(Report.assertEquals("reason", decision.get("reason").toString(), rowDataMap.get("res.decision.reason")));

			if (rowDataMap.get("res.decision.details").equalsIgnoreCase("true")) {
				JSONObject decisiondetails = (JSONObject) decision.get("details");
				resultArr.add(Report.assertEquals("details.wait_time", decisiondetails.get("wait_time").toString(), rowDataMap.get("res.decision.details.wait_time")));
			}

			// recommendations
			JSONObject recommendations = (JSONObject) responseJson.get("recommendations");
			// recommendations>dispute_recommendations
			JSONArray dispute_recommendations = (JSONArray) recommendations.get("dispute_recommendations");
			if (!rowDataMap.get("res.recommendations.dispute_recommendations0").equals(""))
				resultArr.add(Report.assertEquals("dispute_recommendations", dispute_recommendations.get(0).toString(), rowDataMap.get("res.recommendations.dispute_recommendations0")));

			// recommendations>protection_recommendations
			JSONArray protection_recommendations = (JSONArray) recommendations.get("protection_recommendations");
			if (!rowDataMap.get("res.recommendations.protection_recommendations0").equals(""))
				resultArr.add(Report.assertEquals("protection_recommendations", protection_recommendations.get(0).toString(), rowDataMap.get("res.recommendations.protection_recommendations0")));

			// evidences > tracking_evidences
			JSONObject evidences = (JSONObject) responseJson.get("evidences");
			JSONArray tracking_evidences = (JSONArray) evidences.get("tracking_evidences");
			if (rowDataMap.get("res.evidences.tracking_evidences").equalsIgnoreCase("true")) {
				JSONObject tracking_evidence = (JSONObject) tracking_evidences.get(0);

				resultArr.add(Report.assertEquals("tracking_evidences.tracking_number", tracking_evidence.get("tracking_number").toString(), rowDataMap.get("res.evidences.tracking_evidences.tracking_number")));
				resultArr.add(Report.assertEquals("tracking_evidences.shipping_carrier", tracking_evidence.get("shipping_carrier").toString(), rowDataMap.get("res.evidences.tracking_evidences.shipping_carrier")));
				resultArr.add(Report.assertEquals("tracking_evidences.create_time", tracking_evidence.get("create_time").toString(), rowDataMap.get("res.evidences.tracking_evidences.create_time")));
			}

			// evidences > contest_evidences
			JSONArray contest_evidences = (JSONArray) evidences.get("contest_evidences");
			if (!rowDataMap.get("res.evidences.contest_evidences").equals("")) {
				JSONObject contest_evidence = (JSONObject) contest_evidences.get(0);
				resultArr.add(Report.assertEquals("tracking_evidences", contest_evidence.get(0).toString(), rowDataMap.get("res.evidences.contest_evidences")));
			}

			// actions
			JSONObject actions = (JSONObject) responseJson.get("actions");
			if (!rowDataMap.get("res.actions.attach_documents").equals(""))
				resultArr.add(Report.assertEquals("actions.attach_documents", actions.get("attach_documents").toString(), rowDataMap.get("res.actions.attach_documents")));

			// actions>required_actions_on_seller
			JSONObject required_actions_on_seller = (JSONObject) actions.get("required_actions_on_seller");
			if (rowDataMap.get("res.actions.required_actions_on_seller").equalsIgnoreCase("true")) {
				if (!rowDataMap.get("res.actions.required_actions_on_seller.loss_remediation_action").equals(""))
					resultArr.add(Report.assertEquals("actions.required_actions_on_seller.loss_remediation_action", required_actions_on_seller.get("loss_remediation_action").toString(),
							rowDataMap.get("res.actions.required_actions_on_seller.loss_remediation_action")));
				if (!rowDataMap.get("res.actions.required_actions_on_seller.provisional_credit").equals(""))
					resultArr.add(Report.assertEquals("actions.required_actions_on_seller.provisional_credit", required_actions_on_seller.get("provisional_credit").toString(),
							rowDataMap.get("res.actions.required_actions_on_seller.provisional_credit")));
				if (!rowDataMap.get("res.actions.required_actions_on_seller.creditcard_chargeback_fee").equals(""))
					resultArr.add(Report.assertEquals("actions.required_actions_on_seller.creditcard_chargeback_fee", required_actions_on_seller.get("creditcard_chargeback_fee").toString(),
							rowDataMap.get("res.actions.required_actions_on_seller.creditcard_chargeback_fee")));
				if (!rowDataMap.get("res.actions.required_actions_on_seller.effortless_protection").equals("")) {
					// If NOT_PRESENT is displayed then the field should be absent
					if (rowDataMap.get("res.actions.required_actions_on_seller.effortless_protection").equals("NOT_PRESENT"))
						resultArr.add(Report.assertFieldAbsent("res.actions.required_actions_on_seller.effortless_protection", required_actions_on_seller.containsKey("effortless_protection")));
					else
						resultArr.add(Report.assertEquals("actions.required_actions_on_seller.effortless_protection", required_actions_on_seller.get("effortless_protection").toString(),
								rowDataMap.get("res.actions.required_actions_on_seller.effortless_protection")));

				}
			}

			// actions>required_actions_on_buyer
			JSONObject required_actions_on_buyer = (JSONObject) actions.get("required_actions_on_buyer");
			if (rowDataMap.get("res.actions.required_actions_on_buyer").equalsIgnoreCase("true")) {
				resultArr.add(Report.assertEquals("actions.required_actions_on_seller.loss_remediation_action", required_actions_on_buyer.get("loss_remediation_action").toString(),
						rowDataMap.get("res.actions.required_actions_on_seller.loss_remediation_action")));
			}

			if (resultArr.contains(false)) {
				result = false;
				Report.fail("<b>Response fields validation failed.</b>");
			} else {
				Report.pass("<b>Response fields validation passed.</b>");
			}
		} catch (NullPointerException | IndexOutOfBoundsException e) {
			Report.fail("<b>Dispute Adjudication response field validation failed due to either Missing field in response or Testdata not available</b>");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			Report.fail("Dispute Adjudication response field validation failed. Reason : " + e.getMessage());
			e.printStackTrace();
			throw e;
		}

		return result;
	}

}
