package com.paypal.risk.resolution.checkpoints;

import com.paypal.risk.resolution.jaws.support.BuyerCreation;
import com.paypal.risk.resolution.jaws.support.PerformSendMoney;
import com.paypal.risk.resolution.jaws.support.RBODumpProcessor;
import com.paypal.risk.resolution.jaws.support.SellerCreation;
import com.paypal.risk.resolution.report.Report;
import com.paypal.risk.resolution.report.ReportModel;
import com.paypal.risk.resolution.utils.ExcelUtils;
import com.paypal.risk.resolution.utils.PropertyUtil;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.skyscreamer.jsonassert.JSONAssert;
import org.testng.ITestContext;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Base test which should be extended by all ruds checkpoint test cases.
 */
public class RUDSBaseTest {

	final static Logger log = Logger.getLogger(RUDSBaseTest.class);
	String rudsProtocal = PropertyUtil.getConfigValueOf("ruds.default.protocol");
	String rudsVmArgsHostname = System.getProperty("hostname");
	String rudsConfigHost = PropertyUtil.getConfigValueOf("ruds.default.stage");
	String rudsConfigPort = PropertyUtil.getConfigValueOf("ruds.default.port");
	Boolean runOnDefaultHost = Boolean.valueOf(PropertyUtil.getConfigValueOf("ruds.runOnDefaultHost"));
	String rudsDataExcelPath = PropertyUtil.getConfigValueOf("ruds.common.excel.path");
	String rudsDataScehmaPath = PropertyUtil.getConfigValueOf("ruds.common.schema.path");
	static String hostname = null;
	static String port = null;
	String preconditionSheetName = "PreCondition";

	// Report
	static String reportFileName;
	static ReportModel reportModel = new ReportModel();

	@BeforeSuite(alwaysRun = true)
	public void setupSuite(ITestContext ctx) throws Exception {
		System.out.println("---------------->Suite execution starts");
		String suiteName = ctx.getCurrentXmlTest().getSuite().getName();
		reportModel.setSuiteName(suiteName);
		createReport(suiteName);

		port = rudsConfigPort;
		if (runOnDefaultHost) {
			// Preferred in case of regression - use only one stage always which is from
			// default config file
			hostname = rudsConfigHost;
		} else {
			// Below setup takes stage from vmArguments - to test specific case
			hostname = rudsVmArgsHostname;
		}

		Report.addReportInfo("Default Host Flag", runOnDefaultHost.toString());
		Report.addReportInfo("Host", hostname);
		Report.addReportInfo("Port", port);
	}

	public void createReport(String suiteName) throws Exception {
		String datetime = new SimpleDateFormat("_dd_MM_yyyy_HHmmss").format(new Date());
		String serializeTestSuiteName = suiteName.replaceAll(" ", "_");
		reportFileName = "Report_" + serializeTestSuiteName + "_" + datetime + ".html";
		Report.startReportWithFileName(reportFileName, suiteName);
		Report.addReportInfo("Suite Name", suiteName);
		Report.addReportInfo("SeLion Version", "1.2.0");
		Report.addReportInfo("Jaws Restclient", "1.15.2");

	}

	public Map<String, String> setupHeader(String headerData, Map<String, String> preconditionData) throws Exception {
		log.info("Raw Header are : " + headerData);
		Map<String, String> headerMap = new HashMap<String, String>();
		String headerFromTestData = headerData;
		if (headerFromTestData != null) {
			if (!headerFromTestData.equals("")) {
				String splitedHeaders[] = headerFromTestData.split("#");
				for (String eachHeader : splitedHeaders) {
					String headerValue = eachHeader.split("=")[1];

					// ------- If any runtime variable added from Precondition data, then replace
					// with the value -----------//
					if (preconditionData != null && preconditionData.size() > 0) {
						List<String> allMatchedVariables = new ArrayList<String>();
						Pattern p = Pattern.compile("(.*)$(.*)$(.*)");
						Matcher m = p.matcher(headerValue);

						while (m.find()) {
							allMatchedVariables.add(m.group(2));
						}

						if (allMatchedVariables.size() > 0) {
							for (String eachVariable : allMatchedVariables) {
								if (preconditionData.get(eachVariable) != null) {
									headerValue = headerValue.replaceAll("$" + eachVariable + "$", preconditionData.get(eachVariable));
								}

							}
						}
					}

					// ----------------------------------------//
					headerMap.put(eachHeader.split("=")[0], headerValue);
				}

			}
		}

		return headerMap;
	}

	protected boolean commonResponseValidation(Object responseJson, String expectedResponse) throws Exception {
		boolean result = true;
		String processedExpectedResponse = expectedResponse.toString();
		try {
			JSONAssert.assertEquals(processedExpectedResponse, responseJson.toString(), false);
			Report.pass("<b>Actual and Expected Response field values Matched. Response Validation Passed.</b> ");
		} catch (AssertionError e) {
			result = false;
			Report.fail("First Mis-matched field : <b>" + e.getLocalizedMessage() + "</b>");
			log.info("First Mis-matched field : <b>" + e.getLocalizedMessage() + "</b>");
		} catch (JSONException e) {
			result = false;
			Report.fail("Response Validation failed due to Exception : " + e.getMessage());
			log.info("Response Validation failed due to Exception : " + e.getMessage());
			throw e;
		}
		return result;
	}

	protected void triggerRBODumpValidation(String excelSheetPath, String keyName) throws Exception {

		if (System.getProperty("VALIDATE_DUMP") != null) {
			boolean validateRODumpFlag = Boolean.parseBoolean(System.getProperty("VALIDATE_DUMP"));
			if (validateRODumpFlag) {
				Report.info("<b><u>###      RBO Dump File Validation Starts     ###</u></b>");
				String dumpFilePathAsUrl = null;
				RBODumpProcessor rboDumpObj = new RBODumpProcessor();
				try {
					if (System.getProperty("RBO_DUMP_PATH") != null && !System.getProperty("RBO_DUMP_PATH").equals("")) {
						dumpFilePathAsUrl = System.getProperty("RBO_DUMP_PATH");
						boolean result = rboDumpObj.validateRBODump(excelSheetPath, dumpFilePathAsUrl, keyName);
						if(result)
							Report.pass("<b>RBO_DUMP Validation passed. All Variable values Matched.</b>");
						else
							Report.fail("<b>RBO_DUMP Validation failed. RBO Variable values does not match with expected valued.</b>");
					}
				} catch (Exception e) {
					Report.fail("RBO DUMP Validation failed due to reason : " + e.getMessage());
					throw e;
				}
			} else {
				Report.info("<b>RBO DUMP File validation skipped.</b>");
			}
		}

	}

	@AfterSuite(alwaysRun = true)
	public void afterSuite(ITestContext ctx) {
		System.out.println("------------------->Suite execution Ends");
		String suiteName = ctx.getCurrentXmlTest().getSuite().getName();
		Report.reduceHTMLReportSize(reportFileName, suiteName);
		Report.suiteEnds();
	}

	@BeforeTest(alwaysRun = true)
	public void beforeTest(ITestContext ctx) {
		System.out.println("------------->Test execution starts");
		String testcaseName = ctx.getName();
		Report.startTestCase(testcaseName, "");
		log.info("Report Model : " + reportModel + " | Count : " + reportModel.getTotalCase());
		reportModel.addCaseCount();
	}

	@AfterTest(alwaysRun = true)
	public void afterTest(ITestContext ctx) throws Exception {
		System.out.println("------------->Test execution ends");
		Report.endTestCase();

//		log.info("Suite Current stauts - Count : '" + reportModel.getTotalCase() + "' PASSED : " + reportModel.getCasePassed() + "' FAILED : " + reportModel.getCaseFailed());
//		JenkinsHtmlReport reportObj = new JenkinsHtmlReport();
//		reportObj.createJenkinsReport(reportModel.getSuiteName(), reportModel.getTotalCase(), reportModel.getTotalData(), reportModel.getCasePassed(), reportModel.getCaseFailed(), reportModel.getCaseError());

		File file = new File("./test-output/ExtentReports/" + reportFileName);
		double reportFileSizeInBytes = file.length();
		double reportFileSizeInKB = (reportFileSizeInBytes / 1024);
		int fileSize = (int) reportFileSizeInKB;
		log.info("FileSize in KB : " + fileSize);
	}

	public Map<String, String> preconditionDataPrep(String excelPath, Map<String, String> testDataFromTestMethod, String hostname) throws Exception {
		Map<String, String> testData = new HashMap<>();
		Report.info("Executing Pre-Condition Data");

		try {
			// Get the Data from Precondition sheet
			String keyName = testDataFromTestMethod.get("key");
			testData = ExcelUtils.getRowAsMapUsingKey(excelPath, preconditionSheetName, keyName);
			if (testData.size() == 0) {
				Report.warn("No Testdata Row found in Precondition for the Key - '" + keyName + "'");
				return testData;
			}

			if (testData.get("createBuyer") != null) {
				if (testData.get("createBuyer").equalsIgnoreCase("Y")) {
					Report.info("<b>Creating User as Buyer if not Exist</b>");
					// Buyer Creation:
					BuyerCreation buyer = new BuyerCreation();
					testData = buyer.createbuyerIfNotExist(testData, hostname);
				} else {
					Report.info("Create Buyer set to No. Skipping buyer creation");
				}
			}

			if (testData.get("createSeller") != null) {
				if (testData.get("createSeller").equalsIgnoreCase("Y")) {
					Report.info("<b>Creating User as Seller if not Exist</b>");
					// Seller Creation
					SellerCreation seller = new SellerCreation();
					testData = seller.createSellerIfNotExist(testData, hostname);
				} else {
					Report.info("Create Seller set to No. Skipping buyer creation");
				}
			}

			if (testData.get("performTrn") != null) {
				if (testData.get("performTrn").equalsIgnoreCase("Y")) {
					Report.info("<b>Adding Money and Performing Transaction between Buyer and Seller</b>");
					// Perform Transaction
					PerformSendMoney sendMoney = new PerformSendMoney();
					testData = sendMoney.performTransaction(testData, hostname);
				} else {
					Report.info("Create Seller set to No. Skipping buyer creation");
				}
			}

		} catch (Exception e) {
			Report.error("Exception occured in : " + e);
			e.printStackTrace();
		}

		return testData;
	}

}
