package com.paypal.risk.resolution.checkpoints;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.paypal.risk.resolution.constants.RUDSConstants;
import com.paypal.risk.resolution.model.ResponseEntity;
import com.paypal.risk.resolution.report.Report;
import com.paypal.risk.resolution.utils.ExcelUtils;
import com.paypal.risk.resolution.utils.HttpRestClient;

public class IssueInitiationUnAuth extends RUDSBaseTest {

	final static Logger log = Logger.getLogger(IssueInitiationUnAuth.class);
	Map<String, String> headerMap = new HashMap<String, String>();
	String checkpointName = RUDSConstants.ATO_UNAUTH_CP;
	String excelPath = rudsDataExcelPath + checkpointName + ".xlsx";
	String schemaPath = rudsDataScehmaPath + checkpointName + ".json";
	String sheetName = checkpointName;

	@DataProvider(name = "dataProvider")
	public Object[][] testDataProvider() throws Exception {
		Object[][] testData = ExcelUtils.getTableArrayAsMap(excelPath, sheetName);
		return testData;
	}

	@Test(dataProvider = "dataProvider")
	public void test(Map<String, String> testData) throws Exception {
		HttpRestClient client = new HttpRestClient();
		String actualResponse = null;
		Map<String, String> preconditionData = new HashMap<>();
		Report.startComponent(testData.get("key"), testData.get("testcaseName"));

		try {

			// Pre-Condition Test Data Preparation (Create Buyer and Seller and perform transaction):
			if (testData.get("preconditionFlag").equalsIgnoreCase("Y")) {
				preconditionData = preconditionDataPrep(excelPath, testData, hostname);
				Report.info("<b><u>Issue Initiation UNAUTH Testcase validation starts...</b></u>");
			}

			// Setup URL
			String restUrl = rudsProtocal + hostname + ":" + port + "/" + RUDSConstants.ATO_UNAUTH_URI;
			Report.info("<b>Rest URL =  <u>" + restUrl + "</b></u>");

			// Setup Headers
			Map<String, String> headerMap = setupHeader(testData.get("header"), preconditionData);
			Report.info("<b>Request Headers = </b> " + headerMap);

			// Setup Request [Column Name - request in Testdata sheet]
			String request = buildRequestJsonWithData(testData, preconditionData);
			Report.info("<b>Request Payload = </b>" + request);

			// Trigger API Request
			ResponseEntity responseEntity = client.doGenericPost(restUrl, headerMap, request);

			// Validation of Response
			if (responseEntity.getStatusCode() == 200) {

				if (responseEntity.getResponse() != null) {
					actualResponse = responseEntity.getResponse().toString();
					if (actualResponse.equalsIgnoreCase("")) {
						Report.fail("<b>API Response received Empty! Skipping response validation. </b> Check the Request details");
					} else {
						Report.pass("<b>API Response received = </b>" + actualResponse);
						validateResponseFields(actualResponse, testData);
					}
				}

			} else {
				String failureMessage = "<b>API Response code validation failed. Response Code = " + responseEntity.getStatusCode() + "</b>";
				Report.fail(failureMessage);
				throw new Exception(failureMessage);
			}

		} catch (Exception e) {
			Report.fail("Testcase failed due to reason : " + e);
			throw e;
		} finally {
			Report.appendComponent();
		}

	}

	@SuppressWarnings("unchecked")
	private String buildRequestJsonWithData(Map<String, String> testData, Map<String, String> preconditionData) throws Exception {
		JSONObject request = null;
		try {
			FileReader reader = new FileReader(schemaPath);

			JSONParser jsonParser = new JSONParser();
			request = (JSONObject) jsonParser.parse(reader);

			request.put("id", testData.get("id"));
			request.put("type", testData.get("type"));
			request.put("creation_time", testData.get("creation_time"));
			request.put("creation_channel", testData.get("creation_channel"));
			request.put("wait_retry_count", testData.get("wait_retry_count"));
			request.put("session_id", testData.get("session_id"));
			request.put("fraudnet_identifier", testData.get("fraudnet_identifier"));

			if (preconditionData.get("sellerOutputAccountNumber") != null)
				request.put("sender_account_number", preconditionData.get("sellerOutputAccountNumber"));
			else
				request.put("sender_account_number", testData.get("sender_account_number"));

			// customer_provided_data
			JSONObject customer_provided_data = (JSONObject) request.get("customer_provided_data");
			JSONObject buyer_note = (JSONObject) customer_provided_data.get("buyer_note");
			buyer_note.put("note", testData.get("buyer_note.note"));

			// adjudication_decisions
			JSONArray buyer_reported_transactions = (JSONArray) request.get("buyer_reported_transactions");
			JSONObject buyer_reported_transaction = (JSONObject) buyer_reported_transactions.get(0);
			buyer_reported_transaction.put("buyer_transaction_id", testData.get("buyer_transaction_id"));
			buyer_reported_transaction.put("billing_agreement_id", testData.get("billing_agreement_id"));

			JSONArray buyer_reported_activities = (JSONArray) request.get("buyer_reported_activities");
			buyer_reported_activities.add(0, testData.get("buyer_reported_activities"));

		} catch (NullPointerException e) {
			Report.fail("<b>Issue Initiation UnAuth request build failed due to either Missing field in response or Testdata not available</b>");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			Report.error("Issue Initiation UnAuth JSON request building failed. Reason : " + e.getMessage());
			throw e;
		}

		return request.toString();
	}

	private boolean validateResponseFields(String responseObject, Map<String, String> rowDataMap) throws Exception {
		boolean result = true;
		List<Boolean> resultArr = new ArrayList<Boolean>();
		JSONObject responseJson = null;

		try {

			JSONParser jsonParser = new JSONParser();
			responseJson = (JSONObject) jsonParser.parse(responseObject);

			JSONObject decision = (JSONObject) responseJson.get("decision");
			resultArr.add(Report.assertEquals("code", decision.get("code").toString(), rowDataMap.get("res.decision.code")));

			if (!rowDataMap.get("res.decision.reason").equals("")) {
				resultArr.add(Report.assertEquals("reason", decision.get("reason").toString(), rowDataMap.get("res.decision.reason")));
			}

			if (!rowDataMap.get("transactions_decisions.buyer_transaction_id").equals("")) {
				JSONArray transactions_decisions = (JSONArray) responseJson.get("transactions_decisions");
				JSONObject transactions_decision = (JSONObject) transactions_decisions.get(0);
				resultArr.add(Report.assertEquals("transactions_decisions>buyer_transaction_id", transactions_decision.get("buyer_transaction_id").toString(), rowDataMap.get("transactions_decisions.buyer_transaction_id")));
				resultArr.add(Report.assertEquals("transactions_decisions>code", transactions_decision.get("code").toString(), rowDataMap.get("transactions_decisions.code")));
				resultArr.add(Report.assertEquals("transactions_decisions>reason", transactions_decision.get("reason").toString(), rowDataMap.get("transactions_decisions.reason")));
			}

			if (resultArr.contains(false)) {
				result = false;
				Report.fail("Response fields validation failed.");
			} else {
				Report.pass("Response fields validation passed.");
			}

		} catch (NullPointerException | IndexOutOfBoundsException e) {
			Report.fail("<b>Issue Initiation UnAuth request build failed due to either Missing field in response or Testdata not available</b>");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			Report.error("Issue Initiation UnAuth response field validation failed. Reason : " + e.getMessage());
			e.printStackTrace();
			throw e;
		}

		return result;
	}

}
