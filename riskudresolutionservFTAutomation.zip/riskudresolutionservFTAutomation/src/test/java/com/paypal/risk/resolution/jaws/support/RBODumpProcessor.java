package com.paypal.risk.resolution.jaws.support;

import java.io.StringReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.jsoup.Jsoup;
import org.jsoup.select.Elements;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import com.paypal.risk.resolution.constants.RUDSConstants;
import com.paypal.risk.resolution.report.Report;
import com.paypal.risk.resolution.utils.ExcelUtils;
import com.paypal.risk.resolution.utils.FileUtil;
import com.paypal.risk.resolution.utils.HttpRestClient;
import com.paypal.risk.resolution.utils.PropertyUtil;

public class RBODumpProcessor {
	final static Logger log = Logger.getLogger(RBODumpProcessor.class);
	Map<String, String> matchedVariables = new HashMap<>();
	Map<String, String> misMatchedVariables = new HashMap<>();

	public boolean validateRBODump(String excelSheetPath, String filePathAsUrl, String keyName) throws Exception {
		boolean result = true;
		String dumpHtmlPage = null;
		String latestDumpFilename = null;
		String latestDumpFileContent = null;
		String normalizedDumpFileContent = null;

		try {

			List<Map<String, String>> rboDumpExecutionDetail = ExcelUtils.getTableAsListOfMaps(excelSheetPath, RUDSConstants.RBO_DUMP_VALIDATOR_SHEET_NAME);

			if (rboDumpExecutionDetail.size() > 0) {

				// Do a GET HTTP Call with HTML URL Link which as all the RBO DUMP File Details
				dumpHtmlPage = getRBODumpListHtmlPageAsString(filePathAsUrl);

				// Pare the HTML file and get the latest dump file name
				latestDumpFilename = parseHTMLFileForLatestDumpName(dumpHtmlPage);

				// HTTP GET Call with latest dump file name and save the response as string
				latestDumpFileContent = getRBODumpXMLAsString(filePathAsUrl, latestDumpFilename);

				// Normalize the XML
				normalizedDumpFileContent = normalizeRawDumpXML(latestDumpFileContent);

				// Initialize the XML to parse for each RBOs
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document document = dBuilder.parse(new InputSource(new StringReader(normalizedDumpFileContent)));
				document.getDocumentElement().normalize();

				for (Map<String, String> eachRBORow : rboDumpExecutionDetail) {
					if (eachRBORow.get("ValidateFlag").equalsIgnoreCase("Y") || eachRBORow.get("ValidateFlag").equalsIgnoreCase("Yes")) {
						String rboTagName = eachRBORow.get("TagName");
						String rboAttrName = eachRBORow.get("RBOName");
						String rboOrder = eachRBORow.get("Order");
						String rboSheetName = eachRBORow.get("SheetName");
						Report.info("<u><b>Validating RBO = [ " + rboTagName + " - " + rboAttrName + " ] </b></u>");

						if (rboTagName.equalsIgnoreCase("NECompassDisputeCaseInfoSetRBOImpl")) {

							// NECompassDisputeCaseInfoSetRBOImpl > compasscase
							NECompassDisputeCaseInfoSetRBOImpl(document, excelSheetPath, rboSheetName, keyName, Integer.parseInt(rboOrder), rboAttrName);

						} else if (rboTagName.equalsIgnoreCase("NETransactionRBOImpl")) {

							// NETransactionRBOImpl > transaction.rbo.NETransactionRBO
							NETransactionRBOImpl(document, excelSheetPath, rboSheetName, keyName, Integer.parseInt(rboOrder), rboAttrName);

						} else if (rboTagName.equalsIgnoreCase("NETopTransactionRBOImpl")) {

							// NETopTransactionRBOImpl > transaction
							NETopTransactionRBOImpl(document, excelSheetPath, rboSheetName, keyName, Integer.parseInt(rboOrder), rboAttrName);

						}

						// Print the Values in Report
						if (PropertyUtil.getConfigValueOf("ruds.rbodump.print.passed.variable").equalsIgnoreCase("true"))
							for (Map.Entry<String, String> kvPair : matchedVariables.entrySet())
								Report.pass("Variable <b>[" + kvPair.getKey() + "]</b> with value <b>[" + kvPair.getValue() + "]</b> matched.");

						for (Map.Entry<String, String> kvPair : misMatchedVariables.entrySet())
							Report.fail("Variable <b>[" + kvPair.getKey() + "]</b>' value not matched. <b>" + kvPair.getValue() + "</b>.");

						if (result)
							if (misMatchedVariables.size() > 0)
								result = false;
					}
				}

			} else {
				Report.fail("No RBO Rows found in the sheet to execute.");
				return false;
			}

		} catch (Exception e) {
			Report.fail("RBO DUMP Validation failed due to reason : " + e);
			throw e;
		}
		return result;
	}

	private String getRBODumpListHtmlPageAsString(String filePathAsUrl) throws Exception {
		String response = null;
		try {
			// Report.info("<b>Check User if Exist in JAWS</b>");

			// Create a HTTPClient to make a rest call
			HttpRestClient client = new HttpRestClient();

			// Get the URL based on JOB or Default stage configured in Config Prop
			String restUrl = filePathAsUrl;
			Report.info("<b>Given RBO DUMP Folder URL Path = </b><u>" + restUrl + "</u>");

			// Setup Headers
			Map<String, String> headerMap = setupHeadersForRequest();
			// Report.info("<b>RBO DUMP Request Headers = </b>" + headerMap);

			// Make a HTTP post call to the service with the request and header
			Object responseAsObject;
			responseAsObject = client.doGenericGet(restUrl, headerMap);

			if (responseAsObject != null) {
				response = responseAsObject.toString();
				Report.pass("<b>RBO DUMP List received successfully from given URL.</b>");
			} else {
				Report.fail("<b>RBO DUMP List details received as NULL from given URL. Check the Request details </b>");
			}

		} catch (Exception e) {
			Report.fail(this.getClass().getSimpleName() + " RestService Call Failed due to Exception : " + e);
			e.printStackTrace();
		}
		return response;
	}

	private String getRBODumpXMLAsString(String filePathAsUrl, String latestDumpFilename) throws Exception {
		String response = null;
		try {
			// Report.info("<b>Check User if Exist in JAWS</b>");

			// Create a HTTPClient to make a rest call
			HttpRestClient client = new HttpRestClient();

			// Get the URL based on JOB or Default stage configured in Config Prop
			String restUrl = filePathAsUrl + "&fileName=" + latestDumpFilename;
			Report.info("<b>Fetching Latest RBO DUMP File with URL Path = </b><u>" + restUrl + "</u>");

			// Setup Headers
			// Map<String, String> headerMap = setupHeadersForRequest();
			Map<String, String> headerMap = new HashMap<>();
			// Report.info("<b>RBO DUMP Request Headers = </b>" + headerMap);

			// Make a HTTP post call to the service with the request and header
			Object responseAsObject;
			responseAsObject = client.doGenericGet(restUrl, headerMap);

			if (responseAsObject != null) {
				response = responseAsObject.toString();
				Report.pass("<b>RBO DUMP Content of file '" + latestDumpFilename + "' received successfully.</b>");
			} else {
				Report.fail("<b>RBO DUMP Content of file '" + latestDumpFilename + "' received as NULL. Check the Request details </b>");
			}

		} catch (Exception e) {
			Report.fail(this.getClass().getSimpleName() + " Rest Service to fetch RBO Dump file content failed due to Exception : " + e);
			e.printStackTrace();
		}
		return response;
	}

	private Map<String, String> setupHeadersForRequest() throws Exception {
		Map<String, String> headerMap = new HashMap<String, String>();
		try {
			headerMap.put("Content-Type", "application/xml");
		} catch (Exception e) {
			Report.error(this.getClass().getSimpleName() + " Request Header Building - Failed due to exception : " + e);
			e.printStackTrace();
			throw e;
		}

		return headerMap;
	}

	private String parseHTMLFileForLatestDumpName(String htmlFile) {
		// Report.info("<em>Fetching Latest RBO DUMP File from the List</em>");
		String fileName = null;
		try {
			// String HTMLSTring = readAllBytesJava7(filePath);
			String HTMLSTring = htmlFile;
			org.jsoup.nodes.Document html = Jsoup.parse(HTMLSTring);
			org.jsoup.nodes.Element TBody = html.body().getElementsByTag("TBody").first();
			Map<Date, String> rboDumpMapWithTimeAndFilename = new HashMap<>();
			List<Date> rboDumpTimestampList = new ArrayList<Date>();
			DateFormat dateFormatter = new SimpleDateFormat("E MMM dd HH:mm:ss yyyy");

			int fileCount = 0;
			Elements allRows = TBody.getElementsByTag("tr");
			for (org.jsoup.nodes.Element eachRow : allRows) {
				String dumpTmstmp = eachRow.getElementsByTag("td").get(2).text();
				String dumpFileName = eachRow.getElementsByTag("td").get(1).getElementsByTag("a").first().text();
				if (dumpFileName.contains("RBO_DUMP")) {
					// log.info("No. " + fileCount + " | Time : " + dumpFileName + " | FileName : "
					// + dumpFileName);
					Date formattedTime = dateFormatter.parse(dumpTmstmp);
					rboDumpTimestampList.add(formattedTime);
					rboDumpMapWithTimeAndFilename.put(formattedTime, dumpFileName);
					fileCount++;
				} else {
					// log.info("Not a RBO_DUMP file");
				}
			}

			Report.info("<em>Total No. of RBO Dump Files found : " + fileCount + "</em>");
			Collections.sort(rboDumpTimestampList);
			Date timeOfLastFile = rboDumpTimestampList.get(rboDumpTimestampList.size() - 1);
			fileName = rboDumpMapWithTimeAndFilename.get(timeOfLastFile);
			Report.info("Latest RBO_DUMP file name is '<b>" + fileName + "</b>' with Timestamp as <b>[" + timeOfLastFile.toString() + "]</b>");
		} catch (Exception e) {
			Report.fail("Fetching Latest RBO Dump name failed due to reason : " + e);
			e.printStackTrace();
		}
		return fileName;
	}

	private String normalizeRawDumpXML(String dumpXmlFileAsString) {

		String normalizedXml = null;
		try {
			normalizedXml = "<root>" + dumpXmlFileAsString.replaceAll("&lt;", "<");
			normalizedXml = normalizedXml.replaceAll("< ", "<");
			normalizedXml = normalizedXml.replaceAll("&gt;", ">");
			normalizedXml = normalizedXml.replaceAll(" >", ">");
			normalizedXml = normalizedXml.replaceAll("<br>", "");
			normalizedXml = normalizedXml + "</root>";
			Report.pass("Normalizing RBO_DUMP XML file success.");
			// log.info("nomrlaized XML is : " + normalizedXml);
		} catch (Exception e) {
			Report.fail("Normalizing RBO DUMP failed due to reason : " + e);
			e.printStackTrace();
		}
		return normalizedXml;
	}

	private boolean NECompassDisputeCaseInfoSetRBOImpl(Document doc, String excelSheetPath, String sheetName, String KeyName, Integer order, String rboName) {
		boolean result = true;
		matchedVariables.clear();
		misMatchedVariables.clear();
		try {
			Map<String, String> rboTestdata = ExcelUtils.getRowAsMapUsingKey(excelSheetPath, sheetName, KeyName);
			NodeList rboRootNodeList = doc.getElementsByTagName("NECompassDisputeCaseInfoSetRBOImpl");
			boolean isRboFound = false;
			Node nNode = null;
			int index = 0;
			for (int temp = 0; temp < rboRootNodeList.getLength(); temp++) {
				nNode = rboRootNodeList.item(temp);
				Element eElement = (Element) nNode;
				if (eElement.getAttribute("rboName").equals(rboName)) {
					isRboFound = true;
					break;
				}
				index++;
			}

			if (isRboFound) {
				Report.pass("Given Tag <b>'NECompassDisputeCaseInfoSetRBOImpl' with RBO Name '" + rboName + "'</b> is found in RBO DUMP XML.");
				Node rootRbonode = doc.getElementsByTagName("NECompassDisputeCaseInfoSetRBOImpl").item(index);
				Element rootRboElement = (Element) rootRbonode;

				compareNodeValue(rootRboElement, "getCompassDisputeCaseList", rboTestdata);
				compareNodeValue(rootRboElement, "getPlanId", rboTestdata);

				Node getCurrentCompassDisputeCase = rootRboElement.getElementsByTagName("getCurrentCompassDisputeCase").item(0);
				Element element = (Element) getCurrentCompassDisputeCase;

				compareNodeValue(element, "getEntity", rboTestdata);
				compareNodeValue(element, "getTrackingId", rboTestdata);
				compareNodeValue(element, "getPPHInvoiceType", rboTestdata);
				compareNodeValue(element, "getIsValidHardship", rboTestdata);
				compareNodeValue(element, "getSellerResponseDate", rboTestdata);
				compareNodeValue(element, "getBuyerResponseDate", rboTestdata);
				compareNodeValue(element, "getBuyerResponseMethod", rboTestdata);
				compareNodeValue(element, "getDocumentProcessStatus", rboTestdata);
				compareNodeValue(element, "getBuyerResponseHasAttachments", rboTestdata);
				compareNodeValue(element, "getHasBuyerResponded", rboTestdata);
				compareNodeValue(element, "isBuyerNotesPresent", rboTestdata);
				compareNodeValue(element, "getNoSellerResponseCount", rboTestdata);
				compareNodeValue(element, "getUnAuthCaseInfo", rboTestdata);
				compareNodeValue(element, "getAdjudicationMode", rboTestdata);
				compareNodeValue(element, "getWaitForRiskDecisionReason", rboTestdata);
				compareNodeValue(element, "isTeamMateProvidedInfo", rboTestdata);
				compareNodeValue(element, "getNoFaultCountBuyer", rboTestdata);
				compareNodeValue(element, "getNoFaultCountSeller", rboTestdata);
				compareNodeValue(element, "getBuyerAppealedCount", rboTestdata);
				compareNodeValue(element, "getSellerAppealedCount", rboTestdata);
				compareNodeValue(element, "isExternalAppealExists", rboTestdata);
				compareNodeValue(element, "getCaseState", rboTestdata);
				compareNodeValue(element, "getDisputeState", rboTestdata);
				compareNodeValue(element, "getDisputedUSDAmount", rboTestdata);
				compareNodeValue(element, "getRefundAmount", rboTestdata);
				compareNodeValue(element, "getPreviousStageDetails", rboTestdata);
				compareNodeValue(element, "getHasMerchantResponded", rboTestdata);
				compareNodeValue(element, "isMerchantNotesPresent", rboTestdata);
				compareNodeValue(element, "getAdjudicationOutcome", rboTestdata);
				compareNodeValue(element, "getAdjudicationOutcomeReason", rboTestdata);
				compareNodeValue(element, "getSellerResponseMethod", rboTestdata);
				compareNodeValue(element, "getOriginalSellerResponseMethod", rboTestdata);
				compareNodeValue(element, "getAdjudicationIntent", rboTestdata);
				compareNodeValue(element, "getResponseIntent", rboTestdata);
				compareNodeValue(element, "getEscalationParty", rboTestdata);
				compareNodeValue(element, "getCaseCreationTime", rboTestdata);
				compareNodeValue(element, "getCaseClosureTime", rboTestdata);
				compareNodeValue(element, "getSenderDecryptedTransactionId", rboTestdata);
				compareNodeValue(element, "hasEbayShadowCase", rboTestdata);
				compareNodeValue(element, "isTrackingInfoAvailable", rboTestdata);
				compareNodeValue(element, "getCBNumerOfCredits", rboTestdata);
				compareNodeValue(element, "getCBNumerOfDebits", rboTestdata);
				compareNodeValue(element, "getCBProcessor", rboTestdata);
				compareNodeValue(element, "getCBSubProcessor", rboTestdata);
				compareNodeValue(element, "getCBOriginalReasonCode", rboTestdata);
				compareNodeValue(element, "getCBCurrentReasonCode", rboTestdata);
				compareNodeValue(element, "getCCType", rboTestdata);
				compareNodeValue(element, "isCreditedByProcessor", rboTestdata);
				compareNodeValue(element, "isSecondChargeback", rboTestdata);
				compareNodeValue(element, "getCaseCreationTimeInProcessorFile", rboTestdata);
				compareNodeValue(element, "getPreviousCaseAdjudicationOutcome", rboTestdata);
				compareNodeValue(element, "getPartnerCaseAdjudicationOutcome", rboTestdata);
				compareNodeValue(element, "isDJEligible", rboTestdata);
				compareNodeValue(element, "getDisputeSource", rboTestdata);
				compareNodeValue(element, "getTrackingProofBy", rboTestdata);
				compareNodeValue(element, "getDisputeCategory", rboTestdata);
				compareNodeValue(element, "getDisputeSubType", rboTestdata);
				compareNodeValue(element, "getBuyerTempPayoutInfo", rboTestdata);
				compareNodeValue(element, "getRetryCount", rboTestdata);
				compareNodeValue(element, "isRefundedToSameFI", rboTestdata);
				compareNodeValue(element, "getTransactionId", rboTestdata);
				compareNodeValue(element, "getCaseId", rboTestdata);
				compareNodeValue(element, "getDisputeReason", rboTestdata);
				compareNodeValue(element, "getNoFaultBuyerPayoutCount", rboTestdata);
				compareNodeValue(element, "getDisputeStage", rboTestdata);
				compareNodeValue(element, "getDuplicateTransactionId", rboTestdata);
				compareNodeValue(element, "getRegulationName", rboTestdata);
				compareNodeValue(element, "getSellerProtectionCriteria", rboTestdata);
				compareNodeValue(element, "getEscalationTime", rboTestdata);

				// getDisputedAmount Node
				Node getDisputedAmount = element.getElementsByTagName("getDisputedAmount").item(0);
				Element subElement = (Element) getDisputedAmount;

				compareNodeValue(subElement, "has_negative_balance", rboTestdata);
				compareNodeValue(subElement, "amount_in_cents_raw", rboTestdata);
				compareNodeValue(subElement, "usd_amount_in_cents", rboTestdata);
				compareNodeValue(subElement, "getUsdAmount", rboTestdata);
				compareNodeValue(subElement, "getCurrencyCode", rboTestdata);

				// Continue with parent node
				compareNodeValue(element, "getTeammateNotes", rboTestdata);
				compareNodeValue(element, "getSellerNotes", rboTestdata);
				compareNodeValue(element, "getBuyerNotes", rboTestdata);
				compareNodeValue(element, "getBuyerAdjudicationOutcome", rboTestdata);
				compareNodeValue(element, "getBuyerAdjudicationOutcomeReason", rboTestdata);
				compareNodeValue(element, "getSellerAdjudicationOutcome", rboTestdata);
				compareNodeValue(element, "getSellerAdjudicationOutcomeReason", rboTestdata);
				compareNodeValue(element, "getOfferAmount", rboTestdata);
				compareNodeValue(element, "getHasAttachments", rboTestdata);
				compareNodeValue(element, "getDisputeType", rboTestdata);
				compareNodeValue(element, "getPotentialDupTxnsCount", rboTestdata);
				compareNodeValue(element, "getPotentialRefundedReversedTxnsCount", rboTestdata);
				compareNodeValue(element, "getBuyerAccountNumber", rboTestdata);
				compareNodeValue(element, "getSellerAccountNumber", rboTestdata);
				compareNodeValue(element, "isChargebackMoneyMovement", rboTestdata);
				compareNodeValue(element, "isDisputeCategory", rboTestdata);
				compareNodeValue(element, "isDisputeState", rboTestdata);
				compareNodeValue(element, "isDisputeStage", rboTestdata);
				compareNodeValue(element, "isDisputeSubReason", rboTestdata);
				compareNodeValue(element, "isDisputeSubType", rboTestdata);
				compareNodeValue(element, "isFirstCBStatusCode", rboTestdata);
				compareNodeValue(element, "isSellerProtectionCriteria", rboTestdata);
				compareNodeValue(element, "isShippingAddrMatchesDestinationAddr", rboTestdata);
				compareNodeValue(element, "isShippingAddrMatchesDeliveryAddr", rboTestdata);
				compareNodeValue(element, "isTrackingStatus", rboTestdata);
				compareNodeValue(element, "isSellerRecoveredStatus", rboTestdata);
				compareNodeValue(element, "isRegulationName", rboTestdata);
				compareNodeValue(element, "isDisputeReason", rboTestdata);
				compareNodeValue(element, "isSellerResponseMethod", rboTestdata);
				compareNodeValue(element, "isBuyerRefundedStatus", rboTestdata);
				compareNodeValue(element, "isAssociatedTransaction", rboTestdata);
				compareNodeValue(element, "isReasonSwitchedFrom", rboTestdata);
			} else {
				Report.fail("<b>Given Tag 'NECompassDisputeCaseInfoSetRBOImpl' with RBO Name '" + rboName + "' is not found in RBO DUMP XML.</b>");
				result = false;
			}

		} catch (NullPointerException e) {
			Report.info("One of the Node is not found either in XML or in the Excel Data");
			result = false;
			e.printStackTrace();
		} catch (Exception e) {
			Report.info("NECompassDisputeCaseInfoSetRBOImpl RBO Validation failed due to reason : " + e);
			result = false;
			e.printStackTrace();
		}

		return result;
	}

	private boolean NETransactionRBOImpl(Document doc, String excelSheetPath, String sheetName, String KeyName, Integer order, String rboName) {
		boolean result = true;
		matchedVariables.clear();
		misMatchedVariables.clear();
		try {
			Map<String, String> rboTestdata = ExcelUtils.getRowAsMapUsingKey(excelSheetPath, sheetName, KeyName);
			NodeList rboRootNodeList = doc.getElementsByTagName("NETransactionRBOImpl");
			boolean isRboFound = false;
			Node nNode = null;
			int index = 0;
			for (int temp = 0; temp < rboRootNodeList.getLength(); temp++) {
				nNode = rboRootNodeList.item(temp);
				Element eElement = (Element) nNode;
				if (eElement.getAttribute("rboName").equals(rboName)) {
					isRboFound = true;
					break;
				}
				index++;
			}

			if (isRboFound) {
				Report.pass("Given Tag <b>'NETransactionRBOImpl' with RBO Name '" + rboName + "'</b> is found in RBO DUMP XML.");

				// Root Node -> <NETransactionRBOImpl>
				Node rootRbonode = doc.getElementsByTagName("NETransactionRBOImpl").item(index);
				Element rootRboElement = (Element) rootRbonode;

				compareNodeValue(rootRboElement, "getFlags", rboTestdata);
				compareNodeValue(rootRboElement, "getTransferType", rboTestdata);
				compareNodeValue(rootRboElement, "getSubType", rboTestdata);
				compareNodeValue(rootRboElement, "getPartnerAccountNumber", rboTestdata);
				compareNodeValue(rootRboElement, "getIncentiveUSDAmount", rboTestdata);
				compareNodeValue(rootRboElement, "getFundType", rboTestdata);
				compareNodeValue(rootRboElement, "isPayPalMeFlow", rboTestdata);
				compareNodeValue(rootRboElement, "isOrderTransaction", rboTestdata);
				compareNodeValue(rootRboElement, "isOfflineTransaction", rboTestdata);
				compareNodeValue(rootRboElement, "isTokenizedTransaction", rboTestdata);
				compareNodeValue(rootRboElement, "isRTRTransaction", rboTestdata);
				compareNodeValue(rootRboElement, "getSellerProtectionEligibility", rboTestdata);
				compareNodeValue(rootRboElement, "getTenantTransactionStatus", rboTestdata);
				compareNodeValue(rootRboElement, "getTenantTransactionType", rboTestdata);
				compareNodeValue(rootRboElement, "getTenantActivityType", rboTestdata);

				// Node -> <getFundingBank>
				Node getFundingBank = rootRboElement.getElementsByTagName("getFundingBank").item(0);
				Element fundingBankElement = (Element) getFundingBank;

				compareNodeValue(fundingBankElement, "getRouting", rboTestdata.get("gfb.getRouting"));
				compareNodeValue(fundingBankElement, "getBankListByBankAccountNumber", rboTestdata.get("gfb.getBankListByBankAccountNumber"));
				compareNodeValue(fundingBankElement, "getFlags", rboTestdata.get("gfb.getFlags"));
				compareNodeValue(fundingBankElement, "getVendorId", rboTestdata.get("gfb.getVendorId"));

				// Node -> <getAuditData>
				Node getAuditData = rootRboElement.getElementsByTagName("getAuditData").item(0);
				Element auditDataElement = (Element) getAuditData;

				compareNodeValue(auditDataElement, "isRaptorMigration", rboTestdata.get("gad.isRaptorMigration"));
				compareNodeValue(auditDataElement, "isTier1AuditMode", rboTestdata.get("gad.isTier1AuditMode"));

				// Node -> <getFundingCC>
				Node getFundingCC = rootRboElement.getElementsByTagName("getFundingCC").item(0);
				Element fundingCCElement = (Element) getFundingCC;

				compareNodeValue(fundingCCElement, "getSource", rboTestdata.get("gfcc.getSource"));
				compareNodeValue(fundingCCElement, "getFlags", rboTestdata.get("gfcc.getFlags"));
				compareNodeValue(fundingCCElement, "getCCLast4Str", rboTestdata.get("gfcc.getCCLast4Str"));
				compareNodeValue(fundingCCElement, "getAmountSentPrimaryCurrency", rboTestdata.get("gfcc.getAmountSentPrimaryCurrency"));

				// Node -> <getFundingCC> -> <getBillingAddress>
				Node getBillingAddressOfFundingCC = fundingCCElement.getElementsByTagName("getBillingAddress").item(0);
				Element fundingCCBillingAddrElement = (Element) getBillingAddressOfFundingCC;

				compareNodeValue(fundingCCBillingAddrElement, "getFlags", rboTestdata.get("gfcc.gba.getFlags"));
				compareNodeValue(fundingCCBillingAddrElement, "getStatus", rboTestdata.get("gfcc.gba.getStatus"));

			} else {
				Report.fail("<b>Given Tag 'NETransactionRBOImpl' with RBO Name '" + rboName + "' is not found in RBO DUMP XML.</b>");
				result = false;
			}

		} catch (NullPointerException e) {
			Report.info("One of the Node is not found either in XML or in the Excel Data");
			result = false;
			e.printStackTrace();
		} catch (Exception e) {
			Report.info("NETransactionRBOImpl RBO Validation failed due to reason : " + e);
			result = false;
			e.printStackTrace();
		}

		return result;
	}

	private boolean NETopTransactionRBOImpl(Document doc, String excelSheetPath, String sheetName, String KeyName, Integer order, String rboName) {
		boolean result = true;
		matchedVariables.clear();
		misMatchedVariables.clear();
		try {
			Map<String, String> rboTestdata = ExcelUtils.getRowAsMapUsingKey(excelSheetPath, sheetName, KeyName);
			NodeList rboRootNodeList = doc.getElementsByTagName("NETopTransactionRBOImpl");
			boolean isRboFound = false;
			Node nNode = null;
			int index = 0;
			for (int temp = 0; temp < rboRootNodeList.getLength(); temp++) {
				nNode = rboRootNodeList.item(temp);
				Element eElement = (Element) nNode;
				if (eElement.getAttribute("rboName").equals(rboName)) {
					isRboFound = true;
					break;
				}
				index++;
			}

			if (isRboFound) {
				Report.pass("Given Tag <b>'NETopTransactionRBOImpl' with RBO Name '" + rboName + "'</b> is found in RBO DUMP XML.");

				// Root Node -> <NETransactionRBOImpl>
				Node rootRbonode = doc.getElementsByTagName("NETopTransactionRBOImpl").item(index);
				Element rootRboElement = (Element) rootRbonode;

				compareNodeValue(rootRboElement, "getMerchantDetails", rboTestdata);
				compareNodeValue(rootRboElement, "getSenderParty", rboTestdata);
				compareNodeValue(rootRboElement, "getEbayData", rboTestdata);
				compareNodeValue(rootRboElement, "getMarketplaceData", rboTestdata);

				// Node -> <get_funding_info>
				Node get_funding_info = rootRboElement.getElementsByTagName("get_funding_info").item(0);
				Element get_funding_infoElement = (Element) get_funding_info;

				compareNodeValue(get_funding_infoElement, "getRiskFundingInVO", rboTestdata.get("gfi.getRiskFundingInVO"));
				compareNodeValue(get_funding_infoElement, "getOrder", rboTestdata.get("gfi.getOrder"));
				compareNodeValue(get_funding_infoElement, "getFlowCanHandleAuthflowDecision", rboTestdata.get("gfi.getFlowCanHandleAuthflowDecision"));
				compareNodeValue(get_funding_infoElement, "getTenantFundingType", rboTestdata.get("gfi.getTenantFundingType"));

				// Node -> <get_transaction>
				Node get_transaction = rootRboElement.getElementsByTagName("get_transaction").item(0);
				Element get_transactionElement = (Element) get_transaction;

				compareNodeValue(get_transactionElement, "getFlags", rboTestdata.get("gt.getFlags"));
				compareNodeValue(get_transactionElement, "getTransferType", rboTestdata.get("gt.getTransferType"));
				
				// Node -> <get_transaction> > <getFundingBank>
				Node getFundingBank = get_transactionElement.getElementsByTagName("getFundingBank").item(0);
				Element getFundingBankElement = (Element) getFundingBank;

				compareNodeValue(getFundingBankElement, "getRouting", rboTestdata.get("gt.gfb.getRouting"));
				compareNodeValue(getFundingBankElement, "getBankListByBankAccountNumber", rboTestdata.get("gt.gfb.getBankListByBankAccountNumber"));
				
				// Node -> <getShipmentInfoRBO>
				Node getShipmentInfoRBO = rootRboElement.getElementsByTagName("getShipmentInfoRBO").item(0);
				Element getShipmentInfoRBOElement = (Element) getShipmentInfoRBO;
				
				// Node -> <getShipmentInfoRBO> > <getTrackingInfo>
				Node getTrackingInfo = getShipmentInfoRBOElement.getElementsByTagName("getTrackingInfo").item(0);
				Element getTrackingInfoElement = (Element) getTrackingInfo;

				compareNodeValue(getTrackingInfoElement, "getServiceName", rboTestdata.get("gsi.gti.getServiceName"));
				compareNodeValue(getTrackingInfoElement, "isSuccess", rboTestdata.get("gsi.gti.isSuccess"));
				compareNodeValue(getTrackingInfoElement, "getTrackingStatus", rboTestdata.get("gsi.gti.getTrackingStatus"));

				// Node -> <getRiskPaymentAttributeRBO>
				Node getRiskPaymentAttributeRBO = rootRboElement.getElementsByTagName("getRiskPaymentAttributeRBO").item(0);
				Element getRiskPaymentAttributeRBOElement = (Element) getRiskPaymentAttributeRBO;

				compareNodeValue(getRiskPaymentAttributeRBOElement, "getExternalIntegrationPartnerType", rboTestdata.get("grpa.getExternalIntegrationPartnerType"));
				compareNodeValue(getRiskPaymentAttributeRBOElement, "getIntegrationChannelType", rboTestdata.get("grpa.getIntegrationChannelType"));
				compareNodeValue(getRiskPaymentAttributeRBOElement, "getIntegrationIdentifier", rboTestdata.get("grpa.getIntegrationIdentifier"));

			} else {
				Report.fail("<b>Given Tag 'NETransactionRBOImpl' with RBO Name '" + rboName + "' is not found in RBO DUMP XML.</b>");
				result = false;
			}

		} catch (NullPointerException e) {
			Report.info("One of the Node is not found either in XML or in the Excel Data");
			result = false;
			e.printStackTrace();
		} catch (Exception e) {
			Report.info("NETransactionRBOImpl RBO Validation failed due to reason : " + e);
			result = false;
			e.printStackTrace();
		}

		return result;
	}

	private void compareNodeValue(Element mainElement, String tagName, Map<String, String> testObjArray) {
		// Expect Value can have - Actual Result, ANY_NUMBER, NOT_NULL, NOT_EMPTY
		Node node = mainElement.getElementsByTagName(tagName).item(0);
		Element element = (Element) node;

		String actualValue = element.getTextContent();
		String expectedRawValue = testObjArray.get(tagName);
		String expectedValue = null;

		if (expectedRawValue.contains("#")) {

			String attribute = expectedRawValue.split("#")[0];
			expectedValue = expectedRawValue.split("#")[1];

			String expectedAttributeName = attribute.split("=")[0];
			String expectedAttributeValue = attribute.split("=")[1];
			String actualAttributeValue = element.getAttribute(expectedAttributeName);

			compareValue(element.getParentNode().getNodeName() + " -> " + tagName + " [Attribute : " + expectedAttributeName + "]", actualAttributeValue, expectedAttributeValue);

		} else {
			expectedValue = expectedRawValue;
			compareValue(element.getParentNode().getNodeName() + " -> " + tagName, actualValue, expectedValue);
		}
	}

	private void compareNodeValue(Element mainElement, String tagName, String expectedRawValue) {
		// Expect Value can have - Actual Result, ANY_NUMBER, NOT_NULL, NOT_EMPTY
		Node node = mainElement.getElementsByTagName(tagName).item(0);
		Element element = (Element) node;

		String actualValue = element.getTextContent();
		String expectedValue = null;

		if (expectedRawValue.contains("#")) {

			String attribute = expectedRawValue.split("#")[0];
			expectedValue = expectedRawValue.split("#")[1];

			String expectedAttributeName = attribute.split("=")[0];
			String expectedAttributeValue = attribute.split("=")[1];
			String actualAttributeValue = element.getAttribute(expectedAttributeName);

			compareValue(element.getParentNode().getNodeName() + " -> " + tagName + " [Attribute : " + expectedAttributeName + "]", actualAttributeValue, expectedAttributeValue);

		} else {
			expectedValue = expectedRawValue;
			compareValue(element.getParentNode().getNodeName() + " -> " + tagName, actualValue, expectedValue);
		}
	}

	private void compareValue(String nodeName, String actualValue, String expectedValue) {
		if (expectedValue.equals("ANY_NUMBER")) {
			try {
				Long.parseLong(actualValue);
				matchedVariables.put(nodeName, actualValue);
			} catch (java.lang.NumberFormatException e) {
				misMatchedVariables.put(nodeName, "Expected Any Number Value. Actual Value = [" + actualValue + "]");
			}
		} else if (expectedValue.equals("NOT_NULL")) {
			if (!actualValue.equalsIgnoreCase("null")) {
				matchedVariables.put(nodeName, actualValue);
			} else {
				misMatchedVariables.put(nodeName, "Expected Any Number Value. Actual Value = [" + actualValue + "]");
			}
		} else if (expectedValue.equals("NOT_EMPTY")) {
			if (!actualValue.equals("") && !actualValue.equalsIgnoreCase("null")) {
				matchedVariables.put(nodeName, actualValue);
			} else {
				misMatchedVariables.put(nodeName, "Expected Not Empty Value. Actual Value = [" + actualValue + "]");
			}
		} else {
			if (actualValue.equals(expectedValue)) {
				matchedVariables.put(nodeName, actualValue);
			} else {
				misMatchedVariables.put(nodeName, "Expected Value = [" + expectedValue + "] Actual Value = [" + actualValue + "]");
			}
		}
	}

	public static void main(String[] args) {
		// RBODumpProcessor obj = new RBODumpProcessor();
		try {
			String HTMLSTring = FileUtil.readAllBytesJava7("C:\\Users\\layyakannu\\Desktop\\Sample.txt");
//			Map<String, String> testObjArray = ExcelUtils.getRowAsMapUsingKey(
//					"C:\\Project\\RRDS\\ALL_WORKSPACES\\RUDS_FT_2\\riskudresolutionserv\\riskudresolutionservFTAutomation\\src\\test\\resources\\testdata\\checkpoint\\data\\DisputeEligibility.xlsx", "CompassDisputeCaseRBO", "Venmo RTED Validation");
			// System.out.println("testObjArray : " + testObjArray.toString());

			List<Map<String, String>> rboDumpExecutionDetail = ExcelUtils.getTableAsListOfMaps(
					"C:\\Project\\RRDS\\ALL_WORKSPACES\\RUDS_FT_2\\riskudresolutionserv\\riskudresolutionservFTAutomation\\src\\test\\resources\\testdata\\checkpoint\\data\\DisputeEligibility.xlsx", RUDSConstants.RBO_DUMP_VALIDATOR_SHEET_NAME);
			System.out.println("Excel Driver : " + rboDumpExecutionDetail);

			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(new InputSource(new StringReader(HTMLSTring)));
			doc.getDocumentElement().normalize();
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

			NodeList rboRootNodeList = doc.getElementsByTagName("NEAccountRBOImpl");

			boolean isRboFound = false;
			Node nNode = null;
			int index = 0;
			for (int temp = 0; temp < rboRootNodeList.getLength(); temp++) {
				nNode = rboRootNodeList.item(temp);
				Element eElement = (Element) nNode;
				if (eElement.getAttribute("rboName").equals("account3")) {
					isRboFound = true;
					break;

				}
				index++;
			}

			System.out.println("isRboFound " + isRboFound);
			System.out.println("Found index is " + index);

			Node node = doc.getElementsByTagName("NEAccountRBOImpl").item(index);
			Element element = (Element) node;

			Node node2 = element.getElementsByTagName("getPartnerName").item(0);
			Element element2 = (Element) node2;

			String actualValue = element2.getTextContent();
			System.out.println("Value : " + actualValue);

		} catch (NullPointerException e) {
			log.info("One of the Node is not found in the Excel Data");
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
