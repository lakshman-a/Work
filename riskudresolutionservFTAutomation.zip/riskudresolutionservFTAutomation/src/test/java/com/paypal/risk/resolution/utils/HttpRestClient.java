package com.paypal.risk.resolution.utils;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.paypal.risk.resolution.model.ResponseEntity;
import com.paypal.risk.resolution.report.Report;
import com.paypal.test.jaws.http.rest.PayPalRestClientFactory;
import com.paypal.test.jaws.http.rest.impl.EntityRestClient;

public class HttpRestClient {
	final static Logger log = Logger.getLogger(HttpRestClient.class);

	public ResponseEntity doGenericPost(String url, Map<String, String> headersMap, String payload) throws Exception {
		ResponseEntity response = new ResponseEntity();
		Report.info("Processing HTTP POST Call...");
		try {
			EntityRestClient<String> testClient = (EntityRestClient<String>) PayPalRestClientFactory.createEntityClient(String.class, new URL(url), MediaType.APPLICATION_JSON);
			testClient.addHeaders(headersMap);

			String responseObj;
			try {
				responseObj = testClient.simplePost(payload);
			} catch (javax.ws.rs.WebApplicationException e) {
				log.info("Response Code for the Request is not 200. So Capturing the response from Exception. Exception is - " + e);
				responseObj = e.getLocalizedMessage();
				// e.printStackTrace();
			}

			Report.info("<b>Response Details [ Code = " + testClient.getStatus().getStatusCode() + ", Status = " + testClient.getStatus().getReasonPhrase() + ", Time = " + String.valueOf(testClient.getElapsedMillis()) + " ms ]</b>");
			Report.info("<b>Response Headers : </b>" + String.valueOf(testClient.getResponseHeaders().toString()));

			response.setHeaders(String.valueOf(testClient.getResponseHeaders().toString()));
			response.setResponseTime(String.valueOf(testClient.getElapsedMillis()) + " ms");
			response.setStatusInfo(testClient.getStatus().getReasonPhrase());
			response.setStatusCode(testClient.getStatus().getStatusCode());

			if (responseObj != null)
				response.setResponse(responseObj);

		} catch (Exception e) {
			Report.fail("HTTP POST Method failed. Reason is : " + e);
			e.printStackTrace();
			throw e;
		}
		return response;
	}

	public Object doGenericGet(String url, Map<String, String> headersMap) throws Exception {
		Object responseAsObject = null;
		//Report.info("Submitting HTTP GET Request.");
		try {
			EntityRestClient<String> testClient = (EntityRestClient<String>) PayPalRestClientFactory.createEntityClient(String.class, new URL(url), MediaType.APPLICATION_JSON);
			testClient.addHeaders(headersMap);

			String response;
			try {
				response = testClient.simpleGet();
			} catch (javax.ws.rs.WebApplicationException e) {
				log.info("Response Code for the Request is not 200. So Capturing the response from Exception. Exception is - " + e);
				response = e.getLocalizedMessage();
				// e.printStackTrace();
			}

			if (response != null)
				responseAsObject = response.toString();
			else
				return null;

		} catch (Exception e) {
			Report.fail("HTTP GET Method failed. Reason is : " + e);
			e.printStackTrace();
			throw e;
		}
		return responseAsObject;
	}

	public JSONObject doPost(String url, Map<String, String> headersMap, String payload) throws Exception {
		JsonNode responseAsJsonNode = null;
		JSONObject responseAsJsonObject = null;
		Report.info("Processing HTTP POST Call...");
		try {
			EntityRestClient<String> testClient = (EntityRestClient<String>) PayPalRestClientFactory.createEntityClient(String.class, new URL(url), MediaType.APPLICATION_JSON);
			testClient.addHeaders(headersMap);

			String response;
			try {
				response = testClient.simplePost(payload);
			} catch (javax.ws.rs.WebApplicationException e) {
				log.info("Response Code for the Request is not 200. So Capturing the response from Exception. Exception is - " + e);
				response = e.getLocalizedMessage();
				// e.printStackTrace();
			}

			Report.info("<b>Response Details [ Code = " + testClient.getStatus().getStatusCode() + ", Status = " + testClient.getStatus().getReasonPhrase() + ", Time = " + String.valueOf(testClient.getElapsedMillis()) + " ms ]</b>");
			Report.info("Response Headers : " + String.valueOf(testClient.getResponseHeaders().toString()));

			// String Response to JSON Node
			ObjectMapper mapper = new ObjectMapper();
			responseAsJsonNode = mapper.readTree(response);
			responseAsJsonObject = mapper.convertValue(responseAsJsonNode, JSONObject.class);

		} catch (Exception e) {
			Report.error("Exception occured while involing the POST Request. Exception is : " + e);
			e.printStackTrace();
			throw e;
		}
		return responseAsJsonObject;
	}

	public JSONObject doGet(String url, Map<String, String> headersMap) throws Exception {
		JsonNode responseAsJsonNode = null;
		JSONObject responseAsJsonObject = null;
		try {
			EntityRestClient<String> testClient = (EntityRestClient<String>) PayPalRestClientFactory.createEntityClient(String.class, new URL(url), MediaType.APPLICATION_JSON);
			testClient.addHeaders(headersMap);

			String response;
			try {
				response = testClient.simpleGet();
			} catch (javax.ws.rs.WebApplicationException e) {
				log.info("Response Code for the Request is not 200. So Capturing the response from Exception. Exception is - " + e);
				throw e;
			}

			Report.info("<b>Response Details [ Code = " + testClient.getStatus().getStatusCode() + ", Status = " + testClient.getStatus().getReasonPhrase() + ", Time = " + String.valueOf(testClient.getElapsedMillis()) + " ms ]</b>");
			Report.info("Response Headers : " + String.valueOf(testClient.getResponseHeaders().toString()));

			// String Response to JSON Node
			ObjectMapper mapper = new ObjectMapper();
			responseAsJsonNode = mapper.readTree(response);
			responseAsJsonObject = mapper.convertValue(responseAsJsonNode, JSONObject.class);

		} catch (Exception e) {
			log.error("Exception occured while involing the GET Request. Exception is : " + e);
			e.printStackTrace();
			throw e;
		}
		return responseAsJsonObject;
	}

	public JSONArray doPostGetArray(String url, Map<String, String> headersMap, String payload) throws Exception {
		JsonNode responseAsJsonNode = null;
		JSONArray responseAsJsonObject = null;
		try {
			EntityRestClient<String> testClient = (EntityRestClient<String>) PayPalRestClientFactory.createEntityClient(String.class, new URL(url), MediaType.APPLICATION_JSON);
			testClient.addHeaders(headersMap);

			String response;
			try {
				response = testClient.simplePost(payload);
			} catch (javax.ws.rs.WebApplicationException e) {
				Report.info("Response Code for the Request is not 200. So Capturing the response from Exception. Exception is - " + e);
				response = e.getLocalizedMessage();
				// e.printStackTrace();
			}

			// String Response to JSON Node
			ObjectMapper mapper = new ObjectMapper();
			responseAsJsonNode = mapper.readTree(response);
			responseAsJsonObject = mapper.convertValue(responseAsJsonNode, JSONArray.class);

		} catch (Exception e) {
			Report.error("Exception occured while involing the POST Request. Exception is : " + e);
			e.printStackTrace();
			throw e;
		}
		return responseAsJsonObject;
	}

	public static void main(String[] args) {
		try {
			HttpRestClient obj = new HttpRestClient();
			Map<String, String> headerMap = new HashMap<String, String>();
			headerMap.put("Accept", "application/json");
			//headerMap.put("Content-Type", "application/json");

			//ObjectMapper jsonObjectMapper = new ObjectMapper();
			//JsonNode request = jsonObjectMapper.readTree(new File("src/test/resources/request.json"));

			// JSONObject response = obj.doPost("https://stage2ma152946.qa.paypal.com:11833/v1/risk/resolution-regulation-decision", headerMap, request.toString());
			Object response = obj.doGenericGet("https://riskudresolutionserv51173.qa.paypal.com:12020/log/list/applog?service=.ENV357o36h9ib5.riskudresolutionserv-app__ENV357o36h9ib5.riskudresolutionserv-app__ENV357o36h9ib5-GCE01-CLjsyrm8au-CPT4i9bf342n3h&manifest=active&package=lcmriskudresolutionserv&dirName=cronus/scripts/log/applogs", headerMap);

			System.out.println("Respons : " + response);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
