package com.paypal.risk.resolution.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.paypal.risk.resolution.report.Report;

public class ExcelUtils {

	private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
	private static XSSFCell Cell;

	public static Object[][] getTableArray(String FilePath, String SheetName) throws Exception {

		Object[][] tabArray = null;

		try {
			FileInputStream ExcelFile = new FileInputStream(FilePath);
			// Access the required test data sheet
			ExcelWBook = new XSSFWorkbook(ExcelFile);
			if (ExcelWBook.getSheetIndex(SheetName) == -1) {
				Report.fail("Given Sheet '" + SheetName + "' does not exist in the Excel '" + FilePath + "'");
				throw new Exception("Exception occured while readinf Excel sheet.");
			}
			ExcelWSheet = ExcelWBook.getSheet(SheetName);
			int totalRows = ExcelWSheet.getPhysicalNumberOfRows() - 1;
			int totalCols = ExcelWSheet.getRow(0).getLastCellNum();
			tabArray = new Object[totalRows + 1][totalCols];

			for (int i = 0; i <= totalRows; i++) {
				for (int j = 0; j < totalCols; j++) {
					tabArray[i][j] = getCellData(i, j);
				}
			}
		} catch (FileNotFoundException e) {
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}
		return (tabArray);
	}

	public static List<Map<String, String>> getTableAsListOfMaps(String FilePath, String SheetName) throws Exception {

		List<Map<String, String>> listOfHMs = new ArrayList<Map<String, String>>();
		try {
			FileInputStream ExcelFile = new FileInputStream(FilePath);
			ExcelWBook = new XSSFWorkbook(ExcelFile);

			if (ExcelWBook.getSheetIndex(SheetName) == -1) {
				Report.fail("Given Sheet '" + SheetName + "' does not exist in the Excel '" + FilePath + "'");
				throw new Exception("Exception occured while readinf Excel sheet.");
			}

			ExcelWSheet = ExcelWBook.getSheet(SheetName);
			int totalRows = ExcelWSheet.getPhysicalNumberOfRows() - 1;
			int totalCols = ExcelWSheet.getRow(0).getLastCellNum();
			for (int i = 1; i <= totalRows; i++) {
				Map<String, String> datamap = new HashMap<>();
				for (int j = 0; j < totalCols; j++) {

					datamap.put(getCellData(0, j), getCellData(i, j));
				}
				listOfHMs.add(datamap);
			}

		} catch (FileNotFoundException e) {
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}
		return listOfHMs;
	}

	public static Map<String, String> getRowAsMapUsingKey(String FilePath, String SheetName, String keyName) throws Exception {
		Map<String, String> datamap = new HashMap<>();
		try {
			FileInputStream ExcelFile = new FileInputStream(FilePath);
			ExcelWBook = new XSSFWorkbook(ExcelFile);
			if (ExcelWBook.getSheetIndex(SheetName) == -1) {
				Report.fail("Given Sheet '" + SheetName + "' does not exist in the Excel '" + FilePath + "'");
				throw new Exception("Exception occured while readinf Excel sheet.");
			}
			ExcelWSheet = ExcelWBook.getSheet(SheetName);
			int totalRows = ExcelWSheet.getPhysicalNumberOfRows() - 1;
			int totalCols = ExcelWSheet.getRow(0).getLastCellNum();

			int keyColumnIndex = -1;
			for (int j = 0; j < totalCols; j++) {
				XSSFCell cell = ExcelWSheet.getRow(0).getCell(j);
				if (cell.getStringCellValue().equalsIgnoreCase("key")) {
					keyColumnIndex = cell.getColumnIndex();
				}
			}

			for (int i = 1; i <= totalRows; i++) {
				if (getCellData(i, keyColumnIndex).equalsIgnoreCase(keyName)) {
					for (int j = 0; j < totalCols; j++) {
						datamap.put(getCellData(0, j), getCellData(i, j));
					}
				}
			}

		} catch (FileNotFoundException e) {
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}
		return datamap;
	}

	public static Object[][] getTableArrayAsMap(String FilePath, String SheetName) throws Exception {
		Object[][] obj = null;
		try {
			FileInputStream ExcelFile = new FileInputStream(FilePath);
			ExcelWBook = new XSSFWorkbook(ExcelFile);
			if (ExcelWBook.getSheetIndex(SheetName) == -1) {
				Report.fail("Given Sheet '" + SheetName + "' does not exist in the Excel '" + FilePath + "'");
				throw new Exception("Exception occured while readinf Excel sheet.");
			}
			ExcelWSheet = ExcelWBook.getSheet(SheetName);
			int totalRows = ExcelWSheet.getPhysicalNumberOfRows() - 1;
			int totalCols = ExcelWSheet.getRow(0).getLastCellNum();

			int keyColumnIndex = -1;
			for (int j = 0; j < totalCols; j++) {
				XSSFCell cell = ExcelWSheet.getRow(0).getCell(j);
				if (cell.getStringCellValue().equalsIgnoreCase("runMode")) {
					keyColumnIndex = cell.getColumnIndex();
				}
			}

			List<Integer> rowNumToExecute = new ArrayList<>();
			for (int i = 1; i <= totalRows; i++) {
				if (getCellData(i, keyColumnIndex).equalsIgnoreCase("Y") || getCellData(i, keyColumnIndex).equalsIgnoreCase("Yes")) {
					rowNumToExecute.add(i);
				}
			}

			// log.info("Rows that will be executed are : " + rowNumToExecute);
			obj = new Object[rowNumToExecute.size()][1];

			int i = 0;
			for (Integer rowNo : rowNumToExecute) {
				Map<String, Object> datamap = new HashMap<>();
				for (int j = 0; j < totalCols; j++) {

					datamap.put(getCellData(0, j), getCellData(rowNo, j));
				}
				obj[i][0] = datamap;
				i++;
			}

//			for (int i = 1; i <= totalRows; i++) {
//				//Only execute the rows with runMode Y or Yes
//				if (rowNumToExecute.contains(i)) {
//					Map<String, Object> datamap = new HashMap<>();
//					for (int j = 0; j < totalCols; j++) {
//
//						datamap.put(getCellData(0, j), getCellData(i, j));
//					}
//					obj[i - 1][0] = datamap;
//				}
//
//			}

		} catch (FileNotFoundException e) {
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}
		return obj;
	}

	public static String getCellData(int RowNum, int ColNum) throws Exception {
		String value = "";
		try {
			Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
			int dataType = Cell.getCellType();

			switch (dataType) {
			case 3:
				value = "";
				break;
			case 1:
				value = Cell.getStringCellValue();
				break;
			case 4:
				value = String.valueOf(Cell.getBooleanCellValue());
				break;
			case 0:
				value = String.valueOf(Cell.getNumericCellValue());
				;
				break;
			default:
				break;
			}

//			if (dataType == 3) {
//				return "";
//			} else {
//				String CellData = Cell.getStringCellValue();
//				return CellData;
//			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw (e);
		}
		return value;
	}

	public static void main(String[] args) throws Exception {
//		Object[][] testObjArray = ExcelUtils.getTableArrayAsMap("C:\\Project\\RRDS\\ALL_WORKSPACES\\RUDS_FT\\riskudresolutionserv\\riskudresolutionservFunctionalTests\\src\\test\\resources\\testdata\\checkpoint\\AppealEligibility.xlsx",
//				"AppealEligibility");
//		System.out.println("Returned -  rows : " + testObjArray.length + " Cols : " + testObjArray[0].length);
//		for (int i = 0; i < testObjArray.length; i++) {
//			System.out.print(testObjArray[i][0].toString() + " | ");
//		}

		Map<String, String> testObjArray = ExcelUtils.getRowAsMapUsingKey("C:\\Project\\RRDS\\ALL_WORKSPACES\\RUDS_FT\\riskudresolutionserv\\riskudresolutionservFunctionalTests\\src\\test\\resources\\testdata\\checkpoint\\AppealEligibility.xlsx",
				"PreCondition", "Appeal Count not Exceeded");
		System.out.println("testObjArray : " + testObjArray.toString());
	}

}
