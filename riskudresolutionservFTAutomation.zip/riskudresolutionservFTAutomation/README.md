# RUDS FT Automation Repository

This Repository contains JAVA sources to run/execute RBO Automation cases and RUDS API Checkpoint validation Test cases.

## RUDS Checkpoint REST API  Automation
The Purpose of this project is to automate any functional test cases related to RUDS Checkpoint/APIs which adds up to the regression suite.

Before you start the development of your own test cases, you need to understand how this archetype works and also know how to execute and report it up.

## Automation Framework

This is a Hybrid Automation framework (Parallel, Modularized and Data-Driven) which is built over Selion, JAWS APIs, Bluefin and TestNg to record, run and report any API related test cases. 

This repository has all necessary resources such as JAVA Test classes and methods, TestNg XML files to execute a test case using different data from spread sheet and report the results in a HTML file format.

## Installation

Download the repository and run maven command to install.

```bash
mvn clean install -DskipTests
```
## Write a new Test case

This project has built-in Test Classes for each available checkpoint and a common Rest template for easy recording. 

To write a New Test case (new checkpoint or any separation) kindly follow the below steps:

  * All Test Classes can be found under the Package `com.paypal.risk.resolution.checkpoints`
  * Within the same package, clone and re-use any existing test class re-naming the necessary data points and extending the base class `RUDSBaseTest`.
  * Clone and re-use any Test Data Spreadsheet available in the path `src\test\resources\testdata\checkpoint\data`.
* To Create or update any API schema, it could be found under the path `src\test\resources\testdata\checkpoint\schema`.
* Framework level configuration could be found in the file `src\main\resources\config.properties`.
* Add the Test class with Test name in the TestNg Suite XML file under the path `src\test\resources\suites\checkpoint`.
* Reports will be generated successfully under the path `test-output\ExtentReports` on following the above steps.


## Running the Test or Suites

a. To execute the suite file from cmd line:

`mvn clean test -DdefaultSuiteFiles=./src/test/resources/suites/checkpoint/small.xml -DJAWS_HOSTNAME=msmaster.qa.paypal.com -Dhostname=msmaster.qa.paypal.com -DJAWS_SSH_RESTRICTED_STAGE=true -DJAWS_SSH_COMMAND_OPTIONS=StrictHostKeyChecking=no`

b. To execute the default suite xml file

`mvn clean test -DJAWS_HOSTNAME=msmaster.qa.paypal.com -Dhostname=msmaster.qa.paypal.com -DJAWS_SSH_RESTRICTED_STAGE=true -DJAWS_SSH_COMMAND_OPTIONS=StrictHostKeyChecking=no`

c. To execute the TestNg file while using Eclipse by selecting `Run Configuration` option with following arguments

`-DJAWS_HOSTNAME=msmaster.qa.paypal.com -Dhostname=msmaster.qa.paypal.com -DJAWS_SSH_RESTRICTED_STAGE=true -DJAWS_SSH_COMMAND_OPTIONS=StrictHostKeyChecking=no`


## Test Reports
On Successful execution of the Test Suite, Report will be produced in the folder `test-output\ExtentReports` which has all necessary step-wise details on the Testcase such as:
* Testcase Name and Description
* Precondition data execution details.
* Total Testcase count, Testcase Status and time stats for each case.
* Each case has details such as API Name, URL, Request and Response Headers, Request and Response Payload, each verification points, HTTP Request time, status and code and all necessary details.

This is a Stand-alone report and can be shared to any.

