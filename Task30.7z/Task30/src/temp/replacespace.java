package temp;

import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class replacespace {

	public static void main(String[] args) {

		new File("C:\\Users\\laks3339\\Desktop\\READ\\log.txt");
		String subject = "Hello!, Check out this <^a href=\"http://www.entrepreneur.com/article/234538\">10 Movies Every Entrepreneur Needs to Watch <^/a>";
		Pattern regex = Pattern.compile("<[^<>]*>|( )");
		Matcher m = regex.matcher(subject);
		
		StringBuffer b= new StringBuffer();
		while (m.find()) {
		    if(m.group(1) != null) m.appendReplacement(b, "&nbsp;");
		    else m.appendReplacement(b, m.group(0));
		}
		
		m.appendTail(b);
		
		String replaced = b.toString();
		System.out.println(replaced);
		System.out.println("done");
		
		
	}
	
}
